# Research verification ledger

This verifies the research deliverable, not the authenticated Overleaf application.

## Independent source and coverage checks

- PASS: direct official pricing, AI and Server Pro/Community Edition pages reopened; current opened text distinguished from stale search-index wording. See observation-manifest.md and lead-supplement.md.
- PASS: sixty original angle verification handoffs present after all six first-stage runs settled.
- RECOVERED: expected raw handoff scan found projects/harvest-13.md absent. Lead reconstructed it from three directly opened primary sources and labeled its provenance. Its absence had already been disclosed by expand-13, not concealed.
- PASS: current upload documentation explicitly resolves the 180-files-per-upload limit.

## Cluster digest checks

| Cluster | Exact evidence inspected | Verdict | Residual constraints |
|---|---|---|---|
| Compilation | read(waves/compilation/slice.md), read(waves/compilation/verify-cluster-2.md) | PASS | All angles 21-30 covered with primary URL map. Package counts, hosted shell-escape policy, some entitlement matrices and PythonTeX current status remain explicitly unresolved. No runtime claims. |
| Projects | read(waves/projects/slice.md), read(waves/projects/verify-cluster-2.md) | PASS with cross-slice qualification | All angles 11-20 covered. Hosted operation details and search/sort semantics are not invented. Reviewer-as-link permission must inherit the collaboration slice's contradiction caveat; do not assert it unconditionally from F23. Missing original harvest was subsequently recovered by the lead. |
| Authoring | read(waves/authoring/slice.md), read(waves/authoring/verify-cluster-2.md) | PASS | All angles 1-10 covered. Removed AI actions, experimental Labs, Library copying, and Unicode upload-versus-edit restrictions are qualified. No arbitrary-LaTeX, accessibility-certification or assistive-technology test claim. |
| Collaboration | read(waves/collaboration/slice.md), read(waves/collaboration/verify-cluster-2.md) | PASS | All angles 31-40 covered. Named Reviewer versus link Reviewer and link-joiner visibility conflicts remain explicit. Free-owned reviewers are comment-only; project premium inheritance is not unrestricted account entitlement. |
| Integrations | read(waves/integrations/slice.md), read(waves/integrations/verify-cluster-2.md), web.run open official enterprise comparison | PASS | All angles 41-50 covered. Lead directly confirmed named third-party integrations excluded from both self-hosted editions, while Server Pro Git is included. AI/reset/managed-account and Dropbox-output documentation conflicts remain qualified. |
| Administration | read(waves/administration/slice.md), read(waves/administration/verify-cluster-2.md) | PASS | All angles 51-60 covered. Hosted/group/Commons/self-hosted scopes separated; no native-MFA, full-backup, API or delivered-metrics guarantee inferred. SAML-signature and AI policy conflicts remain explicit. |

## Final deliverable checks

PASS: all six digests were read and accepted. The final inventory contains exactly sixty numbered areas, no missing/duplicate IDs, no section without a primary-source link, and no draft markers. It contains 132 unique cited URLs across www.overleaf.com, docs.overleaf.com and github.com. The report is approximately 6,010 whitespace-delimited words including link destinations.

### Lead disposition of the synthesis audit

The independent audit passed structural coverage/citation checks but reported five specificity findings. Its initial FAIL remains preserved in synthesis-audit.md as historical evidence.

1. API specificity: the existing report already distinguished imports/CLSI from hosted automation. Clarified JSON REST, self-hostable component scope, external processing-engine/API use, and unasserted partner/private interfaces.
2. AI reset: summary already disclosed a reset conflict; added the explicit 24-hour versus up-to-72-hour statements and both source links.
3. Reviewer links: declined as an omission finding; the summary already explicitly stated the conflict and cited both sharing and Reviewer pages. Existing report section 33 gives the two opposing statements.
4. File/search limits: summary already stated the 2 MB editability exceptions; added the distinct project-search exclusion and explained why neither becomes a universal upload ceiling.
5. Backups: summary already distinguished configuration export from data backup; added the concrete operator-export metadata exclusions and consistent-backup distinction.

Lead final verdict: PASS for source-backed documentation inventory and concise summary. These prose-only edits do not require code tests. No ulw-plan reviewer gate was triggered, and no unconditional external review approval is claimed. The rendered HTML was unchanged, so its existing visual evidence remains valid.

### Inline rendering evidence

- Direct draft guard: `BUN_BE_BUN=1 omo.exe <frontend>/scripts/perfection/check-draft-guard.ts research/report.html`; exit 0, stdout `check-draft-guard: 1 file(s), clean`.
- Actual rendering: omowright owned Chrome, file URL for research/report.html, presets desktop-1440 and iphone-14, explicit light and dark color schemes.
- Desktop: viewport 1440 by 900, full document height 2291; mobile: viewport 390 by 844, document height 4396. All six feature sections present; no out-of-bounds content found.
- Lead visually inspected all four full-page PNG captures. PASS: readable, no blank sections, horizontal overflow, overlapping content or clipped source links.
- Evidence: evidence/report-desktop-light.png, evidence/report-desktop-dark.png, evidence/report-mobile-light.png, evidence/report-mobile-dark.png.
- Browser target disappeared between initial navigation and the first capture step; no screenshots were falsely recorded. Recreated the report tab and captured in one interaction; all four succeeded.
- Cleanup receipt: owned browser closed; report-browser profile removed and absence verified.

## Resource cleanup

PASS: all research and delivery runs reached terminal completion. Owned browser closed; profile and C:/Users/Admin/AppData/Local/Temp/overleaf-research-7WEy7s removed. Both directory-absence checks returned true. Direct guard and accidental wrapper process both exited 0. No server, port, repository clone or worktree was created. Durable research files and PNG evidence are retained.

## Delivery receipt

`show_html_page` accepted the already-inspected report.html and produced the thread's HTML page artifact under `.senpi/html-pages/`. Final deliverables are OVERLEAF-FUNCTIONALITY.md, summary.md, report.html, source-index.md, the research evidence and this verification ledger.

Criteria 1 and 2: PASS. Scope is publicly documented functionality with clearly disclosed contradictions and unknowns, not a guarantee of unpublished functionality or runtime acceptance.
