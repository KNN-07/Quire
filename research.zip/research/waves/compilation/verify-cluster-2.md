# Independent verification: compilation angles 21–30

Cutoff: October 26, 2026. This checks the reconciled file `expand-cluster-2.md` against its source register and original verification notes. Documentation support is not runtime verification: no account, project, or compile was used.

## Verdict: PASS — evidence-complete feature inventory, with caveats

The reconciled inventory preserves the useful documented functionality and appropriately avoids treating missing plan labels as nonavailability or implying arbitrary package compatibility. I independently opened key primary pages and sought contradictory statements. Several caveats need to remain visible: package-count docs conflict; some on-prem TeX Live image lists are stale; hosted shell-escape policy is undocumented; several controls have no explicit plan/edition matrix. These gaps limit availability/version precision, not the core feature inventory. No claim of measured functionality is supported.

## Accepted claim groups

- **Compiler/version controls and package boundary (21, 22, 27):** The current compiler page documents per-project TeX Live and engine selection. The official August 18, 2026 TeX Live announcement confirms TL2026, existing projects retaining their version, and the option to switch; it also documents concrete TL2026 incompatibilities. Sources: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler ; https://docs.overleaf.com/troubleshooting-and-support/tex-live ; https://www.overleaf.com/blog/tex-live-2026-is-now-available . Uploading missing `.sty`/`.cls` is expressly qualified “in many cases,” not a blanket guarantee: https://docs.overleaf.com/troubleshooting-and-support/tex-live/latex-packages-on-overleaf .
- **Recompile controls, diagnostics, viewer and navigation (23–25):** Current pages support manual/automatic recompile, draft mode, stop-on-first-error, logs/cache actions, error navigation, PDF viewer controls, SyncTeX and source search. The plan-limits page does not gate those controls. It documents Free 10-second and premium 240-second compile timeouts, but that is not evidence of a tier matrix for each control. Sources: https://docs.overleaf.com/getting-started/recompiling-your-project ; https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error ; https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache ; https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits .
- **Limits and self-hosted deployment (26):** Hosted timeout values are explicit. On-prem docs independently specify a default 180 seconds and configuration route. Server Pro sandboxing is optional and runs each compile in an isolated container; Community Edition has no sandbox and is for trusted users. Sources: https://docs.overleaf.com/on-premises/support/project-limits ; https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition ; https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles .
- **Build config and integrations (28–30):** Project `latexmkrc` customization and knitr integration are directly documented; Labs experiments expressly carry no stability guarantee. The on-prem troubleshooting page confirms CE disables `\write18` by default and documents an opt-in. Sources: https://docs.overleaf.com/managing-projects-and-files/the-latexmkrc-file ; https://docs.overleaf.com/integrations-and-add-ons/r-code-knitr ; https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments ; https://docs.overleaf.com/on-premises/support/troubleshooting .

## Corrections and unresolved caveats

1. **Package count conflict, angles 27 and 30:** the current parent TeX Live page says “over 5,000”; its child says “about 4000.” Both are live official pages. Do not state a precise count; inventory is unchanged. URLs above.
2. **Stale deployment defaults versus current image list, angles 22 and 27:** the sandboxed-compiles page still says the default image is TL2017.1 and its example defaults to TL2024, while the same page's available-image list now includes `texlive-full:2026.1`. Do not repeat its old default/example as current; the 2026 image is explicitly listed. This supersedes the reconciliation's implication that the page's whole image list is stale. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles . The Server Pro 6.3 release announcement is dated August 31, 2026 and also says TL2026 is available for sandboxed compiles: https://www.overleaf.com/blog/overleaf-server-pro-6-3-is-available .
3. **Shell escape, angles 28 and 30:** CE’s default is explicitly documented; Server Pro recommends sandboxing because documents can execute arbitrary shell commands. Neither establishes the exact Server Pro `\write18` default or hosted allowlist/by-tier policy. Keep these unresolved; do not generalize CE settings to hosted Overleaf.
4. **Plan/deployment availability, angles 21, 23–25, 27, 29–30:** omission of tier labels does not establish absence. Retain documented user-facing features; mark only specific unsupported matrices as unknown. Do not imply self-hosted parity or absence.
5. **No runtime testing:** all accepted statements describe vendor documentation. Compilation success, timing, package/class/font compatibility, enforcement, and live feature behavior were not measured.

Unresolved items do not change the final feature inventory. They constrain exact package counts, particular deployment defaults and entitlement matrices, and compatibility guarantees. No arbitrary LaTeX package guarantee should be added.

## Ten-angle coverage checklist

- [x] 21 — Engines and main document
- [x] 22 — TeX Live versions/upgrades
- [x] 23 — Recompile modes
- [x] 24 — PDF viewer, SyncTeX, search, layouts
- [x] 25 — Errors, logs, diagnostics
- [x] 26 — Timeouts and performance
- [x] 27 — Packages, classes, fonts
- [x] 28 — `latexmkrc`, shell escape
- [x] 29 — Bibliographies and Biber
- [x] 30 — knitr, Python, minted, plots

## EXPAND

Lead closure: **PASS for bounded inventory.** Keep the package-count discrepancy, stale image-catalog caveat, hosted shell-escape boundary, and unlisted tier/edition matrices explicit. These are availability or compatibility caveats, not grounds to remove documented ordinary compilation features. No further search is warranted for undocumented runtime behavior or exhaustive arbitrary-package guarantees.
