# Harvest 30: R knitr, PythonTeX, minted, plots, and external tools

Research date: 2026-10-26. Public Overleaf sources only; documentation statements are not independent compile tests. No authenticated tests or purchases were performed.

## R / knitr

Overleaf documents a built-in R/knitr integration for dynamic LaTeX output. The integration requires source files to use `.Rtex` or `.Rnw`; chunks use `<<...>>=` through `@`, support `echo`, inline `\Sexpr{...}`, and can emit plots. The docs specifically say `cache=TRUE` is not supported on Overleaf (though it should work locally). Plot chunks document `fig.pos`, `fig.height`, `fig.width`, `fig.cap`, and `fig:` labels. External R scripts can be imported with `read_chunk()` and labeled `## ----`; the docs say imported scripts must not be cached. These are platform-specific claims for Overleaf’s documented integration, not a guarantee that arbitrary R packages or arbitrary R workflows are installed or usable. No plan tier is stated on the integration page.

Source: https://docs.overleaf.com/integrations-and-add-ons/r-code-knitr — headings “R code (knitr),” “Chunks of code,” “Inline commands,” “Plots,” “External R scripts,” and “Reference guide.”

## PythonTeX

**Legacy status, dated:** Overleaf’s FAQ says PythonTeX “is not currently supported on Overleaf v2” owing to a security-model change. The FAQ is explicitly historical (v2 launched in 2018; account section updated Dec. 18, 2020), not a current 2026 product-status page. Search found no newer official documentation confirming that status has changed or providing a supported PythonTeX execution workflow. Therefore current Overleaf-hosted PythonTeX support is **UNRESOLVED**; do not repeat the old statement as a verified current limitation. This is distinct from displaying Python source as text (e.g. minted), and from running arbitrary Python independently to make plots.

Source: https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ — “What has Changed?” (PythonTeX bullet); legacy date context in “What happens to my premium ShareLaTeX / Overleaf Pro account?” (updated 18 Dec 2020).

## minted: display, not execution

Overleaf’s current minted article presents `\usepackage{minted}` and `minted` environments for typesetting/highlighting code, and says Overleaf works “out of the box”; it contrasts this with local LaTeX, where Pygments must be installed. This means source highlighting, not execution of the displayed Python/R program. The page makes no plan-tier distinction and does not itself describe this as arbitrary shell access. Treat the documented behavior as hosted minted support, not as evidence PythonTeX, all Pygments extensions, or user-installed executables are available.

Source: https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted — opening explanation and “Basic usage.”

## Plots and external programs

Plots can be embedded as ordinary project assets, while `pgfplots` can create plots directly from functions or data in LaTeX/TikZ. Overleaf’s `pgfplots` article documents a contour option `contour gnuplot=...` and explicitly says the external `gnuplot` software works on Overleaf; for local compilation it says install gnuplot (or use Matlab). This is a specific documented invocation, not a general promise that arbitrary external tools can be run.

Knitr plots are a separate R-generated route (see above). TikZ externalization can cache diagrams, but Overleaf requires `\tikzexternalize` in the main `.tex` file; many/complex graphics may time out during initial generation. The official timeout guide says compile limits depend on plan and calls complex TikZ/pgfplots time-consuming; it suggests downloading and compiling locally when the workload exceeds available hosted compile time. It does not establish that every package’s externalization or toolchain works on every plan.

Sources: https://cs.overleaf.com/learn/latex/Pgfplots_package — “Compilation time (brief background)” and contour-plot explanation; https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts/reducing-the-compile-time-for-diagrams — “How to externalize TikZ graphics” and “Too many complex graphics to externalize!”; https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts — opening and “Time-consuming practices and packages.”

## Shell escape and deployment boundary

Do not conflate hosted Overleaf with self-hosted deployments. Official on-premises troubleshooting says `\write18` is disabled by default in **Community Edition**, and documents enabling it via a project `latexmkrc` rule for `pdflatex --shell-escape`. That statement applies to Community Edition deployment configuration, not to hosted Free/premium plans, and the page does not make a Server Pro-specific guarantee. Hosted `minted` and the documented gnuplot example are explicit platform claims; neither authorizes inference of general shell execution. Availability of arbitrary executables, additional Python/R libraries, and equivalent behavior on Server Pro is **UNRESOLVED** in the sources examined. No Free/premium, AI, Commons, or Server Pro tier gate was documented for the cited feature examples.

Source: https://docs.overleaf.com/on-premises/support/troubleshooting — “Please verify that you have enabled system calls. For pdflatex, this is 'pdflatex -shell-escape'.”

## EXPAND

- **LEAD (current PythonTeX status):** Find a newer official hosted-platform status page or changelog; the only direct support statement found is the dated v2 FAQ, so 2026 status remains unresolved.
- **LEAD (toolchain / tier matrix):** Look for official current documentation specifying Python/R runtime packages, arbitrary executable availability, shell-escape policy on hosted plans, and Server Pro differences. Existing sources describe only specific features and Community Edition defaults; they do not establish a complete matrix.
