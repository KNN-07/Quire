# Verify angle 24: PDF viewer, SyncTeX, search, zoom, split layouts

Research date: October 26, 2026. Method: read both upstream notes (harvest-24, expand-24), then opened the primary Overleaf doc pages directly. Web search providers failed or were rate-limited in this session, so counter-checks rely on fetched primary pages, not snippets. Nothing was executed or tested; these are documented behaviors.

## Verdict: PARTIAL

Viewer, SyncTeX, search, zoom, and layout behaviors are confirmed from primary docs. Plan entitlements and Server Pro / Community Edition availability are UNRESOLVED.

## Claim table

| Claim | Source (URL and heading) | Availability | Evidence status |
|---|---|---|---|
| Two PDF viewers: Overleaf and Browser; Overleaf viewer remembers position between compiles and supports jump-to-location | docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation, "The Overleaf PDF and the Browser PDF viewers" | Viewer choice is a user setting (Settings > Editor > PDF Viewer); no plan restriction stated | CONFIRMED |
| Browser viewer: SyncTeX arrows do not work, recompile returns to page one, Overleaf nav controls unavailable | same URL, "Browser PDF viewer limitations" | Same | CONFIRMED |
| Zoom menu: zoom in/out, fit width/height, custom %, presets 50/75/100/150/200/400%, presentation mode | same URL, "The zoom-level menu" and "How to use presentation mode" | Not tier-stated | CONFIRMED |
| Shortcuts: Cmd/Ctrl with +, -, 0 (fit width), 9 (fit height); pinch and modifier+scroll zoom | same URL, "Keyboard shortcuts" table and "Other ways to navigate your PDF" | Not tier-stated | CONFIRMED |
| Presentation mode hides Overleaf UI; exit with Esc | same URL, "How to use presentation mode" | Not tier-stated | CONFIRMED |
| Compile emits output.synctex.gz; SyncTeX is line-level accurate, not character-level | docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/moving-between-the-editor-and-pdf, "SyncTeX" and "Troubleshooting and known limitations" | Not tier-stated | CONFIRMED |
| Stale output.synctex.gz and two-column layouts reduce accuracy | same URL, "The jump-to-location is not accurate" | Not tier-stated | CONFIRMED |
| "Couldn't find the corresponding source file" causes: bibliography (.bbl), main doc not top-level, leading ./ in \input/\include, spaces or special characters in filenames | same URL, "An error ... was shown" | Not tier-stated | CONFIRMED |
| Double-click PDF jumps to source in any view; arrows on the split divider in Split view; Show in PDF / Show in code in separate tab | same URL, "Using jump-to-location" and "Jump to location in a separate tab" | Not tier-stated | CONFIRMED |
| Layout menu has five options: Split view (default), Editor only, PDF only, Open PDF in separate tab, Focus mode | docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/editor-and-pdf-layout-and-sizing, "Layout options" | Not tier-stated | CONFIRMED |
| Project-wide search groups matches by file; selecting a result jumps to location; files over 2 MB excluded | docs.overleaf.com/navigating-in-the-editor/searching-within-a-project, "Project-wide search" | Not tier-stated | CONFIRMED |
| File search has match case, regex, whole word, within selection, replace and replace all; not for read-only files or files over 2 MB | same URL, "Search and replace within the current file" | Not tier-stated | CONFIRMED |
| Project search covers project files, not rendered PDF text | Absence in same URL; docs describe file search only | N/A | UNRESOLVED (not documented either way; do not claim PDF-text search) |
| PDF detach/separate-tab layout available to Free and Premium users | overleaf.com/blog/new-feature-ready-set-detach, June 15, 2022 ("All users (from free and premium plans)") | DATED LEGACY (2022) | CONFIRMED for 2022 only; current tier UNRESOLVED |
| Current Free/Premium entitlement for viewer, search, zoom, layouts | No current doc states tiers for these features | UNRESOLVED | UNRESOLVED |
| Server Pro / Community Edition support for these UI features | docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition, "Benefits for users" and admin tables | Edition comparison tables do not list viewer, search, zoom, or layout | UNRESOLVED |
| SyncTeX is a TeX-engine extension; \synctex and -synctex are TeX capabilities, not Overleaf UI | Upstream cites overleaf.com/learn MLTeX_EncTeX_and_SyncTeX article | Not tier-stated | UNRESOLVED (learn article not opened in this session) |

## Corrections to upstream

- Harvest and expand say the Overleaf viewer provides "Focus mode" in the layout menu alongside the other layouts. The layout page shows Focus mode as a fifth menu entry, so this is confirmed, but it is a layout option, not a zoom option.
- Expand calls SyncTeX "arrows navigate between source and preview" without qualification. Arrows exist only on the Split view divider; in separate-tab mode the buttons are Show in PDF / Show in code. Confirmed with that qualification.
- Expand cites a presentation mode entry in the zoom menu. The zoom menu page lists it; confirmed.

## Limitations

- No authenticated or in-app test was done; behavior is as documented.
- Doc pages are GitBook pages that may change; the 2022 blog is legacy.
- Plan tiers and on-prem edition mapping remain open.

## Counter-search queries (for a future pass)

- "Overleaf plans Free Premium PDF viewer layout features" (site:overleaf.com/plans)
- "Overleaf Server Pro Community Edition PDF preview SyncTeX"
- "Overleaf project search PDF text" (site:docs.overleaf.com)
- "Overleaf presentation mode plan"
- "SyncTeX output.synctex.gz Overleaf learn MLTeX EncTeX"

## EXPAND

- LEAD: Current Free/Premium entitlement for PDF viewer, search, zoom, and layouts. Reason: no current official doc states tiers; the only tier statement is the 2022 blog.
- LEAD: Server Pro and Community Edition support for the viewer, search, zoom, and layout controls. Reason: on-prem comparison tables do not list these features.
- LEAD: Verify the overleaf.com/learn SyncTeX article for the -synctex and \synctex command claims. Reason: not opened in this session.
