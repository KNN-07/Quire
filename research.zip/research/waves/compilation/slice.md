# Compilation functionality: angles 21-30

**Cutoff: October 26, 2026. Verdict: documentation-supported inventory PASS, with unresolved availability and policy boundaries.** Overleaf documents per-project engine and TeX Live selection, managed compilation, PDF navigation, diagnostics, bibliography builds, project-local dependencies and selected computational workflows. Hosted compile time is plan-limited; self-hosted configuration and isolation differ by edition. These findings describe official documentation, not runtime testing: no account action, project compile, performance measurement or deployment test occurred. The cluster challenge passed this bounded inventory; upstream PARTIAL findings remain visible below rather than being represented as execution passes.

## Feature matrix

Source IDs in the primary URL column resolve to explicit official URLs in the source list. Unless stated, a hosted feature's page does not establish its exact Free/Premium/Commons or self-hosted entitlement matrix. Missing tier labels do not establish feature absence.

| Feature | Behavior | Availability/limits | Primary URL |
|---|---|---|---|
| Compiler and output selection | Select pdfLaTeX (default), LaTeX, XeLaTeX or LuaLaTeX per project. Final preview is PDF; LaTeX-engine DVI can be downloaded. | Engine choice affects accepted graphics: LaTeX lists EPS/PS; pdfLaTeX PNG/JPG/PDF with an extra EPS conversion step; Xe/Lua PNG/JPG/PDF/EPS. Not unrestricted custom-binary execution. | [S1] |
| Main document | Settings selects the main `.tex`, which must contain `\documentclass`; root placement is recommended. | Files exceeding 2 MB are non-editable and cannot be selected as main. No complete entitlement matrix documented. | [S2] |
| TeX Live versions | New/copied projects default to latest installed release, TL2026 at cutoff; existing projects retain their version. Editors can reversibly change the shared project setting. | Legacy releases remain available without an announced removal date. Version pinning is not a byte-identical reproducibility guarantee. | [S3], [S4] |
| Experimental TeX Live | Labs rolling TeX Live offers a changing build. | **Experimental:** untested and unsupported by Overleaf, not the stable default. | [S3] |
| Recompile controls | Manual Recompile; optional auto compile every few seconds; Fast [draft] skips images; default error handling attempts compilation despite errors. | Exact auto-compile trigger, interval and default are not specified beyond that description. | [S5] |
| Stop on first error | Halt compilation at the first error instead of continuing through failures. | The documented mode produces no PDF on error; it does not extend compute allowance. | [S5], [S6] |
| PDF viewer and navigation | Overleaf/browser viewer choices, zoom and presentation controls; SyncTeX movement between source and PDF; five editor/PDF layouts. | Browser viewer has navigation limitations. No verified cross-edition parity matrix. | [S7], [S8], [S9] |
| Source search | Search current-file or project source. | Do not reinterpret source search as documented PDF-text search. | [S10] |
| Diagnostics and generated files | Error/warning classes, line navigation, syntax checking, full logs and generated-file access; download output such as `.bbl`. | Standard source download excludes generated files; submission ZIP can include `.bbl`. No measured diagnostic accuracy claim. | [S11], [S12] |
| Cache actions | Clear cache or recompile from scratch to rebuild auxiliary output. | Troubleshooting controls, not added server capacity. | [S13] |
| Error Assist | Suggest fix operates on full logged compile errors. | Not available for live code-check errors without the required logged error. AI availability/allowances follow current plan docs; do not revive the old standalone add-on model or claim AI Assistant for Free/ordinary Commons. | [S14], [S15] |
| Hosted timeouts/performance | Free compile timeout 10 seconds; premium 240 seconds (24 times basic). Docs suggest draft mode, first-error stopping and optimization. | No published numeric CPU/RAM allocation established. Optimizations do not increase the timeout. | [S16], [S17] |
| Self-hosted timeouts | Current docs specify default 180 seconds, configurable through `COMPILE_TIMEOUT`; existing users require database updates. | On-prem configuration, not hosted plan limits. Enforcement was not runtime-tested. | [S18], [S19], [S20] |
| Server Pro compilation isolation | Optional, recommended Sandboxed Compiles run compiles in separate restricted Docker containers; administrators select available/default TeX Live images. | Server Pro only; CE lacks sandboxing and is intended for trusted users. The available-image list includes `texlive-full:2026.1`; stale default/example text is not a current-default guarantee. Without sandboxing, Server Pro uses a limited basic TeX Live scheme. | [S21], [S22] |
| Packages and custom classes | TeX Live supplies packages; missing `.sty`/`.cls` can **in many cases** be uploaded. Root dependencies or `TEXINPUTS`/`BSTINPUTS` configuration support dependency lookup. | Compatibility depends on release, engine and dependency requirements. No arbitrary package/class guarantee or exact package count. | [S3], [S23], [S24] |
| Custom fonts | Uploaded OTF/TTF text fonts can use `fontspec` with XeLaTeX/LuaLaTeX; pdfLaTeX needs metric/map/FD resources. | The custom-font guide covers text, not all math fonts. No exhaustive supported-font inventory inferred. | [S25] |
| Build customization/plain TeX | Project `latexmkrc` sets LatexMk variables/rules and can substitute plain-TeX engine commands. System LatexMk is read first and varies by TeX Live release. | Custom build rules do not prove unrestricted executable access. | [S26], [S27] |
| Shell escape | CE documents `\write18` disabled by default and an administrator opt-in route using `latexmkrc`. Server Pro recommends isolation because documents can execute commands. | CE default cannot be generalized to hosted or Server Pro. Hosted policy/allowlist and Server Pro default remain unresolved. | [S28], [S21] |
| Bibliography builds | Create/upload `.bib`; use BibTeX or biblatex/Biber. Biblatex is recommended for new unconstrained projects; Biber is its documented default backend. Latexmk handles required BibTeX/LaTeX reruns. | BibTeX remains documented, not deprecated. No universal bibliography-style guarantee or Biber-version/deployment matrix. | [S29], [S30], [S31], [S32] |
| Citation helpers/reference imports | Simple citation-key search; advanced search and Mendeley/Zotero/ReadCube integrations. | Simple search available to all; advanced search/integrations premium, including eligible Commons/group/individual subscriptions. Manual `.bib` upload remains a fallback. | [S33], [S34] |
| R/knitr | `.Rtex`/`.Rnw` workflows supported. | `cache=TRUE` is not supported; `read_chunk` scripts are not cached. No plan matrix established. | [S35] |
| minted highlighting | Official guide documents out-of-box use without local Pygments installation or special compile commands. | Uploaded custom-lexer method is documented only for TL2022 or earlier; do not extend it to TL2026. No arbitrary Python execution implication. | [S36] |
| Plots and diagram caching | `pgfplots` guide covers 2D/3D plots; TikZ externalization reuses generated graphics. | Main-file externalization and an existing prefix folder are required; generated caches may be garbage-collected, unlike uploaded `.pdf/.md5/.dpth` assets. Package examples are not universal compatibility tests. | [S37], [S38] |
| Python Script Runner | Labs tool executes Python in-browser with Pyodide and saves generated files to the project tree. | **Experimental, opt-in:** may change/disappear; no tier/cost matrix established. Not server-side arbitrary execution and not evidence of current PythonTeX support. | [S39] |

## Ten-angle coverage map

| Angle | Inventory coverage | Principal sources |
|---|---|---|
| 21 | Engines, graphics/output, main document, plain TeX | S1, S2, S27 |
| 22 | Version selection, retained projects, TL2026, legacy/Labs | S3, S4, S20, S21 |
| 23 | Manual/auto/draft compilation, error handling/cache | S5, S6, S13 |
| 24 | PDF viewer, SyncTeX, layouts, source search | S7-S10 |
| 25 | Errors, logs, generated output, Error Assist | S11-S15 |
| 26 | Hosted limits, optimization, on-prem timeout/isolation | S16-S22, S38 |
| 27 | Packages, classes, font uploads, version compatibility | S3, S4, S23-S25 |
| 28 | `latexmkrc`, system config, shell-escape boundary | S21, S26-S28 |
| 29 | `.bib`, BibTeX/biblatex/Biber, citation/import assistance | S12, S29-S34 |
| 30 | knitr, minted, plots/externalization, Python experiments | S35-S39 |

## Resolved contradictions and corrections

- **Deployment image freshness:** S21 combines stale TL2017 default prose and a TL2024 example with a live list containing TL2026.1. The challenge correction supersedes the claim that the entire image list is stale. Report TL2026 availability, not an inferred deployment default. This reduction reopened the full live page and confirmed that distinction.
- **Release versus announcement:** Server Pro 6.3.0 release notes give August 28, 2026; the release announcement is August 31. They date different events, not conflicting releases. TL2026's hosted announcement is August 18 (S4); the AI plan announcement is July 2 (S15).
- **Legacy timeout issue:** a 2024 CE non-enforcement report is not current product policy. Current on-prem limits/configuration and 6.x release notes document timeout handling (S18-S20); enforcement remains untested here.
- **minted versus shell escape:** out-of-box minted support is package-specific evidence, not a hosted command allowlist. Its TL2022-or-earlier custom-lexer recipe must not become a TL2026 claim (S36).
- **AI freshness:** current plan bundling supersedes stale standalone AI Assist snippets. Plan-dependent allowances do not establish that every AI tool is available for every file type (S14-S15; lead supplement).
- **Scope correction:** general font catalogues and LaTeX tutorials are not bundled-font or arbitrary package guarantees. TL2026 documents actual incompatibilities, including `tabu`/`tabls` failures (S4).

## Unresolved annex

1. **Live package-count disagreement:** S3 says over 5,000; S23 says about 4,000. Neither exact figure is adopted.
2. **Hosted shell escape:** current state, command allowlist, change controls and plan policy not established; Server Pro `\write18` default also unknown (S21, S28). Do not fill gaps using engine help flags, old Markdown examples or community workarounds.
3. **Entitlement/parity:** exact per-control hosted tier/Commons and CE/Server Pro matrices remain unverified for engine/main-document selection, compile/viewer/diagnostic controls, dependency uploads, bibliography builds and computational integrations. Unknown is not unavailable.
4. **Operational precision:** exact auto-compile trigger/default, CPU/RAM allocations, arbitrary binary access and exhaustive Biber/TeX Live/package/font version matrices are not established. Compilation success and timing were not measured.
5. **PythonTeX:** older v2 statements are historical, not a decisive current hosted support ruling. Browser Labs Python does not resolve that status.
6. **Deployment defaults:** S21's old default/example and current image list coexist. Actual configured instance default is not inferred. Self-hosted reference-manager support and tool-specific AI `.bib` check entitlement also remain unasserted.

No verification FAIL survives the cluster challenge. Its PASS is for a bounded, caveated documentation inventory, not for runtime behavior or completeness of unpublished policies. Some upstream notes carry October 27 read dates; no post-cutoff release or behavior is asserted from those dates.

## Bounded source list for final report author

All sources are official Overleaf documentation, Learn material or announcements. The matrix and coverage map identify which claims each supports. The reduction used the verified source register and original notes; it directly reopened S21. A narrow indexed search returned no S21 result, so only the opened live page, not a search snippet, supports the image correction.

[S1]: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler
[S2]: https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document
[S3]: https://docs.overleaf.com/troubleshooting-and-support/tex-live
[S4]: https://www.overleaf.com/blog/tex-live-2026-is-now-available
[S5]: https://docs.overleaf.com/getting-started/recompiling-your-project
[S6]: https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error
[S7]: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation
[S8]: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/moving-between-the-editor-and-pdf
[S9]: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/editor-and-pdf-layout-and-sizing
[S10]: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project
[S11]: https://docs.overleaf.com/troubleshooting-and-support/fixing-latex-errors
[S12]: https://docs.overleaf.com/navigating-in-the-editor/generated-files
[S13]: https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache
[S14]: https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist
[S15]: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
[S16]: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits
[S17]: https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts
[S18]: https://docs.overleaf.com/on-premises/support/project-limits
[S19]: https://docs.overleaf.com/on-premises/user-and-project-management/project-management
[S20]: https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x
[S21]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles
[S22]: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
[S23]: https://docs.overleaf.com/troubleshooting-and-support/tex-live/latex-packages-on-overleaf
[S24]: https://docs.overleaf.com/managing-projects-and-files/adding-latex-dependencies
[S25]: https://www.overleaf.com/learn/latex/Questions/I_have_a_custom_font_I%27d_like_to_load_to_my_document._How_can_I_do_this%3F
[S26]: https://docs.overleaf.com/managing-projects-and-files/the-latexmkrc-file
[S27]: https://www.overleaf.com/learn/latex/Questions/Can_I_run_plain_TeX_on_Overleaf%3F
[S28]: https://docs.overleaf.com/on-premises/support/troubleshooting
[S29]: https://docs.overleaf.com/citing-and-references/creating-a-bibliography
[S30]: https://docs.overleaf.com/citing-and-references/working-with-.bib-files
[S31]: https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX
[S32]: https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex
[S33]: https://docs.overleaf.com/citing-and-references/adding-citations-and-references
[S34]: https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations
[S35]: https://docs.overleaf.com/integrations-and-add-ons/r-code-knitr
[S36]: https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted
[S37]: https://www.overleaf.com/learn/latex/Pgfplots_package
[S38]: https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts/reducing-the-compile-time-for-diagrams
[S39]: https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments

Additional date source: https://www.overleaf.com/blog/overleaf-server-pro-6-3-is-available
