# Expand 30: R knitr, PythonTeX, minted, plots, and external tools

Research date: 2026-10-26 (report written 2026-10-27). Public sources only; no authenticated tests, no purchases. Documentation statements are not compile tests. Tier labels are given only where the cited page states one.

## Verified findings

**1. R / knitr (hosted, documented)**
- Source: https://docs.overleaf.com/integrations-and-add-ons/r-code-knitr, headings "R code (knitr)", "Chunks of code", "Inline commands", "Plots", "External R scripts", "Reference guide".
- Files must be `.Rtex` or `.Rnw`; chunks use `<<...>>=` to `@`; inline output uses `\Sexpr{...}`.
- The page states `cache=TRUE` is "not currently supported in Overleaf, but it should work locally."
- Plot chunks document `fig.pos`, `fig.height`, `fig.width`, `fig.cap`, and a `fig:`-prefixed label.
- `read_chunk()` imports `## ----` labelled scripts; the page says imported scripts must not be cached.
- Tier: none stated on this page. Installed R packages and arbitrary R workflows are not documented, so they are UNRESOLVED.

**2. PythonTeX (legacy, dated; current status UNRESOLVED)**
- Source: https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ, section "What has Changed with Overleaf v2?". The FAQ says the pythontex package "is not currently supported on Overleaf v2" because of a security-model change, and that the team "will investigate whether we can bring it back."
- Date tag: the FAQ predates 2026; it describes the v2 launch era. I found no newer official page confirming or reversing this.
- A Tex.SE question on the same topic (https://tex.stackexchange.com/questions/534049/pythontex-not-working-on-current-overleaf-compiler) returned an empty page on retrieval, so it is not cited.
- Conclusion: do not present "PythonTeX unsupported" as current 2026 fact. Mark current hosted PythonTeX support UNRESOLVED.

**3. minted (display only, documented)**
- Source: https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted, opening section and "Basic usage". The page says Pygments must be installed for local LaTeX, and that minted documents "work 'out of the box'" on Overleaf.
- The page covers highlighting and typesetting. It does not describe execution of the displayed code.
- Legacy note, date-tagged: the "Custom lexers" section says that, because of minted changes since 2023, the custom-lexer approach "will only work in TeX Live 2022 or earlier." Treat custom `.py` lexer loading as UNRESOLVED on current TeX Live.
- Harvest claim verified; no tier stated. The Labs page https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments also lists a "Rolling TeX Live releases" experiment (monthly builds, untested by the team), so the TeX Live version selected affects which minted behaviour applies.

**4. Python Script Runner (Labs experiment; omitted from the harvest)**
- Source: https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments, section "Python Script Runner".
- It runs Python from a `.py` file in the project, writes output files (figures, CSVs) back to the file tree, and makes them usable via `\includegraphics`.
- It runs in the browser on Pyodide 0.29.3 (Python 3.13.2). Packages must be in the Pyodide distribution; packages needing native code outside it cannot be installed.
- Re-verified on the live-experiments page: figures saved by the script appear in the file tree and can be used with `\includegraphics`; a Run/Stop control and an output panel show stdout and errors.
- Known limits on the page: browser resources only, so large scripts may be slow or freeze the tab.
- Labs status: opt-in, "provided as-is, without any guarantee of stability" (https://docs.overleaf.com/accounts-and-security/overleaf-labs). Plan availability is UNRESOLVED: the live-experiments page states no tier, and https://www.overleaf.com/labs/participate returned only a login form on retrieval.
- This is the only Python-execution path I found in the hosted product. It does not run R, does not run arbitrary shell commands, and does not replace PythonTeX.

**5. Plots: pgfplots and gnuplot**
- Source: https://www.overleaf.com/learn/latex/Pgfplots_package, sections "Contour plots" and "Compilation time".
- The page says `contour gnuplot={...}` "works fine in Overleaf"; for local use, gnuplot must be installed (or matlab substituted).
- Pgfplots can externalize figures with `\usepgfplotslibrary{external}` and `\tikzexternalize`.
- Harvest claim verified. Other external programs beyond this documented gnuplot call are UNRESOLVED.

**6. TikZ externalization and timeouts**
- Source: https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts/reducing-the-compile-time-for-diagrams, "How to externalize TikZ graphics" and "Too many complex graphics to externalize!".
- `\tikzexternalize` must appear in the main `.tex` file. Generated files are hidden from the file list; uploaded `.pdf`, `.md5`, and `.dpth` files are never garbage-collected.
- The page recommends local generation for heavy workloads.
- The v2 FAQ states the longest compile timeout on Overleaf v2 is 5 minutes (date-tagged to the v2 era; current limit not re-verified).

**7. Shell escape and self-hosting (deployment boundary)**
- Source: https://docs.overleaf.com/on-premises/support/troubleshooting, last section. It says `\write18` is disabled by default in the Community Edition; enabling it for pdflatex uses a `latexmkrc` containing `$pdflatex = 'pdflatex --shell-escape';`.
- This applies to Community Edition configuration only. The page makes no Server Pro guarantee. Hosted shell-escape policy is UNRESOLVED.

## Duplicates and closed items
- Harvest's PythonTeX, minted, knitr, pgfplots/gnuplot, and TikZ externalization claims: all verified against the pages above; no duplicates found within this angle.
- Search-result snippets (Stack Exchange, example PDFs, templates) were not used as primary evidence.

## Limitations
- Not tested by compilation; all statements are documentation claims.
- Hosted tier availability is unstated on the knitr, minted, and pgfplots pages.
- No Server Pro or Community Edition statement exists for knitr, PythonTeX, or minted in the pages read.
- The AI-bundling question (July 2, 2026 blog vs. older separate AI Assist docs) is outside this angle and was not investigated.

## EXPAND

- **LEAD (current PythonTeX hosted status):** UNRESOLVED. Only the dated v2 FAQ states it is unsupported. Needs a newer official status page or changelog.
- **LEAD (hosted shell-escape and arbitrary executables/Python-R packages, by tier):** UNRESOLVED. No official current matrix found; the only shell-escape statement covers Community Edition.
- **LEAD (Python Script Runner plan availability and Labs participation terms):** UNRESOLVED. live-experiments page read; the participate page returned only a login form.
- **LEAD (current minted custom-lexer support on TeX Live beyond 2022):** UNRESOLVED; the official page limits the documented method to TeX Live 2022 or earlier.
- **Closed:** knitr chunk/plot/external-script claims; minted highlighting claims; pgfplots gnuplot claim; TikZ externalization claims. Each is verified against a primary Overleaf page listed above.
