# Verify 23: Automatic/manual recompilation and compile modes

Date: 2026-10-26. Method: read harvest-23.md and expand-23.md, then opened the primary Overleaf pages they cite (docs.overleaf.com, .md variants). Documentation review only; no authenticated or functional compile test was run.

**Verdict: PARTIAL.** The core recompile, auto-compile, Fast [draft], error-mode, and cache-action claims are confirmed by primary docs. Plan/edition availability, the exact auto-compile interval and trigger, and the default state remain UNRESOLVED. One harvest claim (user-level latexmkrc custom rules) is not supported by the pages I opened and is dropped.

## Claim table

| Claim | Source (heading) | Availability | Evidence status |
|---|---|---|---|
| Recompile button runs a compile to PDF; errors go to logs | https://docs.overleaf.com/getting-started/recompiling-your-project (Compiling) | Not tiered in doc | CONFIRMED |
| Auto compile, when on, recompiles "every few seconds" | same (Compile options > Auto compile) | Not tiered in doc | CONFIRMED; interval, trigger, default: UNRESOLVED |
| Fast [draft] skips image processing; images become empty boxes; faster | same (Compile mode) | Not tiered | CONFIRMED |
| Fast [draft] is a timeout diagnostic for image cost | https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts (Step 2) | Not tiered | CONFIRMED as diagnostic, not guarantee |
| Syntax checks run as you type, separate from compiling | recompiling-your-project (Syntax checks) | Not tiered | CONFIRMED |
| Default mode is "Try to compile despite errors"; output may be wrong or may fail | https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error (Compilation modes on Overleaf) | Not tiered | CONFIRMED |
| Stop on first error halts at first error and produces no PDF for that run | stop-on-first-error (Debugging with Stop on First Error; recompiling-your-project, Compile error handling) | Not tiered | CONFIRMED |
| Stop on first error is per user, per project | stop-on-first-error (How to enable Stop on first error, info hint) | Not tiered | CONFIRMED |
| "Suspend compilation to interact" exists in local TeX but is impractical on Overleaf | stop-on-first-error (Handling errors: compilation modes) | Not selectable on Overleaf | CONFIRMED (not an Overleaf mode) |
| Overleaf uses latexmk as build tool | stop-on-first-error (Compilation modes on Overleaf); timeout guide Step 1 | Not tiered | CONFIRMED as described |
| Recompile from scratch deletes generated files and recompiles immediately | https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache (Recompile from scratch) | Not tiered | CONFIRMED |
| Clear cached files deletes generated files without recompiling | same (Clear cached files) | Not tiered | CONFIRMED |
| Cache is per user; holds .aux/.log/.toc | same (intro) | Not tiered | CONFIRMED |
| User-level latexmkrc may add custom rules | none of the pages opened | n/a | UNSUPPORTED; dropped |
| Auto compile added in Server Pro 1.0.2 | https://docs.overleaf.com/on-premises/release-notes/release-notes-1.x.x (Server Pro 1.0.2) | Server Pro, historical | HISTORICAL CONFIRMED; current parity UNRESOLVED |
| Stop on First Error added in Server Pro 3.3.0 (2022-10-13); CE image ID listed in same entry | https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x (Server Pro 3.3.0) | Server Pro; CE listed as image only | HISTORICAL CONFIRMED; current parity UNRESOLVED |
| Pause auto-preview toggle in writeLaTeX (2013) | https://www.overleaf.com/blog/74-new-feature-toggle-between-auto-compile-and-manual-compile-modes-in-writelatex (Sept 16, 2013) | Legacy writeLaTeX, 2013 | HISTORICAL, legacy |
| Timeouts differ by plan; paid plans give more compile time | timeout guide (intro, Fair use limits) | Plan-based limit | CONFIRMED for time limits; does not show compile modes are plan-gated |
| Compile modes available on Free / Premium / Commons / Server Pro / CE | none found | Unknown | UNRESOLVED |
| Old how-to URLs redirect to current guide | not re-opened in this pass | n/a | UNVERIFIED (carried from expand) |
| cs.overleaf.com help article describes Auto Compile toggle | not opened | n/a | UNVERIFIED legacy (from harvest) |

## Corrections to upstream files

- Harvest's "user-level latexmkrc" sentence is removed (unsupported).
- Harvest's "speed mode" framing is a label choice; the docs call it "Compile mode." Behavior is as described.
- Harvest's auto-compile toggle source is a legacy cs.overleaf.com page I did not open. The current guide's "Auto compile" entry is the source used here.
- No AI, Commons, or AI Assist claims apply to this angle. The July 2, 2026 AI-bundling change was not checked and is not combined with these controls.

## Limits

- No default state, interval, or save-trigger contract is published; do not infer them.
- No plan or edition matrix exists for these controls in the pages reviewed.
- On-premises entries are dated history, not current parity. The 3.x release notes I read end at 3.5.13 (2023-10-06).
- Nothing here confirms how Overleaf behaves at runtime.

## Counter-search queries

Run: "Overleaf automatic compilation manual compile mode docs" (returned Overleaf learn/blog results; no new primary docs beyond those above). "Overleaf compile timeout draft mode auto compile docs.overleaf.com" (no results from providers).

Next: "Overleaf auto compile interval seconds", "Overleaf plan limits compile timeout free premium", "Overleaf Server Pro auto-compile Community Edition current release", "overleaf.com learn How_do_I_compile_my_TeX_file redirect".

## EXPAND

- LEAD: exact auto-compile trigger, interval, and default state. UNRESOLVED; docs say only "every few seconds."
- LEAD: plan/edition availability of Stop on first error, Fast [draft], cache actions, and auto compile on Free, Premium, Commons, Server Pro, and CE. UNRESOLVED; check plan-limits page linked from the timeout guide and current on-premises release notes past 2023.
- LEAD: verify the legacy redirect claims and the cs.overleaf.com auto-compile article, only if the parent needs legacy URLs cited. Low priority.
