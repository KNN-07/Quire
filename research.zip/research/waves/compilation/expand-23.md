# Expansion 23: Automatic/manual recompilation and compile modes

Research date: October 26, 2026. Public official sources only. This is documentation research, not an execution test.

## Recompilation controls

The current [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project), headings “Compiling” and “Auto compile,” says clicking **Recompile** starts a LaTeX compile producing a PDF; errors appear in logs. The **Auto compile** option, when on, automatically recompiles “every few seconds.” The docs do not specify an interval, debounce, exact edits/events watched, default enabled state, or interaction with saves. Thus manual compilation is explicitly available; auto compilation is an optional toggle. These details remain **UNRESOLVED** beyond the stated behavior. The old [How do I compile my TeX file?](https://www.overleaf.com/learn/how-to/How_do_I_compile_my_tex_file%3F) article redirects to the current guide, so it supplies no independent legacy guarantee.

The same current guide, heading “Compile options,” identifies additional controls:

- **Fast [draft]** skips image-file processing and substitutes empty boxes for images; it is a faster, incomplete preview mode, not a full-fidelity PDF. **Normal** is identified by the timeout guide as the comparison mode. [Fixing and preventing compile timeouts](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), “Step 2: Try compiling in Fast [draft] mode,” suggests it as a way to diagnose image-processing delays. If draft succeeds but Normal times out, the cause may be large or numerous images; this is a diagnostic, not a guarantee.
- **Syntax Checks** are described separately from compilation: Overleaf checks common issues as the user types (current recompilation guide, heading “Syntax checks”). These checks are not evidence that a PDF compile has happened.
- **Recompile from scratch** removes temporary generated helper files and immediately recompiles, as described under that heading and in [Clearing the project cache](https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache), heading “Recompile from scratch.” **Clear cached files** deletes generated files without immediately recompiling (same cache page, heading “Clear cached files”). Cache files are user-specific and may include `.aux`, `.log`, and `.toc` files (cache page, opening paragraphs).

## Error handling and build behavior

The default is **Try to compile despite errors**: the compiler attempts to produce a PDF despite errors; the output may be wrong, and serious or numerous errors may still prevent a PDF. **Stop on first error** stops at the first error and does not generate a PDF for that failed run. Sources: [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project), heading “Compile error handling”; [Stop on first error](https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error), headings “The Stop on first error compilation mode” and “Compilation modes on Overleaf.” Stop-on-first-error is explicitly a **per-user, per-project** setting; it does not change collaborators’ setting (same page, “How to enable Stop on first error”). Overleaf lists “Suspend compilation to interact with the user” as a local-installation possibility but impractical on Overleaf (“Handling errors: compilation modes”); it is not a selectable Overleaf mode.

Current docs say Overleaf uses `latexmk` to manage the compile process (Stop on first error, “Compilation modes on Overleaf”; timeout guide, “Step 1”). They do not promise support for arbitrary user-defined build pipelines or external programs. Treat `latexmk`/ordinary LaTeX behavior as implementation context, not an unrestricted platform feature guarantee.

## Availability, history, and limits

Current online documentation describes these controls without assigning them Free, premium, AI, Commons, Server Pro, or Community Edition availability. Current parity is therefore **UNRESOLVED**. A historical on-premises record says Stop on First Error was added in **Server Pro 3.3.0, released October 13, 2022**; its Community Edition image is also listed. Source: [Release notes 3.x.x](https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x), “Server Pro 3.3.0.” This dated note establishes historical release information only, not current edition parity. A separate older note says auto-compile was introduced in Server Pro 1.0.2; source: [Release notes 1.x.x](https://docs.overleaf.com/on-premises/release-notes/release-notes-1.x.x), “Server Pro 1.0.2.” This also does not establish present-day parity.

Timeout limits vary by Overleaf plan: the timeout guide says the free plan covers many projects, while complex projects may need premium extended compile time (“Fair use limits”). This is a limit distinction, not evidence that the compile-mode controls themselves are premium. No plan matrix was found for these controls. No AI or AI Assist behavior is implicated; the July 2, 2026 AI-bundling change is not relevant to recompilation controls, so older AI-plan descriptions are not combined here.

LaTeX image draft behavior and error recovery are compiler/build concepts; the specific dropdown labels, automation control, cache actions, and per-user setting are Overleaf product behavior. No claim is made about execution, compile concurrency, API automation, or precise automatic-compilation timing.

## EXPAND

- **LEAD: exact auto-compile trigger, default, and interval — UNRESOLVED.** Current docs only say the enabled feature compiles every few seconds; no more precise contract is published.
- **LEAD: current plan/deployment availability matrix — UNRESOLVED.** Current docs provide no labels; historical Server Pro/Community Edition release notes do not establish current parity. No other controls were found to add to this matrix.
- **Deprecation / omissions:** The legacy compilation/how-to URL redirects to the current guide; no separate current auto/manual recompilation feature or deprecation announcement was located. The old `latexmk` article also redirects, so custom-rule details from it are not treated as current guarantees.
- **Duplicate closure:** Harvest findings on Stop on first error, Fast [draft], cache clearing, `latexmk`, plan-specific timeout, and unknown current availability are corroborated above; they are consolidated rather than duplicated. The added Syntax Checks and dated Server Pro auto-compile history are contextual, not new promises.
