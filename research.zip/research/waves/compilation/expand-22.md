# Expand 22: TeX Live versions, upgrades, and reproducibility

Checked 2026-10-26. Claims below come from primary Overleaf pages opened in this session unless marked "snippet-only" or "UNRESOLVED". Documented configuration only; no authenticated or functional tests were run.

## Platform features (Overleaf-specific)

**Hosted version selection**
- New and copied projects default to the latest TeX Live on Overleaf's servers; existing projects are not auto-upgraded. Source: https://docs.overleaf.com/troubleshooting-and-support/tex-live, heading "TeX Live and your Overleaf project."
- The version is set per project under Settings, then Compiler, then the TeX Live version dropdown. Source: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler, heading "How do I change a project's TeX Live version?"
- Any collaborator with Editor permission can change it, and the change affects all collaborators. Switching is reversible. Source: same troubleshooting page, bullet list in "TeX Live and your Overleaf project."
- Overleaf does not document a Free/Premium tier restriction on this control. Tier availability: UNRESOLVED.

**Legacy releases (undated, current as of fetch)**
- Older releases appear as "Legacy." Overleaf has set no discontinuation timeline, but older versions "may eventually be phased out." Source: troubleshooting page, heading "What are the 'Legacy' versions of TeX Live?"

**Labs rolling build (opt-in, untested)**
- Labs offers a rolling TeX Live that changes monthly. Overleaf states it is not tested by its team, is unsupported, and may require switching back to an annual release. Source: troubleshooting page, heading "Labs Rolling TeX Live Experiment." Labs is not a reproducible pin.

**2026 release**
- TeX Live 2026 is available and is the latest release in the fetched pages. Source: https://www.overleaf.com/blog/tex-live-2026-is-now-available. The harvest gives an August 18, 2026 announcement date, but the fetched body shows no date. Date: UNRESOLVED from primary body.

**Self-hosted (Community Edition, Server Pro)**
- Community Edition ships a minimal TeX Live. Admins can run `tlmgr install scheme-full` in the container. Changes are ephemeral unless committed with `docker commit`, and must be repeated on each upgrade. Older TeX Live may need a historic repository. Source: https://github.com/overleaf/toolkit/blob/master/doc/ce-upgrading-texlive.md, sections "Installing packages" and "Saving your changes." Instructions are documented as CE-only.
- Server Pro is recommended to use Sandboxed Compiles, which pulls the same images as overleaf.com. Source: https://docs.overleaf.com/on-premises/installation/upgrading-tex-live, opening warning.
- The 2026 blog states that Server Pro admins point `TEX_LIVE_DOCKER_IMAGE` and `ALL_TEX_LIVE_DOCKER_IMAGES` at the 2026 image, with no other upgrade. Source: the 2026 blog, heading "TeX Live 2026 in Server Pro."
- The CLSI README documents `TEXLIVE_IMAGE` (example `texlive-full:2026.1`) and `ALLOWED_IMAGES` for sibling-container compiles. Source: https://github.com/overleaf/overleaf/blob/main/services/clsi/README.md, environment variable list. This documents configuration only; it does not guarantee registry retention.

## Arbitrary LaTeX/TeX Live facts (not Overleaf features)

These are documented changes in the TeX Live 2026 distribution, as reported by Overleaf's 2026 blog (https://www.overleaf.com/blog/tex-live-2026-is-now-available, headings "Common packages affected by TeX Live 2026" and "Other things to be aware of"). Each item is a deprecation or breaking change unless noted.

- `tabu` and `tabls` are unsupported in TL2026 and produce compile errors.
- `frenchb` and `francais` babel options are obsolete; use `french`.
- Source Pro and New Computer Modern font names changed (for example Source Sans 3, NewComputerModern).
- `enumerate`, `theorem`, and `verbatim` are legacy; use enumitem, amsthm, and fancyvrb.
- `\DocumentMetadata` may be called only once.
- Accessible MathML tagging requires LuaLaTeX.
- `\DocumentMetadata` defaults to PDF 2.0. Set `pdfversion=1.7` to target older workflows.
- Known package conflicts (varioref with KOMA classes, thmtools sibling counters, polyglossia with array) are listed with workarounds in the same blog.

## Reproducibility: what the docs do and do not say

- Documented: pinning a project to one release fixes the package versions in that release. Source: troubleshooting page, bullet "After choosing a specific version."
- Documented: releases can change package behavior, so switching may alter output or cause errors. Source: same page.
- Not documented in fetched pages: byte-identical PDFs, indefinite retention of old releases, or full locking of fonts, Docker images, or external inputs. Reproducibility guarantee: UNRESOLVED.

## Excluded or not verified

- Harvest's 2019 upgrade account (~5,000 gallery documents tested): not reopened. Legacy, date-tagged 2019; excluded from claims.
- Server Pro 6.3 date (August 28, 2026) and image IDs: snippet-only from search results, not opened. UNRESOLVED.
- arXiv default TeX Live (2025, with 2023 also offered): snippet-only from docs.overleaf.com checklist page. UNRESOLVED.
- Offline compile guidance (tex.stackexchange, latexmkrc docs): snippet-only, not opened. Not used.
- AI bundling (July 2, 2026): outside this angle; not investigated.
- Commons availability: not stated in the pages opened. UNRESOLVED.

## EXPAND

- Harvest listed no open leads. Its cited sources matched the pages opened here.
- Open items, UNRESOLVED for stated reasons: 2026 announcement date (body missing the date); Server Pro 6.3 release date and image IDs (snippet-only); arXiv TeX Live default (snippet-only); tier and Commons availability (not stated); offline reproducibility guidance (not opened).
