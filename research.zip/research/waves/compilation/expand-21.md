# Expand 21: Compiler engines and main document selection

Checked October 27, 2026 against official Overleaf docs and Overleaf Learn pages. Page dates are not shown on these pages; "current" means the text as fetched on that date. Platform features are kept separate from general LaTeX capabilities.

## Platform features (documented)

**Compiler engine selection.** The "Selecting a TeX Live version and LaTeX compiler" page says the compiler can be changed when a project needs a different engine from the default pdfLaTeX. It names pdfLaTeX as "the default and most frequently used LaTeX compiler." Source: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler (heading "Changing the compiler"; "Why change compilers?").

**Engine format notes (platform guidance, not package guarantees).** The same page says pdfLaTeX may not handle pstricks well on Overleaf. It says XeLaTeX and LuaLaTeX "both support UTF-8 robustly, as well as Truetype and OpenType fonts," and recommends them with `polyglossia` for non-Latin scripts. Source: same URL. The harvest's EPS/PNG/PDF handling per engine was not re-read on this pass beyond the EPS lines the page mentions; treat the detailed per-engine image table as UNRESOLVED until re-checked.

**TeX Live version per project.** The page says the TeX Live setting is "specific to each project and does not affect any other projects." It recommends the most recent version "in most cases" and states "Legacy versions are not recommended for new projects." Source: same URL, heading "How do I change a project's TeX Live version?" The dropdown contents are not listed in the text.

**Main document.** Source: https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document. The page says a `.tex` file "larger than 2 MB" is "categorized as non-editable" and "you won't be able to set such a file as your project's Main document." It also says the Main document can become "None" after restoring an older version through History or converting a non-.tex file, so the setting should be checked after those actions.

**Compile time by plan.** Source: https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts. The page says many projects fit the free plan's time, but "if you're preparing a large or complex document, you may need to subscribe to a premium plan to get more compile time." This is a timeout entitlement, not an engine entitlement. Plan-tier note: **Premium** (time limit only). The premium overview at https://docs.overleaf.com/getting-started/free-and-premium-plans lists "longer compile time" among premium features.

**Plain TeX via latexmkrc (undated Learn article, fetched 2026-10-27).** Source: https://www.overleaf.com/learn/latex/Questions/Can_I_run_plain_TeX_on_Overleaf%3F. Under the LaTeX compiler setting, a `latexmkrc` file with `$latex = 'tex %O %S';` runs plain TeX. The article also lists commented alternatives for pdftex, luatex, and xetex. It describes latexmk as Overleaf's typesetting control program. Plan-tier note: none stated.

## Main document: placement and multi-file behaviour

Source: the Main document page, headings "Best Practices" and "Troubleshooting." Overleaf recommends keeping the main file at project root. A main file in a subfolder can disrupt compilation and features such as jump-to-location, word count, and `makeglossaries`. A same-named root file can be compiled instead of the selected file, which Overleaf attributes to how latexmk runs; unique filenames are recommended. The documented workaround is a root `main.tex` proxy using `\RequirePackage{import}` and `\import{paper/}{manuscript.tex}`.

A project `.tex` file with `\documentclass` can be compiled from the editor without changing the configured main file. The docs describe the Main document as the default entry point, not a prohibition on compiling other eligible files.

## Plan and edition availability

- **Free/premium:** The compiler and main-document pages carry no plan qualifier. Only compile-time limits are tier-specific (above).
- **Server Pro and Community Edition:** The on-premises landing page at https://docs.overleaf.com/on-premises/ says Community Edition "is intended for use in environments where all users are trusted" and is "not appropriate for scenarios where isolation of users is required due to Sandbox Compiles not being available." This is an isolation boundary, not a statement about engine choice. Server Pro vs. Community Edition TeX Live configuration was not retrieved (the TeX Live subpage was listed in navigation but not opened); UNRESOLVED.
- **Commons, AI:** No compiler or main-document docs found that state Commons or AI bundling for these controls. Overleaf's July 2, 2026 AI-bundling blog was not relevant to these settings and was not used. No conflicting AI Assist claim was found in these pages.

## Deprecation and legacy

- **TeX Live legacy versions:** Date-tag as current docs, October 2026. Overleaf says they are "not recommended for new projects." No removal date was found in these pages. Date-tag any future removal as UNRESOLVED.
- **acro package v3 (current docs, Troubleshooting):** The compile-timeout page says acro v3 can be slow, and suggests reverting to v2 as a workaround. This is a package issue, not a platform deprecation of engines.

## Limits

- Choosing an engine does not establish support for arbitrary TeX engines, custom binaries, or every package. The pages describe engine characteristics and recommend settings; they do not guarantee that a given document compiles.
- I did not run any Overleaf project, did not use an authenticated account, and did not verify compile results.

## EXPAND

- **LEAD: current TeX Live version menu and exact legacy-version availability.** UNRESOLVED. The docs describe the control and say legacy versions are discouraged, but do not list choices or removal dates.
- **LEAD: plan/edition matrix for compiler and main-document controls (including Commons, Server Pro, Community Edition).** UNRESOLVED for Commons and Server Pro configuration. Free/premium: compile time is tier-specific; engine and main-document controls carry no documented tier restriction. Do not infer parity.
- **LEAD: custom compiler/binary and command-execution boundaries.** UNRESOLVED as a guarantee. The plain-TeX latexmkrc article shows engine substitution via latexmk config, but it does not document installing other binaries or unrestricted command execution.
- **LEAD: per-engine image format table (EPS/PNG/PDF handling).** UNRESOLVED on this pass. The harvest reports it, but only EPS mentions in the selection page were re-read here.
- **Duplicate closed:** the plain-TeX and latexmkrc content in the harvest is the same source as the Learn article above; no separate lead remains.
