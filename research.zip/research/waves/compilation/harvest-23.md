# Harvest 23: Automatic/manual recompilation and compile modes

Research date: October 26, 2026. Public official Overleaf sources only. This is a documentation-based report, not a functional execution test.

## Findings

### Triggering compilation

- **Manual compile:** The Recompile button starts compilation from project source to PDF; compile errors are reported in logs. The dropdown below it exposes compile options. Source: https://docs.overleaf.com/getting-started/recompiling-your-project, headings “Compiling” and “Compile options.”
- **Automatic compile:** The dropdown’s **Auto compile** option, when enabled, automatically recompiles “every few seconds.” The current documentation does not specify the precise interval, debounce behavior, whether all edits/files trigger it, or its default state. Source: same URL, heading “Auto compile.”
- The help article documents how to choose whether compilation is automatic or manual: toggle **Auto Compile** on/off from the arrow beside Recompile. Source: https://cs.overleaf.com/learn/how-to/How_do_I_compile_my_tex_file%3F, opening paragraph (legacy Learn article; crawled about 1.4 years ago). Current docs confirm the option, but do not detail keyboard shortcuts or a save-trigger contract.

### Speed mode (distinct from error handling)

- **Normal** versus **Fast [draft]** concerns output fidelity/speed, not whether errors stop the build. Fast [draft] skips image processing and substitutes empty boxes for images; this can make image-heavy projects compile faster. Return to Normal for full image output. Sources: https://docs.overleaf.com/getting-started/recompiling-your-project, heading “Compile mode”; https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts, heading “Step 2: Try compiling in Fast [draft] mode.”
- Overleaf recommends Fast [draft] as a diagnostic for image-related timeouts; if draft compiles but Normal does not, image count/size may be implicated. It is a workaround/diagnostic, not a complete PDF substitute. Source: timeout URL, same heading.

### Error-handling mode

- Default **Try to compile despite errors** attempts to continue and may produce a PDF, but output can be incorrect; sufficiently serious/numerous errors can still prevent a PDF. Source: https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error, headings “Compilation modes on Overleaf” and “Overleaf’s LaTeX error reporting.”
- **Stop on first error** halts as soon as an error is detected, reports that error, and does not generate a PDF for that failed run. It is enabled from the Recompile dropdown and can be switched back to the default mode there. The setting is **per-user, per-project**: it does not affect that user’s other projects or collaborators. Source: same stop-on-first-error URL, headings “How to enable Stop on first error,” “Disabling Stop on first error,” and “Debugging with Stop on First Error.”
- Overleaf describes a third LaTeX behavior, “Suspend compilation to interact with the user,” as possible in a local installation but impractical on Overleaf—not an Overleaf selectable mode. Source: same URL, heading “Handling errors: compilation modes.”

### Cache and repeated passes

- Recompile normally preserves generated helper files between runs where possible for speed. **Recompile from scratch** deletes generated files and immediately recompiles; **Clear cached files** deletes them without immediately recompiling. Sources: https://docs.overleaf.com/getting-started/recompiling-your-project, heading “Recompile from scratch”; https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache, headings “Recompile from scratch” and “Clear cached files.”
- Overleaf uses latexmk to automate multi-pass LaTeX workflows (e.g., references/bibliographies); a user-level [0mlatexmkrc[0m may add custom rules. The old article https://www.overleaf.com/learn/how-to/How_does_Overleaf_compile_my_project%3F now redirects to the current recompilation guide, so those implementation details are **legacy**, not confirmed current guarantees. Do not interpret the platform feature as a guarantee that arbitrary external programs or every user-defined LaTeX build workflow are supported.

## Availability and scope boundaries

The current recompilation documentation describes these UI features without labeling them Free, premium, AI, Commons, Server Pro, or Community Edition. **Availability by plan/deployment: UNRESOLVED** from sources reviewed; do not infer parity. The timeout guide says some complex projects may require premium plans’ extended compile time, but that is a time limit distinction, not evidence that compile modes themselves are premium: https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts, opening section. Official on-premises release notes record Stop on First Error added in Server Pro 3.3.0 (2022-10-13); that dated historical release entry does not prove current edition parity: https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x, “Server Pro 3.3.0.”

These are Overleaf editor/build-service controls. Fast draft and error handling are not general LaTeX language capabilities. Conversely, ordinary LaTeX compilation semantics and user-defined build behavior should not be conflated with Overleaf UI guarantees. No claim is made about execution, API automation, compile concurrency, exact auto-compile timing, or undocumented plan availability.

## EXPAND

- **LEAD: plan and deployment matrix for recompilation controls — UNRESOLVED.** Current primary docs omit tier labels; investigate only if this angle requires feature parity by Free/Premium/Commons/Server Pro/Community Edition.
- **LEAD: exact auto-compile trigger, default, and interval — UNRESOLVED.** Docs say “every few seconds” but make no further timing/trigger guarantee.
- No AI/Commons feature is relevant to this compile-control angle; the July 2, 2026 AI-plan change is therefore not combined with older AI Assist documentation.

