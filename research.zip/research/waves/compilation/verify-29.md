# Verify 29: Bibliography tools, BibTeX, biblatex, and Biber builds

Checked October 27, 2026. Scope: Overleaf bibliography tooling and the documented BibTeX/biblatex/Biber build behavior. Evidence is from official Overleaf documentation and learning pages read in full. No authenticated project, purchase, or live compile was run, so nothing here is a functional execution result.

## Verdict: PARTIAL

Core features (`.bib` creation and upload, BibTeX and biblatex workflows, Biber as biblatex's default backend, automatic rebuilds, `.bbl` download) are confirmed. Deployment-specific claims (Biber/TeX Live versions, Community Edition and Server Pro parity) remain unresolved.

## Corrections to the upstream files

- **Plan gating was partly unresolved upstream; it is now resolved for hosted plans.** The reference-manager integration page states the feature is premium and that premium features apply to Commons participants, group-subscription members, and individual subscription owners. Free users do not get it.
- **"Biber examples" are treated as legacy.** The harvest's Overleaf Biber example pages were not re-opened in this pass, and their update dates were not verified here. Treat them as historical examples, not a current-version guarantee, and treat any "Recent" label as unconfirmed.
- **The expand's Community Edition and Server Pro claim was not verified.** The GitHub wiki and toolkit pages were not opened in the fetch set, so that claim stays open.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Users can create, upload, or template-start a `.bib` file | https://docs.overleaf.com/citing-and-references/working-with-.bib-files, "Creating your bibliography database", "Uploading your bibliography database" | All users (no premium gate stated on these sections) | CONFIRMED |
| Premium users can link Mendeley, Zotero, ReadCube to import `.bib` data | https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations, premium hint | Premium; applies to Commons participants, group members, individual subscription owners | CONFIRMED (hosted) |
| Simple citation-key search is available to all users; advanced reference search is premium | https://docs.overleaf.com/citing-and-references/adding-citations-and-references, "How can Overleaf help to find and cite references?" | Simple: all users; advanced: premium | CONFIRMED |
| Overleaf recommends biblatex for new projects with no template or requirement | https://docs.overleaf.com/citing-and-references/creating-a-bibliography, "LaTeX reference management systems" | All | CONFIRMED |
| biblatex commands: `\usepackage{biblatex}`, `\addbibresource{}`, `\cite{}`, `\printbibliography` | https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX, "Introduction" and "Basic usage" | LaTeX feature | CONFIRMED |
| Biber is biblatex's default and recommended backend; BibTeX backend only sorts (no `.bst` styles) | https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX, "Basic usage" (`backend=biber` note) | LaTeX feature | CONFIRMED (documented, no version given) |
| BibTeX is still documented as supported; biblatex is advised for new work | https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex, "Advisory note" | All | CONFIRMED; no deprecation found |
| Only cited entries print; `\nocite{*}` includes all; cite keys and file names are case-sensitive | https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex, "Some notes on using BibTeX and .bib files" | LaTeX feature | CONFIRMED |
| Overleaf's `latexmk` reruns BibTeX/LaTeX as needed; bibliography builds may take longer | https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex, "Enter BibTeX" and "A note on compilation times" | All | CONFIRMED |
| Preinstalled `.bst` styles come from TeX Live | https://docs.overleaf.com/citing-and-references/available-bibtex-styles, intro and list | All | CONFIRMED; TeX Live version NOT stated |
| `output.bbl` can be downloaded via Logs and output files > Other logs and files | https://docs.overleaf.com/navigating-in-the-editor/generated-files, "How to download a `.bbl` file" | All | CONFIRMED |
| Standard source download excludes generated files; arXiv-style submission ZIP includes `.bbl` | https://docs.overleaf.com/navigating-in-the-editor/generated-files, "Downloading generated files along with the source" | All | CONFIRMED |
| Import from Mendeley/Zotero buttons; EndNote/Paperpile via `.bib` export | https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex, "Export from reference library services" | Mendeley/Zotero import tied to premium links; export workflow generic | PARTIAL (upload button labels from article; premium gate from docs) |
| `.bib` checks for missing, redundant, or unused citations via AI tooling | https://docs.overleaf.com/citing-and-references/working-with-.bib-files, "[New Terminology] .bib support" | AI feature; plan allowances per blog below | PARTIAL: feature named, entitlement not stated |
| Overleaf AI is included in all plans from July 2, 2026, with plan-dependent allowances; a Commons AI tier is added | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans | Plan list not extracted; see blog for allowances | CONFIRMED for 2026 blog; AI not claimed as a bibliography feature |
| AI Assist as a separate add-on (Digital Science, June 24, 2025) | https://www.digital-science.com/press-releases/digital-science-launches-new-cutting-edge-ai-writing-tools-for-20-million-overleaf-users/ (search snippet only) | Legacy, 2025 | LEGACY; superseded by the July 2, 2026 blog; not opened in full, not combined with it |
| Community Edition and Server Pro bibliography parity, Biber/TeX Live versions by deployment | None opened for this claim | Unknown | UNRESOLVED |

## Counter-search queries

- `site:docs.overleaf.com biber TeX Live version`
- `site:github.com overleaf toolkit biblatex` (deployment behavior)
- `site:docs.overleaf.com reference manager integration status Zotero Mendeley ReadCube`
- `site:overleaf.com blog AI bibliography citation check plan allowance`

## Limitations

- Public docs state that bibliography examples and `.bst` lists exist, not that every custom style, class, or package version compiles.
- No plan matrix covering `.bib` AI checks was found; those claims stay PARTIAL.
- Claims rely on the primary pages fetched in this pass, not on search snippets, except where the table marks a snippet-only source.

## EXPAND

- **LEAD: Biber and TeX Live version per hosted and deployment.** No official version matrix found. Needed: an Overleaf page listing the TeX Live and Biber versions per deployment.
- **LEAD: Community Edition and Server Pro bibliography parity.** Not opened. Needed: official `overleaf/overleaf` wiki and `overleaf/toolkit` pages on compile tooling and bibliography support.
- **LEAD: Reference-manager integration on self-hosted deployments.** Not checked. Likely none; needs an official statement.
- **LEAD: Entitlement for AI `.bib` checks by plan.** Blog gives allowances but not which tools apply to `.bib` checks. Needed: the AI features docs page and plan allowance table.
