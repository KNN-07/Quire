# Expand 27: LaTeX packages, custom classes, and local fonts

Research date: October 26, 2026. Upstream: harvest-27.md. Method: opened the cited Overleaf pages and checked each claim against page text; one web search wave for omitted functionality and deprecation. No projects were compiled or tested, and no authenticated or paid features were used.

Labels: **Platform** = documented Overleaf feature. **Arbitrary LaTeX** = general LaTeX behavior that Overleaf does not guarantee. Availability tier (Free/Premium/AI/Commons/Server Pro/Community Edition) is stated only where a source states it.

## Platform: hosted packages and TeX Live

- **Platform.** Hosted compilation uses TeX Live and offers "over 5,000" packages per release. Source: https://docs.overleaf.com/troubleshooting-and-support/tex-live, heading "Which LaTeX packages does Overleaf support?". Tier: not stated; applies to hosted projects.
- **Platform.** New and copied projects use the latest TeX Live on Overleaf. Existing projects are not auto-upgraded. Any collaborator with Editor permission can change a project's TeX Live version, and the change affects all collaborators. Earlier releases remain selectable. Same URL, section "TeX Live and your Overleaf project".
- **Platform, date-tagged 2026-08-18.** TeX Live 2026 is available for existing projects by changing the project setting. Source: https://www.overleaf.com/blog/tex-live-2026-is-now-available (dated August 18, 2026). The post says some packages are now legacy, recommends newer alternatives for new documents, and reports kernel changes (table-related and math-mode box-positioning behavior). It also warns that previously working projects can error under 2026. This is the primary source for the 2026 breakage risk.
- **Deprecation, unresolved detail.** A secondary search result (ayakaleaf mirror, not primary) claims `tabu` and `tabls` error under TL2026. I did not confirm this on the primary blog text, so it is **UNRESOLVED** for this report.
- **Arbitrary LaTeX.** Overleaf warns that package updates in new TeX Live releases can break code. Source: same troubleshooting page. Compatibility of a given class or package is not guaranteed.

## Platform: compilers and engines

- **Platform.** Compiler choices are pdfLaTeX (default), LaTeX, XeLaTeX, and LuaLaTeX. XeLaTeX and LuaLaTeX handle TrueType and OpenType fonts natively. Source: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler, heading "Why change compilers?" and the compiler-comparison text.
- **Arbitrary LaTeX.** Engine-specific limits (for example pdfLaTeX with OpenType) are described in general terms; no exhaustive per-package engine matrix was found.

## Platform: project-local classes, packages, and bibliography styles

- **Platform.** `.cls`, `.sty`, and `.bst` files placed in the project are found by LaTeX. Files may be organized in folders. Overleaf documents setting search paths (`TEXINPUTS` and `BSTINPUTS`) through a `latexmkrc` file at the project root, while the main document and the `latexmkrc` file stay at the top level. Source: https://docs.overleaf.com/managing-projects-and-files/adding-latex-dependencies, "Adding LaTeX dependencies" (folder organization and top-level file requirement, verified in page text).
- **Arbitrary LaTeX.** Custom classes are standard LaTeX authoring. Overleaf Learn covers `\ProvidesClass`, `\LoadClass`, options, and `\RequirePackage`: https://www.overleaf.com/learn/latex/Writing_your_own_class. This is ordinary LaTeX, not an Overleaf class builder.
- **Not found.** No documented Commons-specific limit on uploaded `.cls` or `.sty` files. **UNRESOLVED** (see EXPAND).

## Platform: local fonts

- **Platform.** Fonts that are not on Overleaf's servers can be uploaded to the project. With XeLaTeX or LuaLaTeX, load them via `fontspec`. Overleaf says this route does not need `.tfm`, `.enc`, or `.map` setup. pdfLaTeX custom fonts need TeX metrics and encoding files, which the guide walks through. Source: https://www.overleaf.com/learn/latex/Questions/I_have_a_custom_font_I%27d_like_to_load_to_my_document._How_can_I_do_this%3F, headings "Using custom fonts with XeLaTeX and LuaLaTeX" and "Using custom fonts with pdfLaTeX".
- **Scope.** The guide covers text fonts only, not math fonts. It also says "custom font" means one not available on Overleaf's servers, including licensed commercial fonts. Users must respect font licences.
- **Bundled fonts.** Overleaf Learn lists font families reachable through font packages (for example Times, Palatino, Helvetica, Latin Modern, TeX Gyre). Source: https://www.overleaf.com/learn/latex/Font_typefaces. The same page states that not every catalogue font is distributable with TeX Live, so not all are on Overleaf. No exhaustive hosted font list was found.

## Self-hosted: Community Edition and Server Pro

- **Community Edition.** The README says Community Edition is for trusted users because Sandboxed Compiles are not available, and that without Sandboxed Compiles users have full read and write access to the environment. Source: https://github.com/overleaf/overleaf, README "Community Edition". Tier: Community Edition.
- **Custom TeX Live images.** The Extending TeX Live page says it offers guidelines for new packages or fonts in a custom Dockerfile image, and that custom-image configuration is not covered by Overleaf's support terms. It states the sections apply to Server Pro, and the page text I read was truncated before naming the full scope. Source: https://docs.overleaf.com/on-premises/maintenance/extending-tex-live. The harvest's "Server Pro with Sandboxed Compiles only" wording is **partially verified**. A search-surfaced Server Pro 6.3.0 release note (dated 2026-08-28, https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x) says TeX Live 2026 is available for Server Pro instances running Sandboxed Compiles. I did not open the full page.
- **Community Edition package installs.** The Upgrading TeX Live page says the Community Edition and Server Pro images ship a minimal TeX Live install, and that changes made inside the container are ephemeral unless saved with `docker commit` into a new image. Source: https://docs.overleaf.com/on-premises/installation/upgrading-tex-live, section "Installing packages" and "Saving your changes".
- **Legacy note.** The same page's example output says "runs TeX Live 2021" but shows a 2025 `tlmgr` version line. The example is internally inconsistent. Verify against the deployed image before following it.

## Tier and AI labels

- No Free, Premium, or Commons-specific limits for packages, classes, or uploaded fonts were found in the pages read. Treat hosted features as general platform features, not a guarantee for every tier.
- AI is not relevant to this angle. I did not combine or compare the July 2, 2026 "AI bundled" blog statement with any older AI Assist docs.

## Limitations

- No project was compiled. Nothing here confirms that any specific package, class, or font works on Overleaf.
- The Extending TeX Live page was truncated in my read, so its exact scope sentence is not fully verified.
- The `tabu`/`tabls` claim is secondary-only.
- The harvest's claim about `docs.overleaf.com` deployment paths was checked against page headings, not full bodies.

## EXPAND

- **LEAD: TeX Live 2026 deprecations of `tabu` and `tabls` on Overleaf.** UNRESOLVED. Reason: found only in a secondary mirror (ayakaleaf); the primary Overleaf blog I read says some packages are legacy but does not name these two. Next step: open the full primary blog or the upstream TeX Live 2026 release notes.
- **LEAD: Exact on-premises scope of custom TeX Live images (Server Pro vs Community Edition).** UNRESOLVED in full. Reason: the Extending TeX Live page read was truncated; the Server Pro 6.3.0 release note was seen only in search. Next step: open the full on-prem Extending TeX Live page and release notes.
- **LEAD: Searchable hosted font inventory per engine and TeX Live release.** UNRESOLVED. Reason: Learn pages give examples and caveats but no complete versioned list.
- **LEAD: Commons-specific limits for custom `.cls`, `.sty`, or uploaded fonts.** UNRESOLVED. Reason: no Commons policy was found; no equivalence or restriction is inferred.
- **Duplicates closed:** the harvest's two "Legacy" and "ephemeral CE" notes are covered in this report under Self-hosted and Platform. The harvest's TeX Live version claims are confirmed by the troubleshooting page.
