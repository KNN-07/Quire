# Verify 26: Timeouts, resource limits, and performance tuning

Research date: 2026-10-26. Upstream: harvest-26.md, expand-26.md. Scope: public official Overleaf docs and pricing page. No authenticated tests, no purchases. No temp resources were created.

## Verdict: PARTIAL

Compile timeout values for hosted plans and on-prem defaults are confirmed on primary pages. The "CE does not enforce timeouts" claim conflicts with evidence and stays UNRESOLVED. No source documents CPU, RAM, or concurrency allocations for hosted or Server Pro compiles.

## Findings

**Hosted (overleaf.com).** The [plan limits page](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits), heading "Overleaf plan limits", lists a 10-second compile timeout on Free and 240 seconds on Premium. Its "More about our premium plans" section names Standard, Pro, and Student. The [pricing page](https://www.overleaf.com/user/subscription/plans), "Performance" section, lists "Basic" for Free and "24x Basic" for the paid Student, Standard, and Pro cards. This confirms the 24x multiplier on the English page, which upstream had marked unverified. The same pricing page lists a "Compile speed" row with "Fast" and "Fastest" labels but gives no numeric speed. Free plan project limits are 2,000 files, 7 MB editable material, 2 MB per editable text file, and 50 MB per upload, the same across plans. Project size has no enforced cap; the plan-limits footnote recommends 500 MB, or under 100 MB with GitHub sync or Git integration, and warns that projects over 4 GB may hit problems such as project copy.

**Performance controls (hosted, platform features).** The [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project) page, "Compile mode", says Fast [draft] skips image processing and replaces images with empty boxes. "Recompile from scratch" clears helper files that are normally kept to speed later builds. The [fixing compile timeouts guide](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), Step 1, recommends [Stop on first error](https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error), a per-user, per-project setting that stops at the first error. Step 2 describes Fast [draft] for timeout diagnosis. These are diagnostic modes, not added compute.

**LaTeX practices (not platform features).** The same timeout guide, "Time-consuming practices and packages", names TikZ/pgfplots, `\tracingall`, EPS/SVG conversion, `tabularray`, and some `acro` v3 and `mhchem` cases as slow. It recommends PDF for diagrams and JPEG for photos. Upstream harvest was correct that these exist. These advisories are Overleaf guidance, not benchmarked results.

**Fair use.** The guide's "Fair use limits" section says some projects may need more time than paid plans give, and recommends local compilation. Upstream expand-26 said this was absent; that was wrong.

**On-prem (Community Edition and Server Pro).** The [Project limits page](https://docs.overleaf.com/on-premises/support/project-limits) lists a 180-second compile timeout default. The [Project management page](https://docs.overleaf.com/on-premises/user-and-project-management/project-management), "Updating project compile timeout", says to set `COMPILE_TIMEOUT` in `config/variables.env`, recreate the container with `bin/up -d`, and avoid going past 10 minutes. It also says the value applies only to new users; existing users need a database update of `features.compileTimeout`. The docs do not split the 180 s default by edition.

**Sandboxing (Server Pro only).** The [Sandboxed Compiles page](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles) says each compile runs in its own Docker container with limited capabilities and no host-network access. It requires mounting the Docker socket. No CPU or memory limits are stated. The [Server Pro vs. Community Edition page](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition) says CE has no sandboxing and compiles run with container privileges, so CE is for fully trusted users only. That is a security distinction.

**Conflict: CE timeout enforcement.** Upstream harvest says a 2024-08-28 maintainer comment on [overleaf/overleaf issue #1166](https://github.com/overleaf/overleaf/issues/1166) states CE does not enforce compile timeouts. The fetched issue body is a user question asking whether a default timeout exists. A search snippet of the thread quotes a maintainer saying the CE default is 180 seconds. The 2024-08-28 comment was not reached. Status: UNRESOLVED.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Free compile timeout 10 s | plan-limits, "Overleaf plan limits" | Free | Verified |
| Premium compile timeout 240 s | plan-limits, same table | Standard, Pro, Student | Verified |
| 24x Basic compile timeout on paid cards | pricing page, "Performance" | Paid plans | Verified (English page) |
| Fast [draft] skips image processing | Recompiling, "Compile mode" | Hosted, all plans | Verified |
| Recompile from scratch clears helper files | Recompiling | Hosted | Verified |
| Stop on first error for timeout debugging | stop-on-first-error; timeout guide Step 1 | Hosted, per user/project | Verified |
| Fair use / local compile advice | timeout guide, "Fair use limits" | Hosted | Verified (upstream expand wrong) |
| tabularray, acro v3, TikZ slow | timeout guide, "Time-consuming practices" | LaTeX packages | Verified as guidance; not benchmarked |
| Project size: no enforced cap; 500 MB or 100 MB recommended | plan-limits footnote | Hosted | Verified |
| On-prem compile timeout default 180 s | on-prem Project limits; Project management | CE and Server Pro | Verified |
| COMPILE_TIMEOUT applies to new users; DB update for existing | Project management | On-prem | Verified |
| Sandboxed compiles, Docker container per compile | sandboxed-compiles page | Server Pro only | Verified |
| CE runs compiles without sandbox | Server Pro vs. CE, warning | CE | Verified (security) |
| CE does not enforce timeouts (2024-08-28) | overleaf issue #1166 | CE | UNRESOLVED; conflicts with snippet |
| Numeric CPU/RAM limits for hosted or sandboxed compiles | none found | Hosted, Server Pro | UNRESOLVED (absence in reviewed pages) |
| "Fast" / "Fastest" compile speed | pricing page, "Compile speed" | Plan tiers | Label verified; numeric speed UNRESOLVED |
| Cache files garbage-collected; upload local drawings | reducing-compile-time page | Hosted | UNRESOLVED (page not fetched) |
| nginx timeouts raised to 10 min (PR #805) | GitHub PR snippet | On-prem, 2020 | Legacy; snippet only |

## Corrections to upstream

1. Expand-26 said "Fair use" and "tabularray" were not found. Both are in the timeout guide. Harvest was right.
2. Expand-26 said the 24x figure was German-snippet only. The English pricing page confirms it.
3. The harvest's CE-enforcement claim is not confirmed and conflicts with a snippet.

AI bundling (July 2, 2026 blog vs. older AI Assist docs) is out of scope and was not investigated.

## Counter-search queries

- Overleaf Community Edition default compile timeout COMPILE_TIMEOUT 180 issue 1166
- overleaf issue 1166 maintainer comment 2024-08-28 compile timeout enforcement
- Overleaf Server Pro sandboxed compiles CPU memory limit container
- Overleaf compile timeout plan limits 240 seconds
- Overleaf reducing compile time diagrams externalize cache garbage collected

## EXPAND

- **LEAD: issue #1166 full thread.** Open the 2024-08-28 comment and the maintainer replies to resolve the CE enforcement conflict.
- **LEAD: Server Pro sandbox resource settings by release.** No numeric CPU, memory, or per-version timeout defaults were found in reviewed docs.
- **LEAD: reducing-compile-time-for-diagrams page.** Needed to confirm the cache garbage-collection claim.
- **LEAD: on-prem nginx and proxy timeouts by release.** PR #805 and issue #955 are snippet-only and date from 2020–2021.
- **Hosted per-compile CPU and RAM:** no source found; no LEAD opened because no public official page is likely to state it. Treat as unresolved, not absent.
