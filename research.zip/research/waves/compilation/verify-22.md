# Verify 22: TeX Live versions, upgrades, and reproducibility

Checked 2026-10-27 against public Overleaf and TUG pages. Documented configuration only; no authenticated tests, purchases, or compile runs. Tool note: apply_patch was unavailable, so this file was written with the write tool.

**Verdict: PARTIAL.** Version selection, upgrade behavior, and self-hosted image configuration are confirmed by primary pages. A reproducibility guarantee is not documented, and tier, Commons, and Server Pro 6.3 date questions remain unresolved.

## Confirmed findings

- **TeX Live 2026 is current on Overleaf, with one official update per year after testing.** Source: https://www.overleaf.com/blog/tex-live-2026-is-now-available (section "What is TeX Live?"). TUG confirms TeX Live 2026 was released 1 March 2026: https://www.tug.org/texlive/. The blog body shows "August 18" as its date.
- **New projects get the latest installed release; existing projects are not auto-upgraded.** Source: https://docs.overleaf.com/troubleshooting-and-support/tex-live ("TeX Live and your Overleaf project"). The page says "latest" without a year, so the exact default is UNRESOLVED.
- **Per-project switch.** Settings → Compiler → TeX Live version. Any editor can change it, it affects all collaborators, and it is reversible. Source: same troubleshooting page and https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler.
- **Upgrade risk.** Overleaf advises against switching unless needed, because new errors or warnings can appear. Source: the 2026 blog, "Will my existing projects work as usual?"
- **Legacy and Labs.** Older versions are labelled Legacy with no discontinuation timeline. The Labs rolling build is untested, unsupported, and not a pin. Source: troubleshooting page.
- **Community Edition.** Ships a minimal TeX Live. Admins can run `tlmgr`, but changes are lost on container recreation unless committed with `docker commit`, and must be repeated on upgrade. Source: https://docs.overleaf.com/on-premises/installation/upgrading-tex-live. An older GitHub copy (https://github.com/overleaf/toolkit/blob/master/doc/ce-upgrading-texlive.md) uses example version 5.0.3 and has the same substance; it is date-tagged as legacy.
- **Server Pro.** Sandboxed Compiles use the same images as overleaf.com. Image choice uses `TEX_LIVE_DOCKER_IMAGE` (default for new projects) and `ALL_TEX_LIVE_DOCKER_IMAGES`. The list includes `texlive-full:2026.1`. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles. Its "current default is 2017.1" text is stale and date-tagged as legacy.
- **Configurable reference.** The CLSI README documents `TEXLIVE_IMAGE` (example is a full registry path, not a bare tag) and `ALLOWED_IMAGES`. It does not state registry retention. Source: https://github.com/overleaf/overleaf/blob/main/services/clsi/README.md.

## Distribution changes (not Overleaf features)

The 2026 blog lists packages affected by TL2026, including tabu/tabls (unsupported), frenchb (use french), font renames, DocumentMetadata changes, and LuaLaTeX requirements for accessible tagging. Source: the 2026 blog, "Common packages affected by TeX Live 2026" and "Other things to be aware of." Treat these as reported facts; per-package details were not individually verified.

## Contradictions and unresolved items

- **Server Pro 6.3 date:** the blog snippet says August 31, 2026; the toolkit CHANGELOG snippet says 2026-08-28. Snippet-only; UNRESOLVED.
- **Hosted tier and Commons:** not stated on the pages opened. UNRESOLVED.
- **arXiv default TeX Live:** snippet-only. UNRESOLVED.
- **2019 upgrade figures (~5,000 gallery documents):** not opened; excluded.
- **Reproducibility guarantee:** the docs say pinning fixes package versions within a release, not byte-identical output or locked fonts, images, or external inputs. Not documented; UNRESOLVED as a guarantee.
- **AI bundling (July 2, 2026):** out of this angle; not investigated and not combined with TeX Live claims.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| TeX Live 2026 available; annual update | 2026 blog | Hosted | Confirmed |
| TL2026 released 1 March 2026 | tug.org/texlive | Distribution | Confirmed |
| New projects default to latest | Troubleshooting page | Hosted | Confirmed; exact year UNRESOLVED |
| Existing projects not auto-upgraded | Troubleshooting page | Hosted | Confirmed |
| Per-project switch in Settings → Compiler | Selecting-version page | Hosted | Confirmed |
| Legacy versions, no timeline | Troubleshooting page | Hosted | Confirmed |
| Labs build untested, unsupported | Troubleshooting page | Labs | Confirmed |
| CE tlmgr changes need docker commit | Upgrading TeX Live (on-prem) | CE | Confirmed; GitHub copy legacy |
| Sandboxed Compiles use overleaf.com images | Sandboxed Compiles page | Server Pro | Confirmed |
| TEXLIVE_IMAGE, ALLOWED_IMAGES | CLSI README | Self-hosted | Confirmed (config only) |
| tabu/tabls unsupported in TL2026 | 2026 blog | Distribution | Confirmed |
| Reproducibility guarantee | Not stated | N/A | UNRESOLVED |
| Server Pro 6.3 date | Blog vs CHANGELOG snippets | Server Pro | UNRESOLVED (conflict) |
| Free/Premium tier, Commons | Not stated | N/A | UNRESOLVED |

## Counter-search queries

- "site:docs.overleaf.com TeX Live Free premium plans"
- "site:docs.overleaf.com Commons TeX Live"
- "Overleaf Server Pro 6.3 release date"
- "site:github.com/overleaf/toolkit CHANGELOG TexLive 2026"
- "Overleaf arXiv TeX Live default version"

## EXPAND

- **LEAD: Server Pro 6.3 date.** Open the 6.3 blog and release notes to resolve August 31 vs August 28.
- **LEAD: Free/Premium and Commons availability.** Open the plans page and search Commons TeX Live docs.
- **LEAD: current hosted default year.** The docs say only "latest"; confirm the release new projects get.
- **LEAD: arXiv default TeX Live.** Open the arXiv checklist before making any claim.
- **Not a lead: reproducibility guarantee.** No official page documents one; further search is unlikely to change that.
- **Not a lead: 2019 figures and AI bundling.** Excluded as legacy or out of angle.
