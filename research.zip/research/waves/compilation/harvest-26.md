# Harvest 26: Timeouts, resource limits, and performance tuning

Research date: October 26, 2026. Scope: public Overleaf-hosted product and on-premises documentation; no authenticated testing.

## Hosted Overleaf: explicit limits

The current [Plan limits](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits), heading **Overleaf plan limits**, specifies a **10-second compile timeout on Free** and **240 seconds on Premium**. It lists the same project limits across plans: 2,000 files, 7 MB of editable material, 2 MB per editable text file, and 50 MB per individual upload. Total project size and project count are listed as unlimited, but the docs clarify that “unlimited” means no enforced total-size cap: they recommend at most 500 MB per project, or under 100 MB with GitHub sync or Git integration, and warn projects over 4 GB can have issues such as copying. Those are hosted-plan limits/recommendations, not universal LaTeX limits.

The current [pricing page](https://www.overleaf.com/user/subscription/plans), **Performance** section, describes paid plans as 24× Basic compile timeout. This is consistent with 10 seconds versus 240 seconds in plan limits. The exact current limits above come from the current plan-limits table, rather than older secondary or historical references.

The [timeout troubleshooting guide](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), **Fair use limits**, says some large projects may exceed even paid-plan time and recommends local compilation if the hosted timeout remains insufficient. It promises no specific CPU, RAM, concurrency, or throughput allocation in these sections; do not infer such guarantees from timeout values.

## Hosted performance controls and troubleshooting

In [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project), **Compile mode** documents **Fast [draft]**: it skips image processing and substitutes empty boxes for graphics. This is a faster editing mode, not a final-output optimization, and it can help isolate image-processing cost. **Recompile from scratch** clears temporary helper files; normal compiles preserve them when possible to speed later builds, but clearing may help if stale or erroneous generated files exist.

The [timeout troubleshooting guide](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), **Time-consuming practices and packages**, identifies expensive TikZ/pgfplots drawing, `\tracingall` log output, EPS/SVG-to-PDF conversion, large/high-resolution raster images, and (as documented there) `tabularray` and some package/version cases as possible causes. It recommends PDF for diagrams/plots, JPEG for photographs, and externalizing TikZ drawings. These are LaTeX project-level practices, not Overleaf platform functions; package behavior may vary by document and versions.

The guide’s **Step 1** recommends **Stop on first error** because attempting to produce a PDF despite errors can prolong a failing build. Its **Specific timeout situations** also recommend matching the project’s TeX Live version when a local build works but an upload or copy times out. These are diagnostic steps, not additional compute resources or guaranteed fixes.

For complex externalized TikZ graphics, [Reducing the compile time for diagrams](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts/reducing-the-compile-time-for-diagrams), **Generating the drawings locally**, says generated cache files may be garbage-collected on the server; uploading locally generated files avoids that cleanup for uploaded files, but changes to source graphics can require replacing corresponding cached outputs. This is a documented workaround with cache-maintenance cost, not a hosted caching guarantee.

## On-premises distinction

[Sandboxed Compiles](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles), **Improved security** and **How it works**, is an optional **Server Pro-only** feature: each project compile runs in its own Docker container with limited capabilities and no host-network access. It provides project isolation and package/TeX Live image management; the cited documentation does not specify numeric CPU or memory ceilings. **Community Edition** lacks sandbox compiles and runs compiles as subprocesses without that project isolation, per [Server Pro vs. Community Edition](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition), **Differences**. This is a deployment/security distinction, not a paid hosted-plan timeout.

**Legacy claim, dated August 28, 2024:** an Overleaf maintainer stated in [overleaf/overleaf issue #1166](https://github.com/overleaf/overleaf/issues/1166), comment dated 2024-08-28, that Community Edition does not enforce compile timeouts and that Server Pro sandboxed compiles can enforce them. Treat this as historical implementation guidance, not a current numeric CE guarantee; current public on-prem documentation reviewed here does not state a CE timeout value. The same issue describes database and proxy timeout configuration, but its advice is deployment-specific and should not be generalized into current supported settings without version-specific confirmation.

## EXPAND

- **LEAD: Server Pro timeout configuration by release/version.** Current docs establish sandboxing availability but this review did not find current numeric defaults or complete administrator timeout controls; avoid inferring a setting.
- **LEAD: Hosted resource quotas beyond documented project limits.** No current official source reviewed specifies per-compile CPU, RAM, or parallel-job allocation; availability/guarantees remain unresolved.
