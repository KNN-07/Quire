# Overleaf angle 24 expansion: PDF viewer, SyncTeX, search, zoom, layouts

Research date: October 26, 2026. This is a public-source evidence report, not a functional test. The feature descriptions concern the Overleaf editor; LaTeX typesetting behavior is distinguished below. Availability labels reflect what the cited official sources explicitly establish.

## PDF viewer, zoom, and layouts

Overleaf documents two viewer modes: its own viewer and the browser PDF viewer. The Overleaf viewer provides page navigation, zoom controls, position retention between compiles, and source/PDF jump-to-location. The browser viewer is a fallback for some rendering problems, but its documented limitations are material: SyncTeX arrows do not work, recompilation returns to page one, and Overleaf navigation controls disappear. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation — “The Overleaf PDF and the Browser PDF viewers”; “Browser PDF viewer limitations.”

The Overleaf viewer’s zoom menu supports zoom in/out, fit width/height, custom percentage, presets (50%, 75%, 100%, 150%, 200%, 400%), and presentation mode. Keyboard shortcuts include Ctrl + / Ctrl - and Ctrl 0 / Ctrl 9 on Windows/Linux; equivalent Command shortcuts are documented for Mac. Trackpad pinch and modifier-plus-scroll are also supported. Presentation mode hides the Overleaf interface for full-screen PDF viewing. Source: same URL — “The zoom-level menu,” “How to use presentation mode,” and “Navigation shortcuts using a keyboard and mouse.”

Documented layouts are Split view (editor and PDF in one tab), Editor only, PDF only, and PDF in a separate tab; Focus mode can combine with these layouts. The separate-tab layout supports placing editor and preview on separate displays. The layout article says cross-tab “Show in code”/“Show in PDF” navigation continues to work via SyncTeX. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/editor-and-pdf-layout-and-sizing — “Split view (the default),” “Open PDF in a separate tab,” and “Focus mode”; https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/moving-between-the-editor-and-pdf — “Using jump-to-location.”

## SyncTeX behavior and limitations

Overleaf says compilation emits `output.synctex.gz`, mapping `.tex` locations to PDF positions; the editor/viewer use it for jump-to-location. In the documented workflow, double-clicking PDF text jumps to source, and arrows navigate between source and preview. SyncTeX’s mapping precision is line-level, not character-level; stale generated data can impair accuracy, and two-column or multicolumn layouts can reduce accuracy. Documented source-file resolution problems include bibliography output produced from intermediate `.bbl`, a main `.tex` file inside a subfolder, `./` prefixes in `\input`/`\include`, and spaces or special characters in filenames. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/moving-between-the-editor-and-pdf — “SyncTeX” and “Troubleshooting and known limitations.”

The underlying SyncTeX extension is a TeX ecosystem capability, while Overleaf’s arrows and jump UI are platform features. Overleaf’s documentation describes its own compilation/UI integration; it does not guarantee identical mappings for every document structure or engine workflow. These are not extra features furnished merely by arbitrary LaTeX source.

## Search scope

File search/replace applies to editable text in the current file and offers case sensitivity, regex, whole-word, and selection-only matching. It excludes read-only files, including externally sourced text and files over 2 MB. Project-wide search groups matches by file and jumps to the selected source location; files over 2 MB are excluded. The docs describe searches over project files, not rendered PDF text, so PDF-text search is **UNRESOLVED/not documented as a capability**. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project — “Search and replace within the current file,” “How to use search or search and replace,” and “Project-wide search.”

## Plan and deployment availability

The current viewer, search, zoom, and layout documentation does not assign these functions to Free versus paid tiers. Thus current plan entitlement for these specific UI features is **UNRESOLVED** by those sources; do not infer either restriction or inclusion from silence. A June 15, 2022 Overleaf blog explicitly said PDF detach was available to Free and Premium plans then. This is **dated legacy** evidence and does not establish current plan entitlements for all layouts: https://www.overleaf.com/blog/new-feature-ready-set-detach — “New feature: ready, set… DETACH!”

Official on-premises docs identify Server Pro and Community Edition as separate Overleaf deployments and document their product differences, but the pages reviewed do not map this angle’s viewer/search/zoom/layout functions to either edition. Availability for Server Pro and Community Edition is therefore **UNRESOLVED**; no feature-level inference is made. Sources: https://docs.overleaf.com/on-premises/welcome — “Overview of Server Pro and Community Edition”; https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — “Benefits for users.”

## Duplicate closure and scope

The upstream harvest’s search, viewer, zoom, SyncTeX, and layout findings are retained and narrowed to evidence actually stated in the current docs. Its two plan/deployment leads remain unresolved as above. “Project-wide search” means project source files, not PDF content; this closes the duplicate search-scope question without inventing PDF indexing. LaTeX’s effect on rendered layout and SyncTeX precision is not an Overleaf viewer control. No AI claim is relevant to this angle; the current evidence does not need to reconcile AI packaging.

## EXPAND

- LEAD: Current Free/Premium entitlements for viewer, search, zoom, and layouts — UNRESOLVED; current feature docs omit tier mapping. The 2022 detach statement is date-tagged and cannot settle current status.
- LEAD: Server Pro and Community Edition support for these specific UI behaviors — UNRESOLVED; reviewed deployment sources describe editions generally but do not specify these controls.
- No other open leads: PDF-text search is not documented in the project-search source; do not treat it as supported.
