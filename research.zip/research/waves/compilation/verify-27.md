# Verify 27: LaTeX packages, custom classes, and local fonts

Research date: 2026-10-27. Upstream: harvest-27.md, expand-27.md. Method: opened primary Overleaf pages (docs.overleaf.com, overleaf.com/learn, overleaf.com/blog, GitHub README) and checked each claim against fetched text. Search snippets were used only to find pages and are labeled where they were the sole evidence. No project was compiled; no authenticated, paid, or AI features were used.

**Verdict: PARTIAL.** Core platform claims are confirmed. One upstream item was narrowed, one contradiction is unresolved, and several items remain UNRESOLVED.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| TeX Live on Overleaf provides over 5,000 packages per release | https://docs.overleaf.com/troubleshooting-and-support/tex-live (intro) | Hosted; no tier limit stated | Confirmed (primary) |
| Package-count page says "about 4000" packages | https://docs.overleaf.com/troubleshooting-and-support/tex-live/latex-packages-on-overleaf | Hosted | **Contradiction** with the 5,000 figure; UNRESOLVED |
| Project TeX Live version is per project; any Editor can change it and it affects all collaborators | tex-live page, "TeX Live and your Overleaf project" | Hosted | Confirmed |
| Selecting a TeX Live version: most recent recommended; legacy versions not recommended for new projects | https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler, "How do I change a project's TeX Live version?" | Hosted | Confirmed. Does not state a default for new projects. |
| Legacy TeX Live versions exist with no discontinuation timeline | tex-live page, Legacy section | Hosted | Confirmed; no timeline stated |
| Compilers: pdfLaTeX, LaTeX, XeLaTeX, LuaLaTeX. XeLaTeX supports pstricks; LuaLaTeX does not | selecting-compiler page, "Why change compilers?" | Hosted | Confirmed |
| Upload a `.cls`/`.sty` directly "in many cases" when a class or package is missing from the project's TeX Live | latex-packages-on-overleaf page | Hosted | Confirmed. Hedged wording; not guaranteed. |
| `.cls`, `.sty`, `.bst` must be top level unless `latexmkrc` sets TEXINPUTS/BSTINPUTS | https://docs.overleaf.com/managing-projects-and-files/adding-latex-dependencies | Hosted | Confirmed |
| Class structure: `\NeedsTeXFormat`, `\ProvidesClass`, `\LoadClass`, `\RequirePackage`, `\DeclareOption`/`\ProcessOptions`, `\ClassError` | https://www.overleaf.com/learn/latex/Writing_your_own_class | Arbitrary LaTeX (not a platform feature) | Confirmed. Page also advises checking CTAN first. |
| Custom OTF/TTF fonts load via fontspec in XeLaTeX/LuaLaTeX without .tfm/.enc/.map | https://www.overleaf.com/learn/latex/Questions/I_have_a_custom_font_I%27d_like_to_load_to_my_document._How_can_I_do_this%3F | Hosted (upload) | Confirmed |
| pdfLaTeX custom fonts need .tfm, a map entry (`\pdfmapline`), and .fd files | Same page | Hosted | Confirmed |
| The font guide covers text fonts only, not math fonts | Same page, introduction | Hosted | Confirmed |
| Bundled font families (Computer Modern, Latin Modern, TeX Gyre, Times, Palatino, Helvetica, etc.) | https://www.overleaf.com/learn/latex/Font_typefaces, "Reference guide" | Hosted (via font packages) | Confirmed that these packages are listed. The page does not say "bundled," so the upstream wording overstates it. Some catalogue fonts may be unavailable on Overleaf. |
| TL2026 renames: Source Sans Pro to Source Sans 3, Source Serif Pro to Source Serif 4, New Computer Modern names | https://www.overleaf.com/blog/tex-live-2026-is-now-available | Hosted, TL2026 | Confirmed. Relevant to local-font breakage. |
| TL2026 does not support `tabu` or `tabls` (compile errors) | Same blog | Hosted, TL2026 | Confirmed. Closes the expand-27 UNRESOLVED item. |
| TL2026: `enumerate`, `theorem`, `verbatim` are legacy; use `enumitem`, `amsthm`, `fancyvrb` | Same blog | Hosted, TL2026 | Confirmed |
| Blog date "2026-08-18" | Search snippet only | — | UNRESOLVED. Blog body has no date. |
| Server Pro 6.3.0 (release 2026-08-28): TeX Live 2026 available for Sandboxed Compiles | https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x, "Server Pro 6.3.0" | Server Pro + Sandboxed Compiles | Confirmed. Closes the release-note LEAD. |
| Server Pro TeX Live image is set with `TEX_LIVE_DOCKER_IMAGE` | Blog, per earlier fetch | Server Pro | Confirmed in blog. Other variable names were not checked. |
| Custom TeX Live images (Dockerfile, tlmgr) apply to Server Pro with Sandboxed Compiles only; custom-image config is outside support terms | https://docs.overleaf.com/on-premises/maintenance/extending-tex-live (danger hint) | Server Pro + Sandboxed Compiles | Confirmed. Example Dockerfiles use legacy tags (texlive-full:2022.1, 2023.1), so they are date-tagged as legacy. |
| Community Edition: TeX Live is minimal; `tlmgr install` changes are lost unless saved with `docker commit` | https://docs.overleaf.com/on-premises/installation/upgrading-tex-live, "Installing packages" and "Saving your changes" | Community Edition only | Confirmed. Its example output is inconsistent (tlmgr output shows 2025, text says 2021). |
| Community Edition is for trusted users only, because Sandboxed Compiles are unavailable | https://github.com/overleaf/overleaf (README) | Community Edition | Confirmed |
| Community Edition is AGPLv3 | Not re-checked in fetched text | Community Edition | UNRESOLVED |
| DEFAULT_LATEX_COMPILER sets the default compiler for new projects (pdflatex, latex, xelatex, lualatex) | https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x, "Server Pro 6.2.0" | Server Pro | Confirmed |
| Labs rolling TeX Live is experimental and untested | tex-live page | Labs participants | Confirmed. Not standard hosted behavior. |

## Platform vs arbitrary LaTeX

- **Platform (documented Overleaf):** per-project TeX Live version, compiler choice, project-local `.cls`/`.sty`/`.bst` upload, `latexmkrc` search paths, font upload for fontspec, Server Pro image and Sandboxed Compiles configuration, Community Edition tlmgr changes.
- **Arbitrary LaTeX (no Overleaf guarantee):** whether a given class, package, or font compiles. Overleaf documents specific breakages (tabu, tabls) but gives no general compatibility promise.

## Corrections to upstream

- The expand-27 `tabu`/`tabls` concern is confirmed on primary: unsupported in TL2026.
- "Over 5,000 packages" is on the TeX Live page, but the package-count page says "about 4000." Both are reported; the conflict is open.
- "Server Pro with Sandboxed Compiles only" for custom images is correct.
- "Bundled" overstates the font list; the page lists font packages and warns that some catalogue fonts are unavailable.

## Limitations

- Nothing was compiled, so no specific package, class, or font is confirmed to work on Overleaf.
- No Free, Premium, Commons, or Server Pro limits for packages, classes, or uploads were found in any page read. Treat as not documented.
- No exhaustive hosted font or package inventory per engine and TeX Live release was found.
- AI is out of scope. The July 2, 2026 AI-bundling claim was not examined and was not combined with older AI Assist docs.

## Counter-search queries

- "Overleaf supported LaTeX packages list docs.overleaf.com": run; TeX Live and package pages read.
- "Overleaf custom fonts local fonts upload": run; font guide read.
- "Overleaf custom LaTeX classes .cls upload": run; dependency page read.
- "Overleaf Learn Font typefaces bundled fonts": run; Font_typefaces read.
- "Overleaf Writing your own class": run; page read.
- "Server Pro 6.3.0 release notes TeX Live 2026": run; release-notes page read.
- "Overleaf does not find cls file using latexmkrc" (tex.stackexchange 722749): fetch returned no text; UNRESOLVED.
- "Overleaf Commons custom cls sty fonts limits": not run; UNRESOLVED.

## EXPAND

- **LEAD: Package count conflict (about 4000 vs over 5,000).** UNRESOLVED. Two official pages disagree. Next: check which is current for TL2026, or ask Overleaf support.
- **LEAD: tex.stackexchange 722749 (latexmkrc does not find .cls).** UNRESOLVED. Fetch returned no content. Next: retry the thread or search for its accepted answer, then compare with the dependency page.
- **LEAD: Commons-specific limits for uploaded .cls, .sty, or fonts.** UNRESOLVED. No Commons policy found; do not infer equivalence or restriction.
- **LEAD: Hosted font inventory per engine and TeX Live release.** UNRESOLVED. Learn pages give examples and caveats only.
- **LEAD: Community Edition AGPLv3 license.** UNRESOLVED. Not re-checked in fetched text.
- **LEAD: Blog publication date (2026-08-18).** UNRESOLVED. Date is from search only.
