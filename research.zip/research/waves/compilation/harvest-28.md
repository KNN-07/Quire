# Harvest 28: `latexmkrc`, build configuration, and shell escape

Research checked 2026-10-26 against current public Overleaf documentation. This report describes documented configuration and restrictions; it does not claim functional execution or test any project.

## Project-level build configuration

Overleaf runs LaTeX through Perl-based LatexMk. A project may include a file named exactly `latexmkrc` to set LatexMk variables or add compile steps. Documented examples include setting the `TZ` environment variable and extending `TEXINPUTS` to find project dependencies. (Official docs, **“The latexmkrc file,” “Example: setting the time zone,” “Example: setting the TEXINPUTS variable”**: https://docs.overleaf.com/managing-projects-and-files/the-latexmkrc-file)

Overleaf also loads its system-wide `LatexMk` configuration from `/usr/local/share/latexmk/LatexMk` before project-level user configuration. Its rules include Overleaf-specific processing and common package steps such as glossaries and nomenclature. The contents can vary with TeX Live release and selected compiler; the docs describe a project that copies the active file into output files as a way to inspect that instance’s configuration. This is documentation of a provided inspection method, not a claim that this report ran it. (Same official docs, **“Overleaf’s LatexMk file,” “How to view a copy…”**.)

The project Compiler settings expose engine and TeX Live selection. The documented engines are pdfLaTeX (default), LaTeX, XeLaTeX, and LuaLaTeX; TeX Live version is project-specific. (Official docs, **“Selecting a TeX Live version and LaTeX compiler,” “Changing the compiler”**: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler) TeX Live packages and behavior vary by selected release; existing projects are not automatically upgraded when a new release arrives. The rolling TeX Live option is explicitly an experimental Labs feature, changes over time, and is untested/unsupported by Overleaf. (Official docs, **“TeX Live and your Overleaf project,” “Labs Rolling TeX Live Experiment”**: https://docs.overleaf.com/troubleshooting-and-support/tex-live)

## Shell escape: cloud versus self-hosted

Shell escape enables TeX’s `\write18` system-command mechanism. Overleaf’s official compiler-option article lists `--shell-escape` as enabling system commands and `--no-shell-escape` as disabling them; it also lists LuaTeX’s `--shell-restricted` mode as restricting commands to those in `texmf.cnf`. The article search result exposed this option text, but the page could not be opened due to a redirect loop, so the exact article URL is recorded and the full article detail is **UNRESOLVED** here: https://www.overleaf.com/learn/latex/TeX_engine_command_line_options_for_pdfTeX%2C_XeTeX_and_LuaTeX.

Do not generalize the self-hosted instructions to Overleaf’s hosted service. Current on-premises troubleshooting docs say `\write18` is disabled by default in **Community Edition**, explaining that compiles occur in the same ShareLaTeX container; the documented opt-in is a root-project `latexmkrc` containing `$pdflatex = 'pdflatex --shell-escape';`. This is an administrator-controlled deployment setting, not a general guarantee about arbitrary hosted projects. The cited section names Community Edition specifically; equivalent defaults or guarantees for Server Pro are **UNRESOLVED**. (Official docs, **“Please verify that you have enabled system calls…”**: https://docs.overleaf.com/on-premises/support/troubleshooting)

Packages or documents that rely on external executables remain distinct from Overleaf platform support. In particular, enabling a TeX engine flag is not evidence that every requested external program is installed, available on `PATH`, or allowed by a deployment’s policy. The official docs above do not establish a universal command allowlist or provide a hosted-service shell-escape guarantee. **UNRESOLVED:** exact current hosted shell-escape policy, permitted command set, and plan-by-plan availability; do not infer these from Community Edition guidance.

## Availability and boundaries

- **Free/premium/AI:** The cited build-setting and `latexmkrc` documentation does not state plan-tier restrictions. Availability by plan is **UNRESOLVED**; no AI feature is documented for this angle.
- **Community Edition:** shell escape is documented disabled by default, with a project `latexmkrc` opt-in as above.
- **Server Pro:** docs mention Server Pro in other troubleshooting context, but do not specify its shell-escape default here; **UNRESOLVED**.
- **Hosted Overleaf:** docs establish LatexMk, project compiler and TeX Live settings, but the sources reviewed do not establish a blanket shell-escape state or user-controlled switch for hosted compilation.
- **Arbitrary LaTeX capabilities:** engine flags and Perl `latexmkrc` configuration are underlying tools/configuration mechanisms. Their existence does not prove that any particular external binary, filesystem operation, or system call succeeds on a given Overleaf deployment.

## EXPAND

- **LEAD — open the official engine-options article:** its search-indexed excerpt identifies enabled, disabled, and restricted shell-escape flags, but direct opening failed with a redirect loop. Revisit for authoritative full-page wording.
- **LEAD — hosted shell-escape and plan matrix:** current official sources reviewed do not say whether hosted projects may enable it, what commands are permitted, or which plans expose it. Leave unresolved rather than infer from CE.
- **LEAD — Server Pro default:** current troubleshooting guidance gives a CE default only; seek an explicit Server Pro source before assigning one.
