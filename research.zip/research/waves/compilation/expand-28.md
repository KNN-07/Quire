# Expanded angle 28: `latexmkrc`, build configuration, and shell escape

Research checked October 26, 2026, using public official Overleaf documentation and the official Overleaf GitHub repository. This report records documented behavior, not functional execution or authenticated tests.

## Project configuration and build selection

Overleaf documents `latexmkrc` as a project-level file named exactly `latexmkrc` that customizes its Perl-based LatexMk compilation process; it can set LatexMk variables or add compile steps. Official examples set `TZ` and extend `TEXINPUTS`. The project file is read after Overleaf’s system-wide `/usr/local/share/latexmk/LatexMk`; that system config includes Overleaf processing and common package rules, and may vary across TeX Live releases. The docs offer a project example for exposing the active config as an output file, but that example uses `\ShellEscape` and does not prove arbitrary commands are enabled in every environment. Source: https://docs.overleaf.com/managing-projects-and-files/the-latexmkrc-file — headings “The latexmkrc file,” “Overleaf’s LatexMk file,” and “How to view a copy of Overleaf’s LatexMk file.”

The supported project compiler choices are pdfLaTeX (default), LaTeX, XeLaTeX, and LuaLaTeX; the project Compiler settings also select a project-specific TeX Live release. Overleaf’s TeX Live page says previous releases remain available, while the Labs rolling release is experimental, changes over time, and is untested. These choices affect available tools and packages, so config examples should not be assumed identical across releases. Sources: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler — “Changing the compiler” and TeX Live selection; https://docs.overleaf.com/troubleshooting-and-support/tex-live — “Can I use the latest version of TeX Live?” and “What packages changed between TeX Live releases?”

The official `minted` guide says projects using `minted` work on Overleaf without local Pygments installation or special compile commands. This documents a supported package workflow, not a general shell-access promise. Source: https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted — introductory note on local Pygments versus Overleaf.

## Shell escape: engine mechanism versus platform policy

Overleaf’s official engine-options article is available at https://www.overleaf.com/learn/latex/TeX_engine_command_line_options_for_pdfTeX%2C_XeTeX_and_LuaTeX (also indexed at https://pt.overleaf.com/learn/latex/TeX_engine_command_line_options_for_pdfTeX%2C_XeTeX_and_LuaTeX). It describes `[-no]-shell-escape` as disabling/enabling `\write18` and `-shell-restricted` as restricting system commands to a list in `texmf.cnf`. This is upstream engine option documentation, not evidence that hosted users can set any such flag or that a particular command will run. Opening the main English page failed in this research; the official localized page’s indexed text supplies the option definitions.

For on-premises Community Edition, current troubleshooting docs explicitly say `\write18` is disabled by default and describe an opt-in root-project `latexmkrc` setting `$pdflatex = 'pdflatex --shell-escape';`. Treat this as deployment-specific guidance; it does not establish an equivalent Server Pro default. Source: https://docs.overleaf.com/on-premises/support/troubleshooting — “Please verify that you have enabled system calls. For pdflatex, this is 'pdflatex -shell-escape'.”

An older Overleaf article (post-publication update dated May 13, 2017) says hosted Overleaf enabled shell escape automatically for the `markdown` package. This is historical, package-specific evidence, not a current universal hosted policy or plan matrix. Source: https://www.overleaf.com/learn/latex/Articles/Markdown_into_LaTeX_with_Style — introduction, dated update.

## Availability and boundaries

- **Hosted Free/premium/AI:** no plan-specific shell-escape setting or command allowlist found in reviewed current primary documentation; **UNRESOLVED**.
- **Community Edition:** disabled by default per current on-premises troubleshooting docs; documented project-level opt-in above.
- **Server Pro:** shell-escape default/policy **UNRESOLVED**; do not extrapolate the CE statement.
- **Overleaf Commons:** no angle-specific availability statement found; **UNRESOLVED**.
- **Arbitrary LaTeX/engine capabilities:** flags, Perl configuration, or package requirements describe underlying tools, not a guarantee an external binary exists, is on `PATH`, is allowed, or succeeds on a particular deployment.
- **Deprecation:** no deprecation of `latexmkrc` or shell-escape settings documented in the sources reviewed. Older package-specific advice is date-tagged rather than combined with current policy.

## EXPAND

- **Engine-options article lead: closed.** The official English article URL is indexed but direct open failed; the official Portuguese Overleaf version exposes the same option definitions. It documents engine capabilities only.
- **Hosted shell-escape and plan matrix lead: unresolved.** Current reviewed official docs do not specify hosted command policy, user control, or plan-by-plan availability; the 2017 Markdown article is too old and narrow to fill this gap.
- **Server Pro default lead: unresolved.** The current on-premises troubleshooting section names Community Edition only; no explicit Server Pro shell-escape default located.
- **Omitted functionality/deprecation check: closed within scope.** Current primary docs also document compiler/TeX Live selection and `minted` support; no shell-escape/latexmkrc deprecation surfaced. No functional execution is claimed.
