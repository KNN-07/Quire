# Verify angle 30: R knitr, PythonTeX, minted, plots, external tools

Verdict: PARTIAL. Knitr, minted (basic use), pgfplots, and TikZ externalization are supported by current or recent Overleaf docs. PythonTeX hosted status, hosted shell-escape policy by tier, and minted custom lexers on TeX Live 2026 remain UNRESOLVED. The Python Script Runner is documented as a Labs experiment, but its plan tier is not stated.

Separation: "platform" means Overleaf-hosted behavior. "LaTeX" means package behavior that is independent of the host. Tier availability is marked UNSTATED when the page names no tier.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Knitr (.Rtex/.Rnw) projects are supported; `cache=TRUE` is not supported on Overleaf; `fig` label prefix is used; `read_chunk` scripts are not cached | https://docs.overleaf.com/integrations-and-add-ons/r-code-knitr | Platform; tier UNSTATED | Confirmed (primary) |
| PythonTeX is not supported on Overleaf v2, because of a security-model change | https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ ; Overleaf support answer at https://tex.stackexchange.com/questions/534049/pythontex-not-working-on-current-overleaf-compiler | Platform; tier UNSTATED. Date-tag: legacy, pre-2026 | Legacy, primary-dated. No current 2026 primary page found. UNRESOLVED for today |
| minted works out of the box on Overleaf; `\usepackage{minted}` with `\begin{minted}{python}` | https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted | Platform; tier UNSTATED | Confirmed (primary, recent) |
| Custom minted lexers work only on TeX Live 2022 or earlier | https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted | Platform; TL2026 status not stated | Legacy wording. UNRESOLVED on TL2026 |
| TeX Live 2026 is available; existing projects keep their TeX Live version; the version can be changed in project Settings > Compiler | https://www.overleaf.com/blog/tex-live-2026-is-now-available (dated Aug 18, 2026) | Platform; tier UNSTATED | Confirmed (primary). Blog does not mention minted, pgfplots, or PythonTeX |
| Server Pro admins can move to TeX Live 2026 by pointing the TeX Live Docker image variables at the 2026 image | same blog, "TeX Live 2026 in Server Pro" | Server Pro | Confirmed (primary) |
| `\write18` / shell escape is disabled by default in Community Edition; a `latexmkrc` with `--shell-escape` is one documented route | https://docs.overleaf.com/on-premises/support/troubleshooting | Community Edition only | Confirmed for CE. No Server Pro guarantee is stated. Hosted policy UNRESOLVED |
| Community workarounds enable shell escape in texmf.cnf | https://github.com/overleaf/overleaf/issues/1341 | CE, unofficial | Non-primary, unofficial. Not cited as fact |
| Python Script Runner runs Python in-browser with Pyodide 0.29.3 (Python 3.13.2); generated files are saved to the file tree | https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments | Labs opt-in; plan tier UNSTATED | Confirmed (primary). Labs page warns features may change, with no stability guarantee |
| The Python Script Runner executes Python on the server (or arbitrary executables) | none | none | Not supported by any primary source. Do not claim |
| pgfplots: basic 2D/3D plots, `\addplot`, `\addplot3`, `\addlegendentry`, `contour gnuplot`; gnuplot "works fine in Overleaf" | https://www.overleaf.com/learn/latex/Pgfplots_package | Platform; tier UNSTATED | Confirmed (primary). Local use of contour gnuplot needs gnuplot installed |
| TikZ externalization: `\tikzexternalize` must be in the main file; `prefix=` folder must exist and contain a dummy file | https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts/reducing-the-compile-time-for-diagrams | Platform; tier UNSTATED | Confirmed (primary) |
| Externalized output is garbage-collected; uploaded `.pdf/.md5/.dpth` files are not | same page | Platform | Confirmed (primary) |
| Compile timeout is set per plan. Free plan is about 10 s; premium is about 240 s | https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits (search snippet only) | Free vs premium | Snippet-verified. Full page not fetched. Treat numbers as UNRESOLVED until full page is read |
| Premium features are project-level and based on the project owner's subscription | https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features (search snippet) | Premium | Snippet-verified |

## Limits and contradictions

- PythonTeX: the only Overleaf-authored statement found is the v2 FAQ (dated). The 2015 GitHub issue #313 is legacy (closed 2015). The gist hack and LinkedIn posts are non-primary and are not cited as facts.
- minted: the learn page says it works out of the box. The community Stack Exchange thread says the TeX Live version must match a working minted setup. Those two are not contradictory, but TL2026 minted behavior is unverified.
- The Python Script Runner is a Labs experiment. Labs participation terms and cost were not confirmed. The page warns it can change or be removed.
- Hosted shell-escape by tier: no primary page was found. The only primary statement is about Community Edition.
- The July 2, 2026 AI-bundling blog was not read. It is outside this angle and must not be merged with older AI Assist docs.

## Counter-search queries

1. "Overleaf PythonTeX support" (exa results: Overleaf support answer on TeX StackExchange; GitHub issue #313)
2. "Overleaf shell-escape minted allowed plan" (exa results: learn minted page; plan-limits snippet)
3. "Overleaf Python Script Runner Labs plan availability" (Labs about page; Labs live-experiments page)

## EXPAND

- LEAD: Read the full plan-limits page to confirm the free and premium compile timeouts. Reason: only search snippets were seen.
- LEAD: Find a 2026 official Overleaf statement on PythonTeX hosted status. Reason: only a dated v2 FAQ exists.
- LEAD: Find a hosted shell-escape or minted policy by tier on docs.overleaf.com. Reason: only Community Edition is documented.
- LEAD: Confirm minted custom-lexer status on TeX Live 2026. Reason: learn page wording predates TL2026.
- LEAD: Check the Labs participate page for terms and cost of the Python Script Runner. Reason: plan tier not stated on the experiment page.
- NONE: knitr, pgfplots, and TikZ externalization need no further lead for this angle beyond tier wording, which the pages do not state.
