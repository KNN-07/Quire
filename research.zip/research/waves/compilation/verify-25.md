# Verify angle 25: Overleaf compile errors, warnings, logs, and troubleshooting

Snapshot: October 26, 2026. Sources: official Overleaf docs (docs.overleaf.com), overleaf.com blog, and official overleaf/toolkit and overleaf/overleaf GitHub repositories. No compilation was run and no authenticated or paid action was taken.

Verdict: **PARTIAL.** The core error/warning/log/timeout workflow is confirmed by primary pages. Three items remain unresolved: the July 2, 2026 AI-bundling date (not visible in the fetched blog text), the August 18, 2026 TeX Live 2026 date (not visible in the fetched text), and Server Pro/Community parity for logs and diagnostics.

## Confirmed: diagnostics and log workflow (Hosted platform)

- **Warnings vs. errors.** Warnings appear light orange and are often automatic adjustments; errors appear red and can block output; underfull/overfull box warnings are shown in blue. Source: [Fixing LaTeX errors](https://docs.overleaf.com/troubleshooting-and-support/fixing-latex-errors), heading "Is there an error or warning?" The harvest claim is confirmed.
- **Line navigation.** When a line number is given, clicking the message jumps to the source. Same page, heading "Does the message indicate a specific error or line number?"
- **Default compile mode.** Overleaf tries to produce a PDF despite errors. Source: [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project), "Compile error handling."
- **Stop on first error.** Stops compiling at the first error; no PDF is produced. It is per-user, per-project, and recommended when debugging or hitting timeouts. Source: [Stop on first error](https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error), "The Stop on first error compilation mode."
- **Syntax checks.** As-you-type checks flag unmatched braces, undefined commands, and `\begin`/`\end` mismatches. This is distinct from the compile log. Source: [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project), "Syntax checks."
- **Generated files.** `.aux`, `.log`, and `.toc` are listed under Logs and output files, under "Other logs and files." Standard source downloads omit them. Source: [Generated files](https://docs.overleaf.com/navigating-in-the-editor/generated-files).
- **Cache actions.** "Recompile from scratch" (Recompile menu) deletes generated files and recompiles. "Clear cached files" (Logs panel) deletes them without compiling. Source: [Clearing the project cache](https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache), "Recompile from scratch" and "Clear cached files."

## Confirmed: timeouts and plan limits (Hosted, all plans)

- Compile timeout: **10 seconds on Free, 240 seconds on premium plans** (Standard, Pro, Student named in the premium section). Source: [Plan limits](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits), table row "Compile timeout." Values are a dated snapshot.
- Timeout steps: fix errors with Stop on first error, then try Fast [draft] (skips images, replaces them with empty boxes), then assess slow content. Source: [Fixing and preventing compile timeouts](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), Steps 1-3.
- `\tracingall` can write large log data and slow compiles; the docs recommend the `trace` package instead. Same page, "Including tracing or debugging calls."

## Confirmed: non-compile failures

- A blank PDF or missing log can be a delivery problem. The editor needs access to `compiles.overleafusercontent.com`; the docs suggest trying the browser PDF viewer, disabling extensions, and checking network access. Source: [Resolving PDF rendering and project loading problems](https://docs.overleaf.com/troubleshooting-and-support/resolving-pdf-rendering-and-project-loading-problems), "PDF rendering or project loading issues."

## Confirmed: TeX Live 2026 migration (Hosted; TeX engine/package behavior)

Source: [TeX Live 2026 is now available](https://www.overleaf.com/blog/tex-live-2026-is-now-available).

- Existing projects keep their creation-time TeX Live version; switching is optional and can introduce errors (heading "Will my existing projects work as usual?").
- `tabu` and `tabls` are no longer supported in TL2026 and cause compile errors.
- `frenchb` and `francais` options are obsolete; use `french`.
- `varioref` with KOMA-Script classes triggers a TeX capacity error; the post gives a workaround (`\def\extrasenglish{}` in the preamble).
- Source Pro and New Computer Modern fontspec names changed.
- polyglossia/xepersian with `array` can error on Arabic text in tabular-like environments.

These are TeX/package changes, not Overleaf log-parser features.

## Confirmed: AI (Error Assist), with date caveat

- Error Assist explains compile errors and suggests fixes in the editor. Source: [Overleaf AI now a part of Overleaf plans](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), "How Overleaf AI works."
- The blog says AI is included in all plans at no extra cost, with allowances varying by plan. Free has Basic without AI Assistant; Student has Basic with Assistant; Commons (basic) has no Assistant; Commons AI gives Max plus Assistant.
- Current docs: [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features), "AI allowance by plan" table. Free: Basic, Assistant not included. Student: Basic, Assistant included. Each AI use counts against the daily allowance, which resets every 24 hours. Users can disable AI in Account settings > Integrations.
- **Date:** the harvest says July 2, 2026. The fetched blog text contains no visible date, so the date is **UNRESOLVED** here.
- **Legacy add-on docs:** I did not open an older separate-add-on page, so no legacy claim is made here.

## Contradictions and unresolved items

| Item | Status |
|---|---|
| Error Assist requires a full logged error and is unavailable for live syntax-check errors | UNRESOLVED: not found in fetched AI-features text |
| TeX Live 2026 published August 18, 2026 | UNRESOLVED: date not in fetched text |
| AI bundled July 2, 2026 | UNRESOLVED: date not in fetched text; content confirmed |
| Import troubleshooting (main file in subfolder, TeX Live mismatch) | UNRESOLVED: upload page not fetched |
| Server Pro / Community parity for logs, cache, diagnostics | UNRESOLVED: only sandboxing differences are documented |

## Deployment boundary (on-premises)

- Sibling-container sandboxed compiles are a Server Pro feature and are not available in Community Edition. Source: [Overleaf Toolkit: Sandboxed Compiles](https://github.com/overleaf/toolkit/blob/master/doc/sandboxed-compiles.md), "Sandboxed Compiles" and the Community note.
- The compile-process wiki says it has moved and that its sandboxed-compile description applies to Server Pro; Server CE uses a simple sub-process. Source: [Editor and Compile Process](https://github.com/overleaf/overleaf/wiki/Editor-and-Compile-Process), notice at top.
- Neither source establishes log-display or diagnostic parity; this stays UNRESOLVED.

## Platform vs. TeX boundary

Platform (Overleaf): log pane, navigation, cache actions, compile modes, timeout enforcement, Error Assist, PDF delivery. TeX/LaTeX: error semantics, box diagnostics, generated auxiliary files, package behavior, and the fixes to source.

## Counter-search queries (proposed; primary pages were checked directly)

- `site:docs.overleaf.com "Error Assist" daily allowance full log error`
- `site:overleaf.com blog "July 2, 2026" AI plans`
- `site:overleaf.com "TeX Live 2026" "August 18"`
- `site:docs.overleaf.com upload project main document subfolder TeX Live version`
- `site:github.com overleaf toolkit "Server Pro" compile logs`

## EXPAND

- LEAD: Confirm the Error Assist trigger rules (full logged error only; no live-check errors) on a current AI-features page or Error Assist subpage.
- LEAD: Confirm the July 2, 2026 AI announcement date and the August 18, 2026 TeX Live date from dated sources.
- LEAD: Open the upload/import troubleshooting page for main-file and TeX Live mismatch guidance.
- Open, no lead: Server Pro/Community parity for logs and diagnostics. The official sources reviewed do not establish it, so it stays unresolved.
