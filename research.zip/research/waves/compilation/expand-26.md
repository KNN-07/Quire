# Expand 26: Timeouts, resource limits, and performance tuning

Research date: 2026-10-26. Upstream: harvest-26.md. Method: primary docs pages and the overleaf/overleaf GitHub pages were fetched; items marked "snippet" come only from search results and were not opened in full. No authenticated testing. No compute, CPU, or RAM allocation was found in any source reviewed.

## Hosted overleaf.com: platform limits

- **Compile timeout by plan (platform, Free and Premium labels).** The [Plan limits](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits) page, "Overleaf plan limits" table, lists 10 seconds on the Free plan and 240 seconds on Premium plans. Its "More about our premium plans" section names Standard, Pro, and Student as the premium plans. The same table lists 2,000 files per project, 7 MB editable material per project, 2 MB per editable text file, and 50 MB per upload.
- **Project size is unlimited but not recommended.** Footnote † on the same page says there is no enforced total size cap. It recommends at most 500 MB per project, or under 100 MB with GitHub sync or Git integration, and says projects over 4 GB may have problems such as project copy.
- **Compile timeout is per plan, not a stated resource quota.** The [timeout guide](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts) says a timeout means the build did not finish within "the timeout limit for your Overleaf plan." It does not state CPU, RAM, or concurrency allocations.
- **Pricing page (Basic/Premium labels).** [overleaf.com plans](https://www.overleaf.com/user/subscription/plans) describes a "Basic compile timeout" on the Student free tier. The "24x compile timeout" wording appears only in a German-locale search snippet (de.overleaf.com) and was not opened, so it is treated as unverified on the English page. It is consistent with 10 s versus 240 s but not confirmed here.

## Hosted performance controls (platform features)

- **Stop on first error.** The [timeout guide](https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts), Step 1, recommends this mode because errors can block the latexmk build until it times out. It is a diagnostic mode, not a speedup.
- **Fast [draft] mode.** Step 2 of the same guide (not the Recompiling page, as the harvest stated) describes draft mode as a faster mode for editing. The [Recompiling your project](https://docs.overleaf.com/getting-started/recompiling-your-project) page documents **Recompile from scratch**, which clears helper files that are otherwise kept to speed later builds.

## On-premises (Community Edition and Server Pro)

- **Default timeout 180 s, configurable.** The [Project limits](https://docs.overleaf.com/on-premises/support/project-limits) page lists the compile timeout default as 180 seconds. [Project management](https://docs.overleaf.com/on-premises/user-and-project-management/project-management), "Updating project compile timeout," says to set `COMPILE_TIMEOUT` in `config/variables.env` (example: `COMPILE_TIMEOUT=300`) and recreate the sharelatex container with `bin/up -d`. A danger hint says not to push the value past 10 minutes because another component will time out.
- **Existing users keep their stored value.** Overleaf PR [#805](https://github.com/overleaf/overleaf/pull/805) (merged; opened 2020-10-22; snippet) exposed `COMPILE_TIMEOUT` and raised nginx timeouts to 10 minutes. Issue [#955](https://github.com/overleaf/overleaf/issues/955) (snippet, maintainer comment dated 2021-10-08) says existing user records may need manual database updates. The 10-minute ceiling in current docs matches this.
- **Sandboxed Compiles are Server Pro only.** The [Sandboxed Compiles](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles) page says each compile runs in its own Docker container with limited capabilities and no host-network access. It requires the Docker socket to be mounted. The fetched text gives no numeric CPU or memory limits and no compile timeout setting.
- **Community Edition has no sandbox.** [Server Pro vs. Community Edition](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition) warns that without sandboxing, compiles run with the container's privileges and that CE suits only fully trusted users. This is a security distinction, not a performance one.

## Corrections to the harvest

1. The harvest says current on-prem docs do not state a Community Edition timeout value. The on-prem Project limits and Project management pages both state a 180 s default for on-premises deployments. They do not split this value by edition.
2. The harvest's "Fair use limits" section, the "tabularray" mention, and the "generate drawings locally" advice were not found in the fetched timeout guide text. They are UNRESOLVED here and are not used as facts.
3. The harvest's "2024-08-28" maintainer statement that CE does not enforce timeouts is **conflicting**. Issue [#1166](https://github.com/overleaf/overleaf/issues/1166) body is a user question about whether a default timeout exists. A search snippet of the thread quotes a maintainer saying CE's default compile timeout is 180 s, set through code or env. I could not open the 2024-08-28 comment, so the harvest claim stays UNRESOLVED.

## Third-party (not official)

Discussions [overleaf-cep #37](https://github.com/yu-i-i/overleaf-cep/discussions/37) and [#204](https://github.com/yu-i-i/overleaf-cep/discussions/204) are from a community fork. They say the clsi timeout is stored per user in MongoDB (`features.compileTimeout`), so changing `COMPILE_TIMEOUT` does not update existing users. They are not Overleaf guidance.

## Dated and legacy items

- Issue #955 and PR #805 are 2020–2021 records. Current on-prem docs supersede them for the 180 s default.
- The Sandboxed Compiles image list marks 2021–2023 TeX Live images as "legacy" (page as fetched 2026-10-26).
- AI bundling (July 2, 2026 blog versus older separate AI Assist docs) is not relevant to this angle and was not investigated.

## Sources

- https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits (verified)
- https://docs.overleaf.com/troubleshooting-and-support/fixing-and-preventing-compile-timeouts (verified)
- https://docs.overleaf.com/getting-started/recompiling-your-project (verified)
- https://docs.overleaf.com/on-premises/support/project-limits (verified)
- https://docs.overleaf.com/on-premises/user-and-project-management/project-management (verified)
- https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles (verified)
- https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition (verified)
- https://www.overleaf.com/user/subscription/plans (verified, English page; 24x is snippet-only from de.overleaf.com)
- https://github.com/overleaf/overleaf/issues/1166 (body verified; 2024-08-28 comment unverified)
- https://github.com/overleaf/overleaf/pull/805 (title, merge state verified; body via snippet)
- https://github.com/overleaf/overleaf/issues/955 (snippet)
- https://github.com/yu-i-i/overleaf-cep/discussions/37 and /204 (snippet, third-party)

## EXPAND

- **LEAD: harvest "2024-08-28" CE enforcement claim.** UNRESOLVED. Conflicts with a search snippet. Needs the full issue thread.
- **LEAD: "Fair use limits" and "tabularray" items in the harvest.** UNRESOLVED. Not found in the timeout guide text.
- **LEAD: Server Pro timeout and sandbox resource settings by release.** UNRESOLVED. No numeric CPU, memory, or per-version defaults were found.
- **LEAD: "24x" plan multiplier on the English pricing page.** UNRESOLVED. Only the German snippet was seen.
- **Closed as duplicate:** the harvest's Plan-limits, Stop-on-first-error, and Recompile items are covered above. The COMPILE_TIMEOUT item is covered by the on-prem Project management page and PR #805.
