# Verify 28: latexmkrc, build configuration, and shell escape

Checked October 26, 2026 against official Overleaf documentation. Documented behavior only; no project was compiled and no authenticated or paid feature was tested.

**Verdict: PARTIAL.** The latexmkrc and build-configuration claims are confirmed by primary docs. The hosted shell-escape policy, plan availability, and Server Pro default remain unresolved.

## Confirmed findings

**latexmkrc and system LatexMk.** A project may include a file named `latexmkrc` to set LatexMk variables or add compile steps. Official examples set `$ENV{'TZ'}` and extend `TEXINPUTS`. Overleaf's system file `/usr/local/share/latexmk/LatexMk` is read before user-level config, and it may vary between TeX Live releases. Source: https://docs.overleaf.com/managing-projects-and-files/the-latexmkrc-file, headings "The latexmkrc file", "Example: setting the time zone", "Overleaf's LatexMk file".

**Viewing the system LatexMk.** The same page provides a project that uses the `shellesc` package and `\ShellEscape{cp ...}` to copy the system file into output. This is a documented example that depends on shell escape. It does not show that arbitrary commands are allowed, and I did not run it.

**Compiler and TeX Live selection.** Compiler choices are pdfLaTeX (default), LaTeX, XeLaTeX, and LuaLaTeX. TeX Live is set per project. Source: https://docs.overleaf.com/getting-started/recompiling-your-project/selecting-a-tex-live-version-and-latex-compiler, headings "Changing the compiler", "How do I change a project's TeX Live version?".

**Upgrade and legacy behavior.** New projects use the latest TeX Live on the servers. Existing projects are not upgraded automatically. Legacy versions have no announced end date and may be phased out. Source: https://docs.overleaf.com/troubleshooting-and-support/tex-live, "TeX Live and your Overleaf project", "What are the 'Legacy' versions".

**Labs rolling TeX Live (Labs program).** The rolling build is experimental, changes monthly, is untested by Overleaf, and is not supported. Same source, "Labs Rolling TeX Live Experiment".

**Engine flags (underlying tools, not platform policy).** The engine `--help` output on Overleaf's learn page lists `[-no]-shell-escape` and `-shell-restricted` for pdfTeX and XeTeX. For LuaTeX it lists `--[no-]shell-escape`, `--shell-restricted` (commands limited to a list in `texmf.cnf`), and `--safer`. Source: https://www.overleaf.com/learn/latex/TeX_engine_command_line_options_for_pdfTeX%2C_XeTeX_and_LuaTeX, engine help output.

**Community Edition (on-premises).** `\write18` is disabled by default in Community Edition because compiles share one container. An administrator can opt in with a root-project `latexmkrc` containing `$pdflatex = 'pdflatex --shell-escape';`. Source: https://docs.overleaf.com/on-premises/support/troubleshooting, heading "Please verify that you have enabled system calls".

**Server Pro.** Sandboxed Compiles are "the recommended approach" because documents may run arbitrary shell commands. Each compile runs in a separate container with limited capabilities. Without sandboxing, compiles share the main container, and the docs say users then have full read/write access to its resources. Without sandboxing, Server Pro falls back to a basic TeX Live scheme. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles, "Improved security" and "Easier package management". This page does not state Server Pro's `\write18` default.

**minted (package support).** The official guide says minted documents "work out of the box" on Overleaf without a local Pygments install or special compile commands. Source: https://www.overleaf.com/learn/latex/Code_Highlighting_with_minted, "Introduction". The same guide says custom lexers work only in TeX Live 2022 or earlier.

## Corrections to upstream files

- **Harvest-28 said the engine-options article could not be opened (redirect loop).** It opened on this pass. The content is engine `--help` output, not explanatory prose. Treat it as a flag reference.
- **Expand-28 cited a Portuguese Overleaf mirror of the engine page.** I did not open it, so I drop that citation.
- **Expand-28 said the system-config claim about TeX Live variation was verified.** It is confirmed, but from the latexmkrc page, not the TeX Live page.

## Legacy and secondary (date-tagged, not current policy)

- **2017 Markdown article** (update dated 13 May 2017): says Overleaf adds `--shell-escape` automatically for the `markdown` package. Historical and package-specific. Source: https://www.overleaf.com/learn/latex/Articles/Markdown_into_LaTeX_with_Style, introduction.
- **Unverified secondary claim:** a TeX Stack Exchange answer (undated snippet) says Overleaf has shell escape enabled by default, but only for files in the project root. I did not open the page, so this is UNRESOLVED and not used as evidence.

## Unresolved

- Hosted shell-escape state, permitted command set, and whether users can change it: no current primary doc found. **UNRESOLVED.**
- Free, premium, Commons, and AI availability of shell escape: no primary source. **UNRESOLVED.**
- Server Pro `\write18` default: **UNRESOLVED.**
- GitHub `server-ce/config/latexmkrc`: fetch returned an empty placeholder. **NOT RETRIEVED.**
- TUGboat minted v3 paper (restricted shell escape for minted's executable): search snippet only. **UNRESOLVED** until opened.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Project `latexmkrc` customizes LatexMk | docs.overleaf.com latexmkrc page | All projects | Confirmed |
| System LatexMk read before user config | same | Hosted | Confirmed |
| Compiler choices (pdfLaTeX default, LaTeX, XeLaTeX, LuaLaTeX) | docs.overleaf.com TeX Live/compiler page | Hosted | Confirmed |
| Per-project TeX Live; no automatic upgrade | docs.overleaf.com TeX Live page | Hosted | Confirmed |
| Labs rolling TeX Live is untested and unsupported | docs.overleaf.com TeX Live page | Labs | Confirmed |
| `\write18` disabled by default in CE; opt-in via latexmkrc | docs.overleaf.com on-prem troubleshooting | Community Edition | Confirmed |
| Sandboxed Compiles recommended for Server Pro | docs.overleaf.com sandboxed-compiles | Server Pro | Confirmed (default not stated) |
| minted works out of the box on Overleaf | overleaf.com learn minted | Hosted | Confirmed (package claim only) |
| Hosted shell-escape policy and command set | none found | Hosted | UNRESOLVED |
| Markdown package auto shell escape | overleaf.com 2017 article | Hosted (historical) | Confirmed, date-tagged 2017 |

## Counter-search queries

- "Overleaf hosted shell escape default texmf.cnf site:overleaf.com"
- "Overleaf shell-restricted command list hosted compile"
- "Overleaf Server Pro shell escape default sandboxed compiles"
- "overleaf server-ce config latexmkrc github raw"
- "minted v3 restricted shell escape TeX Live 2024 Overleaf"

## EXPAND

- **LEAD: hosted shell-escape policy and command allowlist.** Search official Overleaf support/blog for a hosted statement. Reason: none found in current docs.
- **LEAD: Server Pro `\write18` default.** Check the Server Pro configuration and environment-variable docs. Reason: the sandboxed-compiles page does not state it.
- **LEAD: GitHub `server-ce/config/latexmkrc` and TUGboat minted v3 paper.** Retry direct opens. Reason: both were not retrieved.
- **No further lead:** the AI bundling date (July 2, 2026) is outside this angle and was not investigated.
