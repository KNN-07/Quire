# Expanded research 29: Bibliography tools and builds

Research checked October 26, 2026. These are documented product capabilities, not results of a live or authenticated compile.

## Project features and plan boundaries

Overleaf projects support creating, uploading, and editing `.bib` files, as well as starting from a bibliography template. Official docs explicitly cover the BibTeX, natbib, and biblatex systems. These are ordinary project-file and LaTeX workflows; docs do not mark them premium. Source: https://docs.overleaf.com/citing-and-references/working-with-.bib-files — “Creating your bibliography database,” “Uploading your bibliography database,” “Supported bibliography management systems.”

Overleaf’s editor offers simple reference search across citation keys in project `.bib` files to all users, alongside citation-key autocomplete. Advanced reference search can search linked managers and is premium. The manager integrations currently named in documentation are ReadCube, Zotero, and Mendeley; premium access is described as applying to Overleaf Premium users, Commons participants, group-subscription members, and individual subscription owners. Free users can still export `.bib` files from a manager and upload them. Sources: https://docs.overleaf.com/citing-and-references/adding-citations-and-references — “How can Overleaf help to find and cite references?”; https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations — opening notice and “Reference Manager integrations”; https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley — opening note.

This is platform functionality, distinct from LaTeX's ability to consume bibliography data. Public docs do not specify which manager integrations or search features are enabled in every Commons or self-hosted deployment.

## BibTeX, biblatex, and Biber

The documented BibTeX pattern uses `\bibliographystyle{...}` and `\bibliography{...}` with cite keys in `.bib` data. BibTeX processes citation data and style into a `.bbl`; LaTeX then uses subsequent passes to include the bibliography and resolve citation labels. Only cited records normally print; `\nocite{*}` can request all entries. Source: https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex — “Enter BibTeX,” “Some notes on using BibTeX and .bib files.”

For biblatex, Overleaf documents `\usepackage{biblatex}`, `\addbibresource{file.bib}`, citation commands, and `\printbibliography`, with configurable style/sorting and filtered or sectioned bibliographies. Its current learning article recommends biblatex for new work absent a template or external requirement, citing flexibility/localization and active development. Templates may mandate another system. Sources: https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX — “Introduction,” “Basic usage,” “Customizing the bibliography”; https://docs.overleaf.com/citing-and-references/creating-a-bibliography — “LaTeX reference management systems.”

The same guide calls Biber biblatex’s default and recommended backend, and lists BibTeX as an alternative backend for sorting (not for using BibTeX `.bst` styles). Overleaf examples demonstrate biblatex+Biber. This documents a hosted workflow, but not a version matrix or a guarantee that arbitrary custom styles/configurations compile. Source: https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX — “Basic usage”; https://www.overleaf.com/latex/examples/tagged/biber — “Recent.”

## Build and output behavior

Overleaf says its `latexmk` build tool reruns LaTeX and associated bibliography processors as necessary; a bibliography may therefore need multiple processing steps and take longer to refresh. Generated `.bbl` output is available through Logs and output files; submission ZIP workflows can include generated files. Standard source downloads exclude generated files. Sources: https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex — “A note on compilation times,” “Enter BibTeX”; https://docs.overleaf.com/navigating-in-the-editor/generated-files — “Downloading generated files along with the source,” “How to download a `.bbl` file.”

Toolchain/deployment boundary: public Overleaf Community Edition and Server Pro materials describe separate deployment products, but the bibliography documentation does not state Biber/BibTeX versions or per-deployment guarantees. The opened deployment materials do not establish bibliography feature parity or plan entitlements; do not infer parity or availability from hosted examples. Sources: https://github.com/overleaf/overleaf/wiki — “Home” (Community Edition and Server Pro developer documentation); https://github.com/overleaf/toolkit — README.

## Legacy and duplicate handling

The harvest's ReadCube/Mendeley/Zotero statement is current in the docs inspected. The older BibTeX article names EndNote/Paperpile as export-to-`.bib` examples; treat it as workflow guidance, not a current integration catalog. The apparent duplicated “Biber availability” lead is resolved only for the documented hosted biblatex example/default; exact version and Community Edition/Server Pro deployment behavior remain unresolved. No deprecation of BibTeX is documented: Overleaf still describes it as supported, while recommending biblatex for new projects. Sources: https://www.overleaf.com/learn/latex/Bibliography_management_with_bibtex — “Export from reference library services,” “Advisory note”; https://www.overleaf.com/learn/latex/Bibliography_management_in_LaTeX — “Basic usage.”

## EXPAND

- **LEAD: Deployment-specific Biber and reference-manager availability.** Partly closed: hosted docs explicitly demonstrate Biber and identify integrations as premium; exact Biber/TeX Live versions and institution/self-hosted enablement remain unresolved because no public deployment/version matrix was found.
- **LEAD: AI bundling/AI Assist status.** Closed as out of scope: this report makes no AI feature or entitlement claim, and bibliography/build conclusions do not depend on AI.
