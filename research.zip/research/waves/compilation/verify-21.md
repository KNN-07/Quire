# Verify 21: Compiler engines and main document selection

Checked October 26-27, 2026. Primary pages were fetched directly from docs.overleaf.com and overleaf.com. Web search was not used; snippets were not relied on. Page dates are shown only as relative "last updated" text on the docs pages, so "current" means the text as fetched on these dates.

## Verdict: PARTIAL

The core claims hold: four engines, a per-project TeX Live setting, the main-document rules, and the subfolder and 2 MB limits. Three harvest details are unsupported or inaccurate: the XeLaTeX/LuaLaTeX image-format list, the "may convert EPS" wording, and the "always PDF" output claim. Plan and edition availability for the compiler and main-document controls is unresolved.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Four compilers: pdfLaTeX, LaTeX, XeLaTeX, LuaLaTeX; pdfLaTeX is default | compiler page, "Changing the compiler" | No tier qualifier | CONFIRMED |
| TeX Live version is per project; legacy versions not recommended for new projects | compiler page, "How do I change a project's TeX Live version?" | No tier qualifier | CONFIRMED (legacy wording). "Most recent in most cases" is carried from expand-21 and was not re-read in this pass |
| LaTeX engine accepts .eps/.ps for \includegraphics | compiler page, "Changing the compiler" | Engine behavior | CONFIRMED |
| pdfLaTeX accepts .png/.jpg/.pdf; EPS needs an extra conversion step | compiler page; timeout page, "Using PDF images" | Engine behavior | CONFIRMED. Harvest wording "may convert EPS to PDF during compilation" is INACCURATE: the timeout page says the user must add a conversion step |
| XeLaTeX/LuaLaTeX accept PNG/JPG/PDF/EPS | harvest-21 only | Engine behavior | UNSUPPORTED. The fetched page says these engines support UTF-8 and TrueType/OpenType fonts; no image-format list for them was seen |
| XeLaTeX and LuaLaTeX recommended with polyglossia for non-Latin scripts | compiler page | Engine guidance | CONFIRMED |
| pstricks: pdfLaTeX may not handle it well; XeLaTeX supports it; LuaLaTeX does not | compiler page | Engine behavior | CONFIRMED |
| LuaLaTeX can run embedded Lua | compiler page | Engine behavior | CONFIRMED |
| Final compiled output is always PDF; LaTeX can produce DVI | compiler page, "Producing a DVI output" | Engine behavior | PARTIAL. DVI is documented as the default LaTeX-engine output; "always PDF" is not stated in the fetched text |
| Settings > Compiler > Main document; or "Set as main document" in file tree | main page, "Setting the Main document" | No tier qualifier | CONFIRMED |
| Main file must contain \documentclass | main page | No tier qualifier | CONFIRMED |
| .tex over 2 MB is non-editable and cannot be set as main | main page, "The document that I want to choose is not in the Main document list" | No tier qualifier | CONFIRMED |
| Main file belongs at project root; subfolder placement causes failures | main page, "Best Practices" | No tier qualifier | CONFIRMED. Specific features named in harvest (jump-to-location, word count, makeglossaries) are not in the fetched text; UNRESOLVED detail |
| Same-named root file compiles instead of the selected folder file | main page, "Best Practices" | No tier qualifier | CONFIRMED. Attribution to LatexMk is not in the fetched text |
| Root proxy main.tex with \import pulls in a subfolder main file | main page, "Keeping the Main document in a folder" | No tier qualifier | CONFIRMED (pattern). Exact \RequirePackage{import} line was truncated in the fetch; UNRESOLVED on exact syntax |
| Open .tex with \documentclass can compile without changing main; "should not be multiple Main documents" | main page, "Compiling other files in the same project" | No tier qualifier | CONFIRMED |
| Main can revert to "None" after History restore or converting a non-.tex file | main page, "I had previously chosen a Main document..." | No tier qualifier | CONFIRMED (expand-21 claim; not in harvest) |
| Free plan includes compile time; large projects may need premium for more | timeout page, intro | Premium: more compile time | CONFIRMED |
| Premium plans include "longer compile time" | free-and-premium-plans page | Premium | CONFIRMED. The page also lists "Overleaf AI" among premium features; see AI lead |
| acro v3 is slow; v2 workaround | timeout page, "Using the acro package" | Package issue, not platform deprecation | CONFIRMED |
| Plain TeX via latexmkrc: set Compiler to LaTeX; `$latex = 'tex %O %S';` | plain-TeX Learn page, "Can I run plain TeX on Overleaf?" | Undated Learn article | CONFIRMED. Commented pdftex/luatex/xetex alternatives were not seen in the fetched text |
| Community Edition: trusted users only; no Sandbox Compiles; Server Pro recommends sandboxing | on-premises landing page | Community Edition vs Server Pro | CONFIRMED. Engine or TeX Live configuration for either edition is UNRESOLVED |
| Commons or AI bundling of compiler/main-document controls | none found | Unknown | UNRESOLVED |

## Platform vs LaTeX

- Platform features (Overleaf-controlled): engine dropdown, per-project TeX Live setting, main-document setting and rules, compile timeouts, latexmkrc handling.
- Arbitrary LaTeX capability: package behavior, font and image handling inside a specific document, and whether a given document compiles. The docs do not guarantee these, and this report does not claim them.

## Date and legacy tags

- TeX Live legacy versions (current docs, October 2026): "not recommended for new projects." No removal date found. Future removal: UNRESOLVED.
- acro v3 slowdown: a package issue; current docs, undated in fetch.
- The July 2, 2026 AI-bundling blog was not checked in this pass. The plans page lists Overleaf AI as a premium feature, so the bundling question remains open.

## Counter-search queries (proposed, not run as web searches here)

- "Overleaf TeX Live version list site:docs.overleaf.com"
- "Overleaf main document site:docs.overleaf.com removed OR deprecated"
- "Overleaf Server Pro TeX Live configuration site:docs.overleaf.com/on-premises"
- "Overleaf AI bundled premium plans July 2026 site:overleaf.com"
- "latexmkrc Overleaf site:overleaf.com/learn"

## EXPAND

- **LEAD: exact TeX Live version menu and legacy-version availability.** UNRESOLVED. The dropdown contents are not listed on the official page.
- **LEAD: plan/edition matrix for compiler and main-document controls (Commons, Server Pro, Community Edition).** UNRESOLVED. No tier qualifier was found on these controls; Server Pro TeX Live setup was not opened. Do not infer parity.
- **LEAD: per-engine image-format table for XeLaTeX/LuaLaTeX.** UNRESOLVED. Harvest claim not supported by the fetched text; re-check the full selection page.
- **LEAD: commented latexmkrc alternatives and "How does Overleaf compile my project?".** UNRESOLVED. Not opened in this pass.
- **LEAD: Overleaf AI in premium plans vs July 2, 2026 AI-bundling blog.** UNRESOLVED. Not checked here; no combination of the two is asserted.
- **LEAD: custom compiler or binary execution.** UNRESOLVED as a guarantee. The latexmkrc example shows engine substitution only.
