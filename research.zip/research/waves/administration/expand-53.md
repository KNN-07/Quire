# Expand 53: Overleaf Commons, institutional access, and Commons AI

Research date: 2026-10-26. Public official Overleaf sources only. No authenticated checks, no purchases. Upstream: harvest-53.md. Legacy items are date-tagged.

## Verified findings

**Commons purpose and enrollment.** Commons gives institutions premium Overleaf features across a campus or to specific groups, with a custom portal, automatic validation/upgrade of eligible users, and an admin hub with metrics. Source: https://docs.overleaf.com/commons/intro-to-overleaf-commons.md ("What is Overleaf Commons?").

**Users self-enroll; admins do not.** Users provision their own accounts and existing accounts can be joined. Source: https://docs.overleaf.com/commons/user-management/user-enrollment.md ("User account provisioning," "User enrollment").

**Non-SSO enrollment is domain-only.** Users who confirm an email on an entitled domain join; no other criteria can be applied. Source: same page, "Non-SSO enrollment."

**SSO enrollment can filter by entitlement.** Login-time entitlement data can limit eligibility by faculty, department, or role. Source: same page, "SSO enrollment"; https://docs.overleaf.com/commons/single-sign-on-sso.md (intro).

**SSO protocol.** SAML 2.0; Overleaf is registered in eduGAIN, InCommon, and UKAMF. Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso/institutional-sso-faqs.md ("How do institutions set up SSO?").

**Joining as a member.** Add and confirm an institutional email in Account Settings; with SSO, confirm via "Link Accounts." Source: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription.md ("Joining an Overleaf Commons subscription").

**Reconfirmation and removal.** Users must reconfirm affiliation on an ongoing basis; the period is set by the institution. Users not recently logged in via SSO may be temporarily removed. Sources: https://docs.overleaf.com/commons/data-ownership-and-user-accounts.md ("reconfirmation requirement"); SSO FAQ, "How do I join the Commons subscription offered by my institution?"

**Data ownership.** Users, not institutions, control account and project data; the institution controls only administrative entitlement data. Source: data-ownership page, "Overleaf accounts are owned by users."

**Leaving a subscription.** If a Commons subscription ends, users without another subscription move to Free and keep projects, but lose premium features such as unlimited collaborators, integrations, tracked changes, faster compiles, and longer timeouts. Source: commons-subscription page, FAQ "What happens if my institution stops offering Overleaf Commons?"

**Plan tiers (institutional sales page).** Standard: up to 10 invited collaborators, track changes, Standard AI allowance. Pro: adds SSO, unlimited collaborators, Max AI. Commons AI: streamlined enrollment and SSO, custom portal, enhanced support, Max AI allowance. Source: https://www.overleaf.com/for/universities (plan headings). Prices are not stated on that page.

**AI allowance by plan (current).** Free: Basic, no Assistant. Student: Basic, Assistant. Standard: Standard, Assistant. Pro: Max (fair use), Assistant. Commons: Basic, no Assistant. Commons AI: Max (fair use), Assistant. Allowance resets every 24 hours. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features.md ("AI allowance by plan").

**Commons AI announcement.** Overleaf AI is included in all plans; Commons AI raises the allowance for campus-wide subscriptions and includes the Assistant. Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans ("What's new: Commons AI for institutions"). The harvest dates this post July 2, 2026; the fetched page text did not show a date, so the date is harvest-reported and not independently verified here.

**Institution-wide AI disablement.** Institutions can request it via Support; it applies to all Commons members in any project, including projects owned by outsiders. Source: https://docs.overleaf.com/commons/intro-to-overleaf-commons.md ("Disabling AI for your institution"). Per-user control is not offered for Commons; the group admin toggle is a separate mechanism (https://docs.overleaf.com/groups/user-management/controlling-feature-availability.md, "How to enable or disable AI features"; a toggle for all members, user-level controls "planned for a future phase").

**Data use.** AI docs say data is never used to train AI models and list what each feature sends (Error Assist: error message, relevant lines, file names; Citation suggestions: citation data via Dimensions). Source: ai-features page, "Data and privacy." The blog phrases this as "never ... without explicit consent." Treat the docs as the stricter statement of record.

**Accuracy limit.** AI "can misinterpret complex or custom LaTeX commands"; suggestions must be reviewed. Source: ai-features page, "Troubleshooting."

## Platform versus LaTeX

Commons entitlements cover the hosted editor and AI allowance. The docs say nothing about which LaTeX packages, engines, or constructs are supported under Commons. Compile support for arbitrary LaTeX is UNRESOLVED for this angle; no inference is made from plan descriptions.

## Legacy and conflicts

- Harvest reported an older "AI Assist" add-on page for individual and managed accounts. I did not reproduce that older version, so its content is UNRESOLVED here. The current ai-features page and July 2026 post agree on Commons versus Commons AI, so no combination is made.
- Harvest's claim that Commons SSO is "site-wide and distinct" from group SSO was not confirmed in fetched text; treated as UNRESOLVED.

## Duplicates closed

- Commons plan tiers and Commons AI tier: same source set (universities page, blog, ai-features table). Merged above.
- Harvest's SSO description duplicates the SSO FAQ and SSO page; merged.

## EXPAND

- **LEAD — Server Pro / Community Edition equivalence:** UNRESOLVED. Not researched in this angle; no Commons source maps to self-hosted editions. Needs separate deployment research from official overleaf GitHub or docs.
- **LEAD — legacy AI Assist add-on page:** UNRESOLVED. Older version not retrieved; cannot confirm its wording or dates.
- **LEAD — institution-specific configuration:** none resolvable from public sources; depends on each institution's contract. Verify with the institution or Overleaf.
- **LEAD — Commons SSO vs group SSO distinction:** UNRESOLVED from fetched text.
- **LEAD — July 2, 2026 date of the AI blog:** harvest-reported; not visible on fetched page.
