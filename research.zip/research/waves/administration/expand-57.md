# Expand 57: Community Edition vs Server Pro feature differences

Checked: 2026-10-26. Scope: self-hosted Overleaf Community Edition (CE) versus Server Pro only. Hosted Free/paid plans are noted only where they could be confused with self-hosted features. No authenticated tests, purchases, or deployments were run.

## Verified feature matrix

Source: [Server Pro vs. Community Edition](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition), headings **Benefits for users**, **Benefits for user admins**, **Benefits for system admins** (fetched and read).

- **Both editions:** powerful LaTeX editor, full project history, direct admin access to all user projects, self-hosted.
- **Server Pro only (users):** commenting, real-time track changes, easy internal collaboration, private template management, Git integration, Symbol Palette. CE is marked absent for each.
- **Server Pro only (user admins):** easy user management via Admin Panel (CE: "Limited"), and no manual upgrade of users required.
- **Server Pro only (system admins):** SSO via SAML 2 and LDAP, and automatic user registration (the matrix row is cut off in my extract; I did not verify its exact wording beyond the leading part).

## Compile isolation (security boundary)

Source: [Sandboxed Compiles](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles), heading **Improved security**. Sandboxed Compiles are recommended for Server Pro because LaTeX documents can run arbitrary shell commands during compile. With sandboxing, each compile runs in a separate Docker container with limited capabilities, shared with no other user or project, and with no host-network access. Without it, compiles run in the main container alongside other concurrent compiles. The same sandboxing page's **Easier package management** section (not re-read in full) is the source for customized TeX Live images. Packaging and isolation are deployment differences; they do not change which LaTeX language features exist.

CE's limitation is stated in the [CE/Server Pro comparison](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition) intro warning: CE should be used only where all users are trusted. Upstream [overleaf/overleaf](https://github.com/overleaf/overleaf) README repeats this limitation (page fetched; the Community Edition section was not isolated in my extract, so this is a harvest-level citation).

## Git integration (Server Pro only)

Source: [Git integration](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration), heading **Git integration**. Available since Server Pro 4.0.1. It is enabled through a separate `git-bridge` service (`GIT_BRIDGE_ENABLED=true` in the Toolkit config, or a matching container in a custom compose file). It is not on by default. This is the self-hosted integration, not hosted GitHub integration.

## Hosted-plan AI: not applicable to self-hosted

Source: [Overleaf AI now a part of Overleaf plans](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), dated July 2, 2026 (fetched). It says AI is included in all Overleaf plans, with allowances by plan, and introduces Commons AI for campus-wide subscriptions. It does not state whether CE or Server Pro includes AI.

Legacy: [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features) (fetched; date of the page text not confirmed) describes the earlier separate AI Assist model. Treat as legacy hosted guidance. Do not combine it with the July 2026 bundling.

Self-hosted AI availability in CE and Server Pro: **UNRESOLVED**.

## Plan and support boundaries

- The [enterprise page](https://www.overleaf.com/for/enterprises) (search-snippet level only; not fully opened) lists hosted Standard and Pro tiers. Its matrix marks third-party integrations (GitHub, Dropbox, Mendeley, Zotero) and Overleaf-hosted templates as unavailable on both self-hosted columns. Treat as harvest-reported.
- Support terms (Server Pro commercial support vs CE GitHub Issues) appear in the comparison page's support section per the harvest; I did not re-read that section in full, so these are **unverified here**.
- A hosted Overleaf subscription does not license Server Pro (harvest-reported, not re-verified).

## Limitations

- The comparison matrix is a documentation page, not a versioned release record. Its "Coming Soon" or "Limited" labels may change.
- I did not test either edition. Availability is documented, not functionally executed.
- The full CE/Pro matrix row for automatic registration was truncated in my extract.

## EXPAND

- **Open lead, unopened:** [Migrating from Server Pro to Group Pro](https://docs.overleaf.com/on-premises/user-and-project-management/user-management/migrating-from-server-pro-to-group-pro) (search snippet only). Relevant to Server Pro deprecation/migration, but I did not open it, so it is not cited for any claim here.
- **Open lead, unverified:** Server Pro support terms (comparison page, "Server Pro Support" section). Needs a re-read before any support claim is made.
- **Open lead, unresolved:** Self-hosted AI availability for CE and Server Pro. No primary source reviewed states it.
- **Closed as duplicate:** the Server Pro-only configuration index lists the same Server Pro-only features; it was not re-read in full here.
