# Verify 59: Self-host compile isolation, scaling, logging and monitoring

Checked October 26, 2026. **Verdict: PARTIAL**: isolation, scaling and logging are documented; monitoring exists at source/release-note level, but supported current scraping, dashboards and alerting remain unresolved. Read both `harvest-59.md` and `expand-59.md`. Public-document/source verification only; no deployment or functional execution.

## Claim table

Source IDs resolve to exact primary URLs and headings below.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Separate limited-capability compile containers, without outside resources such as host-network access | S1, Improved security | Server Pro, optional sandboxing; not CE | CONFIRMED |
| CE compiles are subprocesses, not isolated from other users; require trusted users | S2 warning; S3, Editor and compile process | Free Community Edition | CONFIRMED |
| CLSI uses host Docker socket and project files under `OVERLEAF_DATA_PATH` to launch sibling TeX Live containers | S1, How it works / Enabling | Server Pro | CONFIRMED; socket access is required, not a host-security guarantee |
| Default compile timeout is 180 seconds; `COMPILE_TIMEOUT` affects new users after recreation; existing users require database updates; above ten minutes risks other timeouts | S4, Updating project compile timeout | On-premises shared guidance, no edition restriction stated | CONFIRMED; not CPU/memory quotas |
| Baseline 2 cores/3 GB for roughly five concurrent users; add a core/1 GB per 5–10 | S5, Minimal install / Scaling | On-premises guidance; larger examples Server Pro | CONFIRMED sizing guide, not throughput guarantee |
| Multi-node support since 3.5.6 requires central MongoDB/Redis, S3-compatible project/history storage and load balancing | S6, Requirements | Server Pro | CONFIRMED; CE support UNRESOLVED, not proven impossible |
| Local ephemeral compile disks; sticky routing for editing and compile/output requests; equal hardware recommended; migrations cannot run concurrently | S6, Ephemeral files / Load balancer requirements / Hardware / Upgrading | Server Pro horizontal scaling | CONFIRMED |
| Service errors appear in individual logs; Toolkit can follow several services, including CLSI | S7, Logging | CE/Server Pro Toolkit; listed services depend on installation | CONFIRMED |
| `OVERLEAF_LOG_PATH` persists logs across recreation; host directory UID 33, mode 755 | S7, Persisting logs | CE/Server Pro Toolkit | CONFIRMED; not centralized aggregation |
| `bin/doctor` reports environment, configuration and dependencies | S8, The Doctor | CE/Server Pro Toolkit | CONFIRMED diagnostics, not continuous monitoring |
| Prometheus instrumentation exists; CLSI installs a metrics route and request monitoring | S9 README; S10 lines 24–32 | Public monorepo implementation, not shipped-edition support promise | CONFIRMED source evidence |
| Active-user metrics documented, but endpoint exposure changed | S11, 5.2.1 / 5.1.1 | Versioned on-premises release notes; CE entitlement not separately specified | CONFIRMED historically; current operator contract UNRESOLVED |

## Corrections and boundaries

**Close the ephemeral-storage lead:** S6 explicitly recommends fast local disks; network disks including NFS/EBS can cause compile errors/performance issues. Its separate project/history-storage rule excludes NFS/EFS/EBS from horizontal scaling. Do not conflate these storage roles or strengthen “local disk” into mandatory SSD.

**Correct “no documented metrics”:** S11 records `num_active_users` via `/metrics` in 5.2.1 (October 24, 2024), but 5.1.1 (August 13, 2024) records `/metrics` and `/health_check` returning 404. Internal instrumentation (S9–S10) does not settle external accessibility. Current 6.x release notes (S12, including 6.3.2, October 23, 2026) contain no metrics clarification. Do not advertise an out-of-box public scrape endpoint, compile-queue dashboard, alerts, or monitoring SLA.

**Preserve compile lifecycle evidence:** S3, full/incremental sync, documents stdout/stderr capture, output files, stopped-container cleanup after 24 hours, and failure/timeout cache removal. This is an implementation description, not configurable log-retention policy.

**Configuration distinction:** S1 separates Toolkit `SIBLING_CONTAINERS_ENABLED`/`DOCKER_SOCKET_PATH` from a raw Compose example using `SANDBOXED_COMPILES*`; different deployment paths are not themselves a contradiction.

These are platform controls, not arbitrary LaTeX/package capabilities or universal TeX-code safety guarantees. Server Pro is separately licensed from cloud Pro (S2). Cloud Free/premium, Commons and AI entitlements are not evidence for these self-host features.

## Primary sources

- S1: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles
- S2: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
- S3: https://docs.overleaf.com/on-premises/getting-started/microservices
- S4: https://docs.overleaf.com/on-premises/user-and-project-management/project-management
- S5: https://docs.overleaf.com/on-premises/getting-started/requirements/hardware-requirements
- S6: https://docs.overleaf.com/on-premises/maintenance/horizontal-scaling
- S7: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/logging
- S8: https://docs.overleaf.com/on-premises/support/getting-help
- S9: https://raw.githubusercontent.com/overleaf/overleaf/main/libraries/metrics/README.md
- S10: https://raw.githubusercontent.com/overleaf/overleaf/main/services/clsi/app.js
- S11: https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x
- S12: https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x

## Counter-search queries

- `site:docs.overleaf.com "monitoring"`
- `site:docs.overleaf.com "metrics"`
- `site:docs.overleaf.com/on-premises "alerting"`
- `site:docs.overleaf.com/on-premises "metrics" "5.2"`
- `site:github.com/overleaf/overleaf "injectMetricsRoute" "clsi"`
- `site:github.com/overleaf/overleaf "num_active_users"`

Opened primary pages and current monorepo files, not snippets alone; searched within scaling for routing/storage and within 6.x notes for metrics.

## EXPAND

- **LEAD — Current operator metrics contract:** establish supported scrape address, authentication/exposure and edition scope; historical 404 changes and internal routes do not establish these.
- **LEAD — Dashboards, compile-queue visibility and alerting:** no supporting official operator documentation found; absence of evidence does not prove absence.
- **LEAD — CE horizontal scaling support:** Server Pro-only documentation cannot resolve CE support. Ephemeral storage is closed by S6.
