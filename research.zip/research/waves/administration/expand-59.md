# Expand 59: Self-host compile isolation, scaling, logging and monitoring

Checked October 26, 2026. Upstream: harvest-59.md. Scope: Overleaf Community Edition (CE, free, self-hosted) and Server Pro (licensed on-premises product). Server Pro is a separate product from the Overleaf Pro plan, per the comparison page below. No AI-bundling claims are made here; they are out of scope for this angle.

## Compile isolation

- **Sandboxed Compiles is Server Pro only.** Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles, heading "Improved security": each compile runs in a separate Docker container with limited capabilities, shared with no other user or project, with no host network access. The page's danger hint says that without it, compiles share the `sharelatex` container's filesystem, network and environment variables.
- **CE has no compile isolation between users.** Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition, warning box: CE is for environments where all users are trusted. The comparison table marks Sandboxed Compiles as unavailable for CE. The welcome page (https://docs.overleaf.com/on-premises) gives the same warning and says Docker isolates Overleaf from other host applications, not users from each other.
- **Mechanism (Server Pro).** Source: sandboxed-compiles page, heading "How it works". The Docker socket is mounted into `sharelatex`. For each compile, CLSI writes project files under `OVERLEAF_DATA_PATH` and starts a TeX Live sibling container. Enablement is `SIBLING_CONTAINERS_ENABLED=true` and `DOCKER_SOCKET_PATH` in `config/overleaf.rc`. Inference, not stated in the docs: the socket mount gives the app container control over host Docker, and the docs do not analyze that trade-off.
- **Compile timeout.** Sources: https://docs.overleaf.com/on-premises/support/project-limits (default 180 s) and https://docs.overleaf.com/on-premises/user-and-project-management/project-management, "Updating project compile timeout". `COMPILE_TIMEOUT` is set in `config/variables.env`, then `bin/up -d` recreates the container. The page warns that going past 10 minutes likely hits another component's timeout. This is a timeout setting, not a documented resource quota.
- **CE compile path.** Source: https://docs.overleaf.com/on-premises/getting-started/microservices, note at top: CE runs compiles as simple sub-processes rather than sibling containers.

## Scaling

- **Sizing.** Source: https://docs.overleaf.com/on-premises/getting-started/requirements/hardware-requirements, headings "Minimal install" and "Scaling": 2 cores and 3 GB for about 5 concurrent compiling users, plus 1 core and 1 GB per 5-10 concurrent users. The page calls these guides, not guarantees.
- **Horizontal scaling (Server Pro).** Source: https://docs.overleaf.com/on-premises/maintenance/horizontal-scaling. Introduced in Server Pro 3.5.6. Requires external MongoDB, Redis and S3-compatible storage, plus a load balancer. NFS, EFS and EBS are explicitly not supported for horizontal scaling. The page says setup "requires a significant amount of effort" and that third-party components are outside support terms. Its example is one server with two 4-core CPUs and 32 GB RAM serving 1,000 users.
- **CE horizontal scaling: closed, no support found.** The horizontal-scaling page addresses Server Pro only. In GitHub issue https://github.com/overleaf/overleaf/issues/1390 (August 2025), a maintainer pointed the user to the horizontal-scaling docs and the CE vs Server Pro comparison, not to a CE scaling guide. Do not infer CE support.
- **Legacy, date-tagged 2020:** https://github.com/overleaf/toolkit/issues/8 says the Toolkit runs all services in one container and is not suited to horizontal scaling. This predates Server Pro 3.5.6 support and is not a current statement.
- **Not verified in this pass:** harvest-59 reports that compile files should sit on local SSD and that network disks cause compile errors. The horizontal-scaling page was truncated before its ephemeral-storage section, so this claim is unconfirmed here.

## Logging

- **Per-service logs.** Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/logging. Errors go to files such as `/var/log/overleaf/web.log`. `bin/logs` shows services including `clsi`, `web`, `docstore` and `filestore`. The microservices page confirms per-service logs under `/var/log/overleaf/`, managed by runit.
- **Persistence.** Same logging page, heading "Persisting logs": container recreation discards logs unless `OVERLEAF_LOG_PATH` bind-mounts a host directory. That directory must be owned by uid 33 with mode 755.
- **Diagnostics.** Source: https://docs.overleaf.com/on-premises/support/getting-help: `bin/doctor` reports host, dependencies and configuration. CE issues go to GitHub; Server Pro goes to support email.

## Monitoring

- **Official deployment docs: no metrics or alerting section found.** The on-premises pages read above cover logs and diagnostics only.
- **Source-level metrics module.** https://github.com/overleaf/metrics-module (README states the repo has moved into overleaf/overleaf) wraps prom-client to serve Prometheus metrics at `/metrics`. This is repository code, not an operator guide. The npm page (https://www.npmjs.com/package/@overleaf/metrics) shows last update in 2023, so treat it as legacy.
- **UNRESOLVED:** whether the shipped CE or Server Pro image exposes `/metrics` to operators, and whether Prometheus or any alerting is supported. Neither the Prometheus alerting overview nor the DeepWiki page is Overleaf evidence.

## Legacy and version notes

- Environment variables were renamed from `SHARELATEX_*` to `OVERLEAF_*` at version 5.0.3 per the official horizontal-scaling and sandboxed-compiles pages. The GitHub wiki https://github.com/overleaf/overleaf/wiki/Configuring-Overleaf says 5.0.1 and is marked as moved and outdated. Use 5.0.3, the official docs' version.
- The sandboxed-compiles page documents two enablement paths: `overleaf.rc` keys and Compose `SANDBOXED_COMPILES*` variables. These are not reconciled in the page.

## EXPAND

- Monitoring and metrics exposure for on-prem deployments: **LEAD, UNRESOLVED.** No official operator documentation found. Reason: only the repository README exists.
- CE horizontal scaling: **CLOSED.** Reason: the only official scaling doc is Server Pro-specific, and the maintainer response in issue 1390 points there.
- Harvest's ephemeral-storage claim: **LEAD, UNRESOLVED.** Reason: the horizontal-scaling page was truncated before the relevant section.
