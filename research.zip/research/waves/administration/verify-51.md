# Verify 51: Free, Student, Standard and Pro entitlements

**Checked October 26, 2026. Verdict: PARTIAL.** Core Cloud entitlements verified; individual applicability of advertised administrative capabilities remains unresolved. Read both `harvest-51.md` and `expand-51.md`. Public documentation only: no authenticated tests, purchases, or functional execution.

## Sources

Exact official URLs, opened directly; headings below identify relevant evidence:

- [P: Plans and Pricing](https://www.overleaf.com/user/subscription/plans): plan cards, **Compare all features**, FAQs.
- [F: Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features): feature headings, **Account and project level features**, downgrade section.
- [L: Plan limits](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits): **Overleaf plan limits**, **More about our premium plans**.
- [H: History and versioning](https://docs.overleaf.com/writing-and-editing/history-and-versioning): **Using the full History feature**.
- [A: AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features): **AI allowance by plan**, **Who can use Overleaf AI**, **Troubleshooting**.
- [B: July 2, 2026 announcement](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans): introduction, **What each plan includes**, Commons AI section.
- [G: Git integration](https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration): **Overleaf Cloud**, **Overleaf Server Pro (version 4.0 or later)**.
- [O: Free and premium plans](https://docs.overleaf.com/getting-started/free-and-premium-plans): introduction, **Premium plans**.

## Claim table

Order in four-value cells: Free / Student / Standard / Pro. Premium means Student, Standard and Pro here.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Unlimited projects; ready-to-use templates | P, Editing and collaboration | All four | CONFIRMED |
| Invited editors/reviewers per project | F, Invite more collaborators | 1 / 10 / 10 / unlimited; unlimited viewers each | CONFIRMED; invitation count, not total including owner |
| Compile timeout; speed labels | L, limits; P, Performance | 10s / 240s / 240s / 240s; Fast / Fastest / Fastest / Fastest | CONFIRMED; labels are not benchmarks |
| Track Changes; advanced reference search; symbol palette; Git/GitHub/Dropbox/ReadCube/Zotero/Mendeley integrations | P, collaboration/integrations; F, corresponding headings | Premium | CONFIRMED; service capabilities, not arbitrary LaTeX commands |
| Full history | H, Using the full History feature | Premium; Free retains last 24 hours **and labeled versions** | CORRECTED upstream's overly absolute “only” |
| Offline current-file editing; priority support | F, Offline editing / Priority Support | Free 2 minutes, premium up to 10; premium support prioritized, no extra debugging | CONFIRMED |
| Student eligibility | P, Student notice | Currently enrolled at degree-granting institution | CONFIRMED |
| Daily AI; Assistant | P, cards; A, allowance table | Basic 5/no; Basic 5/yes; Standard 10/yes; Max fair-use/yes | CONFIRMED; each action counts, resets every 24 hours |
| Institutional AI distinction | A, allowance table; B, Commons AI | Commons Basic/no Assistant; Commons AI Max/Assistant | CONFIRMED; not individual tiers |
| Shared resource ceilings | L, limits table/footnotes | All four: 2,000 files, 7 MB editable material, 2 MB editable text file, 50 MB/upload | CONFIRMED; some larger text files may remain editable |
| Nominal unlimited project size | L, footnotes | All four; recommended 500 MB, below 100 MB with Git/GitHub; above 4 GB may disrupt copying | CONFIRMED; not unlimited practical capacity |
| Enterprise/security rows omitted upstream | P, Enterprise capabilities / Data & Security / Global feature controls | Pro column: SSO, managed accounts; Standard/Pro: audit logging, administration/metrics, AI/chat/Dropbox controls; all: ISO certification | CONFIRMED as advertised; individual administrative applicability UNRESOLVED |
| Organizations-only rows | P, same headings and Support & onboarding | Neither of four: Server Pro option, FedRAMP solution, personalized onboarding/support, dedicated account manager | CONFIRMED advertised matrix |

## Corrections and boundaries

F's **Account and project level features** makes compile time, Track Changes and history owner-dependent. Free collaborators inherit these within that project. Git permits all members on premium-owned projects, or premium users on any accessible project; GitHub permits all members to sync an owner-linked repository. Dropbox is personal; only the owner re-syncs imported reference libraries; symbol palette follows the subscribing account. F's downgrade section preserves projects and existing tracked edits but removes further premium access.

B explicitly bundles AI at no extra cost from July 2, 2026; live A and O now agree. Contrary to upstream, live F no longer uses Professional or six Student collaborators. Search-index copies still show those and separate AI Assist purchases: **legacy evidence as encountered October 26, 2026**, not current entitlements. A also says Summarize/Explain were removed despite an introductory listing; do not advertise them. A documents organizational restrictions on AI.

These are Cloud entitlements, not LaTeX package/engine guarantees. G documents Server Pro v4+ Git separately, disabled by default. Mapping this matrix to Server Pro/Community Edition, or inferring tier-specific arbitrary LaTeX support, is **UNRESOLVED**.

## Counter-search queries

- `site.overleaf.com Student Standard Pro plans AI five ten July 2026`
- `site:docs.overleaf.com premium collaborator limit owner offline editing two minutes`
- `site:docs.overleaf.com "AI Assist add-on" "plans"`
- `site:docs.overleaf.com "Student" "6" "collaborators"`
- `site:docs.overleaf.com "offline" "2 minutes" "10 minutes"`

Search results were counterchecked against opened primary pages, not accepted from snippets.

## EXPAND

- **LEAD:** Resolve whether P's Standard/Pro administrative checkmarks apply to single-license subscriptions or only corresponding group configurations; public matrix and FAQs do not establish that guarantee. Do not equate Student and Standard beyond their verified core editor/compile features.
- No additional Cloud core-entitlement lead. Runtime and self-hosted equivalence remain explicitly unsupported boundaries, not inferred benefits.
