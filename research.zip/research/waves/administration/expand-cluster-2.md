# Administration reconciliation and lead closure

Checked October 26, 2026. Public primary-source documentation research, not runtime acceptance testing. Read `brief.md`, `lead-supplement.md`, all `verify-51.md` through `verify-60.md`, and adjacent integrations verifications 41, 46, 49, 50. All thirty administration harvest/expand/verify files exist; no missing angle needs reconstruction. October 27 dates in upstream expansions 52/54 are not evidence of a completed future check.

## Corrected claim table

Source keys below give exact opened URLs and relevant headings. CONFIRMED means documented, not independently executed.

| Angles | Corrected claim and availability | Status / evidence |
|---|---|---|
| 51 | Free/Student/Standard/Pro allow 1/10/10/unlimited invited editors/reviewers. Compile timeout is 10 seconds Free, 240 premium. Shared limits include 2,000 files, 7 MB editable material, 2 MB guaranteed-editable individual text, 50 MB/upload. Nominal unlimited project size has practical recommendations. | CONFIRMED, S1-S2. No arbitrary package or compilation-success guarantee. |
| 51, 56 | Free history includes the last 24 hours **and labeled versions**. Full history requires a premium project owner and is shared with collaborators. | CORRECTED, S3; do not apply Cloud Free retention to CE. |
| 51-53, 60 | AI bundled from **July 2, 2026**. Free/Student Basic: 5 uses/day; Standard: 10; Pro: Max/fair use. Assistant excluded on Free and ordinary Commons, included on Student/Standard/Pro/Commons AI. Commons AI has Max. | CONFIRMED, S1/S4/S5. Not a self-hosted entitlement. |
| 52 | Group admin controls billing/members/managers and sees metrics/audit logs; managers handle membership and metrics. Neither gets premium merely by holding that role. SSO and Managed Users are Pro-group controls. | CONFIRMED, S6. A collaborator is not automatically a licensed member. |
| 53 | Commons users self-enroll; existing accounts work. Without SSO, enrollment uses confirmed institutional email domains; SSO permits further entitlement criteria. | CONFIRMED, S7. Do not substitute Group Pro account ownership/control for Commons. |
| 54 | Primary email/password, Google, ORCID and eligible SSO are documented login routes; X login is discontinued. Session clearing and account-change notifications exist. | CONFIRMED, S8-S9. Native hosted MFA remains unestablished. |
| 54 | The recovered **November 2, 2016** ORCID announcement promised inclusion in submissions to participating publishers. | HISTORICAL CONFIRMED, S10. No universal current publisher/PDF propagation or unlink procedure established. |
| 52, 55 | Managed Pro removal returns an independent Free account with owned/shared projects preserved; owned-project collaborators become viewers, with one writable collaborator permitted. Deletion transfers projects to another managed user. | CONFIRMED, S11. “Release” and “Remove user” describe the same non-destructive outcome in S11-S12; current UI equivalence was not tested. |
| 55 | Terminated managed Pro subscriptions lapse for 60 days, then soft-delete for 90 days before permanent deletion. Lapsed accounts remain accessible; soft-deleted recovery requires Support, not automatic renewal. | CONFIRMED, S13; not ordinary subscription cancellation behavior. |
| 52, 55 | Group admins have a documented all-member AI dashboard toggle; managed Pro defaults off, others on. Support can also set disablement, reflected in that toggle. | CONFIRMED, S14. Pricing HTML still says “Via Support”; this does not erase the detailed self-service workflow. Rollout exceptions remain unverified. |
| 55 | Group SSO FAQ requires assertion **or** response signed; troubleshooting says both. FAQ calls invitation-based account provisioning JIT; the login guide excludes provisioning **from SSO login**. | Signatures UNRESOLVED, S15-S16. JIT terminology is bounded by the different workflows, S15/S17: invitation/linking is documented, login-time provisioning is not supported. |
| 56 | Published security overview describes GCP storage, TLS where supported and redundant backups; AI docs disclose external processing. No-training wording is qualified differently in the Terms and July announcement. | CONFIRMED narrower disclosures, S5/S18-S20; no zero-retention, customer-key or end-to-end-encryption promise. |
| 57 | CE and separately licensed Server Pro have full history. CE supports project collaboration, including anonymous read/write sharing. Pro adds documented review/admin/authentication features and compile sandboxing; CE requires trusted users. | CORRECTED, S21-S22. “Easy internal collaboration” marked absent is not evidence of no CE coediting. |
| 58 | Toolkit/image upgrades are distinct. Consistent backups cover MongoDB, Redis and filesystem with writes stopped. Export script, documented since **5.4.0**, excludes history, collaborators, settings, comments/changes and chat. | CONFIRMED, S23-S25. ZIP/config exports are not full backups; no universal rollback or restore-success guarantee. |
| 59 | Horizontal scaling is documented for Server Pro since **3.5.6**, with central data services, S3-compatible project/history storage and local ephemeral compile disks. | CONFIRMED, S26. Neither CE support nor impossibility follows. |
| 57, 59 | Internal Prometheus instrumentation exists. Historical `/metrics` 404 change and later active-user metric do not establish today's supported scrape address/authentication/edition contract. Enterprise integrated metrics remain “Coming Soon” for Server Pro. | QUALIFIED, S27-S30. No delivered dashboard/queue/alerting claim. |
| 60 | Open in Overleaf imports snippets/files/ZIPs; it is not documented as general Cloud account/compile automation. AUP prohibits using hosted services as an external processing engine/API. | CONFIRMED, S18/S31. Private/partner interfaces unasserted. |

## Closure table for every input EXPAND lead

UNRESOLVED is a final evidence disposition, not a promised future research loop. DUPLICATE rows identify the retained home.

| Input | Lead | Closure and concrete basis |
|---|---|---|
| 51 | Individual Standard/Pro administrative checkmarks | UNRESOLVED for single-license applicability: reopened S1 enterprise rows/FAQ and S6 group role table; they do not establish a single-license admin guarantee. Group functionality confirmed; no unavailable inference. |
| 52 | AI toggle versus “Via Support” | RESOLVED functionality / UNRESOLVED rollout exception. S14 explicitly documents self-service **and** Support changes; S1 tooltip verified in full live HTML. Support-only restriction rejected; no undocumented rollout asserted. |
| 52 | Refunds, seat credits, checkout totals/minimums, Server Pro price/key terms | OUT-OF-SCOPE as comprehensive contractual/procurement guarantees. S1 FAQ documents PO eligibility for five-plus group seats and prorated added seats; neither makes a universal refund or quote promise. No checkout performed. |
| 53 | Legacy AI billing/migration | DUPLICATE of 60 legacy-transition row below and integrations 46/49/50. Current bundling is settled, migration is not. |
| 53 | Institution-specific entitlements/controls | OUT-OF-SCOPE speculative configurations: S7 establishes institution-defined eligibility, not every contract. Generic Commons functionality retained; no institution-specific guarantee inferred. |
| 53 | Commons/self-host deployment parity | DUPLICATE of 57 self-hosted AI. Licensing axes remain separate (S21). |
| 54 | Native hosted MFA | UNRESOLVED: reopened S8-S9 and searched official “two-factor authentication”/“two-factor” documentation; no native-hosted statement established. Third-party/IdP login is not proof of native MFA. |
| 54 | ORCID unlink/current publisher behavior | UNRESOLVED current behavior after S8 and official unlink search. Historical sublead RESOLVED: alternate reader recovered S10, including its 2016 date; publisher scope explicitly limited to participants. |
| 54 | Server Pro guide replacement | RESOLVED upstream: current Toolkit documentation supersedes outdated wiki; legacy redirect/version chronology is OUT-OF-SCOPE for the feature inventory. |
| 55 | One versus two SAML signatures | UNRESOLVED: directly reopened S15 signed-assertion FAQ and S16 error section; contradiction persists. No runtime enforcement claim. |
| 55 | “Release” versus “Remove user” | RESOLVED outcome, S11-S12. Exact authenticated UI wording OUT-OF-SCOPE; report non-destructive removal rather than promise both button labels. |
| 56 | Encryption-at-rest coverage, customer keys, tenant isolation | UNRESOLVED: S18 “Secure Storage” plus official encryption-at-rest/customer-key searches establish no such complete guarantee. GCP hosting alone is insufficient. |
| 56 | Native MFA | DUPLICATE of 54 MFA closure. |
| 56 | Recovery objectives, backup-erasure deadline | UNRESOLVED hosted guarantees: S18 backup/retention sections and S20 deletion guidance give no RPO/RTO or fixed backup-erasure deadline. |
| 56 | Per-provider AI retention/deletion, exhaustive payload map | UNRESOLVED: S4 “Data and privacy” gives feature-level payload categories; S19 processor table gives broad functions, not complete field/retention contracts. |
| 56 | Full hosted account archive | UNRESOLVED beyond project downloads: S20 download instructions and S3 history exports establish project ZIP routes, not a complete account/metadata archive. |
| 57 | Self-hosted AI | UNRESOLVED after opened S4/S21/S28/S30 and executed official on-premises AI/Assistant searches. No CE/Server Pro affirmative entitlement; matrix silence proves neither availability nor absence. |
| 57 | Integrated metrics delivery | RESOLVED advertised state only: reopened S28 still says “Coming Soon”; delivery UNRESOLVED. Active-user count is a separate narrower feature. |
| 57 | “Easy internal collaboration” definition | RESOLVED no-collaboration counterclaim by S22's explicit CE sharing support. Exact extra marketing workflow UNRESOLVED/unasserted; no feature denial based on the label. |
| 58 | Recovery guarantees/runbook | OUT-OF-SCOPE universal operational acceptance; S23 provides consistent-backup instructions and recommends testing. No restore drill executed or service-level guarantee inferred. Hosted RPO/RTO remains at 56. |
| 58 | On-premises AI | DUPLICATE of 57 self-hosted AI. |
| 59 | Current operator metrics contract | UNRESOLVED after S27/S29/S30 and official metrics/scrape searches; internal routes and historical releases do not supply supported exposure/authentication/edition scope. |
| 59 | Dashboards, compile queue, alerts | UNRESOLVED after official dashboard/monitoring searches and S28-S30; no supported operator dashboard/alerting documentation established, not proof of absence. |
| 59 | CE horizontal scaling | UNRESOLVED after S26 and CE/horizontal search. RESOLVED storage sublead: S26 distinguishes local ephemeral compile disks from S3 project/history stores. |
| 60 | General Cloud REST API | UNRESOLVED supported general API; reopened S31 and official API/REST search found no broader documented contract. Private/partner enumeration OUT-OF-SCOPE; S18 restriction retained. |
| 60 | Legacy AI Assist/Writefull transition | UNRESOLVED after S4/S5/S32 and official refund search: live add-on terminology persists, but public evidence does not explain migration/credits/cross-product rights. No separate current purchase requirement inferred. |

## Supplement incorporation

Lead supplement L1-L5 is incorporated, not reopened as five future tasks. Current-file offline editing is up to two minutes Free/ten premium; no file switching, compiling, comments or AI offline, and recovery requires restoring the original tab (S33). Google Drive is external-URL import/manual refresh, not native two-way sync (S34). Labs is opt-in experimental access, not stable availability (S35). S4 explicitly removes named Summarize/Explain actions despite its introductory listing.

Conversion uses Pandoc for DOCX/Markdown import and DOCX/Markdown/HTML export, with fidelity limits (S36). Account Library citations copy entries into project `.bib`; continuous update propagation remains unasserted (S37). Premium ReadCube offers refreshable read-only bulk imports and editable individually cited entries; manual `.bib` upload remains available (S38). These close duplicates in projects/integrations, not new administration restrictions.

Incidental publication dates, exhaustive package/template inventories, arbitrary compatibility guarantees and speculative tier combinations are OUT-OF-SCOPE/unasserted. Executed counter-searches included CE collaboration, hosted MFA, ORCID unlink, on-premises AI, encryption-at-rest/customer keys, metrics/scrape, dashboard/monitoring, CE scaling, AI retention/refunds and Cloud API/REST. Empty results were not treated as product absence. Consequential CE no-collaboration and support-only AI restrictions were counterchecked against explicit live documentation. The alternate reader successfully retrieved offline, ReadCube, termination and historical ORCID pages; truncated legal/pricing responses were checked against full live HTML.

## Opened primary sources

Exact URLs; headings identify evidence. Dates are included only when consequential.

- S1 https://www.overleaf.com/user/subscription/plans — Compare all features; FAQ; Global feature controls (including HTML tooltips).
- S2 https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits — Overleaf plan limits; footnotes.
- S3 https://docs.overleaf.com/writing-and-editing/history-and-versioning — Using the full History feature; Downloading an older version.
- S4 https://docs.overleaf.com/integrations-and-add-ons/ai-features — AI allowance by plan; Data and privacy; Troubleshooting.
- S5 https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — July 2, 2026; What each plan includes; Commons AI.
- S6 https://docs.overleaf.com/groups/user-management/roles-and-permissions — role table.
- S7 https://docs.overleaf.com/commons/user-management/user-enrollment — User account provisioning; Non-SSO enrollment; SSO enrollment.
- S8 https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/login-options — login-method headings.
- S9 https://docs.overleaf.com/accounts-and-security/keeping-your-account-secure — sessions; notifications.
- S10 https://www.overleaf.com/blog/434-now-available-link-your-orcid-id-to-your-overleaf-account — title/body; November 2, 2016.
- S11 https://docs.overleaf.com/groups/user-management/managed-user-accounts — Removing or Deleting Managed Users; Returning ownership.
- S12 https://docs.overleaf.com/groups/user-management/secure-decommissioning-for-managed-users — Option B: Releasing User Accounts.
- S13 https://docs.overleaf.com/groups/user-management/termination-and-deletion.md — Subscription states; Subscription recovery.
- S14 https://docs.overleaf.com/groups/user-management/controlling-feature-availability — How to enable or disable AI features; FAQs; Default AI access.
- S15 https://docs.overleaf.com/groups/overleaf-group-single-sign-on/group-sso-faqs — signed assertions/responses; JIT; SCIM.
- S16 https://docs.overleaf.com/groups/overleaf-group-single-sign-on/maintaining-group-sso — Understanding errors reported by users.
- S17 https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso — introduction information box.
- S18 https://www.overleaf.com/legal — Security Overview; Retention; Overleaf AI; Acceptable Use Policy.
- S19 https://docs.overleaf.com/accounts-and-security/overleaf-data-processors — processor table.
- S20 https://docs.overleaf.com/accounts-and-security/managing-your-personal-information — How to download/delete your information.
- S21 https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — licensing warning; benefits matrices.
- S22 https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — Editor IDE; Admin Panel.
- S23 https://docs.overleaf.com/on-premises/maintenance/data-and-backups — Data storage; Performing a consistent backup.
- S24 https://docs.overleaf.com/on-premises/maintenance/data-and-backups/exporting-projects — introduction; Limitations.
- S25 https://docs.overleaf.com/on-premises/maintenance/upgrading-your-deployment — The bin/upgrade Script; upgrade warning.
- S26 https://docs.overleaf.com/on-premises/maintenance/horizontal-scaling — Requirements; Ephemeral files.
- S27 https://raw.githubusercontent.com/overleaf/overleaf/main/libraries/metrics/README.md — overleaf/metrics-module.
- S28 https://www.overleaf.com/for/enterprises/features — Benefits for User Admins; Benefits for Users.
- S29 https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x — 5.2.1 Other changes (October 24, 2024); 5.1.1 (August 13, 2024).
- S30 https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x — through 6.3.2 (October 23, 2026); no metrics clarification found.
- S31 https://www.overleaf.com/devs — Overview; Post a Snippet by URI.
- S32 https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — introduction; Opening the AI assistant.
- S33 https://docs.overleaf.com/writing-and-editing/working-offline.md — How to work offline; Limitations; Recovering lost edits.
- S34 https://docs.overleaf.com/integrations-and-add-ons/google-drive — introduction; refresh instructions.
- S35 https://docs.overleaf.com/accounts-and-security/overleaf-labs — What to expect from a Labs experiment.
- S36 https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files — introduction; Importing; conversion limitations.
- S37 https://docs.overleaf.com/citing-and-references/library — introduction; Overview of how to use the Library.
- S38 https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md — How to add references; Updating project .bib files.

## EXPAND

- None. Every inherited lead has a final disposition above. The additional Group SSO JIT terminology check distinguishes invitation provisioning from login-time provisioning rather than creating a false new functionality contradiction. Remaining unresolved guarantees require authoritative documentation, not repeated public-source searching.
