# Verify 52: Group subscriptions, billing and license management

Checked **October 26, 2026**. **Verdict: PARTIAL**: core claims confirmed; AI controls conflict and comprehensive refund/pricing terms remain unavailable. Both upstream files read; `expand-52.md` is future-dated October 27, so independently rechecked today. Public documentation only; no authenticated actions, purchases, or functional execution.

## Claim table

Platform administration, not LaTeX capabilities. Sources identify headings; evidence is paraphrased.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Buying creates a group; buyer is its sole admin. PO requires at least five seats; smaller groups can pay by card/PayPal. | [How to create a group: Buy a group subscription](https://docs.overleaf.com/groups/getting-started/how-to-create-a-group) | Hosted groups | CONFIRMED |
| Admin handles billing, members, managers, metrics and audit logs; managers handle members/managers and metrics. Neither receives premium automatically. | [Roles and permissions: role table](https://docs.overleaf.com/groups/user-management/roles-and-permissions) | Group Standard/Pro; Group SSO and Managed Users Pro-only | CONFIRMED |
| Admins/managers consume seats only as members. Invitations do not create accounts; personal subscriptions must be canceled separately. Membership CSV export exists; changing the sole admin requires Support. | [Adding and removing users: warning, Adding users, Exporting, managers](https://docs.overleaf.com/groups/user-management/how-to-add-and-remove-users) | Hosted groups | CONFIRMED |
| Members receive paid features across projects; collaborators need not hold seats. Standard allows ten collaborators/project; Pro unlimited. | [Plans: licenses versus collaborators; Standard/Pro cards](https://www.overleaf.com/user/subscription/plans) | Group Standard/Pro; Free collaborators | CONFIRMED current |
| Only admin buys seats/upgrades; cost preview and emailed invoice. Website-purchased groups can self-upgrade Standard to Pro; absent controls require contact. | [Buying more licenses and upgrading: three sections](https://docs.overleaf.com/groups/user-management/buying-more-licenses-and-upgrading) | Hosted groups; purchase-channel restriction | CONFIRMED |
| Up to twenty additional licenses self-service, prorated at current per-license rate to existing renewal date; more requires Sales. Not a total-seat cap. | [Plans: adding licenses FAQ](https://www.overleaf.com/user/subscription/plans) | Hosted groups | CORRECTS unresolved proration |
| Midterm plan changes are prorated; downgrade assistance is available. | [Switching plans: Options; Remember that](https://docs.overleaf.com/groups/subscription-management/switching-plans) | Hosted groups | CONFIRMED; no detailed credit/refund formula |
| Card/PayPal billing details editable in Subscription; manual billing requires Support. Invoices downloadable/printable; PO invoices emailed to billing contact. | [Updating: payment information](https://docs.overleaf.com/groups/subscription-management/updating-billing-information); [Invoices: How to access](https://docs.overleaf.com/groups/subscription-management/accessing-invoices-and-receipts) | Hosted groups | CONFIRMED |
| Most subscriptions auto-renew; Success usually assists manually billed renewals. | [Renewing a subscription: overview](https://docs.overleaf.com/groups/subscription-management/renewing-a-subscription) | Hosted groups | CONFIRMED, not universal guarantee |
| Leaving most groups returns account to Free; managed members cannot self-leave. Commons affiliation instead depends on institutional email confirmation. | [Canceling: Leaving a group; Leaving Commons](https://docs.overleaf.com/subscriptions-payments-and-billing/canceling-your-subscription) | Groups; Commons | CONFIRMED |
| Managed Users requires lead-admin enablement; restricts email/account/subscription changes. Remove preserves account/projects on Free; Delete permanently deletes account and transfers projects. | [Managed Users: administrator; Removing or Deleting](https://docs.overleaf.com/groups/user-management/managed-user-accounts) | Group Pro only | CONFIRMED; managed subscription-end decommissioning differs |
| Subscription audit export is ZIP containing paginated CSVs, 100 entries/file. | [Audit logs: Accessing the audit logs](https://docs.overleaf.com/groups/user-management/group-subscription-audit-logs) | Group admin | CONFIRMED |
| Support can stop an individual subscription and refund unused latest-payment portion when joining managed group. | [Understanding managed accounts: Stopping an individual subscription](https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts) | Managed-group joiners | CONFIRMED narrow exception, not general group refund policy |
| Server Pro licenses project-accessing users; active means opened project within twelve months. No strict technical seat cap; overages require contacting Success for prorated pricing; renewals use customer-reported counts. | [Understanding license usage: overview and seat-limit paragraphs](https://docs.overleaf.com/on-premises/user-and-project-management/understanding-license-usage) | Server Pro, not hosted groups | CONFIRMED |
| Community Edition is locally runnable open-source software under AGPLv3, not a hosted group entitlement. | [Official repository: Community Edition; License](https://github.com/overleaf/overleaf) | Community Edition | CONFIRMED; no hosted billing equivalence inferred |

## AI corrections and pricing boundary

[July 2, 2026 announcement: What each plan includes; Commons AI](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans) explicitly confirms bundled AI at no extra cost: Standard includes Assistant; Pro has Max/fair-use allowance; Commons has Basic without Assistant, Commons AI Max with Assistant. [Current AI documentation: AI allowance by plan](https://docs.overleaf.com/integrations-and-add-ons/ai-features) agrees. Legacy separate-add-on language remains in the [Assistant introduction](https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant); it does not establish a current extra billing requirement.

[Feature availability: How to enable or disable AI](https://docs.overleaf.com/groups/user-management/controlling-feature-availability) documents an admin-dashboard toggle, default off for Managed Users and on otherwise, contradicting the [pricing comparison's Global feature controls: Via Support](https://www.overleaf.com/user/subscription/plans). Rollout exceptions remain UNRESOLVED.

The [pricing cards](https://www.overleaf.com/user/subscription/plans) show USD Standard $25/month or $199/year, Pro $45/month or $399/year: list-price snapshots, not verified group quotes.

## Counter-search queries

- `site:docs.overleaf.com groups subscription licenses billing refunds prorated`
- `site:overleaf.com "refund" "group" subscription`
- `site:docs.overleaf.com "group" "minimum" "licenses"`
- `site:overleaf.com/blog "overleaf-ai-now-a-part" "2026"`
- `site:docs.overleaf.com "AI Assist" "add-on"`
- `site:docs.overleaf.com "Server Pro" "license key"`
- `site:github.com/overleaf/overleaf Community Edition AGPL license`

## EXPAND

- **LEAD:** Resolve dashboard AI-toggle availability versus pricing comparison's Via Support label; rollout exceptions undocumented.
- **LEAD:** General group refunds, seat-reduction credits, exact group checkout totals/minimums, and Server Pro commercial price/key terms remain UNRESOLVED; public pages above do not supply complete contractual guarantees.
