# Overleaf plan entitlements: Free, Student, Standard, Pro

**Research date: 2026-10-26. Scope:** public Overleaf Cloud plan claims; no account testing or purchases. The sources below are official Overleaf pages. Feature entitlement is not evidence that any LaTeX document or package executes successfully.

## Plan comparison

The current [Plans and Pricing page](https://www.overleaf.com/user/subscription/plans), heading **Compare all features**, shows:

| Entitlement | Free | Student | Standard | Pro |
|---|---|---|---|---|
| Projects | Unlimited | Unlimited | Unlimited | Unlimited |
| Editors/reviewers per project | 1 | 10 | 10 | Unlimited |
| Compile timeout | Basic | 24x Basic | 24x Basic | 24x Basic |
| Compile speed label | Fast | Fastest | Fastest | Fastest |
| Track changes | No | Yes | Yes | Yes |
| Project history | Previous 24 hours only | Full | Full | Full |
| Advanced reference search; symbol palette; listed integrations | Not included | Included | Included | Included |

The page's **Plan limits** table spells out timeout as 10 seconds Free and 240 seconds for premium plans, and states common limits across Free and premium: 2,000 files per project, 7 MB editable material per project, 2 MB per editable text file (larger may sometimes work), and 50 MB per individual upload. Total project size and project count are marked unlimited, but Overleaf recommends under 500 MB generally and under 100 MB when using Git/GitHub sync; projects over 4 GB may have problems with operations such as copying. Source: [Plan limits](https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits), headings **Overleaf plan limits** and **More about our premium plans**.

**Student** requires student eligibility; the pricing page says students currently enrolled at a degree-granting institution. It provides 10 collaborators, full history/track changes, 24x Basic compile timeout, and AI Assistant with Basic AI allowance. **Standard** has 10 collaborators, the same listed premium editor/history/compile entitlements, Standard AI allowance, and AI Assistant. **Pro** raises project collaborators to unlimited and AI to Max (fair use applies); its other core entitlements above match Standard. Source: [Plans and Pricing](https://www.overleaf.com/user/subscription/plans), headings **Student**, **Standard**, **Pro**, and **Compare all features**. AI allowance levels are respectively Basic, Basic, Standard, Max; current [AI features docs](https://docs.overleaf.com/integrations-and-add-ons/ai-features), heading **AI allowance by plan**, define each AI action as one use and the allowance as resetting every 24 hours.

## Premium tools, scope, and restrictions

Premium plans include advanced inline reference search and integrations listed by Overleaf: Git, GitHub, Dropbox, ReadCube, Zotero, and Mendeley; also the symbol palette. [Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), headings **Advanced reference search**, **Reference manager integration**, **Git and GitHub integration**, and **Account and project level features**, describe these functions. Track changes permits review/acceptance of edits; full History offers older versions and restore. Project-level entitlements follow the **project owner's** subscription, so a Free collaborator may use these on a paid owner's project. Account integrations are controlled by the subscribing account; GitHub syncing can be per project, Dropbox syncing is personal, and only the project owner can re-sync an imported reference-manager library. The same docs say Free offline editing is limited to two minutes versus up to ten minutes on paid plans (**Offline editing**).

## AI, deployment labels, and interpretation limits

Overleaf's [July 2, 2026 product update](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), headings **What each plan includes** and **What's new: Commons AI for institutions**, states Overleaf AI is included in plans at no extra cost, with plan-dependent allowances; Student gets AI Assistant despite sharing Free's Basic allowance. Commons is distinct: standard Commons has Basic/no Assistant, while Commons AI offers Max/Assistant. The current [AI features docs](https://docs.overleaf.com/integrations-and-add-ons/ai-features), heading **AI allowance by plan**, agrees with this matrix. An older [Free and premium plans page](https://docs.overleaf.com/getting-started/free-and-premium-plans), heading **AI Assist add-on**, still describes a separately purchased AI Assist add-on; treat that wording as legacy relative to the dated July 2026 update, not as current individual-plan pricing.

These are cloud subscription entitlements, not blanket product or LaTeX-runtime guarantees. The official [Git integration docs](https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration), heading **Git integration**, explicitly cover Overleaf Cloud and Server Pro v4+; this does not establish that the cloud plan matrix applies to Community Edition or every Server Pro deployment. Whether arbitrary LaTeX package/engine support differs by subscription tier is **UNRESOLVED**: the reviewed sources do not claim such a distinction. No compilation was functionally tested.

## EXPAND

No open LEAD: requested plan entitlements and documented limits are covered; arbitrary LaTeX runtime differences are explicitly unresolved rather than inferred.
