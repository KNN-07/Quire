# Expand 55: Managed users, SSO, and organization administration

Checked: October 26, 2026. Sources: official Overleaf docs at docs.overleaf.com (fetched directly; no authenticated tests, no purchases). Scope is account, group, Commons, and self-hosted administration only. Nothing here describes LaTeX language behavior.

Limitation: the three web searches all failed on bot challenges, so the "omitted functionality" and "deprecation" sweep relied on the official docs index and linked pages, not search. No deprecation notice was found in the pages read.

## Managed Users (Pro group only)

- **Availability:** Group Pro only. Source: https://docs.overleaf.com/groups/user-management/managed-user-accounts, intro hint.
- **Enablement:** Only Lead Administrators can enable it (heading "The group administrator role"). Enabling sends transfer-of-management invitations to existing members (heading "Enabling Managed Users").
- **Restrictions on managed members:** they cannot delete their account, change the primary email, add a secondary email, link ORCID, or start or join another subscription with the same email. AI is off by default, but managed-account admins can enable group AI access (section "What's the difference...").
- **Remove user (non-destructive):** the account returns to Overleaf Free. The user keeps owned projects, and collaborators on those projects become read-only, subject to Free limits. The user keeps access to shared projects and must set a password to log in. Source: heading "Returning ownership of a managed account to the original account owner."
- **Delete user (destructive):** the account is permanently deleted, and its projects transfer to another managed member. The original owner loses access. Source: heading "Deleting users and transferring project ownership."
- **Expired subscriptions:** managed groups are "securely decommissioned" by administrators, and remaining data is deleted "after a set period of time." The period is not stated. Source: "The group administrator role." **UNRESOLVED:** the linked pages "Termination and deletion" and "Secure decommissioning for managed users" were checked; the decommissioning page gives no retention period. The termination page was not opened.
- **Naming mismatch (UNRESOLVED):** the decommissioning page (https://docs.overleaf.com/groups/user-management/secure-decommissioning-for-managed-users) describes a "release" option, while the managed-accounts page lists only "Remove user" and "Delete user." Both pages were read; the difference is not explained.

## Group membership and roles

- **Invitations:** adding an address does not create an account; the invitee registers or accepts with an existing account. CSV export is available. Source: https://docs.overleaf.com/groups/user-management/how-to-add-and-remove-users.
- **Roles** (source: https://docs.overleaf.com/groups/user-management/roles-and-permissions):
  - Admin: billing, add and remove members and managers, metrics and audit logs, Group SSO and Managed Users (Pro only). Admin does not get premium automatically.
  - Manager: membership and metrics. Not automatically premium.
  - Member: receives the group's premium features.
- There is one Group Admin, who receives billing and metrics emails. Changing the Group Admin requires contacting support (same how-to page).

## Group SSO (Pro only, SAML 2.0)

- **Protocol:** standard SAML 2.0 only. Overleaf does not support SCIM. Users create or link their own accounts. Source: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/group-sso-faqs.
- **Flows:** service-provider-initiated only. IdP-initiated flows are not supported; the FAQ suggests a bookmark app pointing to https://www.overleaf.com/sso-login (same FAQ).
- **Signing and encryption:** the response or assertion must be signed. Encrypted assertions are supported but optional (same FAQ).
- **Exclusive SSO:** SSO becomes exclusive per managed account only after the user links SSO and accepts the managed invitation (same FAQ, "Can SSO be made an exclusive login option?").
- **Deleting a user in the IdP does not delete the Overleaf account** (same FAQ).
- **Admin tools** (source: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/maintaining-group-sso): view link status, remind users, unlink one user, or unlink all users. Unlinking all is needed only when the unique identifier changes. Certificates can be overlapped during rotation. Disabling SSO temporarily allows password login.

## Commons

- Commons users enroll themselves, and subscription changes go through Overleaf Support. Designated managers can add and remove managers, view metrics, and download a complete user list from the Admin Hub. Source: https://docs.overleaf.com/commons/user-management.
- Commons is not the Group Pro managed-account model. It has no managed-account controls.

## Server Pro (self-hosted)

- **One auth method at a time:** enabling SSO disables local-password login. SAML 2.0 and LDAP create accounts just-in-time at first login. Source: https://docs.overleaf.com/on-premises/user-and-project-management/user-management.
- **Admin role via SSO:** available from Server Pro 5.2.1 (same page).
- **Deletion:** accounts are soft-deleted by default. Permanent removal is controlled by `ENABLE_CRON_RESOURCE_DELETION`. Soft-deleted accounts can be restored within 90 days when that flag is true (same page).
- **Profile sync:** with `OVERLEAF_SAML_UPDATE_USER_DETAILS_ON_LOGIN` set to true, names are set only in the IdP (same page).
- **Admin panel:** Server Pro supports user listing and search, project transfer, audit logs, session management, and active-user counts. Community Edition supports only user creation. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Manage Users" tables.

## Plan and platform labels

- Managed Users and Group SSO: Pro group plans (paid).
- Commons: institutional subscription.
- Server Pro administration: self-hosted, paid Server Pro edition. Community Edition: only user creation (roles page).
- Platform administration only; no LaTeX capability is involved.

## Not resolved in this angle

- **AI bundling date (July 2, 2026):** the harvest lead could not be confirmed. The Overleaf blog index (https://www.overleaf.com/blog) lists July 6, 2026 (Server Pro 6.2.1) and no AI-bundling post. This report does not combine AI Assist and bundled AI. Status: UNRESOLVED.
- **Retention period after managed-group expiry:** UNRESOLVED (see above).
- **Remove vs. release terminology:** UNRESOLVED (see above).

## EXPAND

- Open leads: AI bundling date, retention period, and remove/release terminology. Each is UNRESOLVED for the reason given above; no value was inferred.
- Duplicates closed: the harvest's Commons and Server Pro claims were verified against primary pages. Other harvest claims were verified against https://docs.overleaf.com/groups/user-management/managed-user-accounts, roles, FAQ, and maintaining-SSO pages.
