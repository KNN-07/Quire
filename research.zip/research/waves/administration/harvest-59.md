# Harvest 59: Self-host compile isolation, scaling, logging and monitoring

Research checked October 26, 2026. This covers Overleaf’s on-premises Community Edition (CE) and Server Pro; claims below concern product/platform operations, not the capabilities of arbitrary LaTeX documents.

## Compile isolation and controls

- **Server Pro sandboxing is per compile/project.** Official [Sandboxed Compiles](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles), headings “Improved security” and “How it works”: each compile runs in a separate Docker container with limited capabilities, separated from other users/projects and without outside network access. CLSI creates sibling TeX Live containers through the host Docker socket, using project files under the configured data directory. It requires socket access and configuration (`SIBLING_CONTAINERS_ENABLED=true` in Toolkit). This is Server Pro only.
- **CE is not a multi-user isolation boundary.** [On-premises welcome](https://docs.overleaf.com/on-premises), “Overview of Server Pro and Community Edition”: CE is for trusted users; without sandboxing, LaTeX runs with the main container’s privileges and can access its filesystem, network and environment. Docs recommend sandboxing for multi-user/production deployments. A Docker container isolates Overleaf from other host applications, but does not isolate CE users’ compiles from one another.
- **Compile timeout is configurable but bounded by other components.** [Project limits](https://docs.overleaf.com/on-premises/support/project-limits) reports a 180-second default. [Project management](https://docs.overleaf.com/on-premises/user-and-project-management/project-management), “Updating project compile timeout”: `COMPILE_TIMEOUT` changes the timeout for new users after recreating the container; existing users require a separate update. It warns that pushing beyond 10 minutes likely encounters another component’s timeout. Don’t treat this setting as a guarantee of process termination or a resource quota.
- **Platform compile lifecycle and outputs:** [Microservices](https://docs.overleaf.com/on-premises/getting-started/microservices), compile-process sections, describes CLSI handling incremental/full sync, streaming stdout/stderr, writing logs and output files, cleaning stopped containers after 24 hours, and removing cache on failure/timeout. This documents implementation behavior, not a user-configurable retention SLA.

## Capacity and scaling

- [Hardware requirements](https://docs.overleaf.com/on-premises/getting-started/requirements/hardware-requirements), “Scaling”: concurrency of compiling users is the main sizing factor; baseline is 2 cores/3 GB for about five concurrent users, with a rule of thumb of another core and 1 GB per 5–10 concurrent users. Higher single-core CPU performance improves compile speed. These are recommendations, not capacity guarantees.
- [Horizontal scaling](https://docs.overleaf.com/on-premises/maintenance/horizontal-scaling) documents multi-instance **Server Pro** deployment with shared MongoDB/Redis, S3-compatible project/history storage, load balancing, and routing compile requests plus subsequent PDF/log downloads to the same instance. It recommends equal instance hardware and local SSD for ephemeral compile files; network disks (including NFS/EBS) can cause compile errors/performance problems. Upgrade migrations must run on one instance at a time. No claim here that CE supports this topology.
- [Server Pro infrastructure](https://docs.overleaf.com/on-premises/getting-started/server-pro-infrastructure), “Compiling” and “Networking”: sandboxed compile containers have no network; internal services communicate over Docker networking. Server Pro optionally externalizes MongoDB/Redis and supports S3-compatible storage.

## Logs and monitoring

- [Logging](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/logging): errors go to per-service logs (for example `web.log`); Toolkit `bin/logs` can select/follow services including `clsi`, and `OVERLEAF_LOG_PATH` bind-mounts logs to the host so they persist across container recreation. The host directory needs owner UID 33 and mode 755. This is log access/persistence, not a documented centralized log aggregation or metrics service.
- [Toolkit quick start](https://github.com/overleaf/toolkit/blob/master/doc/quick-start-guide.md), “Check the logs,” gives `bin/logs -f web` and multi-service viewing; it also points to `bin/doctor` for installation diagnostics. [Toolkit configuration](https://github.com/overleaf/toolkit/blob/master/doc/overleaf-rc.md), `OVERLEAF_LOG_PATH`, confirms host log path configuration.
- **Monitoring/alerting integrations:** UNRESOLVED. The reviewed official sources document logs, diagnostics and deployment architecture, but do not establish built-in metrics dashboards, alerting, compile queue monitoring, or monitoring product availability by edition. Do not infer these guarantees from Docker or logs.

## Platform versus document behavior

Sandboxing, compile timeout settings, service logs, storage placement and scaling topology are platform/deployment features. LaTeX packages, shell-escape usage, document complexity and compile time are project-level behavior constrained by the configured compiler/container and resources; the cited material does not promise arbitrary TeX code safety or a fixed throughput. Cloud plan timeout guidance is separate from self-host configuration and should not be conflated with CE/Server Pro limits.

## EXPAND

- Monitoring metrics/alerting and queue visibility: **LEAD** — unresolved in reviewed official docs; search for an official observability/instrumentation guide before asserting availability.
- CE horizontal scaling support: **LEAD** — official horizontal-scaling page is Server Pro-specific; no CE support guarantee found.
