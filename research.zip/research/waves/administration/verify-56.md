# Verify 56: Privacy, data handling, security controls and export

**Checked October 26, 2026. Verdict: PARTIAL.** Both upstream reports and primary pages were read. Unspecified guarantees remain unresolved. No functional execution, authenticated tests, or purchases.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Collects contact/account and usage/technical data; uses it for service, support, improvement and analytics; permits provider/group sharing and safeguarded international transfers. | [Legal][L] | Hosted | CONFIRMED: Privacy Notice, “How do we collect…” / “The legal basis…” / “International transfers”; June 11, 2026. |
| Users retain ownership; managed organizations can access, delete, share or reassign content; users cannot leave managed status independently. | [Legal][L] | Hosted; managed accounts specifically | CONFIRMED: Terms, “Your Stuff & Your Privacy” / “Managed Accounts.” |
| Essential cookies are required; analytics/advertising opt-out uses “essential cookies only.” | [Legal][L] | Hosted | CONFIRMED: Cookie Policy, opt-out table. |
| Retention is purpose/law-based; deletion can lag; backups/shared files may persist. | [Legal][L], [Account data][A] | Hosted; managed deletion requires administrator | CONFIRMED: “Retention,” “Use post-termination,” “How to delete”; separate Writefull account requires separate deletion. |
| GCP storage, HTTPS/256-bit TLS where supported, multi-location redundant backups, and Digital Science ISO/IEC 27001:2022 certification. | [Legal][L] | Hosted | CONFIRMED: Security Overview headings; still published, dated October 2, 2025. Decrypted legal disclosure is possible; not an end-to-end encryption promise. |
| Password reset, clearing other sessions, account-change notifications, Google/ORCID login; selected-subscription SSO. | [Account security][S] | Hosted; SSO conditional | CONFIRMED: “Resetting,” “Checking…sessions,” “Email notifications,” “Use a secure login method”; universal native MFA UNRESOLVED. |
| Processor inventory includes US hosting and Anthropic/OpenAI processing. | [Processors][P] | Hosted; usage varies | CORRECTED: table now dated May 2026, not upstream's March 2025; not a complete payload map. |
| AI external-processing acceptance covers all AI features; disable-all control exists. Error Assist sends error/code/filenames only on requested fix; Assistant sends necessary project content and may query search engines; rewrite sends selection/context. | [AI][I], [Error Assist][E] | Hosted AI, subject to plan/admin restrictions | CONFIRMED: “Data and privacy,” “Enabling and disabling,” and Error Assist “Data and privacy.” |
| AI bundled: Free/Commons Basic without Assistant; Student Basic with Assistant; Standard higher; Pro/Commons AI Max, fair use. | [July announcement][B], [AI][I] | Hosted plans named | CONFIRMED: July 2, 2026 and current “AI allowance by plan”; older separate-add-on descriptions are superseded. |
| No-training assurances do not establish zero retention. | [AI][I], [July announcement][B], [Legal][L] | Hosted AI | QUALIFIED: docs say never; blog says without explicit consent; Terms “Overleaf AI” excepts exclusive-benefit service training and contractually forbids providers' own training. Wording differs; no unconditional guarantee inferred. |
| Individual/bulk source ZIP and separate PDF export; cached `.bbl` can be downloaded separately or through submission ZIP. | [Downloads][D] | Hosted; no premium gate stated | CONFIRMED: “How to download Overleaf projects” / “How to include a .bbl file”; ordinary source ZIP excludes PDF. |
| Prior-version ZIP downloads are limited by accessible history. | [Account data][A], [History][H] | Free: last 24 hours plus labeled versions; premium owner: full history | CORRECTED: upstream omitted this availability qualification; “Using the full History feature.” |
| Git portability is not lossless platform archival: no branches/tags/LFS/contained submodules; pushes/renames can lose comments/tracked changes. | [Git][G] | Cloud premium owner or expressly granted access; Server Pro 4.0+, not enabled by default | CONFIRMED: “Known limitations,” “Repository not found,” “Server Pro.” |
| Docker/air-gapped deployment; CE lacks compile sandboxing, allowing container filesystem/network/environment access; Server Pro offers sandboxing and SAML2/LDAP. | [On-premises][O], [Comparison][C] | CE versus separately licensed Server Pro | CONFIRMED: overview and system-admin comparison. These are deployment controls, not arbitrary LaTeX security guarantees. |
| Consistent operator backup includes MongoDB, Redis and filesystem, with writes stopped; S3-compatible project/history storage supported. Administrative project ZIP export script also exists. | [Backups][K], [Official code][X] | On-premises CE/Server Pro; script version coverage not established by current guide | CONFIRMED: “Data storage” / “Performing a consistent backup”; code `showUsage` supports user/project/all-user export. Not a hosted account-archive feature. |

## Counter-searches and corrections

Queries: `site:docs.overleaf.com "encrypted at rest"`, `"two-factor"`, `"AI" "retention"`, `"AI" "30 days"`, `site:overleaf.com "AI Assist" "separate subscription"`, and official sandbox/processor searches. Searches returned no usable guarantee for the first four; direct pages support only narrower claims.

AI payload documentation partly closes upstream's lead. The [legacy wiki][W] labels content outdated; current backup docs replace it. Export script code was read, not run. Third-party apps may access content under their own policies ([Security Overview, “Third-party Apps”][L]).

[L]: https://www.overleaf.com/legal
[A]: https://docs.overleaf.com/accounts-and-security/managing-your-personal-information
[S]: https://docs.overleaf.com/accounts-and-security/keeping-your-account-secure
[P]: https://docs.overleaf.com/accounts-and-security/overleaf-data-processors
[I]: https://docs.overleaf.com/integrations-and-add-ons/ai-features
[E]: https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist
[B]: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
[D]: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project
[H]: https://docs.overleaf.com/writing-and-editing/history-and-versioning
[G]: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration
[O]: https://docs.overleaf.com/on-premises
[C]: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
[K]: https://docs.overleaf.com/on-premises/maintenance/data-and-backups
[X]: https://github.com/overleaf/overleaf/blob/main/services/web/modules/server-ce-scripts/scripts/export-user-projects.mjs
[W]: https://github.com/overleaf/overleaf/wiki/Data-and-Backups

## EXPAND

- **LEAD — UNRESOLVED:** hosted encryption-at-rest coverage, customer keys, tenant isolation, native MFA, recovery objectives and backup-erasure deadline. [Security overview][L] and [account security][S] do not specify these guarantees.
- **LEAD — UNRESOLVED:** per-provider AI retention/deletion, complete payload mapping, and full hosted account archive beyond project exports. [AI][I], [processors][P], and [downloads][D] establish narrower facts only.
