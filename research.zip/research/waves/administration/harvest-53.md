# Harvest 53: Overleaf Commons, institutional access, and Commons AI

**Research date:** 2026-10-26. Public official Overleaf sources only; no authenticated use or purchase.

## Commons: scope and access

Overleaf Commons is an institutional subscription for universities and organizations to provide premium Overleaf features campus-wide or to designated groups. The documented subscription includes a custom portal, automatic eligibility validation and upgrade, and an administrator hub with usage metrics. Enrollment depends on confirmed affiliation: either institutional SSO entitlement data or a confirmed email at an entitled domain. [Overleaf Docs, “What is Overleaf Commons?” and “Getting Overleaf Commons”: https://docs.overleaf.com/commons (headings “What is Overleaf Commons?”; “Getting Overleaf Commons”).]

Users provision their own accounts; administrators do not directly enroll them. Existing Overleaf accounts can be linked rather than replaced. Without SSO, enrollment is domain-based and cannot be narrowed by other criteria; with SSO, institution-supplied entitlement data can restrict eligibility by faculties, departments, or roles. [Overleaf Docs, “User enrollment”: https://docs.overleaf.com/commons/user-management/user-enrollment (headings “User account provisioning,” “User enrollment,” “Non-SSO enrollment,” “SSO enrollment”).]

Members can confirm affiliation by adding and confirming an institutional email, or, where SSO is offered, by linking through the institution’s SSO portal. Institutional SSO is implemented using SAML2; Commons SSO is site-wide and distinct from SSO configured for an Overleaf group subscription. [Overleaf Docs, “Commons subscription”: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription (heading “Joining an Overleaf Commons subscription”); “Logging in with institutional SSO”: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso (intro).]

Commons subscription access does not mean permanent institutional entitlement. On leaving or when the institution’s subscription ends, an account without another subscription returns to Free; the user retains projects, while premium features such as unlimited collaborators, integrations, tracked changes, faster compilation, and longer compile timeouts are lost. [Overleaf Docs, “Commons subscription”: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription (headings “Leaving or graduating” and FAQ “What happens if my institution stops offering Overleaf Commons?”).]

## Feature boundaries and plan availability

Overleaf’s institutional sales page identifies Standard as research-group/small-department access with up to 10 invited collaborators, real-time track changes, full project history, enhanced performance, integrations, and the Standard AI allowance. Pro adds SSO, unlimited project collaborators, and Max AI allowance. Commons AI is presented as a campus/department tier with streamlined enrollment and SSO, a custom resource portal, enhanced support/onboarding, and Max AI allowance. These are subscription-plan feature claims, not guarantees for every institution’s configuration. [Overleaf, “Overleaf for universities”: https://www.overleaf.com/for/universities (headings “Standard,” “Pro,” “Commons AI”).]

## Commons AI and AI feature details (current sources)

As of the July 2, 2026 product update, built-in Overleaf AI is included in plans with tier-dependent allowances. Commons (standard) has Basic allowance, like Free, and no AI Assistant. Commons AI is a separate institutional tier providing Max allowance (unlimited within fair-use terms) and the Assistant for institutional members; the post says billing and user management remain centralized. [Overleaf Blog, “Overleaf AI now a part of Overleaf plans” (July 2, 2026): https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans (headings “What each plan includes,” “What’s new: Commons AI for institutions”).]

The current AI feature table lists Free: Basic/no Assistant; Student: Basic/Assistant; Standard: Standard/Assistant; Pro: Max, fair use/Assistant; Commons: Basic/no Assistant; Commons AI: Max, fair use/Assistant. One use is counted for each AI feature invocation; allowance resets every 24 hours. Feature examples include error explanations/fixes, language suggestions and rewriting, equation/table generation, TeXGPT, and citation review. [Overleaf Docs, “AI features”: https://docs.overleaf.com/integrations-and-add-ons/ai-features (headings “What’s included,” “AI allowance by plan,” “Where to find AI tools”).]

Institutional administrators can request institution-wide AI disablement through Support; when disabled, affected Commons members cannot use AI even in projects owned by users outside the institution. [Overleaf Docs, https://docs.overleaf.com/commons (heading “Disabling AI for your institution”).] AI processing is distinct from LaTeX capability: these are optional editor assistance tools, not proof that arbitrary LaTeX source compiles, is corrected accurately, or has any specific semantic behavior. Overleaf says AI may misinterpret complex/custom LaTeX. The AI docs specify that some features send project content, error text/code/file names, selected text, or citation data to third parties; the July 2026 post says user content is not used to train AI models without explicit consent. [Overleaf Docs, “AI features”: https://docs.overleaf.com/integrations-and-add-ons/ai-features (headings “Data and privacy,” “Troubleshooting”); Overleaf Blog, July 2, 2026, same URL above (heading “A note on data and AI principles”).]

## Legacy documentation conflict

Older AI Assist documentation describes free daily-limited tools plus a paid AI Assist add-on and says managed organizational accounts cannot access or purchase it. This conflicts in terminology with the July 2, 2026 announcement that Overleaf AI is included in plans and Commons AI is the institutional upgrade. Treat the older add-on page as legacy, not as the current Commons AI offer; the current AI feature table and dated announcement agree on Commons versus Commons AI tiers. [Legacy Overleaf Docs, “AI features”: https://docs.overleaf.com/integrations-and-add-ons/ai-features (search-indexed/older version describes “AI Assist” add-on; current page has been updated); current sources: Overleaf Blog, July 2, 2026, and current AI allowance table at the same docs URL.]

## Platform versus arbitrary LaTeX

Commons grants subscription entitlements to the Overleaf cloud editor and related platform features. It does not document a restriction or guarantee on what LaTeX language constructs a user may write. Whether particular packages, engines, or source compile is **UNRESOLVED here**; no inference about arbitrary LaTeX support is made from plan descriptions.

## EXPAND

- **LEAD — deployment editions:** Commons is a hosted institutional subscription. Whether Commons features map to Server Pro or Community Edition is **UNRESOLVED**; this angle’s official Commons and institutional sources do not specify an edition equivalence. Research separately using official Overleaf deployment documentation if needed.
- **LEAD — institution-specific configuration:** Actual eligibility rules, enabled features, AI opt-out, and Commons AI entitlement depend on an institution’s contract/configuration; public sources do not establish any particular institution’s setup. Verify through that institution or Overleaf, not inference.
- **LEAD — current legacy AI Assist status:** Older AI Assist add-on language conflicts with the July 2026 plan update. Current Commons/Commons AI allowance table is documented; precise migration treatment of legacy individual subscriptions is **UNRESOLVED**.
