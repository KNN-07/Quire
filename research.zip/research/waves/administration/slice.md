# Overleaf administration functionality

**As of October 26, 2026. Documentation-only verification.** Hosted Overleaf combines individual subscriptions, group licensing and institutional Commons access; these are distinct from self-hosted Community Edition (CE) and separately licensed Server Pro. Groups provide membership, billing, audit and feature controls; Pro groups add managed accounts and SSO. Commons emphasizes eligible users' self-enrollment rather than organizational ownership of their accounts. Both self-hosted editions offer editing, collaboration and full history; Server Pro adds review, authentication, administration and isolated compilation. AI became plan-bundled on July 2, 2026, but allowances, Assistant access and organizational controls differ. The matrix records documented behavior, not executed account, billing, deployment, security or recovery tests.

## Feature matrix

References in the primary URL column resolve to exact official URLs and evidence headings in the source list.

| Feature | Behavior | Availability/limits | Primary URL |
|---|---|---|---|
| Hosted plans (51) | Unlimited projects; invited editors/reviewers per project are 1/10/10/unlimited for Free/Student/Standard/Pro. | Owner is additional; viewers unlimited. Student requires current enrollment at a degree-granting institution. | [S1], [S2] |
| Hosted resources (51) | Compile timeout: Free 10 seconds, premium 240 seconds. Shared limits: 2,000 files, 7 MB editable material, 2 MB guaranteed-editable individual text, 50 MB/upload. | Larger text files may remain editable. Nominal unlimited project size has recommendations: 500 MB generally, below 100 MB with Git/GitHub; above 4 GB can disrupt copying. No compilation-success guarantee. | [S3] |
| Premium scope/history (51,56) | Track Changes, extended compilation and full history follow the premium project owner; collaborators inherit these within that project. | Free history includes last 24 hours **and labeled versions**. Symbol Palette is account-level; integrations have their own entitlement rules. Downgrading preserves projects/existing tracked edits, not continued premium access. | [S2], [S4] |
| Hosted AI entitlements (51,53,60) | Bundled since **July 2, 2026**: Free/Student 5 uses/day; Standard 10; Pro Max/fair use. Commons Basic; Commons AI Max/fair use. | Assistant excluded on Free/ordinary Commons; included on Student/Standard/Pro/Commons AI. Current docs specify 24-hour reset; Max has no guaranteed numeric ceiling. | [S1], [S5], [S6] |
| Group roles/licensing (52) | Admin manages billing, members, managers, metrics and audit logs; managers manage membership/managers and metrics. CSV membership export. | Standard/Pro groups. Admin/manager role alone grants no premium access and consumes no seat without membership. Collaborators need not be licensed members. Invitations do not create accounts; sole-admin replacement requires Support. | [S7], [S8] |
| Billing/seat changes (52) | Admin buys seats and upgrades; website-purchased groups can self-upgrade Standard to Pro. Added seats are prorated to the renewal date. Invoices downloadable; billing details editable. | Up to 20 additional seats self-service is not a total-seat cap. PO payment starts at five seats. Manual billing and absent upgrade controls require contact. Personal subscriptions are not automatically canceled. Comprehensive refunds/credits are not established. | [S1], [S8], [S9], [S10], [S66] |
| Group audit/control (52,55) | Audit export is a ZIP of paginated CSVs, 100 entries/file. Support can disable Chat/Dropbox. AI has an all-member dashboard toggle, immediate effect, member emails and audit records. | Managed Pro defaults AI off; other groups on. Support changes also appear in toggle. Not a per-user toggle; pricing's “Via Support” wording does not erase this workflow. | [S11], [S12] |
| Commons enrollment/administration (53) | Institutional portal, automatic validation/upgrades, administrator hub and usage metrics; existing/new users self-enroll. | Non-SSO eligibility uses confirmed institutional email domains; SSO can add department/role criteria. Admins do not directly enroll users. Support can disable institution-wide AI. | [S13], [S14] |
| Commons ownership/leavers (53) | Users retain account/project control; institutions control entitlement data. Leaving without another subscription returns users to Free while preserving projects/current collaborations. | Alternative login remains available; affiliation reconfirmation is institution-defined. Premium limits/integrations end. Not Pro Managed Users ownership/control. | [S15], [S16] |
| Email/login identities (54) | Primary email/password, linked Google/ORCID and eligible SSO. Secondary addresses support invitations/eligibility, not password login. Twitter/X login discontinued. | Managed restrictions apply. No direct account merge: owned-project transfer and re-sharing are separate tasks. Native hosted MFA is unresolved. | [S17], [S18], [S19] |
| Account security/deletion (54,56) | Password reset, clear other sessions, account-change emails; unmanaged self-deletion removes owned projects, not others' projects. | Current session is retained. Active subscription must be canceled first; Writefull deletion is separate. Managed users cannot self-delete. | [S20], [S21] |
| Managed accounts (55) | Lead admin enables management; members transfer account control. Restrictions cover self-deletion, email/secondary-address changes, ORCID linking and other subscriptions using that email. | Pro group only. AI is disabled **by default**, not permanently prohibited. | [S22], [S12] |
| Managed offboarding (55) | Non-destructive removal returns an independent Free account with owned/shared projects preserved; group SSO removed and password required. Deletion transfers projects to another managed member. | Removed owner's collaborators become viewers, with one writable collaborator permitted. Terminated managed subscriptions lapse 60 days, then soft-delete for 90 days before permanent deletion; Support recovery during soft deletion, not automatic renewal. | [S22], [S23] |
| Group SSO (54,55) | SAML 2.0, invitation/account linking, SP-initiated flows; managed accounts can become SSO-exclusive after linking and management acceptance. | Pro group. No SCIM or account deletion triggered by IdP deletion. Invitation provisioning differs from login-time provisioning. Signing contradiction retained below. | [S24], [S25] |
| SSO administration (55) | Inspect linking, remind/unlink users, overlap certificates and temporarily disable SSO for password access. | Unlink-all is needed for changed unique identifiers, not ordinary certificate/redirect changes. Commons separately supports SAML account creation/linking, not SCIM/direct IdP-initiated flows. | [S26], [S27] |
| Hosted privacy/security (56) | Published Security Overview describes GCP storage, TLS where supported and redundant multi-location backups. Users retain content ownership; managed organizations can access/reassign/delete it. | Retention is purpose/law-based; shared content/backups may persist after deletion. Essential cookies required; analytics/advertising opt-out offered. No E2EE/zero-retention promise. | [S28], [S29] |
| AI consent/data controls (56) | One external-processing acceptance covers AI tools; individual disable switch. Error Assist sends requested error/code/filenames; Assistant sends necessary project content and may query search engines; language tools send text/context. | External processors listed. Organizational disablement can block members in outside projects and outside collaborators on organization-owned projects; do not claim owner-independent access. No-training wording is qualified in Terms. | [S5], [S12], [S28], [S30] |
| Export/portability (56) | Source ZIP individually/in bulk, separate PDF, prior-version ZIP within accessible history; `.bbl` separately or submission ZIP. | Source ZIP is not full account/history/metadata archival. Git is not lossless platform backup and can disturb comments/tracked changes. | [S4], [S29], [S31], [S32] |
| Self-hosted editions (57) | CE and Server Pro: editor, collaboration/sharing, full history, operator access to projects. | CE free/open-source AGPLv3; Server Pro commercial, separate from hosted Pro. “Easy internal collaboration” Pro-only marketing label does not negate CE collaboration. | [S33], [S34], [S35] |
| Server Pro licensing (52,57) | Project-accessing users consume licenses; active means opening a project within twelve months. | No strict technical seat cap; overages require contacting Success for prorated pricing. Renewal counts are customer-reported, not hosted-group seat mechanics. | [S70] |
| Server Pro additions (57) | Commenting, tracked changes, private templates, Symbol Palette, SAML/LDAP registration, Git bridge, sandboxed compiles and optimized/customized TeX Live environments. | Explicit edition comparison; Git deployment guide specifies **4.0.1**, user guide 4.0+; bridge disabled by default. Hosted GitHub/Dropbox/reference-manager integrations are not listed for self-hosted editions. Self-hosted AI unresolved. | [S33], [S36], [S37], [S38] |
| Self-host user administration (55,57) | Pro panel lists/searches users, profiles/projects, ownership transfer, audit logs, sessions, active-user counts and URL lookup. | CE user portal registers users; both editions also have site messages/editor close-reopen controls. Server Pro SAML/LDAP replaces local-password authentication; separate cloud lifecycle rules do not apply. | [S34], [S39] |
| Deployment/maintenance (58) | Recommended Toolkit uses Docker Compose on server/VM, supplies start/stop, logs, doctor, config backup and upgrade helpers; local/external MongoDB/Redis supported. Air-gapped image transfer documented. | Both editions; Pro needs private-image credentials. Toolkit update and application-image upgrade are distinct. No skipped major releases; release-specific MongoDB guidance, no MongoDB downgrade. | [S40], [S41], [S42], [S43], [S67], [S68] |
| Backups/project export (58) | Consistent backups cover MongoDB, Redis pending updates and filesystem with writes stopped. Separate project-export script documented since **5.4.0**. | `backup-config` is configuration only; upgrade is not data backup. Project ZIP export excludes settings/history/collaborators/comments/tracked changes/chat. Image rollback alone may not reverse migrations. | [S42], [S44], [S45], [S46], [S69] |
| Compile isolation/settings (59) | Server Pro sandboxing uses separate restricted compile containers, without host-network resources. On-prem compile timeout configurable; documented default 180 seconds. | CE unsandboxed subprocesses require trusted users. Socket access is not universal host-security assurance. Timeout changes affect new users unless existing records updated; above 10 minutes risks other timeouts. | [S33], [S36], [S47] |
| Scaling/logs/diagnostics (59) | Server Pro horizontal scaling since **3.5.6**: central MongoDB/Redis, S3-compatible project/history storage, local ephemeral compile disks and sticky routing. Toolkit follows/persists service logs; doctor checks environment/config/dependencies. | CE scaling support unresolved. Storage roles differ; NFS/EFS/EBS not supported for scaled project/history storage. No throughput guarantee. Doctor is not continuous monitoring. | [S48], [S49], [S50] |
| Monitoring (57,59) | Internal Prometheus instrumentation; historical active-user metric. | Integrated enterprise metrics still “Coming Soon”; current scrape address/authentication/edition contract, dashboards, compile queues and alerting unresolved. | [S38], [S51], [S52] |
| Public developer surfaces (60) | Open in Overleaf imports snippets, HTTP(S) `.tex` or ZIPs; CLSI component documents JSON REST compilation. | Neither establishes general hosted account/compile automation. Hosted AUP prohibits external processing-engine/API use; private/partner interfaces unasserted. | [S28], [S53], [S54] |
| Browser/offline/experiments (60) | Chrome/Firefox/Safari/Edge and recent Firefox ESR supported; mobile browser access with documented limitations. Current-file offline editing: Free two minutes/premium ten. Labs offers opt-in experiments. | Offline: no switching files, compiling, comments or AI; original-tab recovery not guaranteed. Longer local work needs separate tools. Labs can change/disappear; no stable entitlement inferred. | [S55], [S56], [S57], [S58] |
| Integration boundaries (60) | Premium hosted Git/GitHub/Dropbox and ReadCube/Zotero/Mendeley; Google Drive only external-URL import/manual refresh. | GitHub manual/github.com-only, not general Git-host sync. Dropbox two-way sync has project exclusions. These do not imply self-host parity or arbitrary LaTeX compatibility. | [S2], [S32], [S59], [S60], [S61] |

## Angle coverage map

51: hosted plans/resources/history/AI; 52: group licensing/billing/roles/audit; 53: Commons enrollment/ownership/AI; 54: email/login/security/SSO; 55: management/offboarding/SSO/admin; 56: privacy/AI processing/export; 57: CE/Pro comparison/support; 58: deployment/upgrades/backups; 59: isolation/scaling/logs/metrics; 60: developer/browser/offline/integration boundaries. Overlapping integration/AI leads adopt adjacent verifications 41/46/49/50 and the cluster reconciliation, not duplicate tier assumptions.

## Contradictions and unresolved annex

- **Evidence status:** cluster PASS means documentary coverage, not acceptance testing. Angles 51/52/54/55/56/57/59 remain PARTIAL in their angle reports; 53/58/60 passed with bounds. No input FAIL was supplied. No authenticated workflow, purchase, deployment, upgrade, backup or restore executed.
- **SAML:** FAQ allows signed assertion **or** response; maintenance error says both. Actual enforcement unresolved. FAQ's invitation-based “JIT” does not establish provisioning from SSO login. [S24], [S25], [S26]
- **AI:** prefer July 2 bundling/current plan table over residual live “add-on” wording. Legacy subscription migration/credits/Writefull cross-product rights unresolved. Current allowance is documented every 24 hours, while marketing FAQ says up to 72 hours. Parent AI page lists Summarize/Explain then explicitly removes those named actions and old Writefull toolbar: do not advertise them. Blanket managed-account exclusions conflict with explicit admin enablement; pricing “Via Support” coexists with dashboard control. Detailed rollout/cross-organization precedence remains untested. [S1], [S5], [S6], [S12], [S62], [S63]
- **Security/account gaps:** native hosted MFA, current ORCID unlink/publisher propagation, complete at-rest encryption coverage/customer keys/tenant isolation, RPO/RTO, backup-erasure deadlines, complete account archive, exhaustive AI payload/retention contracts unestablished. No-training language differs between docs, consent-qualified announcement and exclusive-benefit exception in Terms; never infer zero retention. Historical ORCID publisher announcement is **November 2, 2016**, limited to participating publishers, not current universal PDF propagation. [S17], [S20], [S28], [S29], [S30], [S64]
- **Edition/operation gaps:** self-hosted AI, CE horizontal-scaling support and delivered integrated metrics remain unresolved, not unavailable by omission. Versioned 5.x metrics changes/internal routes do not prove current public scrape support. MongoDB requirements/default examples disagree; target-release notes govern, not isolated defaults. No universal rollback/restore guarantee. [S33], [S38], [S41], [S44], [S48], [S51], [S52], [S65]
- **Commercial/support bounds:** individual applicability of administrative pricing checkmarks and exhaustive group refunds/credits/checkout/Server Pro commercial terms unresolved. CE community support differs from Pro technical support to one named staff member; Pro excludes LaTeX-language help and specified version/environment/modification issues. Future-dated October 27 upstream checks were not adopted. [S1], [S7], [S33]

## Primary source list

Links resolve to exact primary URLs; link titles identify evidence headings. Sources were opened in the supplied verification chain; decisive plan/AI/control/edition/SAML/scaling pages reopened for this slice.

- Plans and entitlements: [S1], [S2], [S3], [S4], [S5], [S6].
- Group roles, billing, audit and controls: [S7], [S8], [S9], [S10], [S11], [S12], [S66].
- Commons enrollment and ownership: [S13], [S14], [S15], [S16].
- Accounts and lifecycle: [S17], [S18], [S19], [S20], [S21], [S22], [S23].
- SSO: [S24], [S25], [S26], [S27].
- Privacy and portability: [S28], [S29], [S30], [S31], [S32].
- Self-hosted editions and administration: [S33], [S34], [S35], [S36], [S37], [S38], [S39], [S68], [S70].
- Deployment, recovery and scaling: [S40], [S41], [S42], [S43], [S44], [S45], [S46], [S47], [S48], [S49], [S50], [S51], [S52], [S65], [S67], [S69].
- Developer, browser, offline and integrations: [S53], [S54], [S55], [S56], [S57], [S58], [S59], [S60], [S61].
- Contradictory/legacy AI and historical ORCID: [S62], [S63], [S64].

[S1]: https://www.overleaf.com/user/subscription/plans "Plan cards; Compare all features; FAQ"
[S2]: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features "Account and project level features; downgrade"
[S3]: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits "Overleaf plan limits; footnotes"
[S4]: https://docs.overleaf.com/writing-and-editing/history-and-versioning "Using the full History feature; Downloading an older version"
[S5]: https://docs.overleaf.com/integrations-and-add-ons/ai-features "AI allowance by plan; Data and privacy; Troubleshooting"
[S6]: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans "July 2, 2026; What each plan includes; Commons AI"
[S7]: https://docs.overleaf.com/groups/user-management/roles-and-permissions "Role table"
[S8]: https://docs.overleaf.com/groups/user-management/how-to-add-and-remove-users "Adding users; Exporting; managers"
[S9]: https://docs.overleaf.com/groups/user-management/buying-more-licenses-and-upgrading "Buying licenses; upgrading"
[S10]: https://docs.overleaf.com/groups/subscription-management/accessing-invoices-and-receipts "How to access"
[S11]: https://docs.overleaf.com/groups/user-management/group-subscription-audit-logs "Accessing the audit logs"
[S12]: https://docs.overleaf.com/groups/user-management/controlling-feature-availability "AI features; FAQs; How AI access works across organizations"
[S13]: https://docs.overleaf.com/commons/intro-to-overleaf-commons.md "What is Overleaf Commons?; Disabling AI"
[S14]: https://docs.overleaf.com/commons/user-management/user-enrollment "User account provisioning; Non-SSO enrollment; SSO enrollment"
[S15]: https://docs.overleaf.com/commons/data-ownership-and-user-accounts "Overleaf accounts are owned by users; leavers"
[S16]: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription "Joining; Leaving or graduating"
[S17]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/login-options "Login-method headings"
[S18]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/managing-your-email-addresses "Primary email; secondary addresses"
[S19]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/email-addresses-and-login-faqs "Registered email question"
[S20]: https://docs.overleaf.com/accounts-and-security/keeping-your-account-secure "Sessions; notifications; password reset"
[S21]: https://docs.overleaf.com/accounts-and-security/deleting-your-account "Before deletion; account deletion"
[S22]: https://docs.overleaf.com/groups/user-management/managed-user-accounts "Enabling Managed Users; Returning ownership; Deleting users"
[S23]: https://docs.overleaf.com/groups/user-management/termination-and-deletion.md "Subscription states; Subscription recovery"
[S24]: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/group-sso-faqs "JIT; SCIM; signatures; exclusive SSO"
[S25]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso "Introduction information box"
[S26]: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/maintaining-group-sso "Managing users; Understanding errors; Updating SSO"
[S27]: https://docs.overleaf.com/commons/single-sign-on-sso/sso-faqs "Provisioning; SCIM; initiated flows"
[S28]: https://www.overleaf.com/legal "Security Overview; Retention; Managed Accounts; Overleaf AI; AUP; Cookie Policy"
[S29]: https://docs.overleaf.com/accounts-and-security/managing-your-personal-information "Download/delete information"
[S30]: https://docs.overleaf.com/accounts-and-security/overleaf-data-processors "Processor table, May 2026"
[S31]: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project "Downloads; including .bbl"
[S32]: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration "Cloud; Server Pro; Known limitations"
[S33]: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition "Licensing warning; benefits; support"
[S34]: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions "Editor IDE; Admin Panel"
[S35]: https://github.com/overleaf/overleaf "README: Community Edition; License"
[S36]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles "Improved security; Easier package management; How it works"
[S37]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration "Introduction; enabling"
[S38]: https://www.overleaf.com/for/enterprises/features "Benefits for Users; Benefits for User Admins"
[S39]: https://docs.overleaf.com/on-premises/user-and-project-management/user-management.md "Provisioning users; Updating; Restoring"
[S40]: https://docs.overleaf.com/on-premises/getting-started/what-is-the-overleaf-toolkit "Convenience helpers; Checking your server"
[S41]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/toolkit-settings "MongoDB; Redis; Git bridge"
[S42]: https://docs.overleaf.com/on-premises/maintenance/upgrading-your-deployment "The bin/upgrade Script; Upgrade path"
[S43]: https://docs.overleaf.com/on-premises/installation/air-gapped-offline-deployments.md "Image-transfer procedure"
[S44]: https://docs.overleaf.com/on-premises/maintenance/data-and-backups "Data storage; Performing a consistent backup"
[S45]: https://docs.overleaf.com/on-premises/maintenance/data-and-backups/exporting-projects "Introduction; Limitations"
[S46]: https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x/binary-files-migration "Opening note; Update"
[S47]: https://docs.overleaf.com/on-premises/user-and-project-management/project-management "Updating project compile timeout"
[S48]: https://docs.overleaf.com/on-premises/maintenance/horizontal-scaling "Requirements; Ephemeral files; Load balancer requirements"
[S49]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/logging "Logging; Persisting logs"
[S50]: https://docs.overleaf.com/on-premises/support/getting-help "The Doctor"
[S51]: https://raw.githubusercontent.com/overleaf/overleaf/main/libraries/metrics/README.md "overleaf/metrics-module"
[S52]: https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x "5.2.1, October 24, 2024; 5.1.1, August 13, 2024"
[S53]: https://www.overleaf.com/devs "Overview; Post a Snippet by URI; Base64 Data URL"
[S54]: https://github.com/overleaf/overleaf/blob/main/services/clsi/README.md "Installation; API"
[S55]: https://docs.overleaf.com/troubleshooting-and-support/supported-browsers "Supported browsers"
[S56]: https://www.overleaf.com/learn/how-to/Can_I_use_Overleaf_on_an_iPad_or_other_mobile_devices%3F "Known issues"
[S57]: https://docs.overleaf.com/writing-and-editing/working-offline.md "Limitations; Recovering lost edits"
[S58]: https://docs.overleaf.com/accounts-and-security/overleaf-labs "What to expect from a Labs experiment"
[S59]: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization "What is GitHub sync?; Known limitations"
[S60]: https://docs.overleaf.com/integrations-and-add-ons/dropbox "Which projects are synchronized?"
[S61]: https://docs.overleaf.com/integrations-and-add-ons/google-drive "Introduction; uploading; refresh"
[S62]: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant "Introduction; Opening the AI assistant"
[S63]: https://www.overleaf.com/about/ai-features "What are the fair use limits?"
[S64]: https://www.overleaf.com/blog/434-now-available-link-your-orcid-id-to-your-overleaf-account "November 2, 2016; participating publishers"
[S65]: https://docs.overleaf.com/on-premises/getting-started/requirements/software-requirements "Dependencies"
[S66]: https://docs.overleaf.com/groups/subscription-management/updating-billing-information "Updating payment information"
[S67]: https://docs.overleaf.com/on-premises/maintenance/updating-mongodb "Should I update MongoDB?; Update process"
[S68]: https://docs.overleaf.com/on-premises/installation/using-the-toolkit/4.-choose-community-edition-or-server-pro "Obtaining Server Pro Image"
[S69]: https://github.com/overleaf/toolkit/blob/master/bin/backup-config "__main__: configuration archive branches"
[S70]: https://docs.overleaf.com/on-premises/user-and-project-management/understanding-license-usage "Overview; seat-limit paragraphs"
