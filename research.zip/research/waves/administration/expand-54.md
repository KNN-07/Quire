# Expand 54: Accounts, email identities, ORCID and authentication

Checked 2026-10-27. Public sources only: docs.overleaf.com, overleaf.com blog, and the official overleaf GitHub repository. No authenticated tests and no purchases. Written with `write` because this session has no `apply_patch` tool.

## Platform account features

- **Login methods.** Email plus an Overleaf password, institutional SSO (Commons), Group SSO (Pro), Google, and ORCID. Linked accounts sit under Account Settings > Integrations > Linked Accounts. X/Twitter login is no longer supported (deprecation). Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/login-options (headings "Logging in with an email and password" and the linked-accounts section).
- **Primary and secondary email.** Only the primary email works for password login. Secondary emails verify ownership only if added after March 22, 2024. Managed accounts cannot change their email. Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/managing-your-email-addresses.
- **"This email is already registered."** The address is already a primary or secondary email on another account. Recover that account with a password reset. Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/email-addresses-and-login-faqs (heading "I see an error that says this email is already registered").
- **Merging accounts.** No direct merge exists. Transfer owned projects to the kept account, delete the emptied account, then add its email to the kept account. Source: https://docs.overleaf.com/accounts-and-security/understanding-your-overleaf-account/overleaf-accounts-faqs (heading "I created two Overleaf accounts").
- **Deletion.** Self-service from Account Settings. It permanently deletes owned projects, including legacy ShareLaTeX and v1 projects. Shared projects survive. An active subscription must be cancelled first. Writefull has a separate account. Managed accounts cannot self-delete. Source: https://docs.overleaf.com/accounts-and-security/deleting-your-account.
- **Subscription end.** The account stays and reverts to the free plan. Projects and collaborators remain. An SSO-only user may need to set an Overleaf password. Managed accounts can be deleted by the administrator. Source: overleaf-accounts-faqs, heading "My subscription is ending".
- **Managed accounts (Pro group).** Users cannot delete the account, change email, add a secondary email, link ORCID, or use AI by default. Source: https://docs.overleaf.com/groups/user-management/managed-user-accounts.

## Institutional and group SSO

- **Commons institutional SSO.** SAML 2.0, Commons-only. Overleaf is a registered service provider in eduGAIN, InCommon, and UKAMF. "Unlink SSO" removes the Commons enrollment for that email. Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso/institutional-sso-faqs. Per https://docs.overleaf.com/commons/single-sign-on-sso/sso-faqs, JIT provisioning is supported, SCIM is not, and login is SP-initiated only.
- **Group SSO (Pro).** Members only, not managers. The user must create an account and set a password first. No JIT provisioning. Source: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso.
- **Plan availability.** Commons and Pro group only. The pages do not label these against Free or premium tiers.

## ORCID

- **Current docs.** ORCID is a sign-in and linking option (login-options, email FAQ). The docs do not describe how to unlink ORCID.
- **Legacy, dated 2016-11-02.** The ORCID iD was included in submissions to participating publishers and enabled one-click sign-in. Source: https://www.overleaf.com/blog/434-now-available-link-your-orcid-id-to-your-overleaf-account. Treat the publisher claim as historical; no current publisher guarantee was found.

## Server Pro authentication (on-premises, Toolkit)

- **SAML 2.0.** Current page: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/saml-2.0. Enabled with `EXTERNAL_AUTH=saml`. Uses `OVERLEAF_SAML_*` variables. `OVERLEAF_SAML_CERT` is required since 2.7.0. The metadata endpoint `/saml/meta` arrived in 2.6.0. The admin-flag mapping arrived in 5.2.0.
- **LDAP.** Current page: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/ldap. Enabled with `EXTERNAL_AUTH=ldap`. Uses `OVERLEAF_LDAP_*` variables. The first admin is granted through `/launchpad` or the CLI. LDAP users appear in the Admin Panel after their first login.
- **Legacy wiki (date-tagged).** https://github.com/overleaf/overleaf/wiki/Server-Pro%3A-SAML-Config is marked "View outdated content". Its `SHARELATEX_*` naming predates 5.0.1. Use the Toolkit page instead.
- **Repository scope.** The README at https://github.com/overleaf/overleaf states that Community Edition is AGPLv3 open source, that Server Pro adds LDAP and SAML SSO, and that Community Edition lacks Sandboxed Compiles.

## Security

- Session clearing, notification review, and password reset are covered at https://docs.overleaf.com/accounts-and-security/keeping-your-account-secure and https://docs.overleaf.com/accounts-and-security/changing-your-password.

## Limitations

- The docs index (https://docs.overleaf.com/llms.txt) lists no 2FA or MFA page in the account section. A 2FA search returned no Overleaf documentation about it. Absence in indexed docs is not proof of absence in the product.
- Not fetched in full: understanding-managed-accounts, institutional-email-reconfirmation, and troubleshooting-group-sso-login-problems. Only search snippets were seen.

## EXPAND

- **LEAD (a) MFA/2FA: open.** No evidence found in the indexed docs. Needs direct confirmation from Overleaf support or the account settings page, which this research did not test.
- **LEAD (b) ORCID unlinking and current publisher workflow: open.** Current docs do not describe unlinking. Only the 2016 blog covers publisher submission, so no current guarantee can be stated.
- **LEAD (c) Current Server Pro SAML/LDAP guide vs legacy wiki: closed.** The Toolkit pages are current. The wiki is marked outdated.
- **Deprecation: X/Twitter login removal: closed.** Stated on login-options.
- **Deprecation: Group SSO has no JIT provisioning: closed as a documented absence.**
- **Deprecation: SHARELATEX_* naming: closed as legacy.** Current variables are OVERLEAF_*.
