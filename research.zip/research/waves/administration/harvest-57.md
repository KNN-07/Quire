# Harvest 57: Community Edition vs Server Pro

**Checked:** 2026-10-26. Scope is Overleaf's self-hosted Community Edition (CE) versus Server Pro, not hosted Free/paid plans. Sources below are official Overleaf documentation, product pages, or Overleaf-maintained repositories. This report does not test either product.

## Concrete differences

The current [comparison page](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition), headings **Benefits for users**, **Benefits for user admins**, and **Benefits for system admins**, is the clearest CE/Pro matrix:

- **Shared baseline:** both list the powerful LaTeX editor, full project history, direct admin access to all user projects, and self-hosting. Do not read this as all hosted-Overleaf features being available on-premises.
- **Server Pro only (user-facing):** commenting, real-time tracked changes, internal collaboration, private template management, Git integration, and the Symbol Palette. CE marks these absent.
- **Server Pro only (user administration):** full/easy Admin Panel user management and no manual user upgrades. CE's Admin Panel user management is listed as limited.
- **Server Pro only (system administration/security):** SAML 2 and LDAP SSO, automatic registration through LDAP/SAML, sandboxed compiles, optimized TeX Live, and early security-release notification. CE marks these absent.
- **Support/licensing:** CE receives community support via GitHub Issues. Server Pro is commercial and includes reasonable technical support to one named staff member, with version/environment/modification exclusions detailed under **Server Pro Support**. A hosted Overleaf Pro subscription does not license Server Pro. See the same comparison page, lines/sections **Community Support**, **Server Pro Support**, and product distinction.

The official [Server Pro-only configuration index](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration) independently labels LDAP, SAML 2.0, Sandboxed Compiles, Git integration, templates, and adding LaTeX user help as Server Pro-only. The [Git integration guide](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration), heading **Git integration**, says it is available since Server Pro 4.0.1 and requires the optional `git-bridge` service; feature availability does not mean it is enabled by default.

## Security and compilation boundary

The [CE/Server Pro comparison](https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition), warning under the intro, says CE is intended only where all users are trusted: without sandboxing, LaTeX compiles have the container's filesystem, network, and environment-variable access. The [Community Edition upstream README](https://github.com/overleaf/overleaf), **Community Edition**, repeats this limitation. The [Sandboxed Compiles guide](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles), headings **Improved security** and **Easier package management**, explains that Server Pro can put each project's compile in a separate restricted Docker container, with no host-network access. This is an optional Pro capability requiring Docker socket access, not a claim that every Server Pro installation is sandboxed.

Optimized/customized TeX Live images and easier package/version selection are platform packaging/deployment differences, not extra LaTeX language capabilities. The guide says non-sandboxed Pro uses a basic TeX Live scheme with a limited package subset; sandboxing provides customized images. Arbitrary LaTeX documents may execute shell commands during compilation, which is why isolation matters. None of these product differences implies that one edition's LaTeX language can express documents the other cannot.

## Avoid conflating hosted-plan features

The [official enterprise feature matrix](https://www.overleaf.com/for/enterprises/features), **Benefits for Users / User Admins / System Admins**, distinguishes hosted Overleaf Group/Commons from CE and Server Pro. For example, it lists third-party integrations (GitHub, Dropbox, Mendeley, Zotero) and access to Overleaf-hosted templates as unavailable on both self-hosted columns, while Git integration and private templates are Server Pro features. Thus “Git integration” here means the self-hosted Pro integration, not hosted GitHub integration. The matrix marks CE integrated usage metrics absent and Pro “Coming Soon” (as displayed on the checked page); treat that status as page-specific and not a guarantee of current delivery.

**AI status:** do not apply hosted-plan AI entitlements to self-hosted CE/Pro. Overleaf's July 2, 2026 [AI announcement](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), **What each plan includes**, describes AI as bundled in hosted plans and Commons AI as a separate institutional option. It does not establish CE or Server Pro availability; for these editions AI availability is **UNRESOLVED** by the reviewed sources. Older [AI features documentation](https://docs.overleaf.com/integrations-and-add-ons/ai-features) describes the previous separate AI Assist add-on model. That is legacy hosted-plan guidance and should not silently override the July 2, 2026 announcement or be projected onto self-hosted editions.

## EXPAND

- **No open leads.** The comparison, feature-specific deployment docs, upstream CE README, and current hosted matrix establish the documented differences and boundaries. Self-hosted AI remains explicitly UNRESOLVED; no inference made.
