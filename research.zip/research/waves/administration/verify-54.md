# Verify 54: Accounts, email identities, ORCID and authentication

**PARTIAL — checked October 26, 2026.** Both upstream files were read; `expand-54.md`'s October 27 check date is future-dated and is not adopted. Public official pages were opened, not merely searched. No login, functional execution, purchase, or deployment was tested. These are platform identity features, not arbitrary LaTeX capabilities.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Only primary email supports Overleaf-password login; reset links, security/collaboration notifications and collaborator-visible identity use it. | [Email management][email], "Your primary email address is important" | Hosted accounts; no premium prerequisite stated | CONFIRMED |
| Secondary addresses support dashboard invitations, possible Commons/SSO eligibility, and ownership verification only when added after March 22, 2024. Ordinary addresses require email confirmation; institutional SSO addresses authenticate through the institution. | [Email management][email], secondary-address and changing-address sections | Unmanaged hosted accounts | CONFIRMED; not additional password-login identities |
| Google and ORCID can be linked at registration or under Integrations > Linked Accounts; Twitter/X login is discontinued. | [Login options][login], respective login headings | Hosted; no paid prerequisite stated; managed restrictions apply | CONFIRMED |
| Duplicate-email errors indicate another account; direct account merging is unavailable. Transfer owned projects, delete the emptied account, then reuse its email; shared projects require owners to re-share. | [Email FAQ][emailfaq], registered-email question; [Account FAQ][accounts], merge question | Hosted | CONFIRMED; do not promise secondary-address password reset independently of the primary-email rule |
| Self-deletion permanently removes owned projects, including legacy projects, but not projects owned by others; active subscriptions must first be cancelled. Writefull deletion is separate. | [Deletion][delete], deletion and pre-deletion sections | Unmanaged hosted accounts | CONFIRMED |
| Ordinary subscription expiry preserves account/projects on Free, with collaborators becoming viewers. Managed-account non-destructive removal preserves ownership but removes group SSO and requires an Overleaf password. | [Account FAQ][accounts], subscription-ending question; [Managed Users][managed], returning ownership | Individual/Standard/Commons; separate Pro managed removal | CONFIRMED; not blanket preservation for managed subscription termination |
| Managed users cannot self-delete, change email, add secondary addresses, link ORCID, or join another subscription using the same email. Admins can delete and transfer projects. | [Managed Users][managed], differences/admin headings | Pro group only | CONFIRMED |
| Institutional SSO uses SAML 2.0; eduGAIN/InCommon/UKAMF registration is documented. Eligible login enrolls Commons; unlinking removes corresponding enrollment unless relinked for that institution. | [Institutional FAQ][institution], setup/enrollment/unlink questions | Commons institution offering SSO | CONFIRMED |
| Commons permits JIT account creation/linking, not SCIM; directly supports SP-initiated flows only. Group SSO excludes managers, requires an existing password-configured account, and has no JIT. | [Commons FAQ][commons]; [Group SSO][group], introduction | Commons versus Pro group | CONFIRMED; distinct provisioning contracts |
| SAML/LDAP integrations are Server Pro features, not CE entitlements. Toolkit uses `EXTERNAL_AUTH=saml` or `ldap` and `OVERLEAF_*`. | [Repository][repo], Enterprise; [SAML][saml], Overview; [LDAP][ldap], Overview | Server Pro | CONFIRMED |
| SAML certificate required since 2.7.0, metadata endpoint since 2.6.0, admin mapping since 5.2.0; LDAP admin bootstrap uses launchpad/CLI and users appear after first login. | [SAML][saml], Configuration/certificates/metadata; [LDAP][ldap], Overview | Version-specific Server Pro | CONFIRMED |
| Sessions can be cleared except the current session; account-change notifications cover email, identity linking and session clearing. | [Account security][security], session/notification headings | Hosted; no premium prerequisite stated | CONFIRMED |
| Native hosted MFA, ORCID unlinking, and universal current ORCID publisher propagation | [Login options][login]; [Account security][security] | UNRESOLVED | Neither page establishes these guarantees |

## Corrections and limitations

Current [Managed Users][managed] says AI is disabled **by default**, not categorically unavailable. [Feature controls][controls], "AI features", documents an administrator toggle. The [July 2, 2026 announcement][ai] bundles AI into plans with differing allowances; older AI Assist add-on wording must not be combined with this model. Feature controls internally conflicts on non-managed default allowances ("free level" versus its final Standard/Max table); exact allowances are outside this identity verification.

The [SAML wiki][wiki] explicitly marks its content outdated and redirects to current documentation; it dates the `SHARELATEX_*` rename to 5.0.1. [Environment variables][env] explicitly permits MFA through an on-premises identity provider/directory; this does not establish native hosted MFA.

The upstream November 2, 2016 [ORCID publisher announcement][legacy] timed out during retrieval. Its historical publisher claim is **not independently reverified**, and no current automatic project/PDF ORCID guarantee is established. [Email FAQ][emailfaq], lost-primary-email question, directs users to Support; it does not guarantee recovery when all identities are lost.

## Counter-search queries

- `site:docs.overleaf.com accounts login ORCID two factor authentication`
- `site:docs.overleaf.com "two-factor"` and `"two factor" authentication`
- `site:overleaf.com "multi-factor" authentication`
- `site:overleaf.com "ORCID" "unlink"`; `site:docs.overleaf.com ORCID unlink remove`
- `site:docs.overleaf.com commons sso JIT SCIM`
- `site:docs.overleaf.com managed user accounts AI default`
- `site:overleaf.com "July 2, 2026" AI`

## Sources

[email]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/managing-your-email-addresses
[login]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/login-options
[emailfaq]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/email-addresses-and-login-faqs
[accounts]: https://docs.overleaf.com/accounts-and-security/understanding-your-overleaf-account/overleaf-accounts-faqs
[delete]: https://docs.overleaf.com/accounts-and-security/deleting-your-account
[managed]: https://docs.overleaf.com/groups/user-management/managed-user-accounts
[institution]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso/institutional-sso-faqs
[commons]: https://docs.overleaf.com/commons/single-sign-on-sso/sso-faqs
[group]: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso
[repo]: https://github.com/overleaf/overleaf
[saml]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/saml-2.0
[ldap]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/ldap
[security]: https://docs.overleaf.com/accounts-and-security/keeping-your-account-secure
[controls]: https://docs.overleaf.com/groups/user-management/controlling-feature-availability
[ai]: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
[wiki]: https://github.com/overleaf/overleaf/wiki/Server-Pro:-SAML-Config
[env]: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/environment-variables
[legacy]: https://www.overleaf.com/blog/434-now-available-link-your-orcid-id-to-your-overleaf-account

## EXPAND

- **LEAD — Hosted native MFA:** Official security/login pages do not resolve availability; seek an explicit public support statement, not an inference from search absence.
- **LEAD — ORCID unlink/current publisher behavior:** Linking is confirmed; unlink procedure and current publisher propagation remain undocumented in reviewed sources. Re-fetch the legacy announcement only for historical verification.
- Server Pro guide lead closed: current official Toolkit pages replace the outdated wiki.
