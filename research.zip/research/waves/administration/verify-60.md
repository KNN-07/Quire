# Overleaf verification: APIs, integrations, browser/mobile support, boundaries

Checked October 26, 2026 against public primary sources; no authenticated testing or purchases. **Verdict: PASS (bounded)** — upstream conclusions are supported after correcting AI packaging and Community Edition availability. Lack of a published general cloud API is unresolved scope, not proof that private interfaces do not exist.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| **Open in Overleaf** sends snippets, HTTP(S)-fetchable `.tex` files, or ZIPs to `/docs`; it is an import/create surface, not documented account administration or compilation automation. | https://www.overleaf.com/devs — “Overview,” “Post a Snippet by URI (URL),” “Base64 Data URL” | Public Cloud entry point | **CONFIRMED**; general cloud REST API **UNRESOLVED**. |
| CLSI documents JSON REST compilation, including `POST /project/<project-id>/compile`, runnable standalone or in the Overleaf stack. It does not promise public Cloud access. | https://github.com/overleaf/overleaf/blob/main/services/clsi/README.md — “Installation,” “API” | Self-hosted component | **CONFIRMED**; cloud inference rejected. |
| Hosted Overleaf may not be used as an external processing engine/API; access must use supported interfaces. | https://www.overleaf.com/legal — “Acceptable Use Policy,” last modified May 5, 2026 | Hosted service | **CONFIRMED**. |
| Git is Premium on Cloud and Server Pro 4.0+ (disabled by default there). No branches/tags, Git LFS, or nested submodules; symlinks/execute bits are not preserved. | https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration — “Overleaf Server Pro,” “Known limitations” | Premium Cloud; Server Pro; **not CE** | **CONFIRMED**. CE source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — “Benefits for users.” |
| GitHub sync is Premium, github.com-only, manual, and cannot pair two existing projects or later switch/unlink the repository. Guidance says under 100 changed files/commit and 100 MB/project; LFS/submodules are unsupported. | https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization — “What is GitHub sync?”, “File limits,” “Known limitations” | Premium individual/group/Commons | **CONFIRMED**. |
| Dropbox provides Premium two-way sync through fixed `Apps/Overleaf`; read-only/link-shared and archived/trash projects do not actively sync. | https://docs.overleaf.com/integrations-and-add-ons/dropbox — “Which Overleaf projects are synchronized?” | Premium individual/group/Commons | **CONFIRMED**. |
| ReadCube, Zotero, and Mendeley are Premium; provider API data is imported as supplied, so citation keys may differ from manual exports. | https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations — “Reference Manager integrations”; https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero — “Notes…” | Premium individual/group/Commons | **CONFIRMED**. |
| Google Drive is not direct/two-way synchronization: shared files are pulled by external direct-download URL and may be manually refreshed. | https://docs.overleaf.com/integrations-and-add-ons/google-drive — opening paragraph, “Uploading the Google Drive file into an Overleaf project” | General file-import workflow | **CONFIRMED**. |
| Supported browsers are Chrome, Firefox, Safari, Edge, and Firefox ESR releases from the preceding 12 months; preview builds are not guaranteed. Mobile browser access has documented touch, keyboard, scrolling, shortcut, input-device, and PDF-viewer limitations. | https://docs.overleaf.com/troubleshooting-and-support/supported-browsers — “Supported browsers”; https://www.overleaf.com/learn/how-to/Can_I_use_Overleaf_on_an_iPad_or_other_mobile_devices%3F — “Known issues…” | Browser access; no native-app guarantee found | **CONFIRMED**. |
| Since July 2, 2026 AI is plan-bundled: Free/Commons Basic without Assistant; Student Basic with Assistant; Standard Standard with Assistant; Pro/Commons AI Max with Assistant. | https://docs.overleaf.com/integrations-and-add-ons/ai-features — “AI allowance by plan”; https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — “What each plan includes” | Free through Pro; Commons/Commons AI | **CONFIRMED current state**. Separate-add-on wording at https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features is **LEGACY/CONTRADICTED**; old-subscription transition **UNRESOLVED**. |

## Unsupported boundaries

Platform integrations are not arbitrary LaTeX guarantees. Community Edition lacks Git integration and sandboxed compiles and is recommended only for trusted users: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — warning/feature tables. “Server Pro Support” excludes direct LaTeX language, layout, and programming-error help.

## Counter-search queries

- `site:overleaf.com/devs Overleaf REST API project account compile`
- `site:docs.overleaf.com GitHub Enterprise LFS existing repository`
- `site:docs.overleaf.com Community Edition Git sandboxed compiles`
- `site:overleaf.com/blog Overleaf AI plans July 2 2026`
- `site:docs.overleaf.com AI Assist add-on`
- `site:docs.overleaf.com supported browsers mobile native app`

## EXPAND

- **LEAD — general Cloud REST API:** No supported general-purpose Cloud API was found in the reviewed official developer docs; only Open in Overleaf is published. Exact private/partner interfaces are **UNRESOLVED** and must not be inferred.
- **LEAD — legacy AI Assist transition:** Current bundled tiers are explicit, but official public sources reviewed do not explain migration, credits, or entitlement handling for earlier standalone AI Assist/Writefull purchasers.
