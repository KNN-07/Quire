# Verify 53: Commons, institutional access, and Commons AI

**Date:** October 26, 2026. **Verdict: PASS** for documented institutional capabilities; unresolved details are isolated below. Read both `harvest-53.md` and `expand-53.md`. Public-source verification only: no authenticated tests, purchases, or functional execution.

## Claim table

Source identifiers resolve to exact primary URLs below; headings identify the supporting evidence.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Institutional premium upgrades cover campus/company or specified groups; custom portal, automatic validation/upgrades, administrator hub and usage metrics are included. | S1, “What is Overleaf Commons?” | Commons | CONFIRMED |
| Users self-provision and self-enroll; existing accounts work; administrators do not directly enroll users. Without SSO, eligibility can only be restricted by email domain; SSO entitlement data permits faculty/department/role restrictions. | S2, “User account provisioning,” “Non-SSO enrollment,” “SSO enrollment” | Commons | CONFIRMED |
| Join by adding institutional email and confirming it; where SSO exists, use Link Accounts to confirm affiliation. Existing personal subscriptions are not automatically canceled. | S3, “Joining,” existing-individual-subscription FAQ | Commons | CONFIRMED |
| Institutional SSO uses SAML2 and is site-wide, distinct from Group SSO. Overleaf is registered in eduGAIN, InCommon and UKAMF; infrequent SSO logins can cause temporary removal. | S4, introduction/information box; S12, setup/joining FAQs | Some Commons subscribers | CONFIRMED |
| Accounts/project data remain user-controlled; institutions control administrative entitlement data. This does not override institutional IP policies. Alternative login methods remain available; affiliation reconfirmation frequency is institution-defined. | S5, “Overleaf accounts are owned by users,” “How single sign-on works,” leavers section | Commons | CONFIRMED |
| Leaving/expiry without another subscription returns users to Free, preserving projects/current collaborations but losing premium entitlements, including integrations, tracked changes and enhanced compile limits. Maintain an accessible login/email. | S3, “Leaving or graduating,” subscription-ending FAQ | Commons to Free | CONFIRMED |
| Standard advertises 10 invited collaborators, track changes, full history, performance/integrations and Standard AI. Pro adds SSO, unlimited collaborators and Max AI. Commons AI advertises streamlined enrollment/SSO, resource portal, enhanced support/onboarding and Max AI. | S6, plan headings | Institutional Standard / Pro / Commons AI | CONFIRMED; not institution-specific guarantees |
| Free and Commons: Basic AI, no Assistant. Student: Basic plus Assistant. Standard: Standard plus Assistant. Pro and Commons AI: Max plus Assistant, subject to fair use. Invocations count toward allowance, resetting every 24 hours; no numeric Basic/Standard quota is specified here. | S7, “AI allowance by plan” | Free / premium / Commons / Commons AI | CONFIRMED |
| AI is bundled by plan; Commons AI is an institutional upgrade with centralized billing/user management. | S8, July 2, 2026 date; “What's new: Commons AI for institutions” | Commons AI | CONFIRMED; date independently visible |
| Support can disable AI institution-wide, affecting members even in outsiders' projects. | S1, “Disabling AI for your institution” | Commons | CONFIRMED |
| AI assists errors, language/rewriting and table/equation generation; suggestions can misinterpret custom LaTeX. Some content goes to external processors. Docs say no model training; blog qualifies this with “without explicit consent.” | S7, “What's included,” “Data and privacy,” “Troubleshooting”; S8, data principles | AI, plan-limited | CONFIRMED wording difference; no broader privacy guarantee inferred |

## Corrections and boundaries

The current Assistant page still calls it an AI Assist add-on, while subsequently describing plan-based access (S9, opening/“Opening the AI assistant”). This is a **live documentation inconsistency**, not merely an unretrieved historical page. Prefer the explicit current allowance table and dated July 2 announcement for Commons AI entitlements; legacy add-on billing/migration remains UNRESOLVED.

S7 “Troubleshooting” explicitly removes Summarize/Explain despite listing them near the top: do not promise those tools. Its managed-account prohibition also conflicts with S10's group-admin override. Do not equate Commons user-owned accounts with Managed Users (S5). S10's all-members toggle/user-level-controls FAQ concerns Groups; it does not establish that Commons lacks every per-user control.

Commons entitlements are platform features, not guarantees about arbitrary LaTeX packages, engines or successful compilation. S11 distinguishes hosted Overleaf, local Community Edition and supported Server Pro; it does not establish Commons AI parity on self-hosted editions. That parity is UNRESOLVED.

## Primary sources

- S1: https://docs.overleaf.com/commons/intro-to-overleaf-commons.md
- S2: https://docs.overleaf.com/commons/user-management/user-enrollment
- S3: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription
- S4: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso
- S5: https://docs.overleaf.com/commons/data-ownership-and-user-accounts
- S6: https://www.overleaf.com/for/universities
- S7: https://docs.overleaf.com/integrations-and-add-ons/ai-features
- S8: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- S9: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant.md
- S10: https://docs.overleaf.com/groups/user-management/controlling-feature-availability
- S11: https://github.com/overleaf/overleaf — README, “Community Edition,” “Enterprise.”
- S12: https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-institutional-sso/institutional-sso-faqs.md

## Counter-search queries

- `site.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans July 2 2026`
- `site.docs.overleaf.com Commons AI AI Assist institutional SSO groups`
- `site.docs.overleaf.com "AI Assist" "managed"`
- `site.docs.overleaf.com "Commons" "Server Pro"`
- `site.overleaf.com "AI Assist" "add-on" "2026"`

Search-indexed legacy AI Assist text was not treated as current proof; current primary pages were opened directly.

## EXPAND

- **LEAD — legacy billing/migration:** UNRESOLVED; live add-on terminology and plan bundling coexist (S7-S9); no migration guarantee found.
- **LEAD — institution-specific entitlements/controls:** UNRESOLVED publicly; consult the institution's portal/contract, not generic plan inference (S2-S3).
- **LEAD — deployment parity:** UNRESOLVED; S11 separates editions without mapping Commons AI entitlements.
