# Verify 55: Managed users, SSO and organization administration

Checked October 26, 2026. **Verdict: PARTIAL**: core capabilities confirmed; two documentation inconsistencies remain. Read both `harvest-55.md` and `expand-55.md`; counter-checked public primary pages, including their current Markdown versions. No authenticated workflows, purchases, or functional execution. These are platform administration features, not arbitrary LaTeX capabilities.

## Claim table

Sources below provide exact URLs; headings and paraphrased evidence appear in each row.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Only Lead Administrators enable Managed Users; enabling invites existing members to transfer management. Admins/managers can remove/delete users and transfer projects upon deletion. | A: “The group administrator role”; “Enabling Managed Users” | Paid Pro group only | CONFIRMED |
| Managed members cannot self-delete, change email, hold secondary email, link ORCID, or join/start another subscription using that email. AI is disabled by default, but admins can enable group access. | A: “What’s the difference…” | Managed Pro accounts | CONFIRMED; not a blanket AI prohibition |
| Remove returns an unmanaged Free account, preserves owned/shared-project access, removes group SSO, and requires a password. Owned-project collaborators become viewers, with one writable collaborator allowed. Delete permanently removes the account, transferring projects to another managed member. | A: “Returning ownership…”; “Deleting users…” | Managed Pro; Free limits after removal | CONFIRMED |
| Terminated managed subscriptions lapse for 60 days, then soft-delete; permanent deletion follows 90 days later. Lapsed accounts remain accessible; soft-deleted accounts require Support recovery requests, not automatic renewal. | B: “Subscription states”; “Subscription recovery” | Managed Pro groups | CORRECTED: upstream retention lead resolved |
| Decommissioning requires offboarding, exporting project ZIPs, then Support-assisted final subscription/admin closure. “Release” describes return to an independent account, matching Remove’s outcome. | C: “Overview”; “Option B”; “Phase 3” | Managed Pro groups | Outcome confirmed; exact UI label inconsistent |
| Admin handles billing, metrics/audit logs and Pro controls; managers handle membership/managers and metrics. Admin/manager premium access requires membership; otherwise they do not consume seats. Invitations do not create accounts; CSV export exists; changing the sole Group Admin requires Support. | D: role table; E: “Adding users”, “Exporting…”, “Add and remove group managers” | Standard/Pro groups; SSO/Managed Users Pro only | CONFIRMED |
| SAML 2.0 Group SSO uses invitation/account linking, not SCIM; SP-initiated only; deleting an IdP user does not delete Overleaf’s account. Exclusive SSO requires both linking and managed-invitation acceptance. Encryption optional. | F: corresponding FAQ questions | Pro group | CONFIRMED |
| Signing requirement is inconsistent: FAQ requires assertion OR response signed; maintenance troubleshooting says both required. | F: signed-assertion question; G: “Understanding errors reported by users” | Pro group SSO | UNRESOLVED contradiction |
| Admins inspect linking, send reminders, unlink individuals/all, overlap certificates, and temporarily disable SSO for password access. Unlink-all is needed for changed unique identifiers, not ordinary certificate/redirect changes. | G: “Managing your users”; “Updating your SSO setup” | Pro group | CONFIRMED |
| Commons self-enrollment differs from managed accounts: managers administer managers, view metrics and download users; subscription changes go through Support. Commons SSO supports new/existing-account linking, not SCIM or direct IdP-initiated flows. | H: “User management”; I: FAQ | Institutional Commons | CONFIRMED; do not import Pro management controls |
| Server Pro uses one authentication method: SAML/LDAP JIT disables local passwords, including admins. SSO admin-role assignment starts at 5.2.1. Name-sync flags can make names IdP-controlled. Soft deletion defaults; with `ENABLE_CRON_RESOURCE_DELETION=true`, recovery window is 90 days. | J: “Provisioning users”, “Updating…”, “Restoring…” | Self-hosted Server Pro | CONFIRMED; separate from cloud retention |
| Server Pro admin panel supports search/list, profiles, projects/ownership transfer, audit logs, sessions and active-user counts. CE’s Manage Users portal only registers users—not all CE administration: both editions support site messages and closing/reopening the editor. | K: “Admin Panel” matrices | Server Pro versus Community Edition | CONFIRMED; upstream “only user creation” narrowed |
| AI bundling announced July 2, 2026; allowances/features vary by plan, with Commons AI an increased-allowance option. This does not override managed-account default disablement. | L: introduction; A: AI hint | Hosted Free/premium/Commons, plan-dependent | CORRECTED: bundling lead resolved |

## Primary sources

- A: https://docs.overleaf.com/groups/user-management/managed-user-accounts
- B: https://docs.overleaf.com/groups/user-management/termination-and-deletion.md
- C: https://docs.overleaf.com/groups/user-management/secure-decommissioning-for-managed-users
- D: https://docs.overleaf.com/groups/user-management/roles-and-permissions
- E: https://docs.overleaf.com/groups/user-management/how-to-add-and-remove-users
- F: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/group-sso-faqs
- G: https://docs.overleaf.com/groups/overleaf-group-single-sign-on/maintaining-group-sso
- H: https://docs.overleaf.com/commons/user-management
- I: https://docs.overleaf.com/commons/single-sign-on-sso/sso-faqs.md
- J: https://docs.overleaf.com/on-premises/user-and-project-management/user-management.md
- K: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md
- L: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans

## Counter-searches and currency

Queries: `site:docs.overleaf.com managed users release secure decommissioning`; `site:overleaf.com/blog "July 2, 2026" AI`; `site:docs.overleaf.com "Group SSO" "SCIM"`; `site:docs.overleaf.com groups managed users deprecated retention termination deletion`; `site:docs.overleaf.com "SSO" "SCIM" "Commons"`; `site:docs.overleaf.com "AI Assist" "managed"`.

Search calls returned no usable result text, so verification used direct official-page retrieval. The upstream's unconfirmed separate AI Assist interpretation must not override current A and the July 2 announcement (date confirmed in L's HTML). Directly opened https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist.md describes shared daily allowance, not separate-add-on purchasing. No deprecation notice found in reviewed pages; this is not a universal absence guarantee.

## EXPAND

- LEAD: Reconcile F versus G on one versus two SAML signatures; documentation alone cannot establish the actual enforced requirement.
- LEAD: Confirm “Release” versus “Remove user” UI wording. Outcomes match in A/C, but no authenticated UI was inspected.
