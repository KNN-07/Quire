# Verify 58: Self-host deployment, Toolkit, upgrades and backups

Verified October 26, 2026. **Verdict: PASS for documentary verification**, with unresolved guarantees below. Read both `harvest-58.md` and `expand-58.md`. This report concerns Overleaf platform administration, not arbitrary LaTeX capabilities. No deployment, upgrade, backup, restore, authenticated test, or purchase was executed.

## Claim table

Sources are exact primary URLs; headings and paraphrased evidence appear in the final column.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Toolkit is recommended for Docker Compose administration on a single server/VM; helpers include up/start/stop, doctor, logs, backup-config and upgrade. | [Toolkit](https://docs.overleaf.com/on-premises/getting-started/what-is-the-overleaf-toolkit) | CE and Server Pro | CONFIRMED: introduction, "Convenience helpers," "Checking your server." |
| CE is free/default; Server Pro is commercial and separately licensed from the SaaS Pro plan, requiring private image credentials. | [Quick start](https://github.com/overleaf/toolkit/blob/master/doc/quick-start-guide.md); [Choose edition](https://docs.overleaf.com/on-premises/installation/using-the-toolkit/4.-choose-community-edition-or-server-pro) | Free CE / licensed Server Pro | CONFIRMED: "Selecting Overleaf Community Edition or Server Pro"; "Obtaining Server Pro Image." |
| Toolkit provisions MongoDB/Redis or connects to external installations. | [Toolkit settings](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/toolkit-settings) | Both | CONFIRMED: `MONGO_ENABLED`, `MONGO_URL`, `REDIS_ENABLED`, `REDIS_HOST/PORT`. |
| LDAP, SAML, sandboxed compiles, Git integration, templates and LaTeX user-help configuration are Pro-only. | [Server Pro-only configuration](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration) | Server Pro | CONFIRMED: section introduction and feature links; not a promise about LaTeX packages. |
| Toolkit code updates do not automatically update the application image; `config/version` selects the image tag. | [Upgrading](https://docs.overleaf.com/on-premises/maintenance/upgrading-your-deployment) | Both | CONFIRMED: introduction and "The bin/upgrade Script"; previous version value saved to `config/__old-version`. |
| Never skip major releases; deployments over one major behind require manual stepped upgrades, not `bin/upgrade`. | [Upgrading](https://docs.overleaf.com/on-premises/maintenance/upgrading-your-deployment) | Both | CONFIRMED: warning and "Upgrade path"; consult release notes and take consistent backups before major upgrades. Air-gapped image imports use `PULL_BEFORE_UPGRADE=false`. |
| MongoDB upgrades follow target-release guidance; never downgrade MongoDB. | [Updating MongoDB](https://docs.overleaf.com/on-premises/maintenance/updating-mongodb) | Both | CONFIRMED: "Should I update MongoDB?" and "Update process"; examples are not current target-version prescriptions. |
| Consistent backups include MongoDB, Redis and filesystem data, with writes stopped. | [Data and backups](https://docs.overleaf.com/on-premises/maintenance/data-and-backups) | Both | CONFIRMED: "Performing a consistent backup" directs stopping `sharelatex`; recursively copy `OVERLEAF_DATA_PATH`. |
| Redis holds pending updates; AOF is recommended/default for new Toolkit installs. Keep backups separately and test them; replication does not prevent corruption. | [Data and backups](https://docs.overleaf.com/on-premises/maintenance/data-and-backups) | Both | CONFIRMED: "Redis" and backup warning. |
| Project exports are not system backups. | [Exporting projects](https://docs.overleaf.com/on-premises/maintenance/data-and-backups/exporting-projects) | CE/Pro; page introduces script in 5.4.0 | CONFIRMED: "Limitations" excludes settings, history, collaborators, comments/tracked changes and chat. |

## Corrections and boundaries

**Upgrade automation does not create a data backup.** The upstream wording "taking a backup" needs qualification: [official `bin/upgrade` implementation](https://github.com/overleaf/toolkit/blob/master/bin/upgrade), `handle_image_upgrade`, comment "Advise the user to take a backup," explicitly leaves data backup to the operator. [Official `bin/backup-config`](https://github.com/overleaf/toolkit/blob/master/bin/backup-config), `__main__` copy/zip/tar branches, copies/archives only `config`.

**Image rollback is insufficient after migrations.** [Binary files migration](https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x/binary-files-migration), opening note and "Update," documents the 5.5.7 preparation procedure and advises restoring a full system backup when downgrading from 6.0. This is version-specific evidence, not a statement that 6.0 is today's latest release.

**Legacy guidance:** [Compose-to-Toolkit migration](https://github.com/overleaf/toolkit/blob/master/doc/docker-compose-to-toolkit-migration.md) explicitly targets v4.x and earlier; its `SHARELATEX_` examples are legacy. Current backup instructions still address direct Compose deployments; no reviewed source establishes Compose deployment is deprecated. [Software requirements](https://docs.overleaf.com/on-premises/getting-started/requirements/software-requirements), "Operating systems," recommends Debian-based systems such as Ubuntu, rather than requiring Ubuntu exclusively.

**Documentation inconsistency:** that requirements page's "Dependencies" lists MongoDB 7.0/8.0, whereas [Toolkit settings](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/toolkit-settings), `MONGO_VERSION`, still lists default 6.0. Treat neither isolated example/default as target-release compatibility guidance; consult the release notes.

[Data and backups](https://docs.overleaf.com/on-premises/maintenance/data-and-backups), "Data storage" and "Migrating data between servers," supports S3-compatible project/history storage and volume migration to an empty instance with permissions preserved, not instance merging or automatic comprehensive backups. It disclaims data guarantees; RPO/RTO and a universal validated restore drill remain **UNRESOLVED**.

The [July 2, 2026 AI announcement](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), "What each plan includes" and "Commons AI," concerns SaaS/Commons entitlements. It establishes no CE/Server Pro AI inclusion. Older separate-AI-Assist wording must not be combined into a self-host entitlement claim.

## Counter-search queries

- `site:docs.overleaf.com on-premises Toolkit upgrades backups deprecated`
- `site:github.com/overleaf/toolkit backup-config upgrade`
- `site:docs.overleaf.com/on-premises backup restore RPO RTO`
- `site:docs.overleaf.com/on-premises "deprecated" "Toolkit"`
- `site:docs.overleaf.com/on-premises "AI" "Server Pro"`

## EXPAND

- **LEAD - Recovery guarantees:** UNRESOLVED. Sources give backup/migration instructions but no RPO/RTO or universal restore-validation protocol; pursue only for a concrete operational recovery runbook.
- **LEAD - On-premises AI entitlement:** UNRESOLVED. The SaaS announcement does not settle CE/Server Pro inclusion; outside this deployment/backup angle.
