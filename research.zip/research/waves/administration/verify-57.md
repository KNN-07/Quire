# Verify 57: Community Edition versus Server Pro

Checked: 2026-10-26. **Verdict: PARTIAL**: core differences confirmed; self-hosted AI and the precise meaning of the marketing collaboration row remain unresolved. Both upstream reports were read. Evidence is public documentation, not functional execution; no deployments, authenticated tests, or purchases.

## Claim table

Source keys resolve to exact primary URLs below. Evidence descriptions identify relevant headings.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| LaTeX editor, full project history, self-hosting, direct access to user projects | S1, Benefits for users/system admins | CE and Server Pro | CONFIRMED matrix; direct access does not promise the same Admin Panel |
| Commenting, tracked changes, private templates, Symbol Palette | S1, Benefits for users | Server Pro only | CONFIRMED; CE marked absent |
| Easy internal collaboration | S1; S2, Editor IDE; S3, Community Edition | Matrix: Pro only; collaboration itself also exists in CE | QUALIFIED: S2 explicitly permits anonymous read/write sharing in both; S3 calls CE collaborative. Do not claim CE cannot collaborate |
| Full Admin Panel user management | S2, Admin Panel / Manage Users | Pro; CE registration only in user-management section | CONFIRMED: Pro adds user listing/search/deletion, project administration, audit logs, session controls, active-user count and URL lookup; shared site controls still exist |
| No manual user upgrades required | S1, Benefits for user admins | Pro only | CONFIRMED matrix label; no broader automation guarantee |
| SAML 2/LDAP SSO, automatic registration through LDAP or SAML 2, early security-release notification | S1, Benefits for system admins | Pro only | CONFIRMED; resolves upstream truncated registration row |
| Sandboxed compiles and customized TeX Live environments | S4, Improved security / Easier package management | Pro only | CONFIRMED configurable capability, not guaranteed in every Pro deployment |
| Git bridge | S5, Git integration; S6, Container / sharelatex | Pro since 4.0.1; CE absent | CONFIRMED separate service; Toolkit `GIT_BRIDGE_ENABLED` defaults false |
| LDAP, SAML, sandboxing, Git, templates, adding LaTeX user help | S7, Server Pro-only configuration | Pro only | CONFIRMED index classification |
| Commercial technical support versus community GitHub Issues | S1, Community Support / Server Pro Support | Pro versus CE | CONFIRMED: Pro support goes to one named staff member; excludes LaTeX-language help and specified modification, version, environment and uncertified-software problems |
| Hosted Pro subscription licenses Server Pro | S1, introductory licensing note | Neither entitlement transfer nor shared license | REJECTED: separate products/licenses |
| Hosted templates and third-party integrations, including GitHub/Dropbox/Mendeley/Zotero | S8, Benefits for Users | Neither self-hosted edition in matrix | CONFIRMED product integrations; not a ban on manual imports or arbitrary LaTeX workflows |
| Integrated usage metrics | S8, Benefits for User Admins | CE absent; Pro "Coming Soon" | UNRESOLVED delivery; Pro active-user count in S2 is not proof of this broader feature |
| Overleaf AI | S9, What each plan includes / Commons AI; S10, opening | Hosted Free/premium/Commons distinctions; CE/Pro unspecified | UNRESOLVED for self-hosting |

## Corrections and boundaries

S4 describes isolated per-compile Docker containers with restricted capabilities and no host-network access. Without sandboxing, compiles share the application container's resources; S3 warns CE requires trusted users. S6 defaults sibling containers to true but requires Server Pro. Thus configurable does not mean disabled by default. S4's TeX Live images/version selection are packaging features, not evidence of a different LaTeX language.

The migration lead is closed: S11 explains an elective cloud migration, not product-wide retirement. S12 announces Server Pro 6.3 on August 31, 2026 and invites purchases. Its multi-tab editor/branding announcements establish Pro availability, not exclusivity versus CE.

AI correction: the **live** S10 now says premium plans extend free daily limits; upstream's separate AI Assist description is legacy/search-index text, with its original publication date unconfirmed. S9, dated July 2, 2026, bundles AI: Free lacks AI Assistant, paid allowances vary, Commons has Basic without Assistant, and Commons AI adds Max with Assistant. Neither source establishes CE/Server Pro AI.

## Primary sources

- S1: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
- S2: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions
- S3: https://github.com/overleaf/overleaf
- S4: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles
- S5: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration
- S6: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/toolkit-settings
- S7: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration
- S8: https://www.overleaf.com/for/enterprises/features
- S9: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- S10: https://docs.overleaf.com/integrations-and-add-ons/ai-features
- S11: https://docs.overleaf.com/on-premises/user-and-project-management/user-management/migrating-from-server-pro-to-group-pro
- S12: https://www.overleaf.com/blog/overleaf-server-pro-6-3-is-available

## Counter-search queries

- `site.docs.overleaf.com "Server Pro" "Community Edition"`
- `site.docs.overleaf.com "Migrating from Server Pro to Group Pro"`
- `site:overleaf.com "Server Pro" "discontinued"`
- `site:docs.overleaf.com/on-premises "AI"`
- `site.overleaf.com "AI" "Server Pro"`
- `site:docs.overleaf.com "Git" "default" "GIT_BRIDGE_ENABLED"`

## EXPAND

- **LEAD: self-hosted AI.** No edition-specific availability statement found; hosted entitlements cannot settle it.
- **LEAD: integrated metrics delivery.** Current matrix still says "Coming Soon"; no delivery guarantee established.
- **LEAD: easy internal collaboration definition.** Marketing label conflicts with a literal no-collaboration interpretation; exact additional workflow is unspecified.
