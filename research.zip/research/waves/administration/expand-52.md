# Expand 52: Overleaf group subscriptions, billing, and license management

Checked: 2026-10-27. Scope: hosted Overleaf group subscriptions (Group Standard / Group Pro), Commons as a contrast, and Server Pro seat licensing. Public official pages only. No authenticated actions, purchases, or tests. Upstream harvest-52.md was read earlier; its claims are used only where re-verified below.

## Findings

**Group creation and admin (Platform feature, Group Standard/Pro)**
- Buying a group subscription creates the group; the buyer becomes the admin. Source: [How to create a group](https://docs.overleaf.com/groups/getting-started/how-to-create-a-group).
- Purchase orders require at least 5 seats; smaller teams pay by card or PayPal; custom seat counts go through contact. Same source.

**Roles (Platform feature)**
- Admin: billing, add/remove members and managers, metrics, Group SSO and Managed Users (Pro only). Admins do not get premium automatically. Source: [Roles and permissions](https://docs.overleaf.com/groups/user-management/roles-and-permissions).
- Manager: add/remove members and managers, view metrics; no premium unless also a member. Same source.
- Member: receives premium. Same source.

**Seats and membership (Platform feature)**
- Adding a user sends an email invite. Removing a member returns the account to Free. Managers and admins do not consume a seat unless they are members. Source: [Adding and removing users](https://docs.overleaf.com/groups/user-management/how-to-add-and-remove-users).
- Joining a group does not cancel a personal subscription; the user must cancel it separately. Source: [Group subscription](https://docs.overleaf.com/subscriptions-payments-and-billing/group-subscription).
- Leaving returns the account to Free. Managed-account members cannot leave on their own. Source: [Canceling your subscription](https://docs.overleaf.com/subscriptions-payments-and-billing/canceling-your-subscription).

**Buying seats and upgrades (Platform feature)**
- Only the admin can buy licenses; a cost preview appears before purchase; an invoice is emailed. Source: [Buying more licenses and upgrading](https://docs.overleaf.com/groups/user-management/buying-more-licenses-and-upgrading).
- Standard-to-Pro self-upgrade is available only for groups bought on overleaf.com; other groups must contact Overleaf. Same source.
- No proration policy is stated on that page. Proration: UNRESOLVED.

**Pricing (plans page snapshot, undated, fetched 2026-10-27)**
- Standard: $25/month or $16.75/month billed annually ($199/year). Pro: $45/month or $33.25/month billed annually ($399/year). Both list "an extra 10% on group licenses." Source: [Plans and pricing](https://www.overleaf.com/user/subscription/plans).
- Organizations (20+ users): contact sales; "up to 35%" volume savings. Same source.
- Per-seat group price schedule, minimum and maximum self-service seats, and refund terms were not found on the pages read. UNRESOLVED.

**Invoices (Platform feature)**
- Invoices appear on the Subscription page. Manually billed (PO) invoices are emailed to the billing contact. Source: [Accessing invoices and receipts](https://docs.overleaf.com/groups/subscription-management/accessing-invoices-and-receipts).

**Managed Users (Platform feature, Group Pro only)**
- Only the Lead Administrator can enable it. AI is off by default for managed users and admins can enable it. Source: [Managed Users](https://docs.overleaf.com/groups/user-management/managed-user-accounts).
- Remove keeps the account on Free with projects owned by the user; Delete permanently deletes the account and transfers its projects to another managed member. Same source.

**AI entitlements (Platform feature; dated legacy handling)**
- Current plans page: AI Assistant is listed as an included feature of Student (paid), Standard, and Pro. Student (free) and Commons do not include it. Source: [Plans and pricing](https://www.overleaf.com/user/subscription/plans); [AI assistant](https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant), "available on Student, Standard, and Pro plans."
- Daily allowance by plan (Free Basic, Standard 10/day, Pro Max, Commons Basic, Commons AI Max): [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features).
- Overleaf's blog says AI is included in all plans and introduces Commons AI. Source: [Overleaf AI now a part of Overleaf plans](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans). The fetched body shows no date; the July 2, 2026 date comes from the harvest and is not confirmed on the page.
- Legacy: the "AI Assist add-on" wording still appears on the AI assistant page. The plans page shows no separate add-on price, so this is treated as legacy naming, not a separate purchase. Date-tagged, not merged.
- Group admins can mark AI unavailable for members. Source: [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features).

**Commons (separate institutional platform)**
- Joined by confirming an institutional email; removing that email removes the account from Commons. Source: [Commons subscription](https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription); [Canceling](https://docs.overleaf.com/subscriptions-payments-and-billing/canceling-your-subscription).

**Server Pro (self-hosted; not Community Edition)**
- Server Pro licenses every user who opens a project; there is no free collaboration. An active user has opened a project in the last 12 months. Source: [Understanding license usage](https://docs.overleaf.com/on-premises/user-and-project-management/understanding-license-usage).
- No hard seat limit is enforced. Over-seat use is reported to Success, which provides prorated pricing; renewals rely on self-reported counts. Same source.
- Server Pro to Group Pro migration: three-month overlap; only source files export, not settings, comments, or track changes. Community Edition lacks Sandboxed Compiles and LDAP/SAML. Source: [Migrating from Server Pro to Group Pro](https://docs.overleaf.com/on-premises/user-and-project-management/user-management/migrating-from-server-pro-to-group-pro).
- Server Pro license price and key terms: not on these pages. UNRESOLVED.

**Deprecation:** The AI features page notes removal of Summarize and Explain and the Writefull toolbar. These are editor UI changes, not billing or licensing, so they are out of this angle.

## Limitations

- Harvest claims not re-opened: renewal mechanics, billing-detail updates, and the "10 collaborators" Standard limit from a dated FAQ. The plans page now shows 10 collaborators per project for Standard. The dated FAQ is not carried forward.
- The plans page has no date; prices are a snapshot as of 2026-10-27.
- Everything here is documentation, not functional testing.

## EXPAND

- **LEAD (UNRESOLVED):** Per-seat group price schedule, self-service seat min/max, proration, and refunds. Plans page resolved list prices only. Start with the group checkout flow and the Buying more licenses page.
- **LEAD (RESOLVED with caveat):** Legacy "AI Assist add-on" vs. the July 2, 2026 bundling. Current plans page shows AI Assistant as an included plan feature with no separate add-on price. Blog date still unconfirmed in body.
- **LEAD (UNRESOLVED):** Group SSO setup and any billing interaction. The sitemap lists "Logging in with Group SSO" for Group Professional; not opened. Start at [Logging in with Group SSO](https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso).
- **LEAD (UNRESOLVED):** Renewal and updating-billing-information pages (harvest-only); not opened.
- **LEAD (UNRESOLVED):** Server Pro price and license-key terms; the on-prem pages describe usage, not price.
- **LEAD (RESOLVED):** Server Pro vs. Group Pro licensing. Covered above by the on-prem license and migration pages.
