# Verify 38: Version comparison, restore, and deleted-file recovery (Overleaf)

Checked 2026-10-27 (task date 2026-10-26). Public documentation only. No restore, compare, or purchase was run. Findings are from documentation text, not functional testing.

## Verdict: PARTIAL

Version history, compare, single-file and whole-project restore, and deleted-file recovery are confirmed by current official docs. Edition-level restore support, whether restore creates a history entry, label gating, and Community Edition behavior remain UNRESOLVED.

## Corrections to upstream files

- Harvest said deleted-file steps came only from a ShareLaTeX mirror. The current official history page has a "Recovering deleted files" section. Upgraded to CONFIRMED.
- Restore is narrower than "anyone with edit capability" on on-premises installs: the roles table allows Owner and Editor, not Reviewer.
- The 24-hour restore window comes from a Dec 2024 blog post (date-tagged). Current docs do not restate it.
- Trash retention: the deleting-a-project page says trashed projects are kept until manually deleted, with no automatic purge queue. This resolves the open retention question.

## Claim table

| Claim | Source (URL, heading) | Availability | Evidence status |
|---|---|---|---|
| View, compare, and download older versions | docs.overleaf.com/writing-and-editing/history-and-versioning, "Comparing versions" and "Downloading an older version" | Platform; plan not stated | CONFIRMED |
| Single-file restore via "Restore this version" | same page, "How to restore a single file" | Platform | CONFIRMED |
| Whole-project restore via "Restore project to this version" | same page, "Restoring an earlier version of the project" | Platform | CONFIRMED |
| Deleted-file recovery from All history | same page, "Recovering deleted files" | Platform | CONFIRMED |
| Free sees last 24 hours plus labeled versions; full history is premium | same page, "Using the full History feature" hint | Premium (owner's plan) | CONFIRMED |
| Full history tied to owner's subscription; downgrade removes it | docs.overleaf.com/getting-started/free-and-premium-plans/premium-features | Premium | CONFIRMED |
| Restore within 24 hours for edit-capable users; older needs "Full document history" | overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes (Dec 11, 2024), "Who can use it?" | Free (24h); premium (older) | CONFIRMED, date-tagged 2024; counter-search snippet matched |
| Restore file or project allowed for Owner and Editor; labels for Owner, Editor, Reviewer | docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, History table | On-premises | CONFIRMED |
| Full project history in both Community Edition and Server Pro | docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition | Both editions | CONFIRMED (history existence only) |
| Trashed projects stay until manually deleted; no auto-purge | docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project, "Trashed Projects" | Platform | CONFIRMED |
| Delete Forever on owned projects removes it for all collaborators, no undo | deleting-a-project page, danger hint; overleaf.com/blog/new-feature-using-archive-and-trash (undated) | Platform | CONFIRMED |
| Shared projects you do not own can only be left, not deleted | deleting-a-project, "How does trashing a project affect collaborators?" | Platform | CONFIRMED |
| Restore a trashed or archived project to the main list | docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects, "How to restore an individual project" | Platform | CONFIRMED |
| Dropbox folder delete keeps project; renames may look like delete-and-create | docs.overleaf.com/integrations-and-add-ons/dropbox, "What should I know before syncing projects?" | Premium (Dropbox sync) | CONFIRMED |
| Admin Deleted Docs list and undelete | roles-and-permissions, Admin Panel table | Server Pro only | CONFIRMED |
| Admin script restore_soft_deleted_docs | github.com/overleaf/overleaf wiki, Troubleshooting | Self-hosted admin | SNIPPET ONLY; legacy |
| Restore creates a new history entry | not stated on any page read | Unknown | UNRESOLVED |
| Labels are plan-gated | not stated on history page | Unknown | UNRESOLVED |
| Community Edition restore of file or project | not split on official pages; third-party fork discussion (github.com/yu-i-i/overleaf-cep/discussions/76) is not official | Unknown | UNRESOLVED |

## Legacy (date-tagged, not used for current conclusions)

- tex.stackexchange 582376 (v1/v2 era): said v2 could label versions but not restore them. Pre-2024; superseded by the restore blog.
- "What is the full history service?" (overleaf.com/learn): v1 only.

## Counter-search queries

- Executed: "Overleaf trashed projects automatically deleted after days retention" (confirmed no auto-purge in docs; blog repeats manual deletion).
- Executed: "Overleaf restore project to previous version creates new history entry" (returned restore blog; no statement about a new history entry).
- Not executed (tool failures earlier in session): "Overleaf Community Edition restore project to previous version", "Overleaf free plan labels versions".

## Limitations

- The 24-hour restore rule rests on a 2024 blog post.
- Edition-level restore availability is not split on any official page read.
- The July 2, 2026 AI bundling claim is out of scope and was not used.

## EXPAND

- LEAD: Confirm Community Edition restore support (file or project) on official on-premises history docs or the overleaf GitHub repo. Reason: the roles table does not split editions for restore.
- LEAD: Confirm whether a restore creates a new history entry. Reason: no page read states it, and the counter-search found nothing.
- LEAD: Check whether labels and downloading older versions are plan-gated. Reason: the history page is silent on plan for both.
- LEAD: Run the two unexecuted counter-search queries. Reason: earlier tool failures left them open.
