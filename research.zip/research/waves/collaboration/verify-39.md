# Verify 39: Project ownership transfer and leaving shared projects

Research date: 2026-10-26 (environment date 2026-10-27). Method: upstream files harvest-39.md and expand-39.md read in full; their claims checked against official Overleaf docs (docs.overleaf.com, .md versions) and the official Overleaf blog. No authenticated tests, no purchases. Documented behavior only; nothing here was executed in an account.

Note on tooling: the apply_patch tool was not available, so this file was written with the write tool.

## Verdict: PARTIAL

Core ownership-transfer and leave/delete claims are confirmed. Several upstream claims were not confirmed in the pages I could read, and two upstream claims are not supported by the fetched text (see table).

## Confirmed platform features

**Ownership transfer (owner action)**
- Only the owner can transfer. Exception: projects created by a managed account. Source: https://docs.overleaf.com/collaborating/transferring-project-ownership.md, warning hint at top.
- Steps: Share, then "Make owner" on the collaborator, then "Change owner". Source: same page, steps 1-4.
- The new owner must already be a collaborator. Source: same page step 2 ("invite them first") and https://www.overleaf.com/blog/new-feature-transfer-project-ownership-on-overleaf, summary list.
- The change is immediate; owner-only rights (adding collaborators, link sharing, deleting) move to the new owner at once. Source: transfer docs, hint after step 4.
- Both parties get email notices. Source: transfer docs, steps 5-6.
- The previous owner stays as a collaborator. Source: blog summary list.
- Plan capabilities do not transfer, but sharing settings are kept. Source: blog summary list ("doesn't reset sharing preferences").
- Availability: the blog says "available to everyone" (all plans, as documented). No plan gate on transfer itself was found.

**Collaborator limits after transfer (plan labels as documented)**
Source: transfer docs, "Will transferring project ownership affect collaborator access?" table.
- Free to Free: no change (1 edit collaborator, unlimited view-only).
- Standard or Group Standard to Free: edit access drops from 10 to 1; all made view-only.
- Professional, Group Professional, or Overleaf Commons (institutional access) to Free: edit access drops from unlimited to 1; all made view-only.
- Free to Standard or Group Standard: edit access rises to 10.
- Free to Professional, Group Professional, or Commons: edit access becomes unlimited.

**Leaving and deleting (collaborator and owner)**
- Trashing does not affect collaborators; it only changes where the project shows for you. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project.md, "How does trashing a project affect collaborators?"
- You cannot delete a project you do not own. Move it to Trashed Projects, then choose Leave. Source: same page, "How to leave a shared project" hint.
- Deleting a project you own removes it for you and all collaborators, with no undo. Source: same page, danger hint.
- Archive keeps a project without queuing deletion. Source: same page, Trashed Projects bullets.

**Managed accounts (Pro group feature)**
- Managed Users are available only to Overleaf Pro group subscribers. Source: https://docs.overleaf.com/groups/user-management/managed-user-accounts.md, opening info line.
- Admins have two removal options: "Remove User (Non-Destructive)", which returns ownership of the account and projects to the original owner, and "Delete User (Destructive)", which transfers the projects to another managed user. Source: same page, "Removing or Deleting Managed Users".
- Managed users cannot reassign their own projects if the account is deleted; admins can. Source: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts.md, "What's the difference..." list.
- AI rule: if a managed user's organization disables AI, that user cannot use AI on any project, including ones owned by others. Source: same page, "AI features and managed accounts" (page undated). UNRESOLVED against the July 2, 2026 AI-bundling blog: that blog was not opened in this pass, so no combined claim is made.

## Contradictions and unsupported upstream claims

- Upstream: "Managed accounts cannot be deleted by the user." Not stated in the pages read. The page lists restrictions on email and subscriptions and on reassigning projects, not a self-deletion ban. Status: UNRESOLVED.
- Upstream: "Leave a project" and "Leave multiple projects" are listed in the on-premises roles table. The table was fetched (https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md) but the excerpt I could read did not show those rows. Status: UNRESOLVED.
- Upstream: Server Pro can transfer a project; Community Edition cannot. The "Transfer ownership" row was not in the excerpt I could read. Status: UNRESOLVED. The Server Pro-only table rows I did see (Delete user: Server Pro Yes, Community No) support the general Server Pro vs Community split.
- Upstream: after an admin "Remove user", collaborators become read-only with one edit collaborator allowed. Not in the excerpt read. Status: UNRESOLVED.
- Upstream: link-share removal. The sharing page excerpt says link joiners do not show in Manage access, and that updating the link level updates their permissions. The FAQ "Can link sharing be turned off again?" was not in the excerpt read. Status: UNRESOLVED.
- Date handling: the transfer blog has no visible date in the fetched text. Publication date: UNRESOLVED. The transfer docs carry no date. No legacy transfer page was found.
- Minor wording: the blog says "Change" and "Change Owner" (steps 4-5); the current docs say "Change owner". Treat the docs as current.

## Limitations (unresolved)

- Whether a project owner can leave their own project without transferring or deleting it. Not documented in any page read.
- Whether a transfer can be reversed by the new owner. Not documented.
- What happens to a collaborator's tracked changes or comments on transfer. Not documented; tracked changes and comments are Server Pro only per the on-premises roles page.
- Whether the Trashed "Leave" option depends on plan. The roles table has no plan column and no source found says either way.

## Counter-search queries (not executed in this pass)

Run these next to close the UNRESOLVED items:
- "overleaf owner leave project" site:docs.overleaf.com
- "overleaf transfer project ownership undo" site:docs.overleaf.com
- "overleaf managed users remove user collaborators read only" site:docs.overleaf.com
- "overleaf can link sharing be turned off again" site:docs.overleaf.com
- "overleaf community edition transfer project ownership" site:docs.overleaf.com
- "overleaf AI features disabled managed users July 2026" site:overleaf.com/blog

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Only owner can transfer (managed-account exception) | transferring-project-ownership.md, warning hint | All plans | CONFIRMED |
| Owner clicks Share, Make owner, Change owner | transferring-project-ownership.md, steps 1-4 | All plans | CONFIRMED |
| New owner must already be a collaborator | transferring-project-ownership.md step 2; blog summary | All plans | CONFIRMED |
| Transfer is immediate | transferring-project-ownership.md, hint after step 4 | All plans | CONFIRMED |
| Both parties get email | transferring-project-ownership.md, steps 5-6 | All plans | CONFIRMED |
| Previous owner stays as collaborator | blog, Overleaf 2026 transfer post (undated) | All plans | CONFIRMED, date UNRESOLVED |
| Plan capabilities do not transfer; sharing kept | blog summary list | All plans | CONFIRMED |
| Edit-seat changes by plan (10 / 1 / unlimited) | transferring-project-ownership.md, plan table | Free, Standard, Group Standard, Professional, Group Professional, Commons | CONFIRMED (labels as documented) |
| Trashing does not affect collaborators | deleting-a-project.md | All plans | CONFIRMED |
| Shared projects cannot be deleted; use Trash then Leave | deleting-a-project.md | All plans | CONFIRMED |
| Owner delete removes project for all | deleting-a-project.md, danger hint | All plans | CONFIRMED |
| Managed Users only for Pro group subscribers | groups/user-management/managed-user-accounts.md | Pro group | CONFIRMED |
| Remove User (non-destructive) returns ownership | managed-user-accounts.md | Pro group, Lead Admin/Manager | CONFIRMED |
| Delete User transfers projects to another managed user | managed-user-accounts.md | Pro group | CONFIRMED |
| Managed users cannot reassign own projects on deletion | understanding-managed-accounts.md | Managed accounts | CONFIRMED (wording differs slightly) |
| Managed AI restriction applies to projects owned by others | understanding-managed-accounts.md | Managed accounts | CONFIRMED on page; reconciliation with July 2, 2026 AI blog UNRESOLVED |
| Managed accounts cannot be self-deleted | none found | Managed accounts | UNRESOLVED (upstream claim not supported) |
| Leave / Leave multiple projects listed as user actions | on-premises roles-and-permissions.md | On-prem; plan gate UNRESOLVED | UNRESOLVED (rows not in excerpt read) |
| Server Pro can transfer ownership; Community cannot | on-premises roles-and-permissions.md | Server Pro vs Community | UNRESOLVED (row not in excerpt read) |
| Remove User leaves collaborators read-only, one edit seat | managed-user-accounts.md | Pro group | UNRESOLVED (section not fully read) |
| Link-sharing removal keeps email invitees | collaborating/sharing-a-project.md FAQ | All plans | UNRESOLVED (FAQ not in excerpt read) |
| Owner can leave own project | none found | Unknown | UNRESOLVED |
| Tracked changes and comments on transfer | none found | Server Pro for tracked changes/comments | UNRESOLVED |

## Counter-search queries

See the list above; these were not executed in this pass.

## EXPAND

- LEAD: Owner-leave behavior. Can an owner leave their own project, or must they transfer or delete it first? UNRESOLVED; needs a primary page or an authenticated test, which was out of scope.
- LEAD: Transfer reversal and tracked-change/comment handling on transfer. UNRESOLVED; no primary page found.
- LEAD: Verify the "Transfer ownership" and "Leave a project" rows in the on-premises roles table (full table, not the excerpt read).
- LEAD: Managed-user "Remove User" effect on collaborators (read-only, one edit collaborator). Source page is https://docs.overleaf.com/groups/user-management/managed-user-accounts.md, section "Returning ownership of a managed account to the original account owner"; the rest of that section was not read in this pass.
- LEAD: Date and reconcile the managed-user AI rule with the July 2, 2026 AI-bundling blog.
