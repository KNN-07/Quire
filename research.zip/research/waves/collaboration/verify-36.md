# Verify 36: Overleaf Chat, Mentions, Notifications, Communication

Research date: 2026-10-26. Method: upstream harvest-36 and expand-36 read in full; primary docs.overleaf.com pages fetched and checked against their claims. Search snippets were not used as evidence. No authenticated tests, no purchases, no codebase edits.

## Verdict: PARTIAL

Chat as a project feature is confirmed. Comment mentions and the notification model are confirmed. Chat limits, chat mentions, chat email notifications, and Community Edition chat availability are not documented on any page read. One upstream claim (comment permissions) and one (chat roles row) could not be confirmed from the fetched text.

## Claim table

| Claim | Source (heading) | Availability | Evidence status |
|---|---|---|---|
| Overleaf Chat exists as a project-scoped, real-time communication feature | https://docs.overleaf.com/groups/user-management/controlling-feature-availability ("Overleaf Chat" row); https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions (sentence on in-project chat) | Group plans: standard, on by default. | CONFIRMED |
| Chat is enabled for all groups, admins can request disablement via Support, no self-service toggle | controlling-feature-availability, intro and table | Group subscriptions | CONFIRMED |
| Chat is not a premium-gated feature | premium-features page (Chat not in list); controlling-feature-availability ("standard feature") | Free individual: not stated | PARTIAL: Free availability UNRESOLVED |
| In-project chat can be disabled on self-hosted via OVERLEAF_DISABLE_CHAT=true | roles-and-permissions page, on-premises section | Self-hosted | CONFIRMED for the variable. CORRECTION: I could not confirm the env-variables page lists it, so do not cite that page. Whether it applies to Community Edition is UNRESOLVED. |
| Chat roles: send/view chat for Owner, Editor, Reviewer, named Viewer; not link-sharing Viewer | roles-and-permissions, "Collaborating" table | On-premises role model | UNRESOLVED: table exists but the chat row was not visible in fetched text. Do not rely on the specific Yes/No cells. |
| @-mentions in comments: type @ and a name or email to pick a collaborator | https://docs.overleaf.com/collaborating/commenting ("Collaborative commenting > Mentions") | Comments (all plans with comments) | CONFIRMED |
| Mentions in chat | none found | - | UNRESOLVED |
| Email notifications require Account Settings opt-in | commenting, "Notifications" hint; track-changes, "Notifications" | All users | CONFIRMED |
| Per-project modes: "All project activity" vs "Mentions and replies only" | commenting, "Notifications"; https://docs.overleaf.com/collaborating/track-changes ("Notifications") | All users | CONFIRMED |
| Notifications bundled in ten-minute increments, not real-time | commenting, "Notifications" warning; track-changes "Notifications" | All users | CONFIRMED |
| Notifications cover comments and tracked changes; chat email is covered | documented scope is comments and tracked changes only | - | UNRESOLVED for chat |
| Track changes is premium: Free No, Student/Standard/Pro Yes, Personal no longer offered | https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features ("Real-time track changes"); https://docs.overleaf.com/collaborating/track-changes ("Introduction") | Free: No | CONFIRMED |
| Free plan: one Editor or Reviewer collaborator; Viewers unlimited | premium-features, "Invite more collaborators" table | Free: 1, Student and Standard: 10, Pro: unlimited | CONFIRMED |
| Comments: reply, resolve, edit or delete own, view and re-open resolved threads | commenting, "Using comments" | All plans with commenting | CONFIRMED |
| Commenting is only in Server Pro, not Community Edition | https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions (note: "Commenting and Real-time tracked changes are only available in Server Pro"); https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition (Commenting row: CE X, Server Pro check) | Server Pro only | CONFIRMED. Not in harvest; added. |
| Comment permissions: resolve or delete collaborator comments is Owner and Editor only | roles-and-permissions table | - | UNRESOLVED: not verified in fetched text |
| Real-time sync via Operational Transformation with WebSocket | upstream harvest, collaborating-in-overleaf page | - | NOT RE-CHECKED in this pass; treat as UNRESOLVED |
| overleaf/chat is the chat backend, migrated into overleaf/overleaf, 2014-2019 copyright | https://github.com/overleaf/chat (README) | Legacy | CONFIRMED as legacy history only |
| Users asked for @-mentions in review comments (issue #1278) | https://github.com/overleaf/overleaf/issues/1278 (body) | - | Request text CONFIRMED. Issue state (open, updated 2026-06-04) UNRESOLVED: not in fetched text. Docs now document comment mentions. |

## Contradictions and corrections to upstream

- Expand-36 said the environment-variables table "applies to both Server CE and Server Pro." Not confirmed. The variable is documented on the roles page, not the env page I could read. Corrected to UNRESOLVED for CE.
- Expand-36 said the roles table lists chat for each role. The row was not visible in fetched text. Corrected to UNRESOLVED.
- Expand-36 said the mention feature request "is a duplicate of the documented feature." Docs now document comment mentions, so the request is effectively met. The issue's open state is still unverified.

## Limitations

- English docs.overleaf.com pages only. Several pages were truncated in fetch output.
- Not documented on any page read: chat message length, history retention, edit or delete of messages, markdown, attachments, chat @-mentions, chat email notifications, in-app bell or push.
- AI bundling (July 2, 2026 blog vs older separate AI Assist docs) is out of this angle. The group page describes AI features with Standard and Pro tiers, but it was not investigated further.
- Third-party sources were excluded.

## Counter-search queries

- "Overleaf chat" site:docs.overleaf.com (limits, retention, deletion)
- "OVERLEAF_DISABLE_CHAT" overleaf toolkit environment variables
- "Overleaf" chat mention notification email site:docs.overleaf.com
- overleaf/overleaf issue 1278 mentions comments state
- "Server Pro vs. Community Edition" chat collaboration site:docs.overleaf.com

## EXPAND

- LEAD: Confirm chat limits, retention, edit and delete, and attachments. Reason: no official page read covers them.
- LEAD: Confirm chat @-mentions and whether chat triggers email notifications. Reason: notification and mention docs cover comments and tracked changes only.
- LEAD: Confirm Free individual account chat availability. Reason: group and premium pages do not state it.
- LEAD: Confirm the chat roles table row and comment resolve permissions on the roles page. Reason: fetched text did not show these cells.
- LEAD: Confirm whether OVERLEAF_DISABLE_CHAT applies to Community Edition. Reason: documented on a Server Pro-scoped page.
- LEAD: Check the current chat module in overleaf/overleaf for implementation facts. Reason: only legacy overleaf/chat was read.
- LEAD: Confirm the state of GitHub issue #1278. Reason: only the body was fetched.
