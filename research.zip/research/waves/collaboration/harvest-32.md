# Harvest 32 — Invitations, collaborator limits, and project access

Research checked October 26, 2026. Sources below are official Overleaf documentation, product pages, and the official Overleaf repository. No authenticated tests or purchases were performed; this report describes documented functions, not execution.

## Hosted Overleaf: sharing and permissions

Projects can be shared by named email invitation or by enabling “Anyone with the link”; the default audience is “Only invited people.” Email invitees authenticate to an Overleaf account and accept the invitation. The owner can change or revoke permissions and resend or revoke pending email invites in Share/Manage access. Source: [Sharing a project](https://docs.overleaf.com/collaborating/sharing-a-project), headings “By Email,” “By Link,” and “Manage access.”

The documented permission levels are **Viewer**, **Reviewer**, and **Editor**. Viewers can view source, download source/PDF, and copy the project, but cannot comment, suggest edits, edit source/add files, accept/reject changes, or restore versions. Reviewers can comment and suggest edits (tracked suggestions), but cannot edit source/add files or accept/reject/restore changes. Editors can do those editing and project operations. Source: [Sharing a project](https://docs.overleaf.com/collaborating/sharing-a-project), heading “Understanding permission levels,” permission table.

Reviewers are documented as available on the Free plan for its one collaborator. The reviewer role can be assigned to a named collaborator by email; the docs say it cannot be set on a sharing link, though a link joiner may be changed to Reviewer after joining. Reviewers cannot create files. Source: [Reviewing and reviewers](https://docs.overleaf.com/collaborating/reviewing-and-reviewers), headings “Reviewer permissions” and FAQ “Can I use this for all collaborators?” and “Can a Reviewer add/create files?”

### Collaborator quotas and availability

Current official premium-features documentation lists per-project limits for **Editors and Reviewers**: Free 1, Student 10, Standard 10, Pro unlimited; **Viewers are unlimited** on all listed plans. “Personal” is listed as 1, but is no longer available to new subscribers. Source: [Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), heading “Invite more collaborators.” The quota depends on the project owner’s plan. A July 1, 2024 post says editors joining by edit link count toward the owner’s collaborator limit, while viewers do not; this is dated rollout information, not treated as a newer guarantee. Source: [Changes to project sharing](https://www.overleaf.com/blog/changes-to-project-sharing), “What’s changing?” (July 1, 2024; rollout completion noted November 7, 2024).

On downgrade to Free, the owner retains owned projects, but only one collaborator may retain edit access per project; other collaborators are moved to view-only. Source: [Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), heading “What happens to my projects if I downgrade to the Overleaf free plan?”

For institutional group plans, the current universities page lists Standard with up to 10 invited collaborators and Pro with unlimited collaborators per project; its Commons AI description says “unlimited collaboration.” The separately documented hosted table names plans Free, Student, Standard, and Pro but does not list Commons as its own quota column. Do not assume a Commons-specific quota beyond that marketing statement. Source: [Overleaf for universities](https://www.overleaf.com/for/universities), headings “Standard,” “Pro,” and “Commons AI.”

## On-premises editions

Official on-premises role documentation says **both Server Pro and Community Edition** support anonymous read-only and read-write project access, controlled by `OVERLEAF_ALLOW_PUBLIC_ACCESS` and `OVERLEAF_ALLOW_ANONYMOUS_READ_AND_WRITE_SHARING`. Owner alone can invite users or update sharing permissions; owner, editor, reviewer, and named viewer can see named collaborators, while link-sharing viewers cannot. Sources: [Roles and permissions](https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions), headings “Editor IDE,” “Sharing,” and “Project & file operations”; [official `overleaf/overleaf` repository](https://github.com/overleaf/overleaf), “Community Edition” and “Enterprise” (identifies the open-source Community Edition and officially supported Server Pro).

The on-premises role table marks commenting and real-time tracked changes as **Server Pro only**; it does not publish hosted Free/Student/Standard/Pro collaborator quotas for self-hosted editions. Those on-prem quotas are therefore **UNRESOLVED**. Source: [Roles and permissions](https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions), heading “Collaborating.”

## Product boundary

These are Overleaf platform sharing, identity, and permission features, not properties of LaTeX itself. LaTeX source can encode arbitrary document behavior, but that does not grant Overleaf account/project access or change a plan’s collaborator quota. No claim is made here about arbitrary LaTeX security or execution.

## EXPAND

- **LEAD — link-joiner visibility conflict:** Current [Sharing a project](https://docs.overleaf.com/collaborating/sharing-a-project), “By Link,” says link collaborators do not appear in Manage access; the official 2024 [sharing-change post](https://www.overleaf.com/blog/changes-to-project-sharing), “What’s changing?”, says edit-link users become visible and count toward limits. Resolve whether current UI/docs distinguish link permission type or reflect changed behavior; do not claim visibility as guaranteed.
- **LEAD — on-prem quotas:** Official on-prem role docs describe access roles but no numeric collaborator limits for Server Pro or Community Edition. Confirm from current edition-specific licensing/admin documentation if exact quotas are needed; no quota is inferred.
- **No further lead for AI Assist:** This angle concerns access and collaborator limits; AI availability does not determine those access rules.
