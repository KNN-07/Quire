# Harvest 34: Reviewer roles, comments, threads, and resolution

Research checked October 26, 2026. This report covers Overleaf collaboration features, not journal peer-review workflows or LaTeX syntax.

## Reviewer role and permissions

On Overleaf hosted projects, the project owner can invite a named collaborator as a Reviewer or change an existing collaborator's access in Share. Reviewers default to Reviewing mode, may add and respond to comments, and their edits are tracked suggestions; they cannot switch to Editing or create project files. Editors and owners can switch between Editing and Reviewing. Link-sharing invitations cannot initially assign the Reviewer role, though the docs say a link-shared user can be converted after joining. **Plan distinction:** Free permits one invited collaborator as Reviewer, but that collaborator can only comment; more than one collaborator requires a premium plan. Sources: [Reviewing and reviewers](https://docs.overleaf.com/collaborating/reviewing-and-reviewers), headings “Reviewer permissions,” “Changing a collaborator’s mode,” and “Frequently Asked Questions”; [Sharing a project](https://docs.overleaf.com/collaborating/sharing-a-project), heading “Number of collaborators allowed.”

Track Changes is distinct from commenting: the current hosted docs classify it as a premium feature, available through qualifying individual/group subscriptions or Commons; collaborators on an eligible project can use it. Reviewers can propose tracked changes, while owners/editors accept or reject selected suggestions. Sources: [Track Changes](https://docs.overleaf.com/collaborating/track-changes), introductory paragraph and “How to accept or reject all tracked changes”; [Reviewing and reviewers](https://docs.overleaf.com/collaborating/reviewing-and-reviewers), “Reviewer permissions.” The Reviewer role itself is available on Free, but the Free-plan exception above means not to infer that Free-reviewer edits are tracked suggestions.

## Comments and discussion threads

Comments are attached to selected source text/lines; highlighting text exposes “Add comment” and opens the review panel. A thread supports replies, and collaborators with project access can view, reply to, and resolve comments. Users can edit or delete their own comment via its menu. Comments are available on all hosted accounts, free and paid (legacy how-to page, still consistent with current commenting docs). Sources: [Commenting](https://docs.overleaf.com/collaborating/commenting), headings “The basics,” “Accessing the comment feature,” “Using comments,” “Collaborative commenting”; [How to make comments in an Overleaf LaTeX project](https://www.overleaf.com/learn/how-to/How_to_make_comments_in_an_Overleaf_LaTeX_project), heading “Commenting: feature overview” (legacy article; account availability statement).

Comment threads can mention a specific collaborator by typing `@` and selecting their name/email. Project email notifications require account notifications enabled and are configurable per project: all project activity, or mentions/replies and activity on one's own comments/tracked changes. Notifications are batched in ten-minute increments, not real-time. Source: [Commenting](https://docs.overleaf.com/collaborating/commenting), headings “Mentions” and “Notifications.”

## Resolution, reopening, retention

Click the checkmark on a comment to resolve it. Resolved comments remain available from the resolved-comments view; a user can reopen them or delete the thread there. The docs do not specify a finer-grained permission rule for hosted thread resolution/deletion beyond “all collaborators with access” for viewing/replying/resolving; exact per-role hosted deletion rights are **UNRESOLVED**. Source: [Commenting](https://docs.overleaf.com/collaborating/commenting), “The basics” and “Using comments.”

History restoration is separate from resolving: Overleaf's December 11, 2024 product post says restoring a file/project version restores its comments and tracked changes; resolved comments can be restored but deleted comments cannot, and unresolved threads retain their comment history through the restored version. Older-than-24-hour restore requires the Full document history premium feature; anyone with edit capability can restore versions from the preceding 24 hours. Date-tagged product update. Source: [Restore version with comments and tracked changes](https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes), headings “Who can use it?” and “What else should I know?”

## Self-hosted availability and boundaries

The On-premises roles matrix gives Reviewers permission to add/reply to comments and tracked changes, but not resolve/delete collaborator comments or accept/reject collaborator tracked changes; Owners and Editors can resolve/delete. It explicitly says commenting and real-time tracked changes are **Server Pro only**, not Community Edition. Thus hosted plan availability must not be projected onto self-hosted Community Edition. Source: [Roles and permissions (On-premises)](https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions), “Editor IDE” collaboration matrix and note at “Collaborating.”

These are editor/project collaboration controls, not LaTeX features: arbitrary LaTeX comments or macros do not create Overleaf reviewer identities, anchored discussion threads, or resolution state. The cited docs describe comments as editor-anchored collaboration; they do not document a LaTeX command interface for those platform features.

## EXPAND

- **LEAD — Hosted reviewer role versus Free tracked suggestions:** current reviewer page says Free reviewer “only” comments, while role description generally says reviewers make tracked changes; plan-specific semantics beyond that sentence are **UNRESOLVED**. Reason: official docs do not explain whether Free reviewers can switch on tracked changes or how suggestions are surfaced on Free.
- **LEAD — Hosted role-specific resolution/deletion permissions:** **UNRESOLVED**. Reason: hosted commenting docs state broad collaborator access but no permission matrix; self-hosted matrix cannot be assumed to apply to hosted service.
