# Expand 36: Overleaf Chat, Mentions, Notifications, Communication

Research date: 2026-10-26. Sources: official docs.overleaf.com pages opened in this session, plus one GitHub issue page. Search snippets were used only to find URLs. No authenticated tests, no purchases.

## Platform features (Overleaf-hosted)

### Collaborator chat

- **Location.** The redesigned editor's left bar includes a Chat icon for real-time communication with collaborators. Source: https://docs.overleaf.com/llms-full.txt, section "Redesigned Overleaf editor", heading "Left bar" (from harvest-36; not reopened here).
- **Who can use it.** The roles table under "Collaborating" lists "View and send chat messages" as Yes for Owner, Editor, Reviewer, and named-collaborator Viewer, and No for link-sharing Viewer. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions (heading "Editor IDE", "Collaborating"). This table sits in the on-premises docs, so it describes the Editor IDE role model generally, not a plan tier.
- **Availability by plan (group).** The group feature page lists "Overleaf Chat" as **enabled for all groups** by default and says it is "a standard feature that is available to all Overleaf users unless disablement is requested by the group administrator." Admins request disablement via Support; there is no self-service toggle. Tier label: **Standard (not premium-gated) per this page**. Source: https://docs.overleaf.com/groups/user-management/controlling-feature-availability (table row "Overleaf Chat").
- **Free individual accounts.** Not stated on the group page or the premium-features page (https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), which does not list chat as premium. Inferred Free availability is UNRESOLVED; do not treat it as documented.
- **Self-hosted control.** `OVERLEAF_DISABLE_CHAT=true` disables the in-project chat feature. The variable appears in the "All versions" table, which is stated to apply to both Server CE and Server Pro. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/environment-variables (table row for OVERLEAF_DISABLE_CHAT). Date tag: current page as of this read.
- **Not documented on any page read:** message length, history retention, editing or deleting messages, markdown, attachments, chat @-mentions, and chat email notifications. All UNRESOLVED.

### Comments and @-mentions

- **Mentions exist for comments.** Under "Collaborative commenting > Mentions": type `@` and start typing a collaborator's name or email to get a list, then flag that person in the comment. Source: https://docs.overleaf.com/collaborating/commenting (heading "Mentions").
- **Comment permissions.** Owner, Editor, and Reviewer can add and reply to comments; view-only roles can see them only if named collaborators; link-sharing viewers cannot. Resolve or delete of collaborator comments is Owner and Editor only. Source: roles-and-permissions page, "Collaborating" table.
- **Comment actions.** Resolve with the checkmark, edit or delete via the ellipsis menu, view resolved threads, delete or re-open a resolved thread. Source: https://docs.overleaf.com/collaborating/commenting (heading "Using comments").
- **Legacy (date-tagged).** A 2014 blog post on rich commenting refers to "the Overleaf v1 platform" and says the new Overleaf has a Review tab. Source: https://www.overleaf.com/blog/176-rich-commenting-is-here-manage-your-feedback-and-review-on-writelatex-number-backtoschool (2014-09-03). Treat as history only.

### Notifications

- **Prerequisite.** Email notifications on project activity must be enabled in Account Settings. Source: https://docs.overleaf.com/collaborating/commenting (hint under "Notifications").
- **Per-project modes.** File > Settings > Project Notifications: "All project activity" (all comments and tracked changes) or "Mentions and replies only" (mentions, replies, and activity on your own comments and tracked changes). Source: same page, "Notifications"; also https://docs.overleaf.com/collaborating/track-changes ("Notifications").
- **Timing.** Notifications are not real-time; they are bundled in ten-minute increments. Source: same pages, warning hint.
- **Scope.** The documented notification settings cover comments and tracked changes only. Chat email notification is UNRESOLVED.
- **In-app bell or push.** Not found in pages read. UNRESOLVED.

### Track changes (adjacent review communication)

- Track Changes is a premium feature, usable in a project when the project owner's account has the subscription. Free accounts: No. Standard, Pro, Student: Yes. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features (heading "Real-time track changes") and https://docs.overleaf.com/collaborating/track-changes (heading "Introduction"). The Personal plan is no longer offered to new subscribers (date-tag: current as of this read).
- Free plan: one collaborator (Editor or Reviewer) per project; unlimited Viewers. Source: premium-features page, "Invite more collaborators" table.

## Open-source and legacy code

- **overleaf/chat.** Per the harvest (not reopened here), this repo describes itself as the backend for chat in ShareLaTeX and has been migrated into overleaf/overleaf; its copyright lines are 2014-2019. Treat as legacy. Source: https://github.com/overleaf/chat (README, as recorded in harvest-36).
- **Current chat implementation** inside overleaf/overleaf was not read. UNRESOLVED.

## Duplicates and conflicts

- **Mentions feature request vs. docs.** GitHub issue #1278, "Feature Request: User Mentions in Comments," asks for @-mentions in review comments to notify people. Source: https://github.com/overleaf/overleaf/issues/1278 (body text). The current commenting docs describe exactly this behavior (see Mentions above). The issue metadata shows state "open," last updated 2026-06-04, per the search result snippet, which I did not confirm on the page. Conclusion: docs now document mentions; whether the issue is stale or still open is UNRESOLVED. The issue is a duplicate of the documented feature for this angle.
- **Chat vs. mentions.** The mention docs are for comments only. No chat @-mention docs found.

## Limitations

- English docs.overleaf.com pages only. The llms-full.txt export was used only as harvested.
- No official page found on chat limits, retention, deletion, or chat email notifications.
- Third-party sources (NativeOverleaf DeepWiki, a Tex StackExchange thread, university guides) were excluded as non-official.
- AI bundling (July 2, 2026 blog vs. older separate AI Assist docs) is out of this angle and was not investigated.
- The `apply_patch` tool was not available in this session; this file was written with the write tool.

## EXPAND

- LEAD: Chat limits, retention, edit/delete, markdown, attachments. Reason: no official page read covers them.
- LEAD: Chat @-mentions and chat email notifications. Reason: notification and mention docs cover comments and tracked changes only.
- LEAD: Free individual account chat availability. Reason: group and premium pages do not state it.
- LEAD: Current chat code in overleaf/overleaf. Reason: only the legacy overleaf/chat README was consulted, via the harvest.
- LEAD: Status of GitHub issue #1278 versus the mention docs. Reason: the issue page body was fetched but the state was taken from search metadata.
- LEAD: Chat on Server Pro vs. Community Edition beyond the disable variable. Reason: the variable table implies availability in both, but no page states it directly. Partial: confirm on https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition.
