# Expand 38: Version comparison, restore and deleted-file recovery (Overleaf)

Research date: 2026-10-26. Public sources only. No authenticated tests, no purchases. Claims below were checked against pages opened in this session unless marked otherwise.

## 1. Platform features

### Version history and comparison

- **Open history.** The History icon above the preview panel opens History mode. "All history" lists every version; "Labels" lists labeled versions. Source: https://docs.overleaf.com/writing-and-editing/history-and-versioning (heading "How to access a project's history").
- **Compare.** Versions are listed newest first. Each version has align icons: compare up to this version, compare from this version, or a range via a drop-down for middle versions. Source: same page, heading "Comparing versions".
- **Labels.** Any version can carry multiple labels; the live state is "Current state." Labels make versions easy to find for compare, download, or restore. Source: same page, heading "Labeling a project version".
- **Download an older version.** The File-menu download only returns the current state. For older versions, use All history, the three-dot menu, and "Download this version" (.zip). Source: same page, heading "Downloading an older version of your project".
- **Copies start fresh.** A copied project does not inherit the original's history. Source: same page, heading "What happens to the history if you copy a project?".

### Restore

- **Who can restore.** Anyone with edit capability can restore a file or project version from the past 24 hours. Restoring anything older requires the "Full document history" premium feature. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes (blog dated December 11, 2024; heading "Who can use it?").
- **Single file.** Choose the version, select the file in the file list, then "Restore this version." This reverts content plus comments and tracked changes to that time. Source: same blog, "Restore a single file"; docs page heading "How to restore a single file to a previous version."
- **Whole project.** Choose "Restore project to this version" from the version's three-dot menu. Source: docs page heading "Restoring an earlier version of the project"; blog "Restore a full project."
- **Comments.** Resolved comments can be restored; deleted comments cannot. Unresolved threads keep their full history up to the target version. Source: blog, heading "What else should I know?"

### Deleted-file recovery

- **Method.** Switch to All history, select a version where the file existed, pick the struck-through file in the list, then "Restore this version." Source: docs page heading "Recovering deleted files."
- **Projects in Trash.** Trash is a separate folder. "Delete Forever" permanently deletes a project you own for you and all collaborators, with no undo; leaving is the option for projects you collaborate on. Source: https://www.overleaf.com/blog/new-feature-using-archive-and-trash-to-keep-your-projects-organized (undated in the fetched text).
- **Restoring a project from Trash** is listed as available to User-role accounts. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions (table "Project management and collaboration", row "Restore a project").

## 2. Plan and edition availability

- **Full project history is premium.** Free accounts see only the last 24 hours plus labeled versions. Premium is gated on the project owner's subscription, so collaborators on a premium-owned project can use it. Source: docs history page hint "Using the full History feature"; https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features (headings "Full document history and versioning" and "Account and project level features").
- **Downgrade.** Full project history stops being available after downgrading to the free plan. Source: premium-features page, "What happens to my projects if I downgrade."
- **Community Edition vs Server Pro.** The comparison table lists "Full project history" as available in both. Commenting, real-time track changes and Git integration are Server Pro only. Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition.
- **Role gating (on-premises).** The roles table lists "Restore file or project from history" for Owner and Editor only, and "Add labels" for Owner, Editor and Reviewer. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions (History section). This table is the on-premises roles page; it does not split out Community Edition for these rows.

## 3. Legacy and secondary (not used for conclusions)

- The Dec 2024 blog's "always been possible" note on single-file restore is a historical remark, not a version marker.
- The Overleaf v2 FAQ, tex.stackexchange 582376 and tum.de ShareLaTeX mirror appeared only as search snippets in the harvest. They describe older v2-era or ShareLaTeX behavior and were not reopened here. Treat them as legacy only.
- Server Pro 5.0.1 doc-version-recovery release note (harvest S5) was not reopened here; it is an admin migration procedure, not a user restore feature.

## 4. Deprecated or admin-only paths

- **Admin soft-delete recovery.** The GitHub wiki Troubleshooting page describes a self-hosted script, `restore_soft_deleted_docs.js`, which restores docs listed in a project's `deletedDocs` array via a MongoDB query and admin user ID. Source: https://github.com/overleaf/overleaf/wiki/Troubleshooting (section "Recovering deleted docs"). The page carries an "outdated content" banner, so treat it as legacy. It is admin-only and not an end-user feature. The on-premises Admin Panel lists "Deleted Docs: list / undelete" for Server Pro only. Source: roles-and-permissions page, "Deleted Docs" table.

## 5. Dropbox interaction

- Deleting a folder in Dropbox removes its contents in Overleaf but keeps the project for history. Renaming or moving folders or files can register as delete-and-create, which loses history, tracked changes and comments. Source: https://docs.overleaf.com/integrations-and-add-ons/dropbox, heading "What should I know before syncing projects?"
- Archived or trashed projects stop syncing from Dropbox, but a copy remains in the Dropbox folder. Source: same page, heading "Which Overleaf projects are synchronized?"

## 6. UNRESOLVED / limitations

- Whether restore creates a new history entry is not stated in the pages read. UNRESOLVED.
- Whether labeling is plan-gated is not stated on the history page. UNRESOLVED.
- Whether Community Edition supports restore, or only viewing history, is not stated per edition. UNRESOLVED.
- The "Deleting a project" and "Archiving, deleting, and leaving projects" docs pages (listed in the sitemap per the harvest) were not opened. UNRESOLVED.
- No end-user time window is documented for restoring from Trash. UNRESOLVED.
- The July 2, 2026 AI bundling is outside this angle and not used here.
- No restore or compare action was executed; all statements are from documentation.

## EXPAND

- Open leads from harvest: Dropbox snippet (now verified), GitHub admin script (verified, legacy), v2 FAQ and tex.stackexchange (legacy, not reopened), tum.de mirror (legacy, not reopened), Server Pro 5.0.1 release note (not reopened, admin-only), "Deleting a project" docs page (not opened).
- Duplicates closed: the two blog-based restore claims in the harvest are the same Dec 2024 post; the Trash/Archive blog is a separate source.
- Next lead if needed: open the "Deleting a project" docs page to settle the Trash retention question.
