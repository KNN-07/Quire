# Harvest 38: Version comparison, restore, and deleted-file recovery (Overleaf)

Research date: 2026-10-26. Public sources only. No authenticated tests, no purchases.

Note: the write tool was used because no apply_patch tool was available in this session.

## Sources read (primary)

- S1: https://docs.overleaf.com/writing-and-editing/history-and-versioning.md (official "History and versioning" page, read in full through the Comparing versions section).
- S2: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes (official blog, dated December 11, 2024).
- S3: https://docs.overleaf.com/sitemap.md (official docs index, used to locate pages).
- S4: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition.md (official feature table).
- S5: https://docs.overleaf.com/on-premises/release-notes/release-notes-5.x.x/doc-version-recovery.md (official Server Pro release note).

Secondary or snippet-only (not opened in full): S6 tex.stackexchange and search snippets noted below.

## Findings

### Version history and comparison (Free vs Premium)

- The History panel lets users view, download, and compare project versions, and restore deleted files. (S1, intro)
- Full Project History is a premium feature. Free users see edits from the last 24 hours plus labeled versions. (S1, hint "Using the full History feature")
- The project owner must be on premium for the owner and collaborators to access full history. (S1)
- Comparison: versions are listed newest first. Icons on each version compare up to this version, compare from this version, or a range (drop-down). (S1, "Comparing versions")
- Download an older version: in All history, use the three-dot menu and choose "Download this version" to get a .zip. The File menu download only gives the current version. (S1)
- Labels: a version can be labeled (multiple labels allowed). The current version is "Current state." Labels are used to find versions for comparison, download, or restore. (S1, "Labeling a project version")
- Copying a project starts a fresh history; the original history is not copied. (S1)

Plan gating for labels is not stated on the pages read. UNRESOLVED: whether labeling is available on Free.

### Restore (single file and whole project)

- Who can restore: anyone with edit capability on a project can restore a file or project version from the past 24 hours. Restoring versions older than 24 hours requires the "Full document history" premium feature. (S2, "Who can use it?")
- Single file: in History, pick the version, select the file in the file list, then "Restore this version." This reverts that file's content plus its comments and tracked changes to the selected time. (S2, "Restore a single file"; S1 has a matching "How to restore a single file" section.)
- Whole project: go to the version and choose "Restore project to this version." (S2, "Restore a full project")
- Restore is documented as available for projects; the blog does not state whether restore creates a new version entry. UNRESOLVED.

### Deleted-file recovery

- Official S1 intro: History lets users restore previously deleted files. The steps (select the version where the file existed, pick the crossed-out file, restore) are documented in a ShareLaTeX-era mirror, not the current Overleaf docs. Secondary, legacy source: https://sharelatex.tum.de/learn/latex/Using_the_History_feature (search snippet; not opened in full). Date-tag: legacy ShareLaTeX mirror.
- S2 states that restoring a single deleted file from history has "always been possible." (Blog, December 2024.)
- Deleted-project recovery (whole project in trash): the sitemap lists "Deleting a project" and "Archiving, deleting, and leaving projects" (S3), but these pages were NOT read. UNRESOLVED.
- Dropbox sync: a search snippet of https://docs.overleaf.com/integrations-and-add-ons/dropbox (snippet only, not opened) says deleting a Dropbox folder removes its contents in Overleaf but keeps the project for history, and that renames can look like delete-and-create and lose history. Snippet-only, treat as unverified until opened.

### Platform availability (Community Edition vs Server Pro)

- S4 table: "Full project history" is available in both Community Edition and Server Pro (checkmark). Commenting and real-time track changes are not in Community Edition (X), but are in Server Pro. The feature-table rows for restore are not stated in the excerpt read. UNRESOLVED: whether Community Edition has file/project restore vs only viewing history.
- S4 also says Community Edition runs LaTeX compiles without sandboxing; this does not affect history but is a deployment caveat.
- S5 (Server Pro, release 5.0.1 recovery, updated April 2024): this is an admin migration procedure for installations that ran 5.0.1, not a user-facing recovery feature. It involves downtime and a history-store chunk recovery. Not a user restore function.

### Legacy (date-tagged, snippet-only)

- Overleaf v2 FAQ snippet (https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ): v2 launched September 4, 2018; v1 editor retired January 8, 2019. Legacy only.
- tex.stackexchange 582376 (snippet): quotes older text saying v2 could label versions but not yet restore them. Legacy, dated before the current restore feature; do not use as current behavior.
- GitHub overleaf/overleaf wiki Troubleshooting (search snippet, not opened): self-hosted admin script `restore_soft_deleted_docs` for soft-deleted docs in the `deletedDocs` array. Admin-only, self-hosted; not for end users.

### Not investigated

- The July 2, 2026 AI bundling claim is not relevant to history/restore; no AI-related claims are made here.
- Plan prices and the full premium-features list (S1 links to a premium-features page; only the intro was read) are not verified.

## Limitations

- Restore timing windows and plan gating rely on the December 2024 blog. Current docs (S1) confirm Full Project History is premium but do not repeat the 24-hour restore rule.
- No restore or comparison was executed; all claims are from documentation.

## EXPAND

- LEAD: Open the deleting-a-project and archiving/deleting pages (S3 sitemap) to verify whole-project recovery from deletion. Reason: not read.
- LEAD: Open the Dropbox integration page in full to verify the history-loss claim. Reason: snippet only.
- LEAD: Read the premium-features page list and the Server Pro/CE restore rows. Reason: only intro and partial table read.
- LEAD: Confirm whether labels are available on the Free plan. Reason: not stated in pages read.
- none beyond these; the GitHub wiki script is admin-only and out of scope for end-user recovery.
