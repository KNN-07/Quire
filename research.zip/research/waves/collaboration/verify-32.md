# Verify 32: Invitations, collaborator limits, and project access

Checked: 2026-10-26 (task date). Method: read the official Overleaf docs, plans page, and blog posts listed below. No authenticated tests, no purchases. Findings describe documented behavior, not executed behavior.

**Verdict: PARTIAL.** Email and link sharing, the Viewer/Reviewer/Editor roles, per-project collaborator quotas, downgrade rules, and group/institutional collaborator limits are confirmed. Link-joiner visibility conflicts between sources. No on-premises or Commons collaborator quota is documented.

## Confirmed (hosted, primary sources)

- **Sharing modes.** Projects can be shared by email invite or by link (https://docs.overleaf.com/collaborating/sharing-a-project, "By Email" and "By Link").
- **Permission levels.** Viewer, Reviewer, Editor (same URL, "Understanding permission levels"). Reviewers are comment-only per the Free-plan FAQ (https://docs.overleaf.com/collaborating/reviewing-and-reviewers). Reviewer can be set on an email invite or changed after a link join, but not on the link itself (same page).
- **Collaborator quotas, per project (Editors and Reviewers).** Free 1, Student 10, Standard 10, Pro unlimited. Viewers unlimited on listed plans. Personal (1) is no longer offered (https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features, "Invite more collaborators"). The current plans page shows the same counts (https://www.overleaf.com/user/subscription/plans, "Collaborators per project").
- **Project-level features follow the owner's plan.** Collaborators of a paid owner get project-level premium features without their own subscription (premium-features page, account vs. project-level section).
- **Downgrade to Free.** Projects remain accessible. Only one collaborator is kept; if the downgrade happens first, other collaborators become view-only and the owner can give edit access to one (premium-features page, downgrade FAQ).
- **Group and institutional limits.** Group Standard: members may invite up to 10 collaborators; group Pro: unlimited. Collaborators need no premium subscription (https://docs.overleaf.com/groups/troubleshooting-and-support/common-problems-and-how-to-fix-them). Universities page: Standard "Up to 10 invited collaborators," Pro "Unlimited collaborators per project" (https://www.overleaf.com/for/universities).
- **Server Pro admin access.** Admins can open any user's projects and transfer ownership (https://docs.overleaf.com/on-premises/user-and-project-management/understanding-license-usage).
- **Server Pro roles.** Owner-only invite and sharing changes; commenting and real-time tracked changes are Server Pro only (https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions). The edition comparison agrees, marking both as absent in Community Edition (https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition).

## Contradictions and unresolved

- **Link-joiner visibility: CONTRADICTION.** The current sharing guide says link joiners do not appear in Manage access. The 2024 post says edit-link joiners become visible and count toward the limit, while viewers do not (https://www.overleaf.com/blog/changes-to-project-sharing; rollout stated as complete October 14, 2024). Current behavior is UNRESOLVED. I do not assert which source is correct.
- **On-premises collaborator quota: UNRESOLVED.** The roles doc lists sharing actions with no numeric cap. License-usage docs count active users (opened a project in the last 12 months) for seat licensing and say Server Pro enforces no strict user limit. That is seat accounting, not a project cap.
- **Commons collaborator quota: UNRESOLVED.** The universities page says "unlimited collaboration" for Commons AI in marketing copy only. No numeric quota appears in the premium-features or plans pages.
- **Anonymous access on-prem.** The roles doc names the OVERLEAF_ALLOW_PUBLIC_ACCESS and OVERLEAF_ALLOW_ANONYMOUS_READ_AND_WRITE_SHARING settings. I did not verify their defaults or how they interact with quotas: UNRESOLVED.
- **AI bundling.** A blog post (https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans) says AI is included in all plans. The July 2, 2026 date does not appear in the captured text, so the date is UNRESOLVED. AI status does not change the access or quota findings above and is not combined with them.

## Legacy and dated

- 2024 link-joiner counting rule (blog post above): dated 2024, partly superseded by the current guide. See contradiction above.
- Personal plan: listed as no longer offered.

## Platform vs. LaTeX

All findings are Overleaf platform sharing, plan, and permission features. None concern LaTeX language capability.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Email and link sharing | sharing-a-project | All hosted | Confirmed |
| Viewer / Reviewer / Editor roles | sharing-a-project; reviewing-and-reviewers | Hosted | Confirmed |
| Reviewer is comment-only on Free | reviewing-and-reviewers FAQ | Free | Confirmed |
| Per-project Editor+Reviewer quotas: Free 1, Student 10, Standard 10, Pro unlimited | premium-features; plans page | Hosted tiers | Confirmed |
| Viewers unlimited | premium-features table | Hosted | Confirmed |
| Downgrade keeps one collaborator; others view-only | premium-features downgrade FAQ | Free | Confirmed |
| Project features follow owner's plan | premium-features | Hosted | Confirmed |
| Group Standard 10 / Pro unlimited collaborators | group FAQ | Group plans | Confirmed |
| Universities Standard 10 / Pro unlimited | universities page | Institutional | Confirmed |
| Link joiners hidden from Manage access | sharing-a-project | Hosted | Contradicted by 2024 post |
| Edit-link joiners visible and counted | 2024 changes post | Hosted, 2024 | Contradicted; UNRESOLVED |
| Commons collaborator quota | universities page (prose only) | Commons | UNRESOLVED |
| On-prem project collaborator cap | roles; license-usage docs | Server Pro | UNRESOLVED (none documented) |
| Admin can open any user's projects | license-usage docs | Server Pro | Confirmed |
| Commenting and tracked changes are Server Pro only | roles doc; edition comparison | Server Pro / Community | Confirmed |
| AI included in all plans | AI blog | All hosted | Included confirmed; July 2, 2026 date UNRESOLVED |

## Counter-search queries

- "Overleaf link sharing collaborators Manage access edit link visible"
- "Overleaf Commons collaborators per project limit"
- "Overleaf Server Pro project collaborator limit"
- "Overleaf Community Edition reviewer track changes"
- "Overleaf reviewer role free plan suggest edits"

## EXPAND

- **LEAD: link-joiner visibility for edit links.** Confirm current Share-menu behavior and whether the Manage access exclusion applies to Editor links. Not tested here (no authenticated check).
- **LEAD: Commons collaborator quota.** No public number found; check Overleaf's institutional documentation or sales.
- **LEAD: on-prem anonymous-access settings.** Check their defaults and any interaction with collaborator limits in the Server Pro configuration docs.
- **LEAD: July 2, 2026 AI bundling date.** Confirm from the full blog post or its dated announcement. Not needed for the access findings.
