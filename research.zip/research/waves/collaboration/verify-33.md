# Verify 33: Link sharing, token access, and read/edit permissions

Research date: October 27, 2026. Scope: Overleaf project sharing and access control only. No authenticated tests, no purchases. Sources were opened as primary pages unless marked "search snippet."

## Verdict: PARTIAL

Hosted link-sharing behavior (audience, default Viewer, revocation, no expiry, permission matrix, plan limits) is confirmed. Reviewer as a link permission is documented in the sharing guide and the Labs sharing experience, but the reviewing guide says the opposite, so it is contested. Token construction, rotation, and hosted access logging are UNRESOLVED.

## Confirmed claims

**Private by default and link tokens.** https://docs.overleaf.com/collaborating/sharing-a-project, FAQ "Are my Overleaf projects private?" Projects are private until shared. Enabling link sharing creates a unique token described as "almost impossible to guess." A published link lets anyone view and download the project and may be indexed.

**Audience and link permission.** Same page, "By Link." Audience is "Only invited people" (default) or "Anyone with the link." The link permission defaults to Viewer; Reviewer and Editor are also listed. Link joiners do not appear in Manage access.

**Revocation and expiry.** Same page, FAQs. Switching back to "Only invited people" removes link-joiner access and keeps email invites. Links do not expire on their own; the owner must deactivate them.

**Permission matrix (hosted UI).** Same page, "Understanding permission levels." Viewer can view and download source and PDF, copy the project, and view comments. Reviewer adds comments and suggested edits. Editor has all listed actions. The matrix governs the project UI only, not copies a recipient has downloaded.

**Reviewer restrictions.** https://docs.overleaf.com/collaborating/reviewing-and-reviewers: Reviewers can comment and make tracked changes but cannot create files.

**Request access (hosted, current).** https://docs.overleaf.com/collaborating/request-access: Viewers can request Reviewer or Editor; Reviewers can request Editor. The owner is notified by a Share badge and by email, then accepts or declines in Manage access.

**Labs sharing experience (experimental).** https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments, "New Project Sharing Experience - Single share link." Owner must be enrolled in Labs. Audience defaults to "Only invited people"; "Anyone with the link" offers Viewer (default), Editor, or Reviewer. Changing the link permission does not change the URL, and later joiners receive the new level. Labs carries no stability guarantee; it is not a general-availability feature.

**Plan limits (hosted).** https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features: Free allows 1 editor-or-reviewer collaborator; Student and Standard allow 10; Pro is unlimited; Personal allows 1 and is no longer offered. Viewers are unlimited on all plans.

**Legacy links (dated).** Sharing guide, FAQ "legacy sharing links": legacy links can be kept, or consolidated into one link, which permanently removes the originals. Blog https://www.overleaf.com/blog/changes-to-project-sharing (July 1, 2024; updated later in 2024) says link-joined editors became visible and counted toward the collaborator limit after a rollout completed October 14, 2024. Historical; not current control logic.

**On-premises roles and variables.** https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md: link viewers cannot see named collaborators, comments, or history. https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/environment-variables.md lists `OVERLEAF_ALLOW_PUBLIC_ACCESS`, `OVERLEAF_ALLOW_ANONYMOUS_READ_AND_WRITE_SHARING`, `OVERLEAF_DISABLE_LINK_SHARING`, and `OVERLEAF_INVITE_TOKEN_SECRET` (required, minimum 16 characters, "Added in Server Pro 6.2.0"). The table is labeled for Server CE and Server Pro. Hosted Overleaf is not configured this way.

**On-premises audit log (admin only).** https://docs.overleaf.com/on-premises/user-and-project-management/project-management.md, "Viewing a projects audit log": admins can view a per-project audit log of link-sharing changes (private vs token-based), invites sent or accepted, and token-based joins. A grep recipe for "join project request" in web.log shows timestamp, user, and project.

**Git tokens (separate, do not conflate).** https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/git-integration-authentication-tokens: account-level Git tokens expire after one year, with a maximum of 10 per account. They are unrelated to link-sharing tokens.

## Corrections to upstream

- **Free-plan collaborators.** Harvest-33 said the count was unspecified. Premium-features documents 1 editor-or-reviewer on Free. Corrected.
- **Reviewer as a link permission: CONTESTED.** The sharing guide and the Labs single-link page list Reviewer as a link permission. The reviewing guide's FAQ says Reviewer is only for named collaborators, with link users upgraded after joining. Expand-33's "cannot be a link permission at invite time" is not confirmed for Labs and is contested for the classic UI.
- **Free reviewer capability: internal inconsistency.** The reviewing guide's FAQ says a Free reviewer can only comment; its permissions section and the sharing matrix say reviewers can also suggest changes. Not resolved by public docs.
- **Learn-page citation.** The "Are my Overleaf projects private?" learn page's body text did not return on fetch; the wording is confirmed in the sharing guide FAQ instead.
- **GitHub wiki variables: outdated.** The wiki is marked as outdated and omits `OVERLEAF_INVITE_TOKEN_SECRET`. Use the current docs page.

## UNRESOLVED

- Token construction, entropy, rotation, or expiry beyond manual deactivation.
- Hosted (non-admin) notification to owners or logs of link access. Only the on-premises admin audit log is documented.
- Whether a viewer who downloaded a copy is restricted in any way.
- Whether `OVERLEAF_INVITE_TOKEN_SECRET` applies to Community Edition (docs state Server Pro 6.2.0 only).
- Reviewer link permission in the classic (non-Labs) Share UI.
- Free-plan reviewer: comment-only versus tracked changes.

## Out of scope

The July 2, 2026 AI bundling change and AI Assist naming were not investigated; they do not affect sharing or permissions.

## Counter-search queries

Run (search snippets used as leads, then checked against primary pages above):
- "site:docs.overleaf.com link sharing Reviewer link permission"
- "site:docs.overleaf.com OVERLEAF_INVITE_TOKEN_SECRET"
- "site:overleaf.com link sharing token access log notification"

Not yet run:
- "site:overleaf.com free plan reviewer comment only tracked changes"
- "site:overleaf.com changes to project sharing 2024 collaborator limit"

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Projects private by default; link token "almost impossible to guess" | sharing-a-project, FAQ | Hosted, all plans | Confirmed |
| Published links allow view and download; may be indexed | sharing-a-project, FAQ hint | Hosted | Confirmed |
| Audience: Only invited people (default) / Anyone with the link | sharing-a-project, "By Link" | Hosted | Confirmed |
| Link permission default Viewer; Reviewer and Editor listed | sharing-a-project, "By Link" | Hosted | Confirmed (Reviewer contested) |
| Turning off link sharing removes link-joiner access | sharing-a-project, FAQ | Hosted | Confirmed |
| Links do not expire on their own | sharing-a-project, FAQ | Hosted | Confirmed |
| Permission matrix (Viewer / Reviewer / Editor) | sharing-a-project, "Understanding permission levels" | Hosted | Confirmed |
| Request Reviewer or Editor from Viewer; Reviewer requests Editor | request-access | Hosted | Confirmed |
| Single share link; link permission Viewer / Editor / Reviewer | live-experiments, Labs | Labs, experimental | Confirmed (Labs only) |
| Link viewers cannot see named collaborators, comments, or history | roles-and-permissions | On-premises | Confirmed |
| Reviewer cannot create files; can track changes and comment | reviewing-and-reviewers | Hosted | Confirmed |
| Reviewer as link permission at invite time | reviewing-and-reviewers FAQ vs sharing-a-project | Hosted | CONTESTED |
| Free plan: 1 editor-or-reviewer; viewers unlimited | premium-features | Free / paid tiers | Confirmed (corrects harvest) |
| Free reviewer can only comment | reviewing-and-reviewers FAQ | Free | Internal inconsistency; UNRESOLVED |
| Legacy links kept or consolidated permanently | sharing-a-project, FAQ | Hosted | Confirmed |
| 2024 collaborator-limit rollout completed Oct 14, 2024 | changes-to-project-sharing blog | Hosted, dated 2024 | Confirmed (historical) |
| Admin per-project audit log: link-sharing changes, invites, token joins | project-management (on-prem) | On-premises, admin | Confirmed |
| `OVERLEAF_ALLOW_PUBLIC_ACCESS`, `..._ANONYMOUS_READ_AND_WRITE_SHARING`, `OVERLEAF_DISABLE_LINK_SHARING` | environment-variables.md | Server CE and Server Pro | Confirmed |
| `OVERLEAF_INVITE_TOKEN_SECRET` required, min 16 chars, Server Pro 6.2.0+ | environment-variables.md | Server Pro (CE unstated) | Partially confirmed |
| Git tokens: 1-year expiry, max 10 per account | git-integration-authentication-tokens | Hosted and Server Pro | Confirmed; separate from link tokens |
| Token construction, rotation, hosted access logging | none found | Not documented | UNRESOLVED |

## EXPAND

- LEAD: Confirm whether Reviewer is selectable as a link permission in the classic Share UI (authenticated check; not performed).
- LEAD: Find an official statement on hosted link-access logging or owner notification; only the on-premises admin audit log is documented.
- LEAD: Find official Community Edition documentation for `OVERLEAF_INVITE_TOKEN_SECRET`; none found.
- LEAD: Resolve the Free-plan reviewer comment-only conflict (query not yet run).
- LEAD: Confirm whether Labs "single share link" permissions reach general availability; Labs pages carry no stability guarantee.
