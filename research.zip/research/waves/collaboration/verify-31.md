# Verify 31: Real-time simultaneous editing and collaborator presence

Checked October 26, 2026 against public Overleaf sources. No authenticated tests or functional execution were performed. This report concerns Overleaf platform features, not features implemented by arbitrary LaTeX packages or source.

## Findings

The current collaboration overview explicitly says multiple authors can work on a manuscript in real time. Its technical description says edits are sent to the server every few seconds, simultaneous edits are rebased using Operational Transformation (OT), and WebSockets push changes to connected clients. This supports real-time collaborative editing as a platform feature, but does not establish a precise latency, offline editing, reconnect behavior, or guaranteed delivery/order under failure. Source: https://docs.overleaf.com/collaborating/collaborating-in-overleaf — **“Collaborating in Overleaf,” simultaneous editing**.

Project access is governed separately through email invitations or sharing links. Editors can edit; reviewers can comment and suggest tracked changes but cannot switch to Editing; viewers have read-only access. Link-shared collaborators do not appear in Manage access, and changing link permissions affects people who joined through that link. Sources: https://docs.overleaf.com/collaborating/sharing-a-project — **“By Email,” “By Link,” “Number of collaborators allowed”**; https://docs.overleaf.com/collaborating/reviewing-and-reviewers — **“Current editing mode,” “Reviewer permissions.”**

Current hosted-plan limits are a restriction on how many collaborators can be invited, not evidence that the synchronization feature itself is limited to paid plans. The current plans page lists 1 user for Free, 10 collaborators for Student and Standard, and unlimited for Pro; Commons/group/organization limits depend on their plan. Free accounts therefore can collaborate, but within the listed project limit. The plans FAQ calls an Editor or Reviewer invited to the project a collaborator. Sources: https://www.overleaf.com/user/subscription/plans — **“Editing and collaboration,” “What’s a collaborator…”**; https://docs.overleaf.com/collaborating/sharing-a-project — **“Number of collaborators allowed.”**

Track Changes is distinct from simultaneous editing. It is documented as premium/project-level: collaborators on a project whose owner has the feature may use it, while the current plans table excludes it from Free and includes it in paid individual tiers. Commons and group subscription terms may differ. Sources: https://docs.overleaf.com/collaborating/track-changes — **opening availability note**; https://www.overleaf.com/user/subscription/plans — **“Editing and collaboration”**.

Presence UI evidence is mixed by age. Current collaboration docs describe synchronization to connected clients but do not specify a live roster, online/away indicator, cursor or selection display, or presence-update cadence. Official Overleaf product copy does document those specific affordances historically: the **May 25, 2018** blog says collaborators’ cursors are shown, and the official **Overleaf v2 FAQ** says users can see cursor locations and who is online. These are explicitly legacy Overleaf v2 claims, not confirmation that the same UI remains in the current editor or on every plan/deployment. No current operational source located confirms or deprecates them. Sources: https://www.overleaf.com/blog/648-tip-of-the-week-overleaf-v2-collaboration-features — **May 25, 2018, collaboration features**; https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ — **“What has Changed with Overleaf v2?”**.

For self-hosted deployments, docs distinguish Community Edition and Server Pro: the roles page identifies both deployment types and says commenting and real-time tracked changes are Server Pro-only. This is not a claim that core simultaneous editing is Server Pro-only; the current docs page does not state that limitation. Do not transfer hosted-plan quantities or undocumented presence behavior to self-hosted installations. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — **“Editor IDE,” “Text operations.”**

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Concurrent users edit shared files with OT rebasing and WebSocket updates | https://docs.overleaf.com/collaborating/collaborating-in-overleaf — “Collaborating in Overleaf” | Hosted; deployment-specific limits not stated here | Confirmed; no timing/failure guarantees |
| Sharing supports editor, reviewer, and viewer permissions | https://docs.overleaf.com/collaborating/sharing-a-project — “By Email/By Link”; https://docs.overleaf.com/collaborating/reviewing-and-reviewers — “Reviewer permissions” | Hosted; reviewer can only suggest/comment | Confirmed |
| Hosted collaborator counts vary by plan | https://www.overleaf.com/user/subscription/plans — “Editing and collaboration” | Free 1; Student 10; Standard 10; Pro unlimited; organization plans vary | Confirmed on page checked Oct. 26, 2026 |
| Track Changes is separate from live editing | https://docs.overleaf.com/collaborating/track-changes — opening note; plans URL above | Premium/project-level; plan and Commons/group terms apply | Confirmed |
| Cursors and online status are shown | https://www.overleaf.com/blog/648-tip-of-the-week-overleaf-v2-collaboration-features — May 25, 2018; https://www.overleaf.com/learn/how-to/Overleaf_v2_FAQ — Overleaf v2 section | Legacy product copy; present availability/plan scope not established | Historical evidence only; current status unresolved |
| Server Pro-only features include commenting and real-time tracked changes | https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — “Text operations” | Server Pro, not Community Edition | Confirmed; core simultaneous editing not thereby excluded |

## Counter-searches and caveats

Queries used: `site:docs.overleaf.com/collaborating/collaborating-in-overleaf real time simultaneous editing Operational Transformation`; `site:docs.overleaf.com/collaborating sharing project collaborator limits plans 2026`; `site:docs.overleaf.com "who's online" Overleaf collaborators current`; `site:docs.overleaf.com "cursor" collaborators Overleaf editor`; `site:overleaf.com "collaborators' cursors" Overleaf`; and `site:overleaf.com/blog "Overleaf AI now a part of Overleaf plans" July 2 2026`. Current official docs substantiate synchronization, sharing, roles and current plan limits. Cursor/online claims appear in legacy official materials, so they are retained as dated evidence rather than silently promoted to current capability. The separate July 2, 2026 announcement says Overleaf AI was included in plans; older AI Assist add-on wording is stale for AI availability and irrelevant to this collaboration verdict.

## EXPAND

- **LEAD — Current presence UI:** Open. Legacy official materials say cursors and online status were shown, but the current operational docs reviewed do not establish whether these UI elements remain available, their plan scope, or their update semantics.
- **LEAD — Synchronization under failure:** Open. Current docs describe OT and WebSocket updates but give no guarantee for offline edits, reconnect, delivery ordering, or latency. Do not infer one.
