# Verify 35: Track Changes, accepting/rejecting edits, and permissions

Checked 2026-10-26 against Overleaf primary pages (docs.overleaf.com, overleaf.com blog). No authenticated tests, purchases, or execution claims.

## Verdict: PARTIAL

Core hosted Track Changes behavior, reviewer restrictions, and plan gating are confirmed. The hosted accept/reject role matrix, the Track Changes + AI interaction, and the LaTeX `changes` boundary are not established by primary sources. The AI availability wording conflicts across pages.

## Claim table

| Claim | Source (heading) | Availability | Evidence status |
|---|---|---|---|
| Track Changes is accessed via Reviewing mode; Editors can switch Editing/Reviewing, review/view-only users cannot | https://docs.overleaf.com/collaborating/track-changes.md ("Accessing Track Changes") | Hosted, all plans with feature | Confirmed |
| Switching to Reviewing turns Track Changes on; switching back to Editing turns it off | https://docs.overleaf.com/collaborating/reviewing-and-reviewers.md ("Changing your mode") | Hosted | Confirmed |
| Owner can force a collaborator's edits to be tracked via sharing permissions | https://docs.overleaf.com/collaborating/track-changes.md ("Configuring whose changes will be tracked") | Hosted | Confirmed |
| Reviewers can only make/respond to comments and make tracked changes; cannot switch to Editing; cannot create files | https://docs.overleaf.com/collaborating/reviewing-and-reviewers.md ("Reviewer permissions"; FAQ "Can a Reviewer add/create files?") | Hosted | Confirmed |
| Editors have the same Reviewing restrictions but can switch to Editing | same, "Reviewer permissions" | Hosted | Confirmed |
| Reviewer role is for named collaborators only, not link sharing; link-sharing users can be upgraded after joining | same, FAQ "Can I use this for all collaborators?" | Hosted | Confirmed |
| Bulk accept/reject: select text (Ctrl/Cmd+A for all), choose "Accept/Reject selected changes", confirm in dialog | https://docs.overleaf.com/collaborating/track-changes.md ("How to accept or reject all tracked changes") | Hosted; premium | Confirmed |
| Individual change accept/reject | https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md ("Real-time track changes") | Premium | Confirmed |
| Copying a project applies all tracked changes in the copy | https://docs.overleaf.com/collaborating/track-changes.md (warning under accept/reject) | Hosted | Confirmed |
| Track Changes is premium and project-level; collaborators need no paid plan | https://docs.overleaf.com/collaborating/track-changes.md ("Introduction"); premium-features ("Account and project level features") | Student/Standard/Pro yes; Free no; Personal (discontinued) no | Confirmed |
| Free plan allows 1 collaborator (Editors and Reviewers) | premium-features ("Invite more collaborators") | Free | Confirmed |
| Free-plan Reviewer "will only be able to comment" | reviewing-and-reviewers.md FAQ "Is the Reviewer role available on the free plan?" | Free | Confirmed, but reads oddly beside the Reviewer tracked-changes rules; no free tracked editing is documented |
| Downgrade to Free keeps existing tracked changes but blocks new ones | premium-features, downgrade FAQ (from upstream harvest) | Free | UNRESOLVED: the fetched page was truncated before this FAQ |
| Notifications for tracked changes are bundled in 10-minute increments | track-changes.md ("Notifications") | Hosted | Confirmed (not in upstream; extra detail) |
| On-prem: Owner and Editor can accept/reject collaborator tracked changes; Reviewer and Viewers cannot | https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md (collaborating table, row "Accept or reject collaborator tracked changes") | Server Pro only | Confirmed for on-prem |
| On-prem: Reviewers can add tracked changes; named Viewers can view them; link-sharing Viewers see changes without author | same page, rows "Add tracked changes", "View tracked changes" | Server Pro only | Confirmed for on-prem |
| On-prem: commenting and real-time tracked changes are Server Pro only, not Community Edition | same page, note under Collaborating | Server Pro only | Confirmed |
| Hosted accept/reject role authority (who can accept/reject in cloud) | none found; the hosted how-to lists no roles | Hosted | UNRESOLVED. Do not transfer the on-prem matrix to hosted |
| Overleaf AI included in all plans at no extra cost; allowances vary; Commons AI added | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans ("Overleaf AI now a part of Overleaf plans", dated July 2, 2026) | All plans, varying allowance | Confirmed (newest source) |
| AI assistant on Student/Standard/Pro only; not Free or Commons | https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant.md ("Opening the AI assistant"; describes "AI Assist add-on") | Student/Standard/Pro | CONTRADICTED by the July 2, 2026 blog; the assistant page is older wording (its screenshot is dated Feb 2026). Unresolved which is current; do not combine |
| AI Apply/Reject diffs create Track Changes entries or follow reviewer rules | none verified; I did not read the AI diff section | Unknown | UNRESOLVED |
| LaTeX `changes` package example shows source-level markup distinct from platform Track Changes | https://www.overleaf.com/latex/examples/tracking-changes-in-latex-with-changes-package/fnpkpytjjwhj.pdf | Any | UNRESOLVED: not opened in this pass |
| Old TeX.SE answer says Accept/Reject All works per section or file, not project-wide | https://tex.stackexchange.com/questions/638068/is-it-possible-to-automatically-accept-all-tracked-changes-in-overleaf (search snippet only) | Legacy, undated | Snippet only; conflicts with the current whole-document Ctrl+A instruction. Treat as legacy |

## Corrections to upstream

- Harvest's "Free: Reviewer can only comment" is accurate, but it does not show free tracked editing. Keep it as a note, not a feature.
- Harvest and expand both say AI Assistant is "AI Assist add-on" with plan access. That is legacy wording; the July 2, 2026 blog is newer. The two are not reconciled here.
- The on-prem matrix is Server Pro only; the expand file's "cloud/on-prem" split is correct.

## Counter-search queries

- "Overleaf accept reject tracked changes reviewer role hosted plans"
- "Overleaf AI included in plans July 2026 AI assistant plan availability"
- "Overleaf AI apply reject suggested edit track changes"
- "Overleaf downgrade free plan tracked changes remain"
- "Overleaf tracking changes LaTeX changes package example"

## EXPAND

- LEAD: Hosted accept/reject role authority. Reason: only the on-prem matrix states it; hosted docs list no roles.
- LEAD: Downgrade FAQ text. Reason: fetched page was truncated; open the full premium-features page.
- LEAD: AI Assistant Apply/Reject and whether it creates Track Changes entries. Reason: not read; the blog and assistant pages conflict on plan access.
- LEAD: LaTeX `changes` package PDF. Reason: not opened; boundary claim unverified.
- Note: web search returned a legacy TeX.SE snippet on section-level accept-all; not verified against current docs.
