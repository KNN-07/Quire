# Harvest 36: Overleaf Chat, Mentions, Notifications, Communication

Scope: public official Overleaf documentation only. No authenticated testing, no purchases, no codebase edits. Sources were opened and read in this session, not taken from search snippets.

## Sourced findings

### 1. Collaborator chat (platform feature)

- **Where it lives.** The redesigned editor has a left vertical bar with File tree, Search, Integrations, Review, and **Chat**. The Chat icon is described as a way to "communicate in real-time with team members or collaborators." Source: https://docs.overleaf.com/llms-full.txt (part 1 of 3, section "Redesigned Overleaf editor", heading "Left bar").
- **Chat is project-scoped.** The collaboration overview describes "collaborator chat" as one of the project collaboration features next to project sharing, track changes, and commenting. Source: https://docs.overleaf.com/collaborating/collaborating-in-overleaf.md (heading "Collaborating in Overleaf").
- **Availability.** The group feature controls page lists "Overleaf Chat" as **enabled for all groups** by default and states it is "a standard feature that is available to all Overleaf users unless disablement is requested by the group administrator." Group admins can request disablement from Support, not via a self-service toggle. Source: https://docs.overleaf.com/groups/user-management/controlling-feature-availability.md (table row "Overleaf Chat"). Tier label: **standard, not premium-gated, per this group page**. The page does not say whether Free individual accounts differ; that is UNRESOLVED from this source alone.
- **Not documented:** message length limits, history retention, editing or deleting chat messages, markdown support, file attachments, and whether chat is available on Server Pro or Community Edition. All UNRESOLVED from the pages read.

### 2. Mentions

- **Mentions are documented for comments only.** Heading "Mentions" under "Collaborative commenting": type `@` and start typing a collaborator's name or email to get a list; the mentioned collaborator is flagged. Source: https://docs.overleaf.com/collaborating/commenting.md.
- **Chat @-mentions:** no official documentation found in the pages read. UNRESOLVED.

### 3. Comments and review threads (adjacent communication)

- Comments attach to highlighted text. Collaborators with project access can reply, resolve (checkmark), edit or delete their own, and view resolved comments. Resolved threads can be re-opened or deleted. Source: https://docs.overleaf.com/collaborating/commenting.md (headings "The basics", "Using comments").
- Comments and track changes sit in the Review pane of the left bar. Source: llms-full.txt, "Left bar".

### 4. Notifications (email)

- **Prerequisite.** Email notifications on project activity must be enabled in Account Settings. Source: https://docs.overleaf.com/collaborating/commenting.md (info hint under "Notifications").
- **Per-project setting.** File > Settings > Project Notifications offers two modes:
  - *All project activity*: notified of all comments and tracked changes.
  - *Mentions and replies only*: notified of mentions, replies, and activity on your own comments and tracked changes.
  Source: same page, "Notifications".
- **Timing.** Notifications are **not real-time**; they are bundled in **ten-minute increments** to avoid inbox overload. Source: same page, warning hint.
- **Chat notifications:** the documented settings above cover comments and tracked changes only. Whether chat messages trigger email is UNRESOLVED.
- **In-app notification bell or push:** not found in the pages read. UNRESOLVED.

### 5. Real-time sync underlying collaboration (platform mechanism)

- Overleaf uses Operational Transformation for simultaneous editing; edits are sent to the server every few seconds, and WebSocket is used to push updates to clients. Source: https://docs.overleaf.com/collaborating/collaborating-in-overleaf.md (paragraph 2). This describes document editing, not chat specifically.

### 6. Open-source chat code (legacy, date-tagged)

- The GitHub repository overleaf/chat describes itself as "the backend API that powers the chat service in ShareLaTeX" and states it has been **migrated into overleaf/overleaf** (monorepo). Its copyright line reads 2014-2019. Treat it as legacy history; it is not evidence of current deployment layout. Source: https://github.com/overleaf/chat (README header).
- Current chat implementation details inside overleaf/overleaf were not read in this harvest. UNRESOLVED.

## Limitations

- Only English docs.overleaf.com pages and one GitHub README were read. The llms-full.txt export was truncated to part 1 of 3 (pages 1-100 of 265); the sections used were in part 1.
- Two first-pass URLs (`/collaboration-and-sharing/chat`, `/collaboration-and-sharing/track-changes`) returned 404; correct paths are under `/collaborating/`.
- Third-party projects surfaced in search (Overleaf-Workshop VS Code extension, a Chrome monitoring extension) were excluded as non-official.
- AI bundling (July 2, 2026 blog vs. older separate AI Assist docs) is outside this angle and was not investigated.

## EXPAND

- LEAD: Confirm whether Chat is available to Free individual accounts and on Server Pro / Community Edition (on-premises docs at https://docs.overleaf.com/on-premises/). Reason: group page covers group subscriptions only.
- LEAD: Find official chat limits, retention, and whether chat messages trigger email notifications. Reason: not in any page read.
- LEAD: Check whether chat supports @-mentions, which the comment docs do not cover. Reason: mentions docs are comment-only.
- LEAD: Read the current chat module in overleaf/overleaf on GitHub for implementation facts. Reason: overleaf/chat is legacy and migrated.
