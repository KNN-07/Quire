# Verify 40: Sharing security boundaries and collaborator premium inheritance

Date: 2026-10-26. **Verdict: PARTIAL**: core boundaries and inheritance are documented; link-user visibility and Reviewer-link availability conflict across official pages. Read both `harvest-40.md` and `expand-40.md`. Public documentation research only; no authenticated tests, purchases, or functional execution. These are Overleaf platform permissions/entitlements, not arbitrary LaTeX capabilities.

## Claim table

Sources below include exact URLs and headings; evidence is paraphrased.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Projects start private; email recipients authenticate before accepting. | S1, “By Email”; privacy FAQ | Hosted Free/premium | Confirmed. |
| Link defaults to Viewer; holders can view/download; public posting can expose projects through search indexing. Disabling links removes link-based permissions, not email invitations. | S1, “By Link”; privacy and disabling FAQs | Hosted Free/premium | Confirmed. Token described as difficult to guess, not a quantified security guarantee. |
| Viewer can read source/comments, download and copy, **not write comments**. Reviewer can comment/suggest, not directly edit/add files, accept/reject, or restore. Editor has those capabilities. | S1, “Understanding permission levels” | Hosted; suggestions require premium | Confirmed; corrects expand's Viewer-comment implication. S4 says Free's one Reviewer can only comment. |
| Link joiners are absent from Manage access; link permission changes affect them together. | S1, “By Link”; S5, “What's changing?” | Hosted | **CONTRADICTION**: current docs say absent; July 1, 2024 blog says edit-link joiners become visible, with rollout completed October 14, 2024. Live behavior UNRESOLVED. |
| Reviewer can be selected for sharing links. | S1, “By Link”; S4, “Can I use this for all collaborators?” | Hosted | **CONTRADICTION**: S1 offers Reviewer links; S4 restricts initial Reviewer assignment to named collaborators. |
| Viewers request Reviewer/Editor; Reviewers request Editor; owner accepts/declines. Legacy dual links still work, but consolidation permanently replaces them. | S12, “Request access”/“Managing Requests”; S1 legacy FAQ | Hosted | Confirmed; requests do not themselves grant access. |
| Owner subscription supplies track changes, compile time, full history to Free collaborators within that project. | S2, “Account and project level features”; S3, limits table | Premium-owned hosted projects | Confirmed. Compile timeout: Free 10 seconds, premium 240; history: Free 24 hours versus full premium history. No account-wide upgrade inferred. |
| Editor/Reviewer seats: Free 1, Student/Standard 10, Pro unlimited; Viewers unlimited. Personal 1 is closed to new subscribers. | S2, “Invite more collaborators” | Hosted plans | Confirmed current Markdown; older indexed Student=6 is stale. |
| Dropbox does not grant collaborator-local sync; references remain citable but only owner re-syncs imported bibliography. GitHub-linked projects allow member sync; Git benefits premium-owned projects or premium users. | S2, integration tabs | Hosted premium | Confirmed; not blanket inheritance of all account features. |
| Downgrade preserves projects/existing tracked text, removes premium features; if downgraded before choosing one editor, **all** collaborators become viewers, then one can regain edit access. Transfers to Free similarly make all viewers. | S2, downgrade FAQ; S6, access table | Hosted | Confirmed; corrects upstream “all others” shorthand. Ownership/control transfers immediately, with managed-account exception. |
| Commons supplies premium access/unlimited collaborators; leaving preserves projects/collaborations but loses premium without another subscription. | S7, subscription-ending FAQ; S6, access table | Commons | Confirmed; institutional eligibility is not required of every collaborator by S2's project rule. |
| Group Pro admins restrict email invites to group/anyone; links to disabled/group/anyone; owners may tighten. Changes do not affect existing projects with collaborators. | S8, “Define Settings”/“Click Apply Changes” | Group Pro only | Confirmed; qualifies S9's generic claim that groups impose no sharing restrictions. |
| Public access defaults false; anonymous read/write sharing is separately configurable; link sharing can be disabled. | S10, “All versions”; S11, “What's new?” | CE/Server Pro configuration, not hosted plans | Confirmed current docs; S11 dates disable flag introduction to Server Pro 6.0.1, November 18, 2025. |
| AI is bundled, but not inherited as an unrestricted project entitlement. | S13, plan sections; S14, “Using AI on projects you've been invited to” | Free/premium/Commons/Commons AI | Confirmed July 2, 2026 bundling supersedes older separate-purchase wording. Own allowance/settings apply; organization-disabled owner projects can also block collaborator AI. Commons Basic lacks Assistant; Commons AI includes it. |

## Primary sources

- S1 https://docs.overleaf.com/collaborating/sharing-a-project.md
- S2 https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md
- S3 https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits.md
- S4 https://docs.overleaf.com/collaborating/reviewing-and-reviewers.md
- S5 https://www.overleaf.com/blog/changes-to-project-sharing
- S6 https://docs.overleaf.com/collaborating/transferring-project-ownership.md
- S7 https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription.md
- S8 https://docs.overleaf.com/groups/getting-started/sharing-permissions-within-your-group.md
- S9 https://docs.overleaf.com/subscriptions-payments-and-billing/group-subscription.md
- S10 https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/environment-variables
- S11 https://www.overleaf.com/blog/overleaf-server-pro-6-0-1-is-available
- S12 https://docs.overleaf.com/collaborating/request-access.md
- S13 https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- S14 https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts.md

## Counter-search queries and limitations

Queries included `site:docs.overleaf.com "Account and project level features"`, `site:docs.overleaf.com "public access"`, `site:docs.overleaf.com "link" "expire" sharing`, `site:overleaf.com "July 2, 2026" AI`, and `site:docs.overleaf.com "AI" "project owner" allowance`. Opened primary bodies, not snippets alone. The obsolete public-access URL failed; the official GitHub configuration wiki redirected to S10, resolving that lead. No non-expiry guarantee was found in S1.

## EXPAND

- LEAD: Resolve link-user visibility and Reviewer-link contradictions through an updated official clarification; authenticated testing remains outside this task.
- LEAD: Link expiry and offline-editing inheritance remain UNRESOLVED; upstream assertions lack explicit supporting evidence in the verified pages.
