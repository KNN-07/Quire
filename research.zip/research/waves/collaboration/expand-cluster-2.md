# Collaboration reconciliation: angles 31-40

As of October 26, 2026. Public-source documentation research, not runtime acceptance testing. Read `brief.md`, `lead-supplement.md`, every collaboration `verify-31.md` through `verify-40.md`, and adjacent `integrations/verify-41.md`, `verify-46.md`, `administration/verify-54.md`, `verify-57.md`, and `verify-60.md`. All ten harvest, expand, and verify files exist; no missing-angle reconstruction was necessary. October 27 dates in upstream reports are not adopted.

## Corrected claim table

Source identifiers resolve to exact official URLs and headings below.

| Angles | Corrected documented claim | Availability and qualification |
|---|---|---|
| 31 | Concurrent editing uses OT rebasing and WebSocket updates [A]. | Core collaboration is not synonymous with paid Track Changes; no latency or delivery guarantee. |
| 32, 40 | Editor/Reviewer quotas: Free 1, Student/Standard 10, Pro unlimited; Viewers unlimited [D, U]. Commons documentation explicitly names unlimited collaborators [M]. | Project quotas, not account seat counts. No numerical on-premises project cap established. |
| 32-34, 40 | Email/link sharing; Viewer-default links also offer Reviewer/Editor. Link joiners are hidden [B]. | Conflicts with named-only Reviewer FAQ [C] and 2024 visibility announcement [O]; universal rollout unasserted. |
| 33, 40 | Private initially; published links expose downloads. Deactivation removes link permissions, retaining email invitations; no expiry [B]. | No token-strength, hosted-access-log, or downloaded-copy recall guarantee. |
| 33-35, 40 | Viewer: read/download/copy; Reviewer: also comment/suggest; Editor: also edit/add files/accept/restore [B]. | Free-owned Reviewer is comment-only [C, D]; premium-owner project features extend to Free collaborators [D]. |
| 34, 36 | Comments support replies, resolution, own-comment editing/deletion, resolved-thread reopening, and mentions [E]. Email notifications require opt-in and are bundled in ten-minute intervals [E, F]. | Exact hosted role-based deletion authority remains undocumented here; do not import the on-premises matrix. |
| 35, 40 | Reviewing enables tracking; selected changes can be accepted/rejected in bulk. Copying applies tracked changes [F]. Downgrade preserves existing tracked text but disallows new tracking [D]. | Track Changes, full history, and compile time follow the project owner's entitlement; external integrations have distinct inheritance rules [D]. |
| 36 | Chat is a standard feature available to all Overleaf users unless group-disabled [L]. | This explicitly resolves Free availability; a missing premium-table row was never sufficient evidence. |
| 37, 38 | History supports labels, comparison, ZIP downloads, file/project restoration, and deleted-file recovery; copying starts fresh history [G]. | Hosted Free shows 24 hours plus labeled versions; premium owner supplies full history. Restore includes comments/tracked changes; resolved comments can return, deleted comments cannot [H]. |
| 31, 34-38 | CE and Server Pro both have full project history [J]. On-premises restore is Owner/Editor; labels also Reviewer. Chat includes named Viewer, excludes link Viewer; collaborator-comment resolution/deletion and change acceptance are Owner/Editor [I]. | Commenting and tracked changes are Server Pro-only. CE is not thereby devoid of collaboration. These are documented capabilities, not every-version compatibility guarantees. |
| 39 | Ownership moves immediately to an existing collaborator; both owners receive emails [K]. Trash does not affect collaborators; Leave applies to non-owned projects; permanent owner deletion affects everyone [R]. | Server Pro admin transfer is separate: recipient need not already collaborate [S]. Its CE exclusion does not prove owner-initiated transfer is impossible. |
| 39, 40 | Managed-user non-destructive removal preserves ownership/shared access but makes owned-project collaborators read-only, with one writable collaborator allowed [N]. Managed users cannot self-delete [P]. | Pro group controls. AI bundling does not override administrator disablement [P, L]. |
| 31, 40 | Browser offline editing: current file, up to two minutes Free/ten premium; reconnect usually syncs, conflicts offer save-as-new-file [Q]. | No file switching, compile, comments, or AI offline; original-tab restoration may recover edits. Exact premium-owner inheritance is not stated. |
| 35, 39, 40 | AI is plan-bundled from July 2, 2026; Assistant is excluded from Free/ordinary Commons, included in Student/Standard/Pro/Commons AI [T, V]. | Own allowance and organizational controls apply, not unrestricted project inheritance. Removed Summarize/Explain buttons remain inconsistently listed [V]; no proven AI-diff/Track Changes integration. |

## Closure table: every input EXPAND lead

IDs follow each angle's EXPAND bullet order. RESOLVED means supported documentation, not executed account behavior. UNRESOLVED is a terminal evidence finding, not a promised future investigation.

| Lead | Disposition | Evidence and reason |
|---|---|---|
| 31.1 Current presence UI | UNRESOLVED | [A] and targeted cursor search do not specify current cursor/roster behavior. Legacy v2 evidence cannot establish present scope. |
| 31.2 Synchronization under failure | RESOLVED / OUT OF SCOPE | [Q] resolves short offline/reconnect behavior; arbitrary ordering, delivery, or latency guarantees remain unasserted. |
| 32.1 Edit-link visibility | DUPLICATE / UNRESOLVED | 40.1. |
| 32.2 Commons quota | RESOLVED | [M], subscription-ending FAQ, explicitly identifies unlimited collaborators; [K] also lists Commons unlimited. |
| 32.3 Anonymous settings/defaults/quotas | RESOLVED / UNRESOLVED | [W]: public access defaults false; anonymous read/write and link-disable flags exist for both editions. Anonymous flag default and quota interaction are not specified. |
| 32.4 AI bundling date | RESOLVED | [T] visibly dated July 2, 2026; “AI included” does not mean Assistant on Free. |
| 33.1 Classic Reviewer link | DUPLICATE / UNRESOLVED | 40.1; no account action used to decide. |
| 33.2 Hosted link-access logging/notification | UNRESOLVED | [B] and targeted official search supply no hosted per-access log. [S] documents on-premises admin logging only; pricing subscription audit logs [U] are different. |
| 33.3 CE invite-token secret | UNRESOLVED | [W] places required 16-character-minimum secret under both-edition “All versions,” but dates introduction specifically to Server Pro 6.2.0. CE minimum/version semantics remain ambiguous. |
| 33.4 Free Reviewer conflict | RESOLVED | Explicit Free exception [C] plus no-Free tracking [D] overrides generic role descriptions. Owner-based inheritance is separately documented. |
| 33.5 Labs sharing general availability | UNRESOLVED | Current general guide [B] documents single-link sharing, but Labs still lists it [X]. Rollout status is not explicitly settled. Do not promote Labs universally. |
| 34.1 Reviewer-link conflict | DUPLICATE | 33.1/40.1. |
| 34.2 Hosted resolve/delete rights | UNRESOLVED | [E] generally permits resolution and own-comment deletion; [B] has no resolve/delete columns. Exact role authority cannot be imported from [I]. |
| 34.3 Restore blog date | RESOLVED | [H] visibly dated December 11, 2024. |
| 34.4 Free tracked suggestions | DUPLICATE / RESOLVED | 33.4. |
| 35.1 Hosted accept/reject authority | RESOLVED | [B] matrix: Editor yes; Reviewer/Viewer no. |
| 35.2 Truncated downgrade FAQ | RESOLVED | Full final bullets [D]: existing tracked changes remain; additional tracking unavailable; all collaborators become viewers if downgrade precedes selection. |
| 35.3 AI Apply/Reject creates tracking | UNRESOLVED | Opened Assistant page [Y], AI parent [V], and tracking guide [F]; none establishes that linkage. Packaging separately resolved by [T]. |
| 35.4 LaTeX changes example/PDF | RESOLVED | Official example [Z] exposes source and abstract: manual package markup, distinct from platform review permissions. Exhaustive package inventories are out of scope. |
| 36.1 Chat limits/retention/edit/delete/attachments | UNRESOLVED | [L], [I], current service README [AA], and targeted retention/attachment searches give no product contract for these details. |
| 36.2 Chat mentions/email | UNRESOLVED | [E/F] notifications concern comments/tracked changes, not chat; targeted search found no explicit chat statement. |
| 36.3 Free individual chat | RESOLVED | [L] explicitly says all Overleaf users. |
| 36.4 Chat row/comment resolution cells | RESOLVED | Complete [I] table inspected; permissions recorded above, on-premises only. |
| 36.5 CE disable-chat setting | RESOLVED | Full [W] includes `OVERLEAF_DISABLE_CHAT` under both-edition “All versions.” |
| 36.6 Current chat module | RESOLVED | Opened current monorepo service README [AA]; it identifies the chat backend. It does not prove undocumented hosted retention or delivery behavior. |
| 36.7 Issue #1278 state | RESOLVED | Official repository page [AB] displays Open. Issue status does not negate current documented comment mentions [E]. |
| 37.1 Premium retention/downgrade purge | UNRESOLVED | [G/D] establish accessible full history and loss of premium access, not storage lifetime or purge. Retention search found no explicit policy. |
| 37.2 Legacy Learn history URL | OUT OF SCOPE | Current canonical [G] establishes needed functionality; redirect archaeology adds no product claim. |
| 37.3 Commons/Server history retention settings | UNRESOLVED | Commons full-history access follows [D/M]; both editions have history [J]. Complete [W] has initialization/display flags and deleted-resource cleanup, not active-history retention policy. |
| 38.1 CE restoration | RESOLVED, DOCUMENTED | [J] plus general on-premises “History” matrix [I] supports file/project restore; no edition exclusion there. Particular release/runtime parity is unasserted. |
| 38.2 Restore creates new history entry | UNRESOLVED | [G/H] and exact-topic search do not state this. |
| 38.3 Label/download plan gating | UNRESOLVED, NARROW | [G] documents labeling/downloading available history and Free labeled-version visibility, not a separate gate or unlimited historical access. No unavailable-tier inference. |
| 38.4 Previously unexecuted searches | RESOLVED / DUPLICATE | Executed official-domain CE restoration and Free-label searches; results checked against [I/J/G]. Substantive outcomes are 38.1/38.3. |
| 39.1 Owner leaving own project | RESOLVED, BOUNDED | [R] assigns Leave to non-owned projects, Delete to owned projects. Transfer [K] is the documented route to becoming a non-owner; no direct owner-leave claim. |
| 39.2 Transfer reversal/comment preservation | UNRESOLVED | [K/R] and owner-leave search do not establish undo or metadata-preservation semantics. Ordinary transfer authority is not a special reversal guarantee. |
| 39.3 On-prem transfer/leave rows | RESOLVED | [I] has Leave/Leave multiple and Server Pro-only **admin** transfer. Corrects upstream overbroad CE-transfer ban. |
| 39.4 Managed Remove User effects | RESOLVED | Full returning-ownership subsection [N] explicitly supplies collaborator read-only/one writable rule. |
| 39.5 Managed AI/date reconciliation | DUPLICATE / RESOLVED | [P/L/T]: enabled by admin, own allowance, organizational project blocks; July 2 bundling is not an override. Incidental rule-publication date is out of scope. |
| 40.1 Link visibility/Reviewer contradictions | UNRESOLVED | [B/C/O/X] conflict. [O]: July 1, 2024, rollout completed October 14. |
| 40.2 Link expiry/offline inheritance | RESOLVED / UNRESOLVED | [B] explicitly says no expiry; [Q] resolves offline behavior, but ten-minute inheritance for Free collaborators remains unstated. |

Additional residuals: hosted token construction/rotation, on-premises numerical project quotas, unlimited retention, and post-download control are unasserted; the checked sharing/configuration/history sources do not establish them. Legacy third-party accept-all snippets do not supersede [F]. No speculative tier combinations or arbitrary compatibility guarantees are added.

## Official source register

All were opened live; `.md` retrieval recovered the complete configuration table and offline page where search extraction failed.

- A: https://docs.overleaf.com/collaborating/collaborating-in-overleaf — “Collaborating in Overleaf.”
- B: https://docs.overleaf.com/collaborating/sharing-a-project — “By Link,” “Understanding permission levels,” FAQs.
- C: https://docs.overleaf.com/collaborating/reviewing-and-reviewers — “Reviewer permissions,” Free/named-collaborator FAQs.
- D: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — collaborator/tracking tables, account/project features, downgrade FAQ.
- E: https://docs.overleaf.com/collaborating/commenting — “Using comments,” “Mentions,” “Notifications.”
- F: https://docs.overleaf.com/collaborating/track-changes — tracking, bulk acceptance/rejection, notifications.
- G: https://docs.overleaf.com/writing-and-editing/history-and-versioning — full History, labeling, downloading, restoration.
- H: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes — “Who can use it?”, “What else should I know?”
- I: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — Dashboard, Collaborating, History, Admin Panel.
- J: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — “Benefits for users.”
- K: https://docs.overleaf.com/collaborating/transferring-project-ownership — transfer steps/access table.
- L: https://docs.overleaf.com/groups/user-management/controlling-feature-availability — Chat row, AI controls.
- M: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription — subscription-ending FAQ.
- N: https://docs.overleaf.com/groups/user-management/managed-user-accounts — “Returning ownership of a managed account to the original account owner.”
- O: https://www.overleaf.com/blog/changes-to-project-sharing — “What's changing?”, “Projects over the collaborator limit.”
- P: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts — restrictions, “AI features and managed accounts.”
- Q: https://docs.overleaf.com/writing-and-editing/working-offline.md — “How to work offline,” syncing, limitations, recovering edits.
- R: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project — “Trashed Projects,” collaborator effects.
- S: https://docs.overleaf.com/on-premises/user-and-project-management/project-management — audit log, ownership transfer, access tracking.
- T: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — July 2, 2026; plan/Commons sections.
- U: https://www.overleaf.com/user/subscription/plans — “Editing and collaboration,” audit logging.
- V: https://docs.overleaf.com/integrations-and-add-ons/ai-features — plan table, troubleshooting.
- W: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/environment-variables.md — “All versions.”
- X: https://docs.overleaf.com/accounts-and-security/overleaf-labs/live-experiments — “New Project Sharing Experience - Single share link,” experiment warnings.
- Y: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — “Chatting with your document.”
- Z: https://www.overleaf.com/latex/examples/tracking-changes-in-latex-with-changes-package/fnpkpytjjwhj — Abstract/Source.
- AA: https://raw.githubusercontent.com/overleaf/overleaf/main/services/chat/README.md — “overleaf/chat.”
- AB: https://github.com/overleaf/overleaf/issues/1278 — issue title/status.

Counter-search executed for the consequential restriction: `site:docs.overleaf.com "Reviewer" "free plan" "comment"`; [C/D] support the Free-owner exception rather than free tracking. Searches also covered retention, CE restore, Free labels, chat mentions/attachments, presence cursors, hosted access notifications, and restore entries; absence is recorded as uncertainty, never unavailability.

Supplement incorporated: offline, Labs, AI freshness and deployment distinctions apply above; conversion, Library/ReadCube and Google Drive are duplicate inventory topics owned by adjacent clusters, not additional collaboration leads.

## EXPAND

None. All 40 input bullets are disposed of above. Remaining documentation gaps and conflicts are explicit UNRESOLVED findings after concrete public-source checks; repeating them as future queries would not create new actionable evidence.
