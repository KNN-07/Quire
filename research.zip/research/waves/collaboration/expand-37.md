# expand-37: Overleaf History timeline, labels, and retention windows

Retrieved 2026-10-26 (sources read via webfetch; no authenticated tests, no purchases, no codebase edits). The `apply_patch` tool was not available, so this file was written with the write tool.

## Platform features (History, labels, restore)

All items below are platform features documented at https://docs.overleaf.com/writing-and-editing/history-and-versioning.md. Tier notes are given where the page or linked pages state them.

- **Access.** History icon above the preview panel; "All history" or "Labels"; "Back to editor" exits. Heading: "How to access a project's history".
- **Labels.** Three-dot menu in All history, then "Label this version", then "Add label". Multiple labels per version are allowed (hint: "You can attach multiple labels"). The current version is shown as "Current state". Heading: "Labeling a project version". No tier restriction is stated on this page.
- **Compare.** Align Start / Align End / Align Space Even icons compare up to, from, or across versions. Heading: "Comparing versions".
- **Download.** Three-dot menu, "Download this version", produces a .zip. Heading: "Downloading an older version of your project".
- **Restore one file.** Select a file in an older version, "Restore this version". Restores content plus comments and tracked changes at that time. Heading: "How to restore a single file to a previous version".
- **Recover deleted files.** Deleted files appear struck through in the version where they were deleted. Heading: "Recovering deleted files".
- **Restore whole project.** Three-dot menu, "Restore project to this version", including comments and tracked changes. Heading: "Restoring an earlier version of the project".
- **Copies start fresh.** A copied project starts a new history; the original history is not copied. Heading: "What happens to the history if you copy a project?".
- **Comment limits on restore.** Resolved comments can be restored; deleted comments cannot; unresolved threads keep history up to the most recent version. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes, section "What else should I know?". The blog's date (Dec 11, 2024, per the harvest) did not appear in the fetched text; treat the date as harvest-reported, not verified.

## Tier and retention windows

- **Free.** History panel shows edits from the last 24 hours plus labeled versions. Source: history-and-versioning page, success hint "Using the full History feature".
- **Premium (Full Project History).** Entire history. Premium is a project-level feature governed by the project owner's subscription, so collaborators on a premium-owned project get full history without paying. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md, "Account and project level features", and the "Full document history and versioning" section, which contrasts full history with "only 24 hours of history availability on a free Overleaf account".
- **Restore older than 24h.** Requires the "Full document history" premium feature; anyone with edit access can restore within 24 hours. Source: the blog, section "Who can use it?".
- **Plans with full history.** Standard, Pro, Student, and group/organization plans. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits.md, "More about our premium plans".
- **Downgrade.** Full project history "will no longer be available"; projects are not deleted. Source: premium-features page, "What happens to my projects if I downgrade to the Overleaf free plan?". The page does not say whether stored history older than 24h is purged. UNRESOLVED.
- **Free-plan label creation.** The docs show labeled versions on free but do not explicitly say free users can create labels. UNRESOLVED.

## Community Edition and Server Pro (on-premises)

- **3.5.13 default.** After upgrading to CE 3.5.13, new projects use Full Project History by default; existing projects stay on the legacy system until migrated. Source: https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x/full-project-history-migration, intro. Features listed: binary-file tracking, labeled versions, and more robustness.
- **Downgrade is backup-based.** Downgrading to an earlier version requires restoring a full system backup. Same page, info hint.
- **Legacy cleanup (Server Pro).** Before 3.5.13, the cleanup script deletes `docHistory` and `docHistoryIndex` content after migration; this is cleanup of legacy data, not a retention policy. Same page, "Clean up legacy history data".
- **Storage.** Full project history data is stored on the filesystem. Source: https://github.com/overleaf/overleaf/wiki/Data-and-Backups, "Data Storage". No retention duration is given.

## Legacy and dated items

- **"Pro users have access to full history" (undated legacy blog).** https://www.overleaf.com/blog/157-save-to-dropbox-and-create-protected-projects-on-pro, section "Full history service". Legacy and undated; superseded by the docs above.
- **Overleaf V1 only.** https://www.overleaf.com/learn/how-to/What_is_the_full_history_service%3F states it covers V1 only. Legacy; not used for current claims.

## Unresolved

- **Premium retention duration.** No reviewed primary page states how long full history is kept or any purge policy. A search for it returned no primary answer. UNRESOLVED.
- **Downgrade purge.** UNRESOLVED (see above).
- **Learn article "Using the History feature".** Two fetches of https://www.overleaf.com/learn/latex/Using_the_History_feature returned the docs history page instead, so the learn article was not verified. UNRESOLVED.
- **Commons and Server Pro retention.** Not documented beyond the migration pages. The Commons data-ownership page surfaced in search but is not history-specific; not opened. UNRESOLVED.
- **July 2, 2026 AI bundling blog.** Not opened; History is not documented as AI-gated, so no AI claims are made here.

## EXPAND

- LEAD: Find an official statement of full-history retention duration and downgrade purge behavior. Searched once; no primary source found. Still open.
- LEAD: Verify the learn article "Using the History feature" directly. Two fetch attempts returned the wrong page. Still open.
- LEAD: Check Commons and Server Pro for any history retention setting. Commons page surfaced but not opened and not history-specific. Still open.
- Closed as duplicate or out of angle: the harvest's on-premises settings lead is covered by the migration page above (no retention setting found there); the AI bundling blog is out of scope for this angle.
