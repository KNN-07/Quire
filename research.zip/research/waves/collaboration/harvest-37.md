# harvest-37: Overleaf History timeline, labels, and retention windows

Retrieved 2026-10-26 from public Overleaf documentation and blog pages. No authenticated tests, no purchases, no codebase edits. Note: the `apply_patch` tool was not available in this session, so this file was written with the write tool.

## Platform features (History, labels, restore)

- **Access.** Open the History icon above the preview panel, then pick "All history" or "Labels"; "Back to editor" exits. Source: https://docs.overleaf.com/writing-and-editing/history-and-versioning.md ("How to access a project's history").
- **Labels.** Labeling is done from the three-dot menu in All history ("Label this version", then "Add label"). Multiple labels per version are allowed. The current version is shown as "Current state". Source: same page, "Labeling a project version".
- **Compare.** Align Start / Align End / Align Space Even icons compare up to, from, or across a range of versions. Source: same page, "Comparing versions".
- **Download.** Three-dot menu, "Download this version", produces a .zip of that version. Source: same page, "Downloading an older version".
- **Restore one file.** Select a file in an older version and choose "Restore this version". This restores the file's content plus its comments and tracked changes at that time. Source: same page, "How to restore a single file".
- **Recover deleted files.** Deleted files appear struck through in the version where they were deleted; restore from there. Source: same page, "Recovering deleted files".
- **Restore whole project.** Three-dot menu, "Restore project to this version"; comments and tracked changes are restored too. Source: same page, "Restoring an earlier version of the project".
- **Comment limits on restore (blog, dated Dec 11, 2024).** Resolved comments can be restored; deleted comments cannot; unresolved threads carry the full comment history. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes ("What else should I know?").
- **Copying a project** starts a fresh history; the original history is not copied. Source: history-and-versioning page, "What happens to the history if you copy a project?".

## Tier and retention windows

| Item | Free plan | Premium (per docs) |
|---|---|---|
| History window | Edits from the last 24 hours, plus labeled versions | "Full Project History" (entire history) |
| Restore older than 24h | Not available | Requires "Full document history" premium feature (blog, Dec 11, 2024) |
| Who must pay | N/A | Project owner's subscription governs; collaborators on a premium-owned project get full history without paying |

Sources: history-and-versioning page, hint under "Using the full History feature"; premium-features page, "Full document history and versioning" and "Account and project level features" (https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md); blog above.

Premium plans that include full history are named as Standard, Pro, and Student, plus group and organization plans (https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits.md, "More about our premium plans").

**Downgrade.** Full project history stops being available on the free plan; existing projects are not deleted. The docs do not say whether already-stored history beyond 24 hours is purged on downgrade. Source: premium-features page, "What happens to my projects if I downgrade".

**Free-plan labels.** The docs say the free History panel shows labeled versions. They do not state a retention duration for labels, and they do not explicitly say free users can create labels. Treat label creation on free as UNRESOLVED.

## Unresolved

- **Premium retention length.** No reviewed page states how long full history is kept or any purge policy. UNRESOLVED.
- **Downgrade purge.** Not documented. UNRESOLVED.
- **Commons, Server Pro, and Community Edition history.** Not verified. The project-history GitHub repo README (https://github.com/overleaf/overleaf/tree/main/services/project-history) only describes local dev and test commands; it states no retention behavior. UNRESOLVED.
- **Learn article "Using the History feature".** The learn page did not load in this session. Only a search-result snippet from a third-party mirror was seen (https://sharelatex.das7pad.de/learn/Using_the_History_feature), which repeats the 24-hour free / premium full-history split. Secondary; not primary-verified.
- **Legacy page.** https://www.overleaf.com/learn/how-to/What_is_the_full_history_service%3F is marked as covering Overleaf V1 only (legacy, undated). Not used for current claims.
- **AI bundling (blog, July 2, 2026).** Not opened. History is not documented as AI-gated, so AI does not affect this angle; no AI claims are made here.

## EXPAND

- LEAD: Search for an official Overleaf blog or help page stating full-history retention duration and downgrade purge behavior.
- LEAD: Open the learn article https://www.overleaf.com/learn/latex/Using_the_History_feature directly and confirm the 24-hour and premium wording.
- LEAD: Check the on-premises docs (https://docs.overleaf.com/on-premises) for any history or retention setting in Server Pro or Community Edition.
- Not opened (out of this angle): the July 2, 2026 AI bundling blog. Open only if an AI-tier question is raised.
