# Verify 34: Reviewer roles, comments, threads, and resolution

Checked against official Overleaf docs and blog pages on 2026-10-26. Verdict: **PARTIAL**. Core reviewer, comment, mention, notification, and restore claims are confirmed. The link-sharing claim is contradicted, and hosted resolution rights and Free-reviewer behavior are unresolved. No authenticated tests were run.

## Confirmed

- **Reviewer role, hosted.** Reviewers can make and respond to comments and make tracked changes, but cannot switch to Editing or create files. Editors can switch between Editing and Reviewing. Source: https://docs.overleaf.com/collaborating/reviewing-and-reviewers, "Reviewer permissions" and FAQ "Can a Reviewer add/create files?". Availability: all plans, but see the Free exception below.
- **Reviewing mode enables tracking.** Switching to Reviewing turns Track Changes on. Source: same page, "Changing your mode."
- **Free plan reviewer.** One invited collaborator can be a Reviewer, but "will only be able to comment." Source: same page, FAQ "Is the Reviewer role available on the free plan?" Availability: Free.
- **Collaborator limit.** More than one collaborator (Editor or Reviewer) is premium. Source: https://docs.overleaf.com/collaborating/sharing-a-project, FAQ "How many collaborators are allowed?"
- **Comments.** Highlight text, choose "Add comment," and reply, resolve, or edit/delete through the comment menu. Resolved comments are viewable and re-openable, and a resolved thread can be deleted from that view. Source: https://docs.overleaf.com/collaborating/commenting, "Accessing the comment feature" and "Using comments." Availability: not tier-specific on this page.
- **Mentions.** Type `@` and a name or email to mention a collaborator. Source: same page, "Mentions."
- **Notifications.** Account notifications must be enabled. Project options are "All project activity" or "Mentions and replies only." Notifications are bundled in ten-minute increments. Source: same page, "Notifications."
- **Track Changes is premium.** Track Changes is a premium feature available through Commons, group, and individual subscriptions. Collaborators on an eligible project can use it. Source: https://docs.overleaf.com/collaborating/track-changes, "Introduction." The premium table lists Free: No, Student: Yes, Standard: Yes, Pro: Yes, Personal: No (discontinued). Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features, "Real-time track changes."
- **Restore with comments (undated blog).** Restoring a file or project restores its comments and tracked changes. Resolved comments can be restored; deleted comments cannot. Restoring versions older than 24 hours requires the "Full document history" premium feature. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes, "Who can use it?" and "What else should I know?" The harvest's date (Dec 11, 2024) does not appear in the fetched text, so it is **unverified**.
- **Self-hosted.** Commenting and real-time tracked changes are Server Pro only, not Community Edition. Reviewers can add and reply to comments but cannot resolve or delete collaborator comments, or accept or reject collaborator tracked changes. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Collaborating" matrix and hints.

## Contradicted or corrected

- **Link sharing and the Reviewer role.** The harvest says link sharing cannot initially assign Reviewer. The current sharing page lists **Reviewer** as a link permission option ("Viewer" by default, with "Reviewer" and "Editor" as alternatives). Source: https://docs.overleaf.com/collaborating/sharing-a-project, "By Link." The reviewing page's FAQ still says the Reviewer role is named-collaborator only. The two official pages conflict. **UNRESOLVED** which is current.
- **Comments on "all hosted accounts."** The harvest cites a legacy how-to for free and paid availability. The current Commenting page does not state tier availability. Treat it as **unverified** for current hosted docs.

## Unresolved

- **Hosted resolve/delete permissions by role.** The hosted Commenting page says all collaborators with access can resolve. The On-premises matrix says Reviewers cannot. These are different products, so the self-hosted matrix does not answer the hosted question. **UNRESOLVED.**
- **Hosted accept/reject rights.** The hosted Track Changes page describes accept/reject but does not say which roles may do it. The sharing page's permission table lists Reviewers as not able to "Accept/ Reject Changes," but that table is not a complete hosted matrix. Treat as **UNRESOLVED** beyond that row.
- **Free reviewer and tracked suggestions.** The reviewing page's general description says reviewers make tracked changes. The FAQ says Free reviewers can only comment. The premium table says Track Changes is unavailable on Free. Whether a Free-owned project changes this is **UNRESOLVED**.
- **Legacy how-to redirect.** The expand report says the legacy how-to redirects to current Commenting docs. I did not independently verify this redirect.

## Counter-search queries (run or to run)

- `site:docs.overleaf.com reviewer link sharing Reviewer permission` (to resolve the link-sharing conflict)
- `site:docs.overleaf.com "Resolve or delete" comments hosted permissions`
- `site:overleaf.com blog restore version comments tracked changes date`
- `site:docs.overleaf.com track changes Free reviewer comment only`

## EXPAND

- **LEAD: Link-sharing Reviewer conflict.** Reason: two official pages disagree. Next step is to check the current UI text or a later doc revision.
- **LEAD: Hosted role-based resolve/delete rights.** Reason: no published hosted matrix. Next step is to search for an official hosted permissions table.
- **LEAD: Restore blog publication date.** Reason: the fetched text has no date. Next step is to find the blog's published date.
- **LEAD: Free reviewer tracked-change behavior.** Reason: the docs conflict. Next step is to find an explicit Free-plan statement.
