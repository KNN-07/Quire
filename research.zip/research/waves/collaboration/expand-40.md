# Expand 40: Overleaf sharing security boundaries and collaborator premium inheritance

Research date: 2026-10-26. Public official sources only. No authenticated tests, purchases, or codebase edits. Claims are documentation claims; nothing here was functionally executed.

## Sharing security boundaries

- **Private by default.** Docs FAQ "Are my Overleaf projects private?": every new project is private, and other users cannot see it unless the owner shares it via the Share menu. Source: https://docs.overleaf.com/collaborating/sharing-a-project.md (FAQ). The same text appears on the learn page https://www.overleaf.com/learn/how-to/Are_my_Overleaf_projects_private%3F (read via search excerpt, body consistent with the docs FAQ). Status: resolved.
- **Unguessable link tokens.** Same FAQ: link sharing creates a unique token used only for that project's link. The docs say it is "almost impossible to guess." Anyone holding a link can view and download the project, and a link posted publicly may be indexed by search engines. Links do not expire; the owner deactivates them by switching back to "Only invited people."
- **Email invites** require the invitee to authenticate before accepting. Turning link sharing off removes permissions for users who joined via a link, but keeps those invited by email (same FAQ).
- **Permission matrix (current).** Viewer: view source, download, copy, comment. Reviewer: adds write comments and suggest edits, no accept/reject or restore versions. Editor: full. Source: sharing-a-project.md, "Understanding permission levels."
- **Visibility conflict (open).** Current sharing docs say link joiners do not appear in Manage access; changing the link permission updates everyone who joined by link. The 2024 blog https://www.overleaf.com/blog/changes-to-project-sharing (dated 2024, edits to Nov 7, 2024) announced that edit-link users would appear in Share settings and must confirm joining, and that the rollout completed Oct 14, 2024. The current doc's screenshots are dated April 2026, so it is the newer source. I could not confirm the live UI behavior without an authenticated test, which I did not run. Status: UNRESOLVED in live product; current docs favor "not shown."
- **Server Pro control.** Server Pro 6.0.1 adds `OVERLEAF_DISABLE_LINK_SHARING=true`, which restricts sharing to individualized email invites. Source: https://www.overleaf.com/blog/overleaf-server-pro-6-0-1-is-available ("Server Pro 6.0.1 introduces the following features"). The GitHub wiki https://github.com/overleaf/overleaf/wiki/Configuring-Overleaf is marked "View outdated content" and lists `OVERLEAF_ALLOW_ANONYMOUS_READ_AND_WRITE_SHARING` for anonymous link editing. Date-tag: legacy wiki; its env names changed from `SHARELATEX_*` to `OVERLEAF_*` in CE/Server Pro 5.0.1 (deprecation).

## Collaborator premium inheritance

- **Owner's plan governs project entitlements.** Premium features page https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features, "Account and project level features": track changes, compile time, and full history follow the project owner's subscription. Free-plan collaborators can use them inside that project. Status: resolved.
- **Collaborator seat limits follow the owner.** Premium-features table (same page): Editors and Reviewers per owner plan: Free 1, Student 10, Standard 10, Pro unlimited, Personal 1 (no longer offered). Viewers unlimited on all plans. The FAQ adds that multiple collaborators are a premium feature, available via a Commons, group, or individual subscription.
- **Account-level features do not inherit.** Dropbox, Mendeley, Zotero, ReadCube are personal to the subscriber. Collaborators can cite imported references, but only the owner can re-sync the .bib. GitHub sync is per project: any project member can sync once the owner links the repo. Git: members of a premium-owned project can clone, push, and pull; a premium user can do so on all projects they can access. Source: premium-features page, "Account and project level features" tabs.
- **Ownership transfer changes seats.** https://docs.overleaf.com/collaborating/transferring-project-ownership.md, "Will transferring project ownership affect collaborator access?": Standard to Free reduces edit collaborators from 10 to 1, others become view-only. Professional, Group Professional, or Commons institutional access to Free reduces edit collaborators from unlimited to 1. Free to Standard raises the limit from 1 to 10. Transfer is immediate; owner-only actions (add collaborators, link toggle, delete) move to the new owner at once.
- **Downgrade behavior.** Premium-features page, "What happens to my projects if I downgrade": projects are kept; collaborators beyond one are moved to view-only; track changes stays in existing text but cannot be used for new changes.
- **Group policy.** https://docs.overleaf.com/groups/getting-started/sharing-permissions-within-your-group.md: only Pro group admins set sharing policy for all group-owned projects. Email invites can be restricted to the group or open to anyone; links can be disabled, restricted to the group, or open. Owners can apply stricter rules per project. Changes are forward-looking; existing projects are not affected. Source: same page.
- **Subscription end.** Group FAQ https://docs.overleaf.com/subscriptions-payments-and-billing/group-subscription.md: when a subscription ends, the account moves to the free plan, keeps its projects, and collaborators are not removed from shared projects.

## Deprecated and legacy items

- Personal plan: no longer offered to new subscribers (date-tag: current as of docs read 2026-10-26).
- 2024 collaborator-limit enforcement: editors over the limit are switched to view-only; this is legacy behavior now completed (Oct 14, 2024).
- Legacy dual view/edit links: owners can consolidate into one link, which is permanent and removes originals. Source: sharing-a-project.md FAQ "What about legacy sharing links?"

## Not covered or unresolved

- AI features: the premium page lists AI free within daily limits. Not investigated here; not combined with the July 2, 2026 bundling claim.
- Commons: only named as institutional access in the transfer table. No Commons-specific sharing or inheritance page was read. UNRESOLVED.
- Community Edition and Server Pro sharing permissions beyond the 6.0.1 disable flag: UNRESOLVED.
- Public access (guest project links): https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/public-access returned 404; a third-party mirror excerpt was not treated as primary. UNRESOLVED.
- Compile-timeout values and the plan-limits page's compile section were not extracted. UNRESOLVED numbers.
- Offline editing limits (10 min premium, 2 min free) are documented but not checked for inheritance. UNRESOLVED.

## EXPAND

- LEAD: Live Share UI behavior for link joiners (current docs vs. 2024 blog). Reason: directly affects security boundary claims. Needs an authenticated test, which is out of scope here; left open.
- LEAD: Commons sharing and inheritance page. Reason: named in transfer table only. Open.
- LEAD: Server Pro/CE public access documentation (the URL 404'd). Reason: needed for guest-access boundary. Open.
- LEAD: Compile-timeout values on the plan-limits page. Reason: premium inheritance claim currently lacks numbers. Open.
- Duplicate closed: "Are my projects private?" learn page and docs FAQ, same claim, one citation chain.
