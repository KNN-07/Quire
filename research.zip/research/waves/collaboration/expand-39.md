# Expand 39: Project ownership transfer and leaving shared projects

Research date: 2026-10-27 (task date 2026-10-26). Scope: ownership transfer and leaving shared projects. Method: public Overleaf docs and blog pages opened in full. No authenticated tests or purchases were run, so all behavior below is documented behavior, not observed behavior. Plan labels follow the docs as written.

## Platform features

**Transferring ownership (owner action, all plans)**
- Only the owner can transfer. Exception: projects created by a managed account. Source: https://docs.overleaf.com/collaborating/transferring-project-ownership, warning hint.
- Steps: Share menu, then "Make owner" on the collaborator, then "Change owner". Source: same page, steps 1-4.
- The new owner must already be a collaborator. Source: https://www.overleaf.com/blog/new-feature-transfer-project-ownership-on-overleaf, summary list.
- The change is immediate. Add-collaborator and link-sharing rights move at once. Source: transfer docs, warning hint after step 4.
- Both parties get email notices. Source: transfer docs, steps 5-6.
- The previous owner stays on the project as a collaborator. Source: blog summary list.
- Plan capabilities do not transfer, but existing sharing settings are kept. Source: blog summary list.
- The blog says the feature is "available to everyone". Labeled: all plans, as documented.

**Collaborator limits after transfer (labeled by plan)**
Source: transfer docs, "Will transferring project ownership affect collaborator access?" table.
- Free to Free: no change, one edit-access collaborator and unlimited view-only.
- Standard or Group Standard to Free: edit-access drops from 10 to 1. All collaborators become view-only.
- Professional, Group Professional, or Overleaf Commons (institutional access) to Free: edit-access drops from unlimited to 1. All collaborators become view-only.
- Free to Standard or Group Standard: edit-access rises from 1 to 10.
- Free to Professional, Group Professional, or Commons: edit-access becomes unlimited.
- Sharing page FAQ says more than one editor or reviewer per project is a premium feature. Source: https://docs.overleaf.com/collaborating/sharing-a-project, FAQ "How many collaborators are allowed?".

**Leaving a shared project (collaborator action)**
- You cannot permanently delete a project you do not own. Move it to Trashed Projects, then choose Leave. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project, section "How to leave a shared project".
- Trashing a project does not affect collaborators. It only changes where the project appears for you. Source: same page, "How does trashing a project affect collaborators?".
- Deleting a project you own removes it for you and all collaborators, with no undo. Source: same page, danger hint.
- Archive keeps a project without deleting it. Source: deleting page, Archive bullet.
- "Leave a project" and "Leave multiple projects" are listed as user actions with no plan column. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Project management and collaboration". Plan gating is UNRESOLVED.

**Removing your own access through link sharing**
- If you joined through a share link, your access ends when the owner switches the link back to "Only invited people". Email-invited collaborators keep access. Source: https://docs.overleaf.com/collaborating/sharing-a-project, FAQ "Can link sharing be turned off again?".

**Managed accounts (Pro group feature)**
- Available only to Overleaf Pro group subscribers. Source: https://docs.overleaf.com/groups/user-management/managed-user-accounts, info hint.
- Managed users cannot delete their own account. Admins can delete it and reassign that user's projects. Source: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts, "What's the difference".
- Admin "Remove user" (non-destructive) is new relative to the harvest. It removes the user from the group, and the user keeps owned projects and their shared-with-me access. Collaborators on those owned projects become read-only, with one edit collaborator allowed under free limits. Source: https://docs.overleaf.com/groups/user-management/managed-user-accounts, "Returning ownership of a managed account to the original account owner".
- Admin "Delete user" is destructive. The account is permanently deleted and its projects move to another managed user chosen by the admin. Source: same page, "Deleting users and transferring project ownership".
- AI rule for collaborators: if a managed user's organization disables AI, that user cannot use AI on any project, including projects owned by others. Source: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts, "AI features and managed accounts". Undated page. Not reconciled with the July 2, 2026 AI-bundling blog, which was not opened in this pass.

**Server Pro and Community Edition (self-hosted)**
- Server Pro admins can transfer a project to another user. Community Edition cannot. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Manage Users -> Users -> User -> Project -> Project Info", row "Transfer ownership of project to another user" (Server Pro Yes, Community No).
- Admin project-level collaborator views and audit logs are Server Pro only. Source: same page, admin tables.

## Dates and legacy
- The transfer blog post shows no date in the fetched text. Publication date: UNRESOLVED.
- The transfer docs carry no date. No legacy transfer page was found for this angle.

## Limitations
- The docs do not say whether a project owner can leave their own project without transferring it first.
- The docs do not say whether the new owner can undo a transfer, or whether the previous owner can reclaim it.
- The docs do not say what happens to a collaborator's tracked changes or comments on transfer.
- Commenting and tracked changes are documented as Server Pro only in the roles table. This does not affect the transfer or leave flows, but it limits what can be checked for hosted accounts.

## EXPAND
- LEAD: Owner-leave behavior (can an owner leave their own project, or must they transfer or delete it first). UNRESOLVED. No primary page in this angle documents it. Requires an authenticated test, which was out of scope.
- LEAD: Managed-user reassignment is now covered by the admin page. Closed as a duplicate of the harvest lead.
- Duplicates closed: the transfer doc, blog, and sharing page overlap with the harvest. Each claim above was checked against the primary page.
- Omitted functionality found: admin non-destructive "Remove user", and the managed-user AI rule.
- Deprecation: none found for this angle.
