# Expand 35: Track Changes, decisions, and permissions

Research date: October 26, 2026. Public Overleaf documentation and official Overleaf blog only; no authenticated tests or purchases were performed.

## Product behavior

Overleaf Track Changes is an editor collaboration feature, distinct from LaTeX markup packages. In the editor, switching to Reviewing turns on Track Changes for that collaborator; an Editor can switch between Reviewing and Editing, while a Reviewer cannot switch to Editing. The project owner can make a collaborator's edits tracked by assigning Reviewer access. Reviewers can make tracked changes and add/reply to comments, but cannot add or create files. This is Overleaf platform behavior, not a guarantee provided by arbitrary LaTeX source.  
Sources: https://docs.overleaf.com/collaborating/track-changes — “Accessing Track Changes” and “Configuring whose changes will be tracked”; https://docs.overleaf.com/collaborating/reviewing-and-reviewers — “Reviewer permissions,” “Changing a collaborator’s mode,” and FAQ “Can a Reviewer add/create files?”

The role is assigned by the project owner when inviting a named collaborator or later through Share / Manage access. It cannot be assigned directly to a link-sharing collaborator; a user who joined via a share link can be changed to Reviewer after joining. A Reviewer cannot self-promote. On Free, the documentation says the one invited collaborator can be assigned Reviewer but “will only be able to comment”; therefore do not interpret that role availability as Free-plan access to tracked edits.

For decision workflow, the current cloud how-to documents selection-based bulk actions: select text containing the revisions (Ctrl+A on Windows or Cmd+A on Mac for the whole document), choose “Accept selected changes” or “Reject selected changes,” then confirm or cancel. The current premium-features page additionally says individual changes can be accepted or rejected. Copying a project automatically applies its tracked changes in the copy, where they are no longer displayed as tracked. These sources do not explicitly state which hosted roles can perform the accept/reject actions, so no cloud role guarantee is inferred.  
Sources: https://docs.overleaf.com/collaborating/track-changes — “How to accept or reject all tracked changes”; https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — “Real-time track changes.”

## Availability and deployment distinctions

For hosted projects, Track Changes is premium and project-level: Free and discontinued Personal are listed as unavailable; Student, Standard, and Pro are available. Eligibility derives from the project owner’s subscription, so collaborators need not each have a paid plan. On downgrade to Free, existing tracked changes remain, but no additional changes can be made with the feature. The docs also identify Overleaf Commons and group subscription participants as eligible premium-feature users.  
Sources: https://docs.overleaf.com/collaborating/track-changes — “Introduction”; https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — “Real-time track changes,” “Account and project level features,” and downgrade FAQ.

The on-premises roles-and-permissions matrix explicitly grants accepting/rejecting collaborator tracked changes to Project Owners and Editors, not Reviewers or Viewers; it grants Reviewers tracked-change creation and Viewers visibility. The page says commenting and real-time tracked changes are available only in Server Pro, not Community Edition. These are on-premises guarantees and must not be transferred to hosted plans.  
Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — “Editor IDE” / collaboration permissions matrix and note below it.

## AI edits and LaTeX boundary

The AI Assistant documentation describes suggested edits as a diff with “Apply” and “Reject” actions. That is an AI suggestion workflow, not an explicit statement that applying an AI diff creates author-attributed Overleaf Track Changes or follows Reviewer permissions. The assistant article currently describes itself as part of the AI Assist add-on and lists plan access; however, Overleaf’s July 2, 2026 official announcement says Overleaf AI became included in plans with varying allowances and features. The current general AI page says AI features are available to all users subject to daily limits and eligibility; no source found directly reconciles the older assistant-specific add-on wording with the July 2026 plan change. In either case, neither source connects AI diff application to Track Changes.  
Sources: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — “Chatting with your document”; https://docs.overleaf.com/integrations-and-add-ons/ai-features — “Who can use Overleaf AI” and “Can I undo an AI suggestion”; https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — July 2, 2026 announcement.

LaTeX packages can represent source-level revisions, but that is separate from Overleaf’s editor-level collaborator attribution, roles, and accept/reject controls. The official example “Tracking changes in LaTeX with changes package” demonstrates package markup, not platform permissions.  
Source: https://www.overleaf.com/latex/examples/tracking-changes-in-latex-with-changes-package/fnpkpytjjwhj.pdf — example title.

## EXPAND

- **LEAD — cloud accept/reject role matrix: UNRESOLVED.** The current hosted how-to documents actions but omits role-level authority. The on-premises matrix resolves only Server Pro / Community Edition and cannot safely answer hosted permissions.
- **LEAD — Track Changes + AI edits: UNRESOLVED.** AI diffs have Apply/Reject controls, but no official source located says applying them enters Track Changes or inherits its permission rules. Keep these workflows separate.
- **LEAD — legacy AI Assist versus July 2, 2026 bundled AI: PARTIALLY CLOSED.** The official announcement establishes the newer plan change, while current docs retain differing AI wording. This inconsistency does not alter the unresolved separation from Track Changes; do not silently combine the claims.
