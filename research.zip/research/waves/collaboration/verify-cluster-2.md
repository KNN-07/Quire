# Collaboration inventory independent verification (angles 31–40)

Checked October 26, 2026 against live official Overleaf documentation and announcements. This is public-source functionality research, not account testing or runtime acceptance. Sources were opened live; claims below are paraphrased. The reconciliation in `expand-cluster-2.md` is broadly sound, with the corrections and caveats below.

## Verdict: PASS — evidence-complete coverage with caveats

All angle IDs 31–40 are represented. Core documented functionality is supported, with deployment and plan boundaries kept distinct. Unresolved documentation conflicts and unspecified guarantees do not change the inventory of confirmed features; they narrow or qualify claims. Do not resolve a conflict by silently preferring a UI feature table over a contradictory FAQ, or by inferring absence from missing tier labels.

## Accepted features and corrections

- **31, simultaneous editing:** The current collaboration overview says multiple authors collaborate in real time and describes Operational Transformation rebasing, edits sent to the server every few seconds, and WebSocket updates. This supports the documented mechanism, not delivery, ordering, latency, or failure guarantees. Historical cursor/online indicators remain legacy evidence, not a current confirmed feature. [A]
- **32, invitations and quotas:** Email and link sharing, role permissions, and hosted per-project collaborator quotas are documented. The current premium-features table is the source for Free 1, Student/Standard 10, Pro unlimited Editors/Reviewers and unlimited Viewers. These are project quotas, not account seats; do not invent a numerical self-hosted cap. [B, C]
- **33–34, links, access, comments:** Current sharing docs explicitly offer Viewer (default), Reviewer, and Editor link levels; link joiners are stated not to appear in Manage access, and changing link level affects link joiners. Email invitations remain individually manageable. Projects begin private; publicized links can enable viewing/downloading; disabling link sharing removes link-derived permissions while retaining email invitations. No expiry is stated in the sharing FAQ. Do not upgrade “almost impossible to guess” into a token-strength guarantee, or claim hosted access logging or recall of downloaded copies. [B]
- **34–35, review and tracked changes:** Comments support threads, replies, resolution/reopening, mentions, and deletion; notification emails require account opt-in, have project settings, and are bundled in ten-minute intervals. Track Changes is a separate premium, project-level feature: collaborators on an eligible owner’s project can use it. Current docs describe Reviewing mode and bulk accept/reject. The hosted role matrix grants Reviewer suggestions but not accepting/rejecting; the on-premises role matrix is a distinct product. [B, D, E]
- **36, chat:** The group feature-control page calls Overleaf Chat a standard feature available to all users unless a group requests disablement. The on-premises permission matrix confirms chat for Owner, Editor, Reviewer, and named Viewer, but not link Viewer, and documents `OVERLEAF_DISABLE_CHAT=true`. Do not infer Community Edition absence from missing explicit edition labels. Chat retention, attachments, message editing/deletion, chat mentions, and chat email notifications remain undocumented in reviewed sources. [F, G]
- **37–38, history and recovery:** Current history docs document labels, compare, ZIP download, single-file/project restore, and deleted-file recovery. Free sees the last 24 hours plus labeled versions; full project history follows the project owner’s premium entitlement. The official edition comparison explicitly lists full project history in both Community Edition and Server Pro, while commenting and real-time Track Changes are Server Pro-only. On-premises roles separately restrict restore to Owner/Editor, while Reviewer can label. [H, I, J]
- **39, ownership and leaving:** Owner-initiated transfer to an existing collaborator is documented as immediate, with emails to both parties and collaborator access adjusted by the new owner’s plan. Trashing a shared project is distinct from leaving it; owner deletion affects collaborators. Managed-user removal is a separate Group Professional admin operation: non-destructive removal returns account/project ownership and collaborators become read-only, with one collaborator writable under Free limits. Managed-account documentation also explicitly prohibits user self-deletion. Server Pro admin transfer is not evidence that ordinary owner transfer is impossible in Community Edition. [K, L, M]
- **40, inheritance/security:** Premium project features such as Track Changes and full history follow the project owner, but account-level integrations and AI allowances do not become unrestricted merely by project invitation. Dated July 2, 2026 AI announcement and current plans distinguish Free/Commons Basic (no Assistant), Student/Standard/Pro, and Commons AI. Current AI docs remove Summarize/Explain despite their appearance in an introductory list; preserve this doc conflict rather than list them as current. [C, N, O]

## Material corrections to the reconciliation

1. **Link visibility is not a live-behavior conclusion.** The current sharing page says link joiners do not show in Manage access; the July 1, 2024 announcement says edit-link joiners became visible and counted, with rollout complete October 14, 2024. Keep the documentary contradiction explicit; no authenticated UI check was in scope. [B, P]
2. **Reviewer link status is conflicted.** Current sharing docs list Reviewer as a link level, while the reviewing FAQ says Reviewer is currently only for named collaborators (and can be assigned after a link user joins). Report both statements; do not call either universal runtime behavior. [B, Q]
3. **Track Changes / Free Reviewer needs narrow wording.** Current docs say Free’s one Reviewer “will only be able to comment,” while general Reviewer guidance says tracked suggestions. Do not claim Free reviewers can make tracked edits. The owner-based premium inheritance claim does not erase that explicit Free exception. [C, D]
4. **AI intro table is stale within its own page.** The live AI page lists Summarize and Explain early, then explicitly says those actions were removed. Use the removal statement; the discrepancy remains a documentation caveat. The July 2, 2026 dated announcement settles bundled plan packaging, not every AI tool’s current availability. [N, O]
5. **Server Pro vs. Community Edition:** Full project history is explicitly checked for both editions; “Easy internal collaboration” is checked only for Server Pro, but that phrase does not establish that Community Edition lacks core live coediting. Avoid converting comparative marketing language into an unsupported exclusion. [I]

## Unresolved caveats and inventory impact

Open documentation conflicts: Reviewer link assignment; link-joiner visibility. Open specifics: current presence UI; exact hosted role authority for comment resolution/deletion beyond documented actions; free Reviewer tracked-edit behavior; chat limits/retention/mentions/notifications; history retention duration and downgrade purge; whether restore creates a history entry; label/download gating; transfer reversal and metadata preservation; precise offline premium-owner inheritance; hosted access logging and link-token rotation/strength. Offline editing itself is documented as short-disconnection editing with feature limitations; it is not an offline application. None of these unknowns overturns an accepted inventory feature; they prohibit stronger guarantees or narrower tier claims.

## Angle checklist

- [x] 31 simultaneous editing and presence
- [x] 32 invitations and collaborator quotas
- [x] 33 link sharing and access boundaries
- [x] 34 comments, mentions, notifications
- [x] 35 Track Changes and review permissions
- [x] 36 chat
- [x] 37 history and retention
- [x] 38 comparison, restoration, deleted files
- [x] 39 ownership transfer and leaving
- [x] 40 security and entitlement inheritance

## Primary sources

- [A] https://docs.overleaf.com/collaborating/collaborating-in-overleaf — “Collaborating in Overleaf.”
- [B] https://docs.overleaf.com/collaborating/sharing-a-project — “By Email,” “By Link,” “Understanding permission levels,” “Are my Overleaf projects private?”, “Can link sharing be turned off again?”
- [C] https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — “Invite more collaborators,” “Account and project level features,” downgrade FAQ.
- [D] https://docs.overleaf.com/collaborating/track-changes — “Introduction,” “Accessing Track Changes,” “How to accept or reject all tracked changes.”
- [E] https://docs.overleaf.com/collaborating/commenting — “Using comments,” “Mentions,” “Notifications.”
- [F] https://docs.overleaf.com/groups/user-management/controlling-feature-availability — “Overleaf Chat.”
- [G] https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — “Project management and collaboration,” “Collaborating,” “History.”
- [H] https://docs.overleaf.com/writing-and-editing/history-and-versioning — “Using the full History feature,” “Labeling a project version,” “Comparing versions,” restore/recovery sections.
- [I] https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — “Benefits for users.”
- [J] https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x/full-project-history-migration — “Server Pro 3.5.0” (dated October 6, 2023); historical migration detail, not current runtime parity.
- [K] https://docs.overleaf.com/collaborating/transferring-project-ownership — transfer steps and “Will transferring project ownership affect collaborator access?”
- [L] https://docs.overleaf.com/groups/user-management/managed-user-accounts — “Removing Managed Users from your subscription,” “Returning ownership of a managed account to the original account owner.”
- [M] https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts — “What’s the difference between a managed user account and an unmanaged user account?”
- [N] https://docs.overleaf.com/integrations-and-add-ons/ai-features — “AI allowance by plan,” “Who can use Overleaf AI,” “Where did Summarize and Explain go?”
- [O] https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — “Overleaf AI now a part of Overleaf plans,” dated July 2, 2026.
- [P] https://www.overleaf.com/blog/changes-to-project-sharing — “What’s changing?” and rollout completion, dated July 1, 2024; rollout stated complete October 14, 2024.
- [Q] https://docs.overleaf.com/collaborating/reviewing-and-reviewers — “Can I use this for all collaborators?”

## EXPAND lead closure status

**PASS — all collaboration EXPAND leads are dispositioned in `expand-cluster-2.md`.** Resolved claims are sourced; duplicate leads point to their shared unresolved issue; remaining unknowns are expressly retained above rather than promoted to facts. No unresolved caveat changes the accepted feature inventory.
