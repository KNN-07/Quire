# Harvest 40: Overleaf sharing security boundaries and collaborator premium inheritance

Research date: 2026-10-26. Public official sources only. No authenticated tests, no purchases, no codebase edits.

## Sources read (primary)

- S1 Premium features: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features (read in full, markdown view)
- S2 Sharing a project: https://docs.overleaf.com/collaborating/sharing-a-project.md
- S3 Transferring project ownership: https://docs.overleaf.com/collaborating/transferring-project-ownership.md
- S4 Reviewing and reviewers: https://docs.overleaf.com/collaborating/reviewing-and-reviewers
- S5 Request access: https://docs.overleaf.com/collaborating/request-access
- S6 Sharing permissions within your group (Groups docs): https://docs.overleaf.com/groups/getting-started/sharing-permissions-within-your-group
- S7 Group subscription FAQ: https://docs.overleaf.com/subscriptions-payments-and-billing/group-subscription
- S8 Overleaf accounts FAQs: https://docs.overleaf.com/accounts-and-security/understanding-your-overleaf-account/overleaf-accounts-faqs.md
- S9 Blog "Changes to project sharing" (dated 2024; legacy): https://www.overleaf.com/blog/changes-to-project-sharing

## Findings

### Platform features: premium inheritance (S1)

- S1, "Account and project level features": certain premium features apply at project level (track changes, compile time, full history) and follow the project owner's subscription. A free-plan user invited to a subscribed owner's project can use those features inside that project.
- S1 plan table, track changes: Free "No", Student/Standard/Pro "Yes". Full history is also listed as a premium feature versus 24 hours of history on a free account.
- S1, compile timeout: premium users get more compile time (linked plan-limits page, not read).
- Inheritance is therefore a per-project entitlement tied to the owner, not to the collaborator's account.

### Collaborator limits (S1, S9)

- S1 table: collaborators (Editors and Reviewers) per owner's plan: Free 1, Student 10, Standard 10, Pro unlimited, Personal 1 (no longer offered to new subscribers). Viewers are unlimited on all plans.
- S9 (2024, legacy): all editors, whether invited by email or via edit link, count toward the owner's plan limit. Viewers do not. Projects over the limit have editors switched to view-only (rollout completed 14 Oct 2024).
- S3 transfer table: moving ownership changes edit-collaborator counts. Free-to-Free: no change. Standard to Free: edit collaborators drop from 10 to 1 and all others become view-only. Professional, Group Professional, or Commons institutional access to Free: edit collaborators drop from unlimited to 1. Free to Standard: edit collaborators rise from 1 to 10.

### Sharing security boundaries

- Default is private: S8 and the Overleaf "Are my projects private?" learn page (search-snippet only, body not retrieved) say projects are private unless shared. UNRESOLVED from primary body.
- Email invite: S2 says owners invite by email with a chosen permission level; invitees must authenticate to accept.
- Link sharing: S2, "By Link": audience "Anyone with the link" is selected from "Only invited people". Link permission defaults to Viewer; options are Reviewer and Editor.
- Link-joiners and visibility conflict (must flag): S2 hint says collaborators who join through a link do not appear in Manage access, and changing permission updates everyone who joined via link. S9 (2024 blog) says edit-link users now appear in Share settings and must confirm joining. The current docs (S2) contradict the 2024 blog on visibility. UNRESOLVED which behavior is live; do not assume either without an authenticated test (not performed).
- Reviewer role (S4): a Reviewer can only make tracked changes and comments and cannot switch to Editing. Editors can switch between Editing and Reviewing. Reviewer role is available for named collaborators only, not link-sharing joiners at invite time; link-joiners can be updated to Reviewer afterwards. Free plan allows one invited collaborator as Reviewer, comments only.
- Viewer access: S1 and S9 state viewers are unlimited and do not count toward the limit.
- Access requests (S5): Viewers can request Reviewer or Editor; Reviewers can request Editor. Owner accepts or declines in Manage access.

### Ownership and group controls

- S3: only the owner can transfer ownership. Owner-only actions (adding collaborators, turning link sharing on or off, deleting the project) move immediately to the new owner. Transfer is immediate.
- S6 (Groups, Pro admins only): group admins set sharing policy for all group-owned projects. Email invites: anyone in group, or anyone. Links: disabled, anyone in group, or anyone. Owners can apply stricter per-project rules. Changes are forward-looking only; existing projects are not changed.
- S7: group members keep a free-plan account and projects after leaving a subscription; they stay as collaborators. S8 states that after a subscription ends, collaborators are kept as viewers.

### Legacy and boundary notes

- S1 lists "Personal" plan as no longer offered (legacy).
- Commons appears only as institutional access in S3; no Commons-specific inheritance rules were found in the pages read. UNRESOLVED.
- AI features (S1 links to AI features page) were not investigated; not part of this angle. Not combined with the 2026 bundling claim here.
- Community Edition and Server Pro: no official sharing-boundary pages were read. UNRESOLVED for this angle.

## Limitations

- Pages S1 to S8 were read from the markdown or full-page fetch. The privacy learn page (search snippet only) did not return body text on fetch.
- No functional testing of sharing, link joins, or inheritance was done; all claims are documentation claims.
- Date tags: S9 is 2024 and its visibility claim conflicts with S2 (current).

## EXPAND

- LEAD: resolve the link-joiner visibility conflict (S2 vs S9) by checking the current Share UI in an official Overleaf help article or changelog. Reason: directly affects security boundary claims.
- LEAD: fetch the plan-limits page for compile-time and history limits per plan. Reason: S1 links it but it was not read.
- LEAD: read Commons and Server Pro sharing pages. Reason: S3 mentions Commons; Server Pro not covered.
- LEAD: retrieve the "Are my projects private?" learn page body. Reason: privacy claim currently snippet-only.
