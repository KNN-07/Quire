# Harvest 39: Project ownership transfer and leaving shared projects

Research date: 2026-10-26. Sources are official Overleaf docs and blog pages read in full. The `apply_patch` tool was not available in this session, so this file was written with the write tool.

## Platform features (sourced)

**Transferring ownership (owner action)**
- Only the project owner can transfer ownership, unless the project was created by a managed account. Source: https://docs.overleaf.com/collaborating/transferring-project-ownership ("Transferring project ownership", warning hint).
- Steps: open Share, choose the collaborator, select "Make owner", then confirm "Change owner". Source: same page, steps 1-4.
- The new owner must already be a collaborator. Source: https://www.overleaf.com/blog/new-feature-transfer-project-ownership-on-overleaf ("How Can I Transfer the Ownership of a Project?").
- The change is immediate. Add-collaborator and link-sharing controls move from the old owner to the new owner at once. Source: transfer docs warning hint; blog summary.
- Both parties get email notifications. Source: transfer docs steps 5-6.
- The previous owner stays on the project as a collaborator. Source: blog summary bullet list.
- Transfer moves ownership, not plan capabilities. Premium features do not follow the project, but existing sharing settings are kept. Source: blog summary.

**Plan effects of transfer (Free and paid tiers)**
- Free to Free: no change. One edit-access collaborator and unlimited view-only collaborators.
- Standard or Group Standard to Free: edit-access collaborators drop from 10 to 1, and everyone is made view-only.
- Professional, Group Professional, or Commons to Free: edit-access drops from unlimited to 1, and everyone is made view-only.
- Free to Standard or Group Standard: edit-access rises from 1 to 10.
- Free to Professional, Group Professional, or Commons: edit-access rises to unlimited.
- Source: transfer docs, "Will transferring project ownership affect collaborator access?" table.
- Labels: Free and paid tier collaborator limits are documented here. Commons is labeled as institutional access in this table.

**Leaving and removing projects**
- You cannot permanently delete a project you do not own. Trash it first, then use Leave in Trashed Projects. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project ("How to leave a shared project", hint).
- Deleting a project you own removes it for you and all collaborators. Trashing alone does not affect collaborators. Source: deleting-a-project, "How does trashing a project affect collaborators?"
- Archive keeps a project without queuing deletion. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects ("Archiving").
- Leaving a project is listed as a user action ("Leave a project", "Leave multiple projects"). Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Project management and collaboration" table. The table has no plan column, so plan-gating is UNRESOLVED.

**Removing your own access through sharing**
- If you joined through a share link, your access is removed when the owner switches the link back to "Only invited people". Email-invited collaborators keep access. Source: https://docs.overleaf.com/collaborating/sharing-a-project, FAQ "Can link sharing be turned off again?"

**Managed accounts (restriction)**
- Managed accounts cannot be deleted by the user, and admins can delete them and reassign ownership of that user's projects. Source: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts, "What's the difference..." list.
- Managed users are told to keep personal projects in a separate account and transfer ownership of those projects. Source: same page, "Keep work and personal projects separate."

**Server Pro and Community Edition (self-hosted)**
- Admins can transfer ownership of a project to another user in Server Pro. Community Edition does not have this. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Manage Users -> Users -> User -> Project -> Project Info" table.
- Admin-side deletion, collaborator views, and audit logs are Server Pro only. Source: same page, admin tables.

## Not Overleaf-specific
- No arbitrary LaTeX capability applies to this angle.

## Limitations and dates
- The blog post has no visible date in the fetched text, so its publication date is UNRESOLVED.
- The transfer docs and blog both describe the feature as available to all users. No plan restriction on transfer itself was documented.
- Legacy pages: none found for this angle.
- AI bundling (the July 2, 2026 change) does not affect ownership or leaving. Managed-account AI rules were noted above only because the managed-accounts page describes them.
- No authenticated test was run. All behavior is from documentation, not from executed actions.

## Unresolved
- Whether a project owner can leave their own project, or must transfer ownership first. Not documented in the pages read.
- Whether a transfer can be undone by the new owner, or whether the previous owner can reclaim it. Not documented.
- What happens to collaborators' tracked changes and comments on transfer. Not documented.
- Whether the Trashed "Leave" option requires a plan. The roles table does not say.

## EXPAND
- LEAD: The owner's own leave/delete path for projects they own (deleting-a-project page already documents delete, but not owner-leave).
- LEAD: Managed account reassignment flow for admins (https://docs.overleaf.com/groups/user-management/managed-user-accounts.md), not read in this pass.
- None else for this angle.
