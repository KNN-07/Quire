# verify-37: Overleaf History timeline, labels, and retention windows

Verified 2026-10-27 against public Overleaf docs and blog pages. No authenticated tests, no purchases, no codebase edits. The `apply_patch` tool was not in this session's toolset, so this file was written with the write tool.

**Verdict: PARTIAL.** Platform features (access, labels, compare, download, restore) are confirmed on primary docs. Retention duration for premium full history, downgrade purge, and Commons/Server Pro retention remain UNRESOLVED. The harvest's learn-article citation could not be verified.

## Platform features (confirmed)

- **Access.** The History icon sits above the preview panel; "All history" and "Labels" are the two views; "Back to editor" exits. Source: https://docs.overleaf.com/writing-and-editing/history-and-versioning.md, "How to access a project's history" and "How to return to editing mode".
- **Labels.** Label via three-dot menu, "Label this version", "Add label". Multiple labels per version are allowed (hint: "attach multiple labels"). The current version is shown as "Current state". Source: same page, "Labeling a project version". No tier restriction is stated on this page.
- **Compare.** Align Start / Align End / Align Space Even icons compare up to, from, or across versions. Source: same page, "Comparing versions".
- **Download.** Three-dot menu, "Download this version", yields a .zip. Source: same page, "Downloading an older version of your project".
- **Restore one file.** Restores the file's content plus its comments and tracked changes at that time. Source: same page, "How to restore a single file to a previous version".
- **Recover deleted files.** Deleted files appear struck through in the version where they were deleted. Source: same page, "Recovering deleted files".
- **Restore whole project.** "Restore project to this version", including comments and tracked changes. Source: same page, "Restoring an earlier version of the project".
- **Copies start fresh.** A copied project does not inherit the original's history. Source: same page, "What happens to the history if you copy a project?".
- **Restore comment limits (blog, date not visible in fetched text).** Resolved comments can be restored; deleted comments cannot; unresolved threads keep history up to the latest version. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes, "What else should I know?". The harvest's Dec 11, 2024 date is not verified.

## Tier and retention windows

- **Free (documented).** History panel shows edits from the last 24 hours plus labeled versions. Source: history-and-versioning page, success hint "Using the full History feature". Also https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md, "Full document history and versioning" ("only 24 hours of history availability on a free Overleaf account").
- **Premium: Full Project History (documented).** Entire project history. This is a premium feature; it is project-level and based on the project owner's subscription, so collaborators on a premium-owned project use it without paying. Source: premium-features page, "Account and project level features".
- **Restore older than 24h (documented).** Requires the "Full document history" premium feature; anyone with edit access can restore within the last 24 hours. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes, "Who can use it?".
- **Plan names.** The premium-features comparison table lists Free, Student, Standard, Pro, and Personal (no longer offered). Pro and Student are named in the blog context. Group and organization plans are harvest-reported only; not verified here.
- **Downgrade (documented, partial).** Full project history "will no longer be available" after downgrade; projects are not deleted. Source: premium-features page, "What happens to my projects if I downgrade to the Overleaf free plan?". The page does not say whether stored history older than 24 hours is purged. UNRESOLVED.
- **Free label creation.** The docs show labeled versions on free but do not explicitly state that free users can create labels. UNRESOLVED.
- **Retention duration (premium).** No primary page found states how long full history is kept. One search returned no primary answer. UNRESOLVED.

## Community Edition and Server Pro (on-premises, dated 3.5.13 era)

- **Default for new projects.** After upgrading to CE 3.5.13, new projects use Full Project History by default; existing projects stay on the legacy system until migrated. Source: https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x/full-project-history-migration.md, intro.
- **Improvements listed.** Binary-file tracking, labeled versions, and robustness. Same page, intro.
- **Downgrade is backup-based.** Downgrading below 3.5.13 requires restoring a full system backup. Same page, info hint.
- **Legacy cleanup.** Before Server Pro 3.5.13, the cleanup script deletes `docHistory` and `docHistoryIndex` content; this is legacy cleanup, not a retention policy. Same page, "Clean up legacy history data".
- **Storage.** A GitHub wiki search snippet says the filesystem stores full project history data. Not opened; snippet-level only. Source: https://github.com/overleaf/overleaf/wiki/Data-and-Backups, "Data Storage". No retention duration is stated in what was seen.
- **Retention on CE or Server Pro.** UNRESOLVED.

## Legacy and superseded

- **"Pro users have access to full history" (undated blog).** https://www.overleaf.com/blog/157-save-to-dropbox-and-create-protected-projects-on-pro, "Full history service". Legacy; superseded by the docs above.
- **Overleaf V1 only.** https://www.overleaf.com/learn/how-to/What_is_the_full_history_service%3F states it covers V1 only. Not used for current claims.

## Corrections to the upstream harvest

- The harvest cited a learn article as its source for the 24-hour and premium split. The learn URL returned the docs history page in two fetches, so it cannot be cited. The docs page and the premium-features page support the same split, so the claim stands on those.
- The harvest's `history-and-labels` URL path does not exist (404; the docs page is `history-and-versioning`).
- The harvest's Dec 11, 2024 blog date is not visible in the fetched text. Treat it as unverified.

## Not in scope

- The July 2, 2026 AI bundling blog was not opened. History is not documented as AI-gated in the pages read, so no AI claims are made here.

## Counter-search queries

- "Overleaf full project history retention duration"
- "Overleaf downgrade full history purged"
- "Overleaf learn Using_the_History_feature"
- "Overleaf Commons project history retention"
- "Overleaf Server Pro project history retention setting"

## EXPAND

- LEAD: Find an official statement of premium full-history retention duration and downgrade purge behavior. Two searches found no primary source. Still open.
- LEAD: Verify https://www.overleaf.com/learn/latex/Using_the_History_feature directly. Two fetches returned the docs page instead. Still open.
- LEAD: Check Commons and Server Pro for history retention settings in the on-premises configuration docs. Not opened. Still open.
- None for the July 2, 2026 AI bundling blog: out of this angle.
