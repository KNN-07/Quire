# Overleaf angle 46: AI Assistant, TeXGPT, and project-aware chat

Research date: October 26, 2026. Public Overleaf documentation and product announcements only. No authenticated testing or purchase was performed; this report describes documented features, not verified execution.

## AI Assistant and project context

Overleaf’s [AI assistant documentation](https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant) (“Chatting with your document”; “AI allowance”; “Data and privacy”) describes a chat panel in the editor for questions and instructions. It is aware of cursor position and selected text, focuses responses on a selection, and can search other parts of the project when needed. Examples include explaining an equation, suggesting a section title, and fixing selected-paragraph grammar. The page says conversation history is not stored between sessions and each new session starts fresh; each message exchange consumes one daily AI use. The assistant sends necessary project content to OpenAI and may query third-party search engines; Overleaf says user data is not used to train AI models.

The assistant can return proposed changes, but its documentation does not promise that generated content is correct or compiles. The broader [AI features documentation](https://docs.overleaf.com/integrations-and-add-ons/ai-features) (“Troubleshooting”) explicitly cautions that AI may misinterpret complex or custom LaTeX and recommends reviewing suggestions. Treat this as an editor-integrated writing aid, not a TeX engine, proof checker, or guarantee of semantic correctness. Nothing in these sources establishes that ordinary chat can reliably understand every file, package, generated artifact, or external dependency in a project; scope of project search beyond “other parts of your project” is **UNRESOLVED**.

## TeXGPT and concrete tools

The current [AI features documentation](https://docs.overleaf.com/integrations-and-add-ons/ai-features) (“What’s included”; “Where to find AI tools”) distinguishes TeXGPT from chat: it generates LaTeX code from natural language and is accessible from a dedicated button at the far left of the main toolbar. The same page lists equation generation from an image or natural language, table generation from an image or natural language, and title/abstract generation based on the document. It places generators in Insert or via TeXGPT when nothing is selected, and rewrite actions in the AI action menu or floating selection menu. This is functionality Overleaf supplies in its editor; it does not mean arbitrary LaTeX source can be executed or that all packages/macros are understood.

The [AI assistant documentation](https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant) (“Citation reviewer”) documents a specific citation workflow: “Scan for unsupported statements” highlights passages, offers publications sourced from Dimensions, and can add a selected citation to the document and bibliography. It warns that citation requests typed into ordinary chat use an LLM and are not thereby verified against authoritative sources. Citation suggestions from the dedicated scan and free-form chat claims therefore have different evidence guarantees.

## Availability, limits, and historical discrepancy

Current documentation’s plan table ([AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features), “AI allowance by plan”) lists Free: Basic allowance, no AI Assistant; Student: Basic, included; Standard: Standard, included; Pro: Max, fair use; Commons: Basic, no assistant; Commons AI: Max, included. Allowances reset every 24 hours; assistant exchanges and tool invocations count. The page says organization-managed accounts or institutions opting out cannot access AI features, and group administrators can disable them. It does not publish numeric quotas in this table.

Overleaf’s July 2, 2026 announcement, [“Overleaf AI now a part of Overleaf plans”](https://es.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans) (“What each plan includes”; “What’s new: Commons AI for institutions”), confirms AI is bundled in plans and distinguishes Commons from Commons AI. This supersedes older documentation framing AI Assist as a separately purchased add-on. **Legacy, date-sensitive:** the older [AI Assist guide](https://es.overleaf.com/learn/how-to/AI_Assist) (“What is AI Assist?”; “Need to purchase AI Assist?”) describes a paid add-on for unlimited access across Overleaf and Writefull, while free use was limited. Do not combine that older purchase model with the July 2026 plan packaging as if both were current. Current docs still use “premium plans” language for higher allowances; exact present-day commercial purchase mechanics are **UNRESOLVED** here.

The sources describe the hosted Overleaf editor. They do not document availability for Community Edition or Server Pro; self-hosted availability is **UNRESOLVED**. No claim is made that these features perform compilation or any functional execution.

## EXPAND

- **LEAD — Self-hosted editions:** Current official material reviewed does not say whether AI Assistant or TeXGPT is available in Community Edition or Server Pro; reason: consulted sources describe hosted plans and give no deployment matrix.
- **LEAD — Chat project-search boundary:** The assistant may search other project content, but indexing rules, file-type coverage, and completeness guarantees are undocumented in the reviewed page.
- **LEAD — Current numeric quotas and purchase flow:** Current plan table gives allowance tiers, not numeric limits or full purchase terms; the July 2026 post likewise uses qualitative tiers.
