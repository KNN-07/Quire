# Overleaf angle 50: AI consent, controls, quotas, and subscriptions (expansion)

Scope: AI consent, controls, quotas, and current versus legacy subscriptions. Sources were opened as primary pages in this session (retrieved October 2026). No authenticated tests, purchases, or codebase changes were made. Labels: **[Free]**, **[Paid]**, **[AI]**, **[Commons]**, **[Server Pro]**, **[CE]**.

## 1. Current quotas and plan entitlements

- **Current model (July 2026):** Overleaf AI is included in all plans at no extra cost, with allowances varying by plan. Commons is Basic with no AI Assistant; Commons AI is Max (fair use) with the Assistant. Source: Overleaf blog, "Overleaf AI now a part of Overleaf plans," July 2, 2026, headings "What each plan includes" and "What's new: Commons AI" (https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans).
- **Numeric quotas:** The plans page states **Basic = 5 AI uses/day** (Free and Student), **Standard = 10 uses/day**, and **Pro = Max, "fair usage applies."** The "Compare all features" table also says the limit "resets every day." Source: https://www.overleaf.com/user/subscription/plans, "Compare all features," row "AI allowance."
- **Correction to the harvest:** the harvest said Basic and Standard tiers are unquantified. The plans page does quantify them (5 and 10). The AI docs' table still uses tier names only (https://docs.overleaf.com/integrations-and-add-ons/ai-features, heading "AI allowance by plan").
- **What counts:** each Error Assist suggestion, each Assistant message exchange, and each language or generator invocation (including accepting a suggestion) counts as one use. The allowance resets every 24 hours, and upgrading resets to the new tier immediately (same doc, "AI allowance by plan").
- **No guarantee:** the Terms say Services may be subject to usage limits, that "fair usage" means no fixed limit but fair-use principles still apply, and that Overleaf may stop or modify Services at any time (https://www.overleaf.com/legal, sections "Usage Limits" and "Our Rights"). Do not infer a fixed Max quota.
- **Assistant availability:** included on Student, Standard, Pro, and Commons AI; not on Free or Commons (https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant, "Opening the AI assistant").
- **Assistant wording conflict (unresolved):** the current AI assistant page still calls the Assistant "a component of the AI Assist add-on." This conflicts with the July 2026 bundling announcement. I did not combine them; the blog is the newer statement.

## 2. Consent and data handling

- **Consent is separate from enabling AI.** You enable AI in Account Settings. You are asked to accept AI terms the first time a feature sends content to external processing; one acceptance covers all AI features (AI features doc, "Data and privacy").
- **What is sent:** Error Assist sends the error message, relevant code lines, and project file names. The Assistant sends needed project content and may query third-party search engines. Rewrite and language tools send selected or surrounding text. Citation suggestions use Dimensions (same heading).
- **Citation caveat:** only the "Scan for unsupported statements" tool is Dimensions-backed; chat-typed citation requests use an LLM and are not verified (AI assistant doc, "Citation reviewer").
- **Training:** the docs say data is not used to train AI models (AI features doc). The Terms say inputs and outputs are not used to train or develop models except as part of the service for your exclusive benefit without consent, and that LLM providers are not authorized to train on your data (https://www.overleaf.com/legal, "Overleaf AI"). Outputs are provided "AS-IS" and users are responsible for checking them.
- **Writefull:** the Terms say Writefull for Overleaf is an Overleaf AI Tool under these Terms, with a separate affiliate product that has its own terms (same "Overleaf AI" section).

## 3. Controls

- **Individual:** Account Settings > Integrations > "Disable AI features" turns off all editor AI, including Error Assist and language suggestions (AI features doc, "Enabling and disabling AI features"). Editor-level toggles for shortcuts, sentence completion, and the floating menu are in the Settings modal (same doc, "AI settings").
- **Group admin:** AI is enabled by default for non-managed groups and disabled by default for Pro groups with Managed Users. The toggle applies to all members; per-user blocking is not supported. Members are emailed on change, and changes appear in the audit log (https://docs.overleaf.com/groups/user-management/controlling-feature-availability, "How to enable or disable AI features" and FAQs).
- **Cross-project rule:** AI access follows the user's own account settings, not the project owner's (same page, "How AI access works across organizations"; also https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts, "AI features and managed accounts").
- **Managed accounts [Paid]:** AI is unavailable unless the administrator enables it (managed accounts page).
- **Global controls:** the plans comparison lists "AI usage" global control as "Via Support" for Standard, Pro, and Organizations, and not included for Free or Student (plans page, "Global feature controls"). This is a support-mediated control. The self-service toggle described above is the documented admin path.

## 4. Commons and institutions [Commons]

- Commons AI access is Basic with no Assistant under the current Commons docs (https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription, "AI features with Commons access").
- **Gap:** that Commons docs page does not mention Commons AI. Commons AI is documented only in the July 2026 blog. Treat it as announced, not yet documented in the help center.
- If an institution disables AI, users cannot use AI tools on Overleaf (same Commons page).

## 5. Legacy and superseded information (date-tagged)

- **[Legacy, undated crawl]** The FAQ at https://www.overleaf.com/about/ai-features says free-tier quotas can reset "up to 72 hours" and that users must buy a plan or wait. This conflicts with the current 24-hour reset. Do not use the 72-hour figure as current.
- **[Superseded]** The current docs say "Summarize and Explain" was removed and the Writefull toolbar was removed; their tools moved to the main toolbar, Insert menu, and AI action menu (AI features doc, "Troubleshooting").
- **[Legacy, unverified]** The harvest cited an "AI Assist" docs page (separate add-on, Writefull premium retention, separate per-tool quotas). I tried https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assist and it returns "Page Not Found." Those claims are **UNRESOLVED** in this session.

## 6. Self-hosted

- Server Pro and Pro plans are separately licensed. A hosted Pro subscription does not license Server Pro (https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition, hint).
- The Server Pro vs. Community Edition feature table lists no AI row, so it does not establish whether hosted AI, consent, or quotas exist in either self-hosted edition. **UNRESOLVED.**

## EXPAND

- **LEAD: Self-hosted AI availability (Server Pro / CE):** UNRESOLVED. The comparison page has no AI row, and the plans page says "On-premises option (optional)" only for Organizations. Do not assume parity.
- **LEAD: Legacy AI Assist add-on, Writefull premium retention, and per-tool quotas:** UNRESOLVED. The cited legacy page returns 404 now and no other primary page was found.
- **LEAD: Commons AI in the help center:** UNRESOLVED as documentation; announced in the July 2026 blog only.
- **LEAD: Exact numeric allowance for Max and Standard quotas beyond the plans-page figures:** none found. Max is "fair use" with no published number.
- **Closed as duplicate:** Free/Student 5/day and Standard 10/day are confirmed by the plans page; the harvest's "unquantified" statement is corrected above. The "Writefull dropped/removed" and Summarize removal claims are confirmed as current deprecations.
