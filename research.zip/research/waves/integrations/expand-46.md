# Overleaf angle 46 expansion: AI Assistant, TeXGPT, project-aware chat

Research date: October 26, 2026. Sources are public Overleaf primary documentation and announcements. No authenticated testing or purchase was performed. This report describes documented functionality, not verified execution.

## AI Assistant and project-aware chat

Overleaf documents the AI Assistant as an editor side-panel chat where users can ask questions about their document or give instructions. It uses cursor position and selected text as context; selecting text focuses its response on that selection, and Overleaf says it can search other project content when needed. Conversation history does not persist between sessions, and each message exchange consumes one daily AI allowance. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant, headings “Chatting with your document,” “AI allowance,” and “Data and privacy.”

The documented project-awareness claim is bounded: the assistant may search “other parts” of the project. File coverage, indexing, whether every project file is consulted, and completeness or correctness guarantees are not specified. Necessary project content is sent to OpenAI, and the assistant may query third-party search engines; the docs say data is not used to train AI models. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant, “Contextual help” (current docs label the section “Chatting with your document”) and “Data and privacy”; broader processing disclosure at https://docs.overleaf.com/integrations-and-add-ons/ai-features, “Data and privacy.”

AI Assistant is an Overleaf-hosted editor feature, not a promise that arbitrary LaTeX is executed, compiled, or semantically validated by chat. Overleaf warns that AI suggestions may misinterpret complex or custom LaTeX and should be reviewed. Citation Reviewer is a separate specialized workflow: its “Scan for unsupported statements” recommendations come from Dimensions and can be inserted into the document and bibliography; free-form chat citation requests use an LLM and are not guaranteed to be verified against authoritative sources. Sources: https://docs.overleaf.com/integrations-and-add-ons/ai-features, “Troubleshooting”; https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant, “Citation reviewer.”

## TeXGPT and adjacent editor tools

Current AI feature docs describe TeXGPT as generating LaTeX code from natural-language instructions inside the editor. The dedicated TeXGPT button is on the main toolbar; generators also appear in Insert, while rewrite tools are available through the AI action menu and selected-text floating menu. Overleaf lists separate equation and table generators (from text or images), and title/abstract tools. Sources: https://docs.overleaf.com/integrations-and-add-ons/ai-features, “What’s included” and “Where to find AI tools”; https://www.overleaf.com/about/ai-features, “LaTeX AI code and writing assistance from TeXGPT.”

These are generated source-writing aids; the product descriptions do not guarantee valid code for every package, macro, or project setup, nor successful compilation. Do not equate code generation with TeX execution. Overleaf’s general warning about complex/custom LaTeX applies. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features, “Troubleshooting.”

## Availability and dated packaging

As of this research date, the live documentation plan table lists Free: Basic allowance, no AI Assistant; Student: Basic, included; Standard: Standard, included; Pro: Max (fair use), included; Commons: Basic, no Assistant; Commons AI: Max (fair use), included. Each AI action counts as one daily use; allowance resets every 24 hours. Organization-managed accounts/institutions that opt out may not access AI, and group administrators can disable it. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features, “AI allowance by plan” and “Who can use Overleaf AI.”

The July 2, 2026 announcement says Overleaf AI is bundled in plans at no extra cost and introduces Commons AI; its tier descriptions align with the current docs. Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans, “What each plan includes” and “What’s new: Commons AI for institutions.”

**Legacy, date-tagged:** older AI Assist pages describe a separately purchasable add-on and unlimited use. That model predates the July 2, 2026 plan-bundling announcement; it should not be silently combined with current packaging. Legacy source: https://es.overleaf.com/learn/how-to/AI_Assist, “What is AI Assist?” and “Need to purchase AI Assist?” No reviewed primary source documents AI Assistant/TeXGPT availability for Community Edition or Server Pro; make no self-hosted deployment claim. These are hosted product features in the reviewed material.

## EXPAND

- **LEAD — Self-hosted editions: CLOSED as unresolved.** Current official docs and plan announcement describe hosted accounts/plans, with no Community Edition or Server Pro deployment matrix.
- **LEAD — Project-search boundaries: CLOSED as unresolved.** Docs establish cursor/selection context and possible searching elsewhere in the project, but no file-type, indexing, or completeness guarantees.
- **LEAD — Numeric quotas and purchase details: CLOSED as unresolved.** Current docs and July 2026 announcement specify qualitative tiers and fair-use language, not numeric quotas or all purchase terms.
- No additional official product evidence located in this angle establishes TeXGPT/chat functional execution or compilation guarantees; these are not claimed.
