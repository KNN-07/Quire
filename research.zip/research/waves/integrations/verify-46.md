# Verify 46: AI Assistant, TeXGPT, and project-aware chat

Research date: October 26, 2026. **Verdict: PARTIAL**: core capabilities and hosted plan entitlements are confirmed; current official pages contain conflicting commercial and managed-account wording. Both `harvest-46.md` and `expand-46.md` were read. Public documentation only; no authenticated tests, purchases, or functional execution.

## Primary sources

- **A:** https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — “Opening the AI assistant,” “Chatting with your document,” “Citation reviewer,” “AI allowance,” “Data and privacy.”
- **B:** https://docs.overleaf.com/integrations-and-add-ons/ai-features — “What's included,” “AI allowance by plan,” “Where to find AI tools,” “Who can use Overleaf AI,” “Troubleshooting.”
- **C:** https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — dated July 2, 2026; “What each plan includes,” “What's new: Commons AI for institutions.”
- **D:** https://www.overleaf.com/about/ai-features — “LaTeX AI code and writing assistance from TeXGPT.”
- **E:** https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts — “AI features and managed accounts.”
- **F:** https://docs.overleaf.com/groups/user-management/controlling-feature-availability — “AI features,” “How AI access works across organizations,” opening feature/default-behaviour table.

## Claim table

Source letters resolve to the exact URLs above; evidence descriptions identify the relevant sections.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Editor-side chat accepts questions/instructions, uses cursor and selection context, and can search other project content when needed. | A, “Chatting with your document” | Student, Standard, Pro; Commons AI confirmed by B/C | CONFIRMED; not exhaustive project indexing. |
| Conversation history does not persist between sessions; each exchange consumes one use. | A, “AI allowance” | Assistant-entitled accounts | CONFIRMED; session semantics not further defined. |
| Project content goes to OpenAI; search-engine queries may occur; docs say no model training on user data. | A, “Data and privacy” | Assistant use | CONFIRMED policy description, not a local-only feature. |
| Citation Reviewer's dedicated scan highlights unsupported passages, retrieves Dimensions papers, and inserts selected citations into document/bibliography. Ordinary chat citation requests are not authoritatively verified. | A, “Citation reviewer” | Assistant workflow | CONFIRMED distinction; no guarantee every claim is detected. |
| TeXGPT generates LaTeX from natural language; its dedicated button precedes undo/redo. Generators also appear in Insert. | B, “What's included”; “Where to find AI tools” | AI allowance; Free has limited tools, not Assistant | CONFIRMED; no separate numeric TeXGPT quota documented. |
| TeXGPT offers figures/code, outlines, examples, skeleton documents, feedback, explanations, and formatting updates. | D, TeXGPT heading | Overleaf AI | CONFIRMED advertised capabilities; not execution guarantees. |
| Equation/table generators accept images or language; title/abstract tools use document context. | B, “What's included” | AI allowance | CONFIRMED adjacent tools, not arbitrary TeX capabilities. |
| Free/Commons: Basic, no Assistant; Student: Basic with Assistant; Standard: Standard with Assistant; Pro/Commons AI: Max with Assistant, fair use. | C, plan/institution sections; B, plan table | Hosted plans | CONFIRMED; “AI included” does not mean Assistant on Free. |
| Daily allowance resets every 24 hours; numeric Basic/Standard quotas are not supplied. | B, “AI allowance by plan” | Eligible AI users | DOCUMENTED, but D's “What are the fair use limits?” still says up to 72 hours; inconsistency unresolved. |
| Managed users can use AI if administrators enable it; organization disablement can also block outside collaborators on its projects. | E, managed-account section; F, access scenarios | Group plans; managed Pro disabled by default | CORRECTION to upstream blanket managed-account exclusion. |
| Community Edition/Server Pro include these official tools. | No supporting deployment source found | Self-hosted | UNRESOLVED; do not transfer hosted entitlements. |

## Contradictions and boundaries

**Packaging:** C bundles AI at no extra cost from July 2, 2026. A retains “add-on” terminology despite listing current plans. The discrepancy remains live. Legacy URL https://es.overleaf.com/learn/how-to/AI_Assist now redirects to B; older add-on claims in upstream reports cannot establish current purchasing terms. Existing subscription migration and external Writefull rights remain UNRESOLVED.

**Managed accounts:** B's “Who can use” blanket exclusion conflicts with E/F's explicit administrator-enablement instructions. Prefer the detailed operational guidance for describing documented controls, while retaining the conflict.

**Deprecated interface:** B's “Troubleshooting” says the Writefull toolbar was removed and dedicated Summarize/Explain actions are no longer available. D's broader explanation capability must not be read as preserving those removed buttons.

**Bounds:** B warns custom/complex LaTeX can be misinterpreted. Code generation is a platform writing feature, not proof of compilation or correctness. A supplies no file-type, indexing, or whole-project completeness guarantee.

**Privacy wording:** C's “A note on data and AI principles” qualifies its no-training statement with “without explicit consent”; A/B state it categorically. Preserve that qualification rather than infer an absolute contractual guarantee.

## Counter-search queries

- `site:docs.overleaf.com "AI assistant"`
- `site:overleaf.com/blog "overleaf-ai-now-a-part-of-overleaf-plans"`
- `site:docs.overleaf.com "TeXGPT" "deprecated"`
- `site:docs.overleaf.com/on-premises "AI"`
- `site:docs.overleaf.com "Server Pro" "Writefull"`
- `site:github.com/overleaf/overleaf "TeXGPT"`

Opened primary pages rather than relying on older search snapshots. Self-hosted searches did not establish an official deployment entitlement.

## EXPAND

- **LEAD — Self-hosted deployment:** UNRESOLVED; need an explicit official Community Edition/Server Pro feature matrix.
- **LEAD — Search coverage:** UNRESOLVED; no documented file coverage or completeness contract.
- **LEAD — Commercial transition:** UNRESOLVED; reconcile residual add-on wording, existing subscriptions, and external Writefull rights.
- **LEAD — Documentation consistency:** UNRESOLVED; blanket managed-account exclusion conflicts with administrator enablement; 24-hour versus up-to-72-hour resets conflict; no numeric Basic/Standard quotas published in reviewed sources.
