# Overleaf harvest 48: AI tables, equations, and image input

Research checked October 26, 2026. Public official Overleaf documentation and product posts only; no authenticated product use, execution test, or purchase was performed.

## Table generation

Overleaf's current [AI Table Generator](https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables/ai-table-generator), heading **AI Table Generator**, accepts either a natural-language table specification or an uploaded table image. The docs describe image input as a screenshot, including a spreadsheet or an existing article. The workflow is editor toolbar table icon → prompt or drag/drop image → Generate → review generated LaTeX → Insert; Regenerate is available to refine output. The docs do not promise exact transcription, layout fidelity, supported image formats, or successful compilation, so those are unresolved rather than guaranteed features.

The page says uploaded prompts, images, and text are sent to the OpenAI GPT API, while Overleaf says it does not store them or use them to train language models; it also states OpenAI API data is not used for model training. See the same page's introductory privacy note. Do not generalize that data-flow statement to all other AI features.

## Equation generation and image input

The current [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features), headings **What AI features are available in Overleaf?** and **Where to find AI tools**, describes the Equation Generator as converting plain English into LaTeX math code and locates generators in the editor's Insert menu; the feature table specifically says equation generation accepts an image or natural language and produces LaTeX math. This supports image-to-equation input as a documented capability, but the separate operational instructions for image upload, accepted formats, output review/insertion mechanics, or accuracy are **UNRESOLVED** in the public material reviewed. The official [Overleaf Status incident](https://status.overleaf.com/incidents/2fdvdyap) from August 27, 2026 also names “Insert math from text or image” as an in-editor AI feature; it records a resolved partial outage, not an availability guarantee.

## Availability and limits

The official July 2, 2026 [Overleaf AI plan update](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans), headings **How Overleaf AI works**, **What each plan includes**, and **What's new: Commons AI for institutions**, supersedes older add-on descriptions for present plan packaging: Free has Basic allowance but no AI Assistant; Student has Basic allowance and the Assistant; Standard has a higher allowance and Assistant; Pro has Max allowance subject to fair use; Commons has Basic without Assistant; Commons AI has Max allowance (fair use) and Assistant. The current [AI features plan table](https://docs.overleaf.com/integrations-and-add-ons/ai-features), heading **AI allowance by plan**, says each AI-feature invocation counts against a daily allowance that resets every 24 hours. Thus table/equation generators can be tried on eligible plans within limits; exact numeric quotas are not published on that page. Institutional administrators may disable AI, and organization-managed or opted-out accounts cannot access it (same docs, **Who can use Overleaf AI**).

Legacy distinction: older AI Assist docs describe AI Assist as a separately purchased add-on for unlimited generator use (for example, [AI Table Generator](https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables/ai-table-generator), older version indexed with “buying the AI Assist add-on”; [AI features](https://docs.overleaf.com/integrations-and-add-ons/ai-features), older version). The July 2, 2026 plan update documents the newer bundled-by-plan model. Current docs retain some older add-on wording, so do not treat the legacy purchase claim as the complete current plan model.

## Platform feature versus LaTeX

AI generation is an editor convenience producing source code, not a special LaTeX language capability. Independently, Overleaf supports ordinary LaTeX table authoring and insertion; its [table guide](https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables), heading **Generating and inserting tables**, distinguishes AI generation from visual insertion and direct LaTeX code, noting direct code offers the most flexibility and complex formatting may require code. Likewise, [Mathematical expressions](https://www.overleaf.com/learn/latex/Mathematical_expressions), headings **Display math mode** and **Reference guide**, documents standard inline/display math environments and LaTeX symbols independently of AI. For ordinary document figures, [Inserting images](https://docs.overleaf.com/writing-and-editing/inserting-images), heading **Simpler ways to add images**, documents upload, paste, drag/drop, and Insert Figure. That is distinct from supplying an image as AI input.

## EXPAND

- LEAD: Find a current official step-by-step Equation Generator page confirming image upload UI, supported image formats, and result review/insertion; the current feature overview confirms image input but operational specifics remain undocumented in reviewed sources.
- LEAD: Determine exact numeric generator quotas by plan; current official plan table gives allowance tiers and reset timing only, not counts.
- LEAD: Verify whether official deployment documentation distinguishes Community Edition or Server Pro availability for these AI generators; reviewed public pages do not document either edition's availability, so no deployment claim is made.
