# Angle 49 verification: Writefull and Citation Reviewer

Date: October 26, 2026. **Verdict: PARTIAL**: core capabilities and cloud-plan access are confirmed; Translate details, legacy entitlement migration, and on-premises availability remain unresolved. Both `harvest-49.md` and `expand-49.md` were read. Public documentation only; no functional execution, authenticated tests, or purchases.

## Primary evidence key

- **A:** https://docs.overleaf.com/integrations-and-add-ons/ai-features — “What's included,” “AI allowance by plan,” “Where to find AI tools,” “Troubleshooting.”
- **B:** https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — “Citation reviewer,” “AI allowance,” opening description.
- **C:** https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — July 2, 2026; “What each plan includes,” “What's new: Commons AI,” “How Overleaf AI works.”
- **D:** https://help.writefull.com/writefull-for-overleaf--user-guide — “Writing features AI: Writefull or third-party services,” “Upgrading to Premium,” “I already have both Writefull and Error Assist.”
- **E:** https://www.overleaf.com/blog/update-writefull-is-now-integrated-with-overleaf-no-extension-needed — May 10, 2023, updated March 12, 2024; “What's included in Writefull?”
- **F:** https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — opening licensing distinction and feature tables.
- **G:** https://docs.overleaf.com/integrations-and-add-ons/ai-features/writefull — currently returns “Page Not Found.”

Source letters below resolve to these exact URLs; section names identify the relevant evidence.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Grammar/fluency suggestions; Paraphrase, Make concise, Make scientific, Split, Join; document-based title/abstract drafts; contextual Synonyms. | A, “What's included” | Cloud AI allowances | CONFIRMED |
| Suggestions are inline; generators use Insert; rewrite selection menus filter actions by selection length. Standalone Writefull toolbar is removed. | A, “Where to find AI tools,” “Troubleshooting” | Cloud editor | CONFIRMED |
| Summarize/Explain are removed despite the introductory inventory retaining them. Translate is named in the menu list but lacks behavior/language details. | A, same sections | Removed / unspecified | CONTRADICTION resolved toward explicit removal; Translate UNRESOLVED |
| Citation Reviewer starts a new assistant chat with “Scan for unsupported statements,” highlights passages, and exposes Dimensions papers through “View suggestions”; selecting a paper inserts the citation and bibliography entry. | B, “Citation reviewer” | Assistant-enabled plans | CONFIRMED |
| Ordinary typed citation-review prompts are LLM-based and not authoritative-source verified unless otherwise specified; the grounded skill is distinct. | B, warning under “Citation reviewer”; C, “How Overleaf AI works” | Chat versus skill | CONFIRMED |
| Free/Commons: Basic, no assistant. Student: Basic plus assistant. Standard: higher allowance plus assistant. Pro/Commons AI: Max, fair use, plus assistant. | C, plan sections; A, allowance table | Cloud plans | CONFIRMED; therefore Citation Reviewer is not established for Free/ordinary Commons |
| Invocations consume allowance; reset is every 24 hours. Administrators can restrict AI; account settings disable all AI. | A, allowance/control sections | Cloud AI | CONFIRMED; numeric quotas unspecified |
| Writefull-model edits and title/abstract generation use proprietary Writefull AI; paraphrasing/style/Split-Join use third-party services. | D, “Writing features AI” | Provider guide, not quota authority | CONFIRMED provider description |
| Server Pro and Community Edition inherit cloud AI entitlements. | F, licensing distinction; no affirmative capability entry | On-premises | UNRESOLVED; do not infer support or categorical absence |

## Corrections and limitations

July 2, 2026 bundling is explicit in C: AI is included without an additional charge, but features/allowances differ. B still calls the assistant part of an AI Assist add-on. D retains Premium upgrades and earlier Writefull/Error Assist consolidation wording. These are conflicting packaging descriptions, not proof that separate payment remains necessary for the cloud capabilities above. Existing Writefull subscription migration/refunds or cross-product entitlement mapping are **UNRESOLVED**.

Harvest's description of G as a live separate-premium page is no longer reproducible: G now reports missing. The old https://www.overleaf.com/learn/how-to/Writefull_integration redirects to A. E establishes historical limited language, paraphrase, title/abstract, and Sentence Palette access; it does not establish today's Sentence Palette availability.

D distinguishes proprietary processing from third-party processing; do not promise that all Writefull tools keep text solely on Writefull servers. A warns that complex/custom LaTeX can be misinterpreted. C says training requires explicit consent, whereas A states no training categorically: retain the consent qualification rather than invent an unconditional guarantee.

These are platform assistance tools, not arbitrary LaTeX capabilities. No reviewed source guarantees semantic preservation, compilation correctness, exhaustive citation detection, or that every suggested paper supports the highlighted claim. Dimensions grounding establishes publication sourcing, not scientific validation (B/C).

## Counter-search queries

- `site:docs.overleaf.com "Translate" "AI"`
- `site:overleaf.com "Translate" "Writefull"`
- `site:overleaf.com "Writefull" "Premium" "2026"`
- `site:overleaf.com "Writefull" "Server Pro"`
- `site:docs.overleaf.com "Citation" "Server Pro"`
- `site:github.com/overleaf "Writefull"`
- `site:overleaf.com "Citation Reviewer" "Free"`

Opened primary pages, not search snippets, determine the findings.

## EXPAND

- **LEAD — Translate:** action name confirmed in A; exact behavior, supported languages, and specific entitlement unresolved.
- **LEAD — legacy subscriptions:** B/D conflict with C's newer bundling; account migration and cross-product benefits remain undocumented in reviewed sources.
- **LEAD — on-premises:** F separates licensing; obtain explicit current official deployment evidence before claiming these tools on Server Pro or Community Edition.
