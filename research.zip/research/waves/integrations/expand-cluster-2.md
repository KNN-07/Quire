# Integrations reconciliation: angles 41-50

As of October 26, 2026. Public-source research only; no account actions, runtime acceptance tests, compilation tests, or deployment tests. Read brief.md, lead-supplement.md, all ten verify files and their upstream EXPAND sections, and adjacent administration verifications 51, 53, 57 and 60. Directory enumeration confirmed every harvest/expand/verify file for 41-50 exists: no missing angle requires reconstruction.

Submitted official-domain counter-searches for self-hosted Zotero/AI, Git entitlement/SSO, Translate, Zotero limits and migration returned no readable search payload. Conclusions below rest on directly fetched live pages, not search absence. Raw HTML recovered the legacy PDF statement omitted by Markdown extraction and confirmed the July 2, 2026 announcement date.

## Corrected claim table

Source IDs resolve to exact official URLs and headings below.

| Angles | Corrected inventory claim | Availability / evidence |
|---|---|---|
| 41 | Git bridge supports clone/local editing/push/pull, translating Overleaf history rather than exposing a complete Git implementation. One linear branch; no LFS, tags or contained submodules. Other Git hosts require a local intermediary. | Hosted premium; Server Pro, not CE [S1-S5]. Deployment guide specifies 4.0.1; user guide's 4.0+ is less precise. |
| 41 | Tokens are the only Git authentication method; old password login is removed. Username is `git`; tokens expire after one year, maximum ten. | Cloud/Server Pro [S6]. Do not derive Cloud viewer push rights from premium entitlement wording. |
| 41 | Browser offline editing permits current-file edits for up to 2 minutes Free / 10 premium; file switching, compilation, comments and AI are unavailable. Reconnection can require saving conflicting edits as a new file. Recovery requires restoring the original tab and is not guaranteed. | Hosted [S7]; long offline work uses downloaded sources or premium integrations plus separate local software, not an offline Overleaf desktop application. |
| 42 | GitHub sync is manual, github.com-only, importing a repository into a new project or exporting a project into a new repository; not existing-to-existing. Owner links; other members can sync. Conflicts create an Overleaf-version branch for merging into default. | Hosted premium [S2,S8]. Explicit comparison excludes direct GitHub sync from both self-hosted editions [S1]. |
| 42 | Under 100 changed files/commit and 100 MB/project are recommendations, not quotas. Sync stops above 7 MB editable content. | [S8], not repository-independent success guarantees. |
| 42 | Word/DOCX and Markdown import; DOCX, Markdown and HTML export use Pandoc. Complex LaTeX/layouts can lose fidelity; source ZIP and PDF remain separate routes. | Feature documented [S9]; complete plan/self-hosted conversion matrix not established. |
| 43 | Dropbox is personal premium two-way sync through `Apps/Overleaf`. Direct editable shares qualify; read-only/link shares do not. Archiving stops inbound sync but edits in Overleaf may still go outward. Deletion/moves can remove contents or lose metadata. | Hosted premium; collaborators need their own access [S2,S10]. Both self-hosted editions explicitly excluded [S1]. |
| 43 | Current Dropbox guide says compiled outputs sync; the still-served older PDF page says they do not. Desktop ignore rules are local, prospective and individual-account-only. | Contradiction retained [S10-S12]; no claim that desktop rules prevent Overleaf server uploads. |
| 44-45 | Zotero, Mendeley and ReadCube offer refreshable read-only bulk `.bib` imports and editable individual citations through advanced search. Mendeley group items require bulk import. Manual `.bib` upload remains available without paid integration. | Hosted premium [S2,S13-S15]; named Zotero/Mendeley integrations explicitly absent in CE/Server Pro [S1]. |
| 44-45 | Account Library supports DOI/data entry and `.bib` upload; citing copies entries into project `.bib`. Library edits do not update existing project copies. Zotero Sync separately updates selected collections one-way into Library; it is not linked-project-file Refresh. | [S13,S16]; advanced search and Zotero integration premium. Full Library tier matrix unresolved. |
| 46,49 | Assistant uses cursor/selection and may search other project content; chat history does not persist across sessions. Citation Reviewer uses the dedicated unsupported-statements scan and Dimensions results, with selected citation/bibliography insertion. Ordinary citation chat is not equivalently source-grounded. | Assistant-enabled hosted tiers [S17-S19]; no exhaustive indexing or citation-validity guarantee. |
| 47 | Error Assist explains logged errors, proposes reviewable edits, applies suggestions and recompiles; Undo reverses edits. Typing-time code-check errors lack the full error required for Suggest fix. | Shared hosted AI allowance, including Free [S17,S20]; not autonomous guaranteed repair. |
| 48-49 | Image/prompt table and equation generation, language suggestions, rewrites, synonyms, TeXGPT and title/abstract generation are documented. Current tools use Insert/AI menus rather than the removed Writefull toolbar. Named Summarize/Explain actions are explicitly removed despite an introductory listing. | Hosted allowance-limited [S17,S21]. Translate is named but not sufficiently specified to claim languages or exact behavior. |
| 46-50 | AI bundled from July 2, 2026. Free/Student: 5 uses/day; Standard: 10; Pro: Max/fair use. Commons Basic equals Free; Commons AI Max. Assistant excluded Free/ordinary Commons, included Student/Standard/Pro/Commons AI. | Current pricing, parent docs and dated announcement agree [S17-S19]. No separate per-generator quotas or numeric Max ceiling asserted. |
| 46-50 | Detailed controls permit managed-account AI when enabled; organization disablement blocks members across projects and outside collaborators on affected projects. Parent page's blanket managed-account exclusion conflicts. Current allowance rule is 24 hours; marketing FAQ still says up to 72. | Preserve contradictions, prefer detailed controls/current allowance model [S17,S22-S24]. |
| 50 | External processing requires initial AI-terms acceptance. Feature-specific content may reach OpenAI; Assistant may query search engines. Legal/announcement wording qualifies no training with consent and service-specific conditions. | [S17-S20,S25]; no zero-retention or unconditional contractual guarantee. Hosted Pro is not a Server Pro license [S3]. |
| supplement | Google Drive is external-URL import/manual refresh, explicitly not native direct two-way sync. Labs remains experimental, not stable feature entitlement. | Drive independently reopened [S26]; Labs retained from lead supplement, not an authenticated experiment inventory. |

## Closure table

Every verifier EXPAND lead and additional upstream EXPAND issue is disposed below. UNRESOLVED is a terminal evidence status for this inventory, not a promise of later research.

| Input lead(s) | Disposition and concrete check |
|---|---|
| 41 Cloud role matrix / personal-versus-owner entitlement | **UNRESOLVED.** Reopened S2's Git tab: personal premium and premium-owned projects both confer access. Counter-search found owner-only troubleshooting in S4/S5. Neither supplies a consistent Cloud role matrix; do not promise viewer pushes or deny personal entitlement. |
| 41 Cloud Commons/Group SSO token restrictions | **UNRESOLVED.** Reopened general token guide S6 and searched `site:docs.overleaf.com Git tokens SSO`; results distinguish Server Pro SAML/LDAP permissions, not a hosted SSO-specific restriction. No restriction inferred. |
| 41 minimum patch; 42 deployment precision | **RESOLVED with qualification.** S1 explicitly excludes direct GitHub sync and CE Git; S3/S5 support Server Pro Git, deployment minimum 4.0.1. S4's 4.0+ heading remains imprecise; no evidence asserting 4.0.0 support. |
| 41 offline duration | **RESOLVED.** S7 explicitly supplies 2/10 minutes and recovery limits, agreeing with S2. |
| 41 local compilation parity / workflow | **OUT OF SCOPE / UNASSERTED.** S7 documents local-editor routes, not arbitrary engine/package parity. No exhaustive toolchain inventory required. |
| 41 GitHub/advanced-Git not reopened upstream | **RESOLVED.** Opened S4,S5,S8 directly here; intermediary remotes and linear-history boundaries confirmed. |
| 42 post-conflict recognition, cleanup and in-editor guarantees | **OUT OF SCOPE / UNASSERTED.** S8 ends with merging into default locally or through GitHub PR. Document that workflow; do not invent automatic cleanup or extra steps. |
| 42 exact API thresholds | **UNRESOLVED.** Reopened S8 file-limit section: recommendations and 7 MB cutoff, not an exact API quota. |
| 42 conversion entitlement/deployment | **UNRESOLVED.** S9 documents conversion but lacks a full entitlement matrix; missing labels establish neither Free exclusion nor self-hosted inclusion. |
| 43 PDF/version boundary | **UNRESOLVED contradiction.** S10 and S11 both reopened and disagree; neither dates a migration. Current instructions may be described as documentation, not universal tested behavior. |
| 43 ignore-rule efficacy | **RESOLVED boundary; stronger claim UNASSERTED.** Counterchecked Dropbox's own S12: remotely added matching files are suppressed on the computer; rules stay local. This does not establish server-upload prevention despite S10's wording. |
| 43 self-hosted Dropbox | **RESOLVED.** Explicit absent cells in S1, not silence in a tier table. |
| 44-45 current on-premises reference connectors/search | **RESOLVED for named Zotero/Mendeley connectors** by S1; **UNRESOLVED for Library, ReadCube and general advanced-search parity**, not separately enumerated there. Adjacent verify-57 supplies the overlooked comparison; outdated FAQ is unnecessary evidence. |
| 44 numeric Zotero cap / cadence | **UNRESOLVED.** S13's Choosing what to sync and Keeping your Library in sync provide an unspecified cap and next/manual sync, no numbers or schedule; targeted official search added none. |
| 44 retired Mendeley endpoints | **OUT OF SCOPE / UNASSERTED.** S14 still documents group imports; connector implementation dependencies are not specified. No product deprecation follows from generic provider API retirement. |
| 44 CiteULike 2018 post / incidental historical dates | **OUT OF SCOPE.** Verify-44 already recovered the historical post and corrected publication versus update dates. A historical integration list is not current functionality. |
| 44 ReadCube duplicate; 45 omitted Library/Citation Reviewer | **RESOLVED / DUPLICATE.** S15-S18 and supplement incorporated above; bulk, individual, Library-copy and grounded-scan mechanisms remain distinct. |
| 45 full Library plan matrix | **UNRESOLVED.** Reopened all S16, checked pricing S19: advanced search is premium, but no complete Library entitlement matrix. |
| 45 AI add-on wording / Commons AI omission / Free access | **RESOLVED current packaging, residual wording conflict.** S17 explicitly lists Commons AI and excludes Free/Commons Assistant; S18 dates bundling. S17-S19 outweigh S18a's add-on introduction. |
| 46-50 self-hosted AI, including Assistant/Error Assist/generators/Writefull | **UNRESOLVED; DUPLICATE consolidated.** Opened S3,S27 and searched official on-premises AI/Writefull. No explicit edition-specific AI entry found. General third-party row S1 does not specifically enumerate these tools; absence is not proven. |
| 46 search coverage; 47 autonomous repair | **OUT OF SCOPE / UNASSERTED.** S18a describes contextual search; S20 describes user-reviewed suggestions. No arbitrary file coverage, indexing completeness or guaranteed compile/repair contract. |
| 46 numeric quotas; 48 Commons number; 50 Commons AI help-center omission | **RESOLVED / DUPLICATE.** S19 gives 5/10; S17 explicitly says Commons Basic same as Free and lists Commons AI. Max remains fair use, not a missing-number research task. |
| 46-50 legacy subscription migration / external Writefull rights / refunds / per-tool legacy quotas | **UNRESOLVED; DUPLICATE consolidated.** Reopened S18,S21,S25 and searched official AI Assist migration. Legacy overlap/cancellation copy does not establish post-July-2026 migration, cross-product rights or separate current quotas. |
| 46,48 managed-account inconsistency; 50 organization precedence | **RESOLVED operational reading; contradiction retained.** S22/S23 explicitly allow admin enablement and any organizational disablement vetoes. S17's blanket exclusion/account-only language cannot support owner-independent access. |
| 46,50 reset inconsistency | **UNRESOLVED contradiction.** Live S17 says 24 hours; live S24 still says up to 72. Neither is an archived-only claim. |
| 48 equation upload compatibility / processing / operation | **RESOLVED basic mechanics**, provider S21 describes upload/generate/regenerate/insert, but obsolete toolbar navigation. **UNRESOLVED** current equation-specific processing detail. Arbitrary image type/size, handwriting/fidelity and compilation guarantees **OUT OF SCOPE / UNASSERTED** despite broad older provider language. |
| 49 Translate behavior/languages/entitlement | **UNRESOLVED.** S17 names Translate only in menu navigation; targeted official Translate/languages search added no operational specification. |
| All legacy redirects, speculative tier combinations and exhaustive package lists | **OUT OF SCOPE / UNASSERTED.** Current destination mechanisms are documented directly. No redirect archaeology, unsupported entitlement Cartesian product, or arbitrary LaTeX compatibility guarantee is needed. |

## Sources opened

- S1 https://www.overleaf.com/for/enterprises/features - Benefits for Users.
- S2 https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features - Account and project level features; Offline editing.
- S3 https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition - licensing note; Benefits for users.
- S4 https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration - Server Pro; Known limitations; Troubleshooting.
- S5 https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration - opening/configuration; plus https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/advanced-git-operations - Synchronizing with another remote.
- S6 https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/git-integration-authentication-tokens - Summary; Understanding tokens.
- S7 https://docs.overleaf.com/writing-and-editing/working-offline.md - How to work offline; Limitations; Recovering lost edits.
- S8 https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization - What is GitHub sync?; Resolving merge conflicts; file limits.
- S9 https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files - Importing; Exporting; conversion limitations.
- S10 https://docs.overleaf.com/integrations-and-add-ons/dropbox - eligibility; Avoiding conflicts on PDF and compiled output files.
- S11 https://www.overleaf.com/learn/how-to/Syncing_PDF_file_in_Dropbox - opening.
- S12 https://help.dropbox.com/sync/how-to-prevent-files-from-syncing - What to expect.
- S13 https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero - Zotero Sync; linked .bib.
- S14 https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley - Import Mendeley library or group.
- S15 https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md - adding references; Updating project .bib files.
- S16 https://docs.overleaf.com/citing-and-references/library - Using the Library in projects; Managing your Library; FAQs.
- S17 https://docs.overleaf.com/integrations-and-add-ons/ai-features - allowance; tools; settings; Troubleshooting.
- S18 https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans - July 2, 2026; plan/Commons AI sections.
- S18a https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant - opening; Chatting; Citation reviewer; Data and privacy.
- S19 https://www.overleaf.com/user/subscription/plans - plan cards; Compare all features.
- S20 https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist - Using Error Assist; Troubleshooting.
- S21 https://help.writefull.com/writefull-for-overleaf--user-guide - Equation/Table Generator; subscription overlap.
- S22 https://docs.overleaf.com/groups/user-management/controlling-feature-availability - AI features; How AI access works across organizations.
- S23 https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts - AI features and managed accounts.
- S24 https://www.overleaf.com/about/ai-features - What are the fair use limits?
- S25 https://www.overleaf.com/legal - Overleaf AI; Usage Limits; Terms modified May 5, 2026.
- S26 https://docs.overleaf.com/integrations-and-add-ons/google-drive - opening/manual refresh.
- S27 https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration - configuration index.

## EXPAND

None. All inherited leads are resolved, duplicate, out of scope/unasserted, or explicitly unresolved after concrete official-source checks. No genuinely new actionable lead requires another research wave.
