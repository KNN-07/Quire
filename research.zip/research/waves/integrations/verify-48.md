# Verify 48: AI table/equation generation and image input

Checked October 26, 2026. **Verdict: PARTIAL**: core hosted capabilities and current plan allowances are confirmed; image compatibility, deployment availability, and conflicting access documentation remain bounded below. Both `harvest-48.md` and `expand-48.md` were read. Public documentation research only: no authenticated generation, compilation, purchase, or functional execution.

## Claim table

Source identifiers resolve to exact primary URLs and headings below.

| Claim | Source | Availability | Evidence status |
| --- | --- | --- | --- |
| Both generators accept an image or natural-language request and produce LaTeX tables/math. | S1, What's included | Hosted AI; Free and paid allowances | CONFIRMED |
| Table workflow: toolbar table icon; prompt or drag/drop image; Generate; Insert into source; Regenerate. Spreadsheet/article screenshots are examples. | S2, AI Table Generator steps | Free daily allowance; Standard/Pro increase allowance | CONFIRMED; not an accuracy guarantee |
| Current generator entry points are Insert or TeXGPT with nothing selected; the Writefull toolbar was removed. | S1, Where to find AI tools; Troubleshooting | Hosted editor | CONFIRMED; prefer this navigation over older guides |
| Equation drag/drop, Generate, regeneration, and insertion are documented by Writefull. | S3, Equation Generator | Writefull for Overleaf; current navigation differs | CONFIRMED as provider documentation, not live UI validation |
| Writefull says both image inputs have no file-type/size limitations. | S3, Table Generator; Equation Generator | Older-toolbar guide | QUALIFIED: explicit claim exists, but current Overleaf docs do not repeat it; present compatibility guarantees UNRESOLVED |
| Free/Student have 5 shared AI uses/day; Standard 10; Pro Max/fair use. Each invocation consumes allowance; reset every 24 hours. | S4, plan cards; S1, AI allowance by plan | Hosted Free/premium | CONFIRMED; not separate quotas per generator |
| Commons has Basic, explicitly same as Free; Commons AI Max/fair use. Free/Commons exclude the conversational Assistant, not generators. | S1, allowance table; S5, institutional section | Hosted institutional AI | CONFIRMED tiers; 5 for Commons follows the documented same-as-Free equivalence, not a separately published numeric institutional quota |
| Table prompts/images go to OpenAI GPT API; Overleaf says it does not store inputs or train its language models with them, and describes API data as not used for training. | S2, introductory privacy note | Table generator | CONFIRMED feature-specific statement; no inference about downstream retention |
| The 2024 launch also described equation prompts/images going to OpenAI. | S6, What happens to your prompts and images | Historical, June 26, 2024 | CONFIRMED historically; current equation-specific processing details UNRESOLVED |
| Generator availability on Community Edition or Server Pro | S7, Community Edition/Enterprise; S8, Getting Server Pro | Self-hosted editions | UNRESOLVED: reviewed deployment sources distinguish editions but do not establish these generators |

## Corrections and contradictions

**Packaging:** S5, dated July 2, 2026, explicitly bundles AI into plans at no extra cost. S2 and S4 now agree. The older separate AI Assist/add-on and unlimited-use language is legacy, not the current general entitlement model. S6's June 26, 2024 Premium-only launch statement is historical.

**Managed accounts:** upstream blanket exclusion is too strong. S1, Who can use Overleaf AI, still says managed accounts cannot access AI. However, S9, AI features, documents administrator overrides, and S10, AI features and managed accounts, permits use when enabled, within the plan allowance. Preserve this as a documentation contradiction; account-specific access was not tested.

**Equation mechanics:** the upstream claim that no official operational instructions exist needs qualification: S3 supplies them, but points to the removed Writefull toolbar. It does not settle current upload-format guarantees.

## Platform boundary and limitations

AI generators emit editable LaTeX; they are not inherent LaTeX capabilities. S11 separately lists manual code, visual insertion, pasting, and AI generation; S12 explains ordinary LaTeX math. S13's Insert Figure/paste/drag-drop workflows add a figure to a document, not an AI transcription request. Exact transcription, layout fidelity, handwriting recognition, and successful compilation are **UNRESOLVED**, not guarantees inferred from image support.

## Primary sources

- S1: https://docs.overleaf.com/integrations-and-add-ons/ai-features
- S2: https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables/ai-table-generator
- S3: https://help.writefull.com/writefull-for-overleaf--user-guide
- S4: https://www.overleaf.com/user/subscription/plans
- S5: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- S6: https://blog.writefull.com/instantly-generate-tables-and-equations-in-writefull-for-overleaf/
- S7: https://github.com/overleaf/overleaf
- S8: https://github.com/overleaf/toolkit/blob/master/doc/getting-server-pro.md
- S9: https://docs.overleaf.com/groups/user-management/controlling-feature-availability
- S10: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts
- S11: https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables — Generating and inserting tables.
- S12: https://www.overleaf.com/learn/latex/Mathematical_expressions — Introduction; Display math mode.
- S13: https://docs.overleaf.com/writing-and-editing/inserting-images — Simpler ways to add images.

## Counter-search queries

Executed searches included:

- `site:docs.overleaf.com "Equation Generator"`
- `site:docs.overleaf.com "equation generator" "image" "PNG"`
- `site:overleaf.com "AI" "equation" "image" generator formats`
- `site:docs.overleaf.com "AI Assist" "add-on"`
- `site:docs.overleaf.com "Server Pro" "AI"`
- `site:overleaf.com "Server Pro" "Writefull"`
- `site:github.com/overleaf "AI features" "Community"`

Findings use opened primary pages, not search snippets; S3 still carries add-on-era subscription copy alongside its operational instructions.

## EXPAND

- LEAD: Current equation-specific upload compatibility and processing documentation; provider instructions retain obsolete navigation.
- LEAD: Resolve S1's managed-account exclusion against S9/S10's explicit administrator enablement.
- LEAD: Official generator entitlement/configuration for Community Edition and Server Pro; deployment documents reviewed do not establish either availability or absence.
