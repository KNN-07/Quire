# Verification 50: AI consent, controls, quotas, subscription generations

**Checked October 26, 2026. Verdict: PARTIAL.** Read both `harvest-50.md` and `expand-50.md`; opened public primary pages and counter-searched their claims. Hosted entitlements and controls are documented, but official pages retain contradictory wording. No authenticated execution, purchases, or functional tests were performed. These are platform AI services, not arbitrary LaTeX capabilities.

## Claim table

Source keys resolve to exact URLs and relevant headings below.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| AI bundled at no additional cost from July 2, 2026; allowances vary. | B, introduction | Hosted, all plans | CONFIRMED; supersedes separate-add-on purchasing as the general current model. |
| Free and Student: 5 uses/day; Standard: 10/day; Pro: Max/fair use. Assistant absent on Free, included on Student/Standard/Pro. | P, plan cards and comparison | Free / premium / AI | CONFIRMED; Basic and Standard are numerically quantified on pricing, though not in the AI docs table. |
| Commons: Basic/no Assistant; Commons AI: Max/fair use plus Assistant. | B, institutional section; A, allowance table; C | Commons / Commons AI | CONFIRMED. Expansion's claim that Commons AI lacks help-center documentation is incorrect: A explicitly lists it. |
| Uses include Error Assist suggestions, Assistant exchanges, language/generator invocations including accepting suggestions. Reset every 24 hours; upgrading immediately resets allowance. | A, allowance section | Hosted AI | CONFIRMED documented rule, not tested. |
| No fixed Max ceiling is promised; fair-use rules apply. | L, Usage Limits | Pro / Commons AI | CONFIRMED; no numeric Max guarantee. |
| First external-processing feature triggers AI-terms acceptance; accepting once covers all features. | A, Data and privacy | Hosted AI | CONFIRMED; distinct from enabling AI. |
| Error Assist sends errors/code/file names; Assistant sends necessary project content and may query search engines; language tools send text/context; citation suggestions use Dimensions. | A, Data and privacy | Hosted AI | CONFIRMED disclosures, not traffic inspection. |
| Individual disable switch turns off editor AI; Settings offers shortcut, sentence-completion, floating-menu, and language-model controls. | A, settings/disable sections | Hosted AI | CONFIRMED; sentence completion requires AI terms. |
| Group dashboard toggle affects all members immediately, not selected users; changes produce email and audit records. Defaults: enabled for non-managed groups, disabled for Pro Managed Users. | G, AI features and FAQs | Hosted groups | CONFIRMED. Managed status alone does not permanently prohibit AI: admin enablement is documented in M. |
| Inputs/outputs not used for model development/training without consent, subject to the exclusive-benefit service exception; provider contracts prohibit their own training. | L, Overleaf AI | Hosted AI | CONFIRMED legal wording; more qualified than A's absolute no-training sentence. No zero-retention guarantee inferred. |
| Server Pro is separately licensed from hosted Pro. Hosted AI/quotas/consent parity is not established. | S, licensing hint and feature tables | Server Pro / Community Edition | Licensing CONFIRMED; AI parity UNRESOLVED. |

## Contradictions and legacy limits

- **Reset conflict remains live:** F's “What are the fair use limits?” still says up to 72 hours, despite A's 24-hour rule and P's daily reset. Treat 24 hours as the documented current allowance model, but flag the unresolved inconsistency rather than calling F an archived page.
- **Add-on remnants:** D still calls Assistant part of AI Assist. W's “I already have both Writefull and Error Assist” says either subscription provides the combined features and recommends canceling one to avoid double billing. These undated legacy descriptions, observed October 26, 2026, do not establish migration guarantees under July 2026 bundling. Upstream's separate per-tool quotas are not confirmed on the opened current pages: UNRESOLVED.
- **Cross-project correction:** G and M say access follows one's account, but their detailed examples also block outside collaborators when the owner's organization disables AI. Thus expansion's owner-independent rule is too broad. Document both organizational vetoes; precedence wording remains inconsistent.
- **Deprecations/controls:** A's Troubleshooting removes Summarize/Explain and the old Writefull toolbar, despite its introductory list retaining Summarize/Explain. P confirms global AI controls “Via Support” for Standard/Pro/Organizations; G also documents self-service control.

## Primary sources

- A: https://docs.overleaf.com/integrations-and-add-ons/ai-features — AI allowance by plan; Data and privacy; AI settings; Troubleshooting.
- P: https://www.overleaf.com/user/subscription/plans — plan cards; Compare all features; Global feature controls.
- B: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — July 2, 2026; What each plan includes; What's new: Commons AI for institutions.
- G: https://docs.overleaf.com/groups/user-management/controlling-feature-availability — AI features; FAQs; How AI access works across organizations.
- M: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts — AI features and managed accounts; invited projects.
- L: https://www.overleaf.com/legal — Overleaf AI; Usage Limits; Terms dated May 5, 2026 (page overview dated August 5).
- C: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription — AI features with Commons access.
- F: https://www.overleaf.com/about/ai-features — fair-use FAQ.
- D: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — opening description.
- W: https://help.writefull.com/writefull-for-overleaf--user-guide — subscription overlap FAQ.
- S: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — licensing and feature comparison.

## Counter-search queries

`site.overleaf.com "AI Assist" "72 hours"`; `site.overleaf.com "Writefull Premium" "AI Assist"`; `site:docs.overleaf.com/on-premises "AI" "Writefull"`; `site:github.com/overleaf "AI" "Writefull"`; `site:overleaf.com/blog "AI Assist" "2025"`.

## EXPAND

- **LEAD: Server Pro/Community Edition AI availability.** No affirmative official deployment guarantee found; comparison-table silence is not proof of absence.
- **LEAD: Legacy subscriptions.** Current migration, billing, and per-tool quota treatment remain unspecified.
- **LEAD: Documentation reconciliation.** Resolve 24/72-hour reset and cross-organization precedence contradictions with an authoritative update.
- **No numeric-Max lead:** L explicitly defines fair use without a fixed limit; do not invent one.
