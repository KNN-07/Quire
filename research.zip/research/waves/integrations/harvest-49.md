# Overleaf angle 49: Writefull tools and Citation Reviewer

Research date: 2026-10-26. Sources below are public Overleaf documentation and blog material, checked on this date. This report describes documented platform behavior, not tested execution.

## Current documented scope

Overleaf’s current AI features page presents Writefull language suggestions and editing/generation features as part of the editor’s AI toolset. Language suggestions provide grammar and fluency edits for academic writing; the rewrite actions are Paraphrase, Make concise, Make scientific, Split (long sentences), and Join (short sentences). Generate actions include Title and Abstract. The broader AI tools table also lists equation and table generation, TeXGPT, and Synonyms, but these are adjacent platform AI tools and should not be conflated with Writefull’s language/rewrite/generation subset. [AI features — “What’s included”](https://docs.overleaf.com/integrations-and-add-ons/ai-features) documents the functions; “Where to find AI tools” says language suggestions appear inline, generators are in Insert (and some via TeXGPT), and rewrite actions appear in the AI action menu or floating selection menu. Available actions depend on selected-text length. The old standalone Writefull toolbar has been removed and its tools moved into the main editor UI. [AI features — “Where to find AI tools” and troubleshooting](https://docs.overleaf.com/integrations-and-add-ons/ai-features)

The documentation’s feature table also lists “Summarize and Explain,” but the same current page explicitly says those actions “have been removed and are no longer available.” Do not treat them as current features. Translate appears in the action-menu list but not in the page’s main rewrite table; its precise current access/availability is therefore **UNRESOLVED**. [AI features — feature table and troubleshooting](https://docs.overleaf.com/integrations-and-add-ons/ai-features)

## Citation Reviewer

Citation Reviewer is the structured “Scan for unsupported statements” assistant skill: it scans a document, highlights passages that may lack references, and offers paper suggestions sourced from Dimensions. Selecting a paper adds its citation to the document and bibliography automatically. Citation recommendations are therefore distinguished from ordinary chat-generated answers: a citation request typed into the AI chat is LLM-generated and is not verified against an authoritative source. [AI assistant — “Citation reviewer”](https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant); [Overleaf AI now a part of Overleaf plans — “How Overleaf AI works”](https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans)

## Availability, controls, and limits

AI features are enabled in Account Settings; users can disable all AI features together. The current AI allowance table says Free and Commons have Basic daily allowance but no AI Assistant; Student has Basic plus AI Assistant; Standard has Standard plus assistant; Pro and Commons AI have Max allowance, with fair use applying. Each tool invocation consumes allowance; limits reset every 24 hours. Organization-managed accounts may have AI disabled by their administrator. [AI features — “AI allowance by plan,” “Enabling and disabling AI features,” and “Who can use Overleaf AI”](https://docs.overleaf.com/integrations-and-add-ons/ai-features)

This current plan framing supersedes older descriptions of Writefull Premium as a separate paid product for the integrated editor. Overleaf’s Writefull integration page, last updated two months before this research date, still says Writefull premium options are separate from Overleaf subscriptions and offer unlimited Writefull feature use. That appears to describe Writefull’s own premium plans/account, not the current Overleaf AI allowance model; the exact mapping of Writefull.com entitlements to current Overleaf plan quotas is **UNRESOLVED**. [Writefull — “Premium Writefull options”](https://docs.overleaf.com/integrations-and-add-ons/ai-features/writefull); [AI features — “AI allowance by plan”](https://docs.overleaf.com/integrations-and-add-ons/ai-features)

Overleaf says language/rewrite requests may transmit selected text or surrounding context to third-party services; its current AI page states user data is not used to train models. Suggestions can misinterpret complex or custom LaTeX, and Overleaf instructs users to review before applying; undo is available. These are editor-assistance features, not LaTeX language primitives or guarantees of semantic preservation, citation completeness, or compilation correctness. The platform’s documented generation is limited to named actions; arbitrary LaTeX remains possible through ordinary editing, but should not be represented as a guaranteed output of these specific tools. [AI features — “Data and privacy” and “Troubleshooting”](https://docs.overleaf.com/integrations-and-add-ons/ai-features)

## Historical note

The March 12, 2024 update to Overleaf’s older Writefull integration blog described free limited language suggestions, Paraphraser, Title/Abstract generators and Sentence Palette, while Writefull Premium expanded usage and added TeXGPT. This is dated legacy packaging, not evidence of today’s Overleaf plan entitlements or current toolbar. [Writefull integration update — “What’s included” (March 12, 2024 update)](https://www.overleaf.com/blog/update-writefull-is-now-integrated-with-overleaf-no-extension-needed)

## EXPAND

- **LEAD — Translate action:** current AI-features documentation names Translate in the action-menu list but omits it from the main feature table; exact behavior and plan availability are **UNRESOLVED**. Reason: current official page does not specify them.
- No additional leads: core functions, Citation Reviewer workflow, current plan tiers, limitations, and legacy distinction are covered by current official sources.
