# Expand 44: Overleaf and Zotero / Mendeley integrations

Checked October 26, 2026. Scope: Overleaf's Zotero and Mendeley integrations only. Sources are public Overleaf docs pages, read directly. No authenticated tests, no purchases, no functional execution claimed.

Note on tooling: the deliverable was requested via apply_patch; this session had no apply_patch tool, so the file was written with a full-file write.

## Availability (verified)

- Reference manager integration is a premium feature. Premium access covers Commons participants, group-subscription members, and individual subscription owners. Source: https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations (opening notice); same notice on https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero and /mendeley.
- Premium-features page classifies Mendeley, Zotero, and ReadCube linking as account-level premium features. Collaborators can cite imported references, but only the project owner can re-sync the imported file. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features ("Account and project level features").
- Free users can export `.bib` from either manager and upload it manually. Source: Zotero and Mendeley pages, green "success" hint.
- AI: none of these pages mention AI. The July 2, 2026 blog (https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans, seen in search only) concerns AI, not these integrations; it was not opened and is not combined with them.

## Zotero (verified on https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero)

Three separate paths:

1. **Zotero Sync (account Library):** one-way, from selected collections into the account-level Library, reusable across projects. Added or changed items appear on the next sync; deleted items or unselected collections are removed on the next sync. Synced entries are read-only in Overleaf; edits must be made in Zotero. Heading: "Zotero Sync: keep your Library up to date automatically." Manual sync is available.
2. **Zotero-linked `.bib` file:** bulk import of My Library or a group as a read-only file in one project. No folder selection; the whole library is flattened. Refresh pulls changes. Heading: "Zotero-linked .bib file: import a whole library or group into a project." The page explicitly says it is distinct from Zotero Sync and that both can be used.
3. **Advanced reference search:** looks up records via `\cite{}` autocomplete and imports cited ones into an editable project `.bib`. Source: https://docs.overleaf.com/citing-and-references/adding-citations-and-references/configuring-advanced-reference-search, section "Configuring advanced reference search to use Zotero."

Limits: Zotero Sync has a cap on collections/items; the page warns but gives no number. Sync cadence is "next sync" with no schedule guarantee.

Permissions: after changing Zotero group permissions, an error appears; the user must "Re-link your account." Heading: "Notes on permissions."

## Mendeley (verified on https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley)

- **Bulk import:** whole library or one group, as a read-only `.bib`, refreshed with the Refresh button. Heading: "Import Mendeley library or group."
- **Folders are not supported.** Explicit note in the same section.
- **Advanced Reference Search:** imports individual records into an editable `.bib`, but cannot retrieve individual records from a Mendeley group; the whole group must be imported read-only instead. Source: https://docs.overleaf.com/citing-and-references/adding-citations-and-references/configuring-advanced-reference-search, "Configuring advanced reference search to use Mendeley" (danger hint). The Mendeley page's "Groups and folders" anchor, linked from that hint, does not exist in the fetched page text; this is a minor doc inconsistency.

## Shared behavior (verified)

- Both integrations pass API output "as provided," without conversion (heading: "Notes on Overleaf's integration with reference managers").
- Citation keys can differ between API output and manual `.bib` export. Switching between them can break citations (heading: "Citation keys"). Zotero's page adds that Zotero platform updates can change keys.
- Advanced-search target file: if no editable `.bib` exists, Overleaf creates `references.bib`; with one, it selects it; with several, it asks. Source: configuring-advanced-reference-search page.

## Legacy and date-tagged items

- **Mendeley Groups post (https://www.overleaf.com/blog/348-new-manage-shared-references-with-mendeley-groups):** the fetched text is dated 18 September 2018 and states that Overleaf v2 (4 September 2018) made Mendeley a paid feature, so the post is obsolete. Date-tag: **2018, legacy.** Correction to harvest: the harvest's "July 4, 2016" date for this post was not confirmed by the fetched page.
- **Reference-manager tip post (https://www.overleaf.com/blog/639-tip-of-the-week-overleaf-and-reference-managers):** the fetch returned only page chrome, no body. The harvest's CiteULike claim (March 29, 2018) is **UNRESOLVED**.

## Server Pro / Community Edition

- Server Pro vs. Community Edition page (https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition) lists SSO, sandboxed compiles, Git integration, and others, but does not list Zotero or Mendeley in either column. Its release table lists 6.3 as supported. It also states that a Pro plan does not license Server Pro. **Result: UNRESOLVED** whether the reference-manager integrations exist in self-hosted editions.

## Adjacent deprecation (search snippets only, not opened)

- Elsevier Support's "Mendeley API Changes" (last updated February 18, 2021) lists retired endpoints, and the Mendeley Developer Portal lists retired Feed, Public Groups, Profiles, and Funding. These are Mendeley platform changes; **no source connects them to Overleaf's connector.** UNRESOLVED.

## EXPAND

- **LEAD (UNRESOLVED):** Server Pro / Community Edition support for Zotero and Mendeley. Reason: no public Overleaf page mentions it; the feature-comparison table omits it.
- **LEAD (UNRESOLVED):** Zotero Sync collection/item limit and sync cadence. Reason: docs warn about a limit and describe "next sync," but give no numbers or schedule.
- **LEAD (UNRESOLVED):** Whether Overleaf's Mendeley connector depends on any endpoint Elsevier has retired. Reason: only search snippets were read; the Elsevier pages were not opened and Overleaf's docs are silent.
- **LEAD (UNRESOLVED):** CiteULike mention in the 2018 reference-manager post. Reason: fetched page had no body text.
- **Closed as not relevant:** the July 2, 2026 Overleaf AI blog (not about reference managers; not combined).
- **Closed as duplicate:** ReadCube and advanced-search general behavior are covered elsewhere; only the Zotero and Mendeley paths are reported here.
