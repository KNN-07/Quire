# Verify 47: Error Assist and AI-assisted compilation debugging

**Checked:** October 26, 2026. **Verdict: PARTIAL** — hosted behavior and current plan entitlements are confirmed; legacy subscription migration and self-hosted availability remain unresolved. Both `harvest-47.md` and `expand-47.md` were read. Public documentation verification only: no authenticated tests, purchases, compilation, or functional execution.

## Claim table

Source keys resolve to exact primary URLs and headings below.

| Claim | Source | Availability | Evidence status |
| --- | --- | --- | --- |
| Error Assist explains compile errors and usually proposes a source edit. Select an editor error marker or Logs and output files, then Suggest fix; review red/green changes, regenerate if needed, and Apply suggestion to recompile. Undo/Ctrl/Cmd+Z reverses the edit; response rating is available. | S1, Using Error Assist; Troubleshooting | Hosted AI, allowance-limited | CONFIRMED |
| Each Suggest fix consumes one shared daily AI use. The allowance resets every 24 hours; exhausted users see reset timing and an upgrade option. | S1, AI allowance; S2, AI allowance by plan | All eligible hosted tiers | CONFIRMED; no fixed numeric tier limits published here |
| Free, Student, and Commons receive Basic; Standard receives Standard; Pro and Commons AI receive Max, subject to fair use. Error Assist is not restricted to paid accounts. AI Assistant is excluded from Free/Commons but included in Student/Standard/Pro/Commons AI. | S2, plan table; S3, What each plan includes / Commons AI | Free, premium, institutional tiers distinguished | CONFIRMED |
| AI must be enabled. Group administrators can make it unavailable; managed accounts and institutions opting out cannot access it. External processing requires initial acceptance of AI terms. | S2, enabling instructions; Who can use Overleaf AI; Data and privacy | Eligible accounts only | CONFIRMED |
| A requested fix sends OpenAI the full error, relevant code lines, and project file names; nothing is sent until Suggest fix. Documentation says data is never used to train AI models. | S1, Data and privacy | Hosted Error Assist | CONFIRMED as vendor policy; not independently audited |
| It needs a complete log error, so typing-time code-check errors lack Suggest fix. Custom/specialised LaTeX can produce wrong suggestions; review is required. | S1, Troubleshooting | Error Assist limitation | CONFIRMED |
| Syntax checks and Stop on first error are separate editor/compiler functions, not AI repair. Default compilation can produce an incorrect PDF despite errors; first-error mode stops immediately and is per-user/per-project. | S4, Syntax checks / Compile error handling; S5, compilation-mode sections | Ordinary hosted compilation; no AI allowance stated | CONFIRMED |
| AI Assistant provides general LaTeX help, but this does not establish an autonomous compile–repair loop or guaranteed successful patches. | S3, How Overleaf AI works; S6, Chatting with your document | Paid/Commons AI chat versus Error Assist | Help confirmed; autonomous repair UNRESOLVED |
| Error Assist is included in Server Pro or Community Edition. | S7, feature comparison; S8, Configuration / Server Pro index | Self-hosted | UNRESOLVED: inspected sources do not document it; absence is not proof of exclusion |

## Primary sources

- **S1:** https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist — workflow, allowance, privacy, troubleshooting.
- **S2:** https://docs.overleaf.com/integrations-and-add-ons/ai-features — current plan table, account restrictions, daily reset.
- **S3:** https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans — **July 2, 2026** announcement: AI bundled at no extra cost with tier-dependent allowances; Commons AI introduced.
- **S4:** https://docs.overleaf.com/getting-started/recompiling-your-project — syntax and compile handling.
- **S5:** https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error — first-error mode versus compiler continuation.
- **S6:** https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant — general project chat; introduction still calls it an AI Assist add-on.
- **S7:** https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition — separate Server Pro licensing; feature tables omit Error Assist.
- **S8:** https://raw.githubusercontent.com/overleaf/toolkit/master/doc/README.md — official deployment documentation index; no AI integration entry.
- **S9:** https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — current “Overleaf AI” section directs users to premium plans for higher limits.

## Corrections and unresolved boundaries

The harvest's legacy URL, https://www.overleaf.com/learn/latex/Error_Assist, returns S1's current content, not a one-use-per-day/add-on policy. The upstream regional-mirror snippet is **legacy, original revision date unverified**; it was not independently confirmed here. Directly opened S1/S2 state shared daily allowance/24-hour reset.

S2 and S9 no longer retain the general add-on purchasing wording attributed upstream; S6 still retains an add-on introduction. This is a residual documentation inconsistency, not evidence against S3's dated bundling announcement. S3 describes Max as unlimited within fair use; S2 says Max/fair use, without a numeric guarantee. Migration rules remain UNRESOLVED. Privacy wording also differs: S1/S2 say data is never used for training, while S3 qualifies this with “without explicit consent”; retain that qualification rather than infer a stronger cross-product guarantee.

S1/S6 do not establish a model version, accuracy rate, supported-error taxonomy, retry guarantee, guaranteed compilation, or PDF correctness. Arbitrary LaTeX capability must not be inferred from an AI assistance feature.

## Counter-search queries

Submitted: `site:docs.overleaf.com/on-premises "Error Assist"`; `site:github.com/overleaf/toolkit "AI" "Error"`; `site:github.com/overleaf/overleaf "Error Assist"`; `site:overleaf.com "AI Assist" "migration"`; `site:docs.overleaf.com "AI Assist" "subscription" "existing"`. The web search interface returned no readable result payload, so no absence claim rests on search results. Direct primary-page fetches supplied the evidence above, including the official raw toolkit index. Search-only discovery and the upstream mirror's historical wording remain unverified.

## EXPAND

- **LEAD — Self-hosted availability:** needs an explicit official edition/configuration statement; current feature tables and toolkit index do not settle inclusion or exclusion. Do not substitute third-party forks.
- **LEAD — Legacy subscription migration:** needs current official billing transition rules; remaining add-on wording does not establish them.
