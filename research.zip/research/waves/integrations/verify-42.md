# Verify 42: GitHub synchronization, import/export, conflicts

Checked October 26, 2026. **Verdict: PARTIAL**: core upstream claims confirmed; import/export coverage corrected below. Remaining guarantees are explicitly unresolved. Read both `harvest-42.md` and `expand-42.md`. Public documentation only; no functional execution, authentication, or purchases.

## Claim table

Source keys resolve to exact primary URLs below; headings identify the evidence.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Owner initializes linked-account sync; organization OAuth permission required; github.com only. | S1: "What is GitHub sync?", "Accessing repositories..." | Cloud premium, including Commons/group/individual subscriptions | CONFIRMED |
| Existing repository imports into a new project; existing project exports into a new repository; existing-to-existing unsupported. | S1: "What is GitHub sync?" | Cloud premium | CONFIRMED |
| Manual pull/push, optional commit message; bundled pushes use linked owner identity; imports appear anonymous. | S1: "Synchronizing with GitHub", "Known limitations" | Cloud premium | CONFIRMED |
| Cannot retarget/unlink for repository creation; copy project instead. | S1: "Disconnecting a project..." | Cloud premium | CONFIRMED |
| Conflict creates timestamped Overleaf-version branch; merge into default branch locally and push, or resolve through GitHub PR. | S1: "Resolving merge conflicts" | Cloud premium | CONFIRMED |
| No branching workflow/LFS/nested submodules; symlinks become files; executable bits reset; pulls risk comments/track changes. | S1: "Known limitations" | Cloud premium | CONFIRMED |
| Recommend <100 changed files/commit and <100 MB project; sync stops above 7 MB editable content. | S1: "GitHub synchronization file limits" | Cloud premium | CONFIRMED; recommendations differ from cutoff |
| Premium owner links; all project users can subsequently sync. | S2: "Account and project level features", GitHub tab | Includes Free collaborators | CONFIRMED; upstream account-level wording oversimplifies |
| ZIP creates a project; each upload up to 180 files, individual files up to 50 MB. | S3: "Uploading large projects" | General Cloud workflow; no premium gate stated | CONFIRMED |
| 2,000 files and 7 MB editable material apply equally to Free/premium; total project size has no enforced cap. | S4: "Overleaf plan limits" | Free and premium | CONFIRMED |
| Source ZIP and PDF are separate downloads; compiler-generated PDF is not added to source. Avoid uploaded `.git` folders. | S5: download headings; S6: "Git folders and files", compiled-PDF guidance | General Cloud workflow | CONFIRMED |
| Standard source excludes generated files; download these separately or use Submit to arXiv ZIP, which does not submit directly. | S7: "Downloading generated files along with the source" | General workflow; no premium gate stated | CONFIRMED |
| Import `.docx`/`.md`; export `.docx`/`.md`/`.html` using Pandoc. | S8: "Importing", "Exporting" | Plan/deployment entitlement UNRESOLVED | CONFIRMED feature; missing upstream |
| Conversion preserves structure, not exact styling; unsupported macros/packages and round trips can lose content/formatting; >50 MB files cannot convert. | S8: "What conversions can and can't do", common issues | Conversion workflow | CONFIRMED; not arbitrary LaTeX equivalence |
| Separate Git bridge supports local intermediaries; on-premises instructions specify Server Pro 4.0.1, while user docs say 4.0+. | S9; S10: "Overleaf Server Pro" | Server Pro; Community Edition entitlement not established here | CONTRADICTION in exact minimum version |

## Corrections and deprecated behavior

S8 materially expands the upstream ZIP/PDF-only inventory. Transport and conversion features do not guarantee arbitrary LaTeX packages, styling, or successful compilation; S8 explicitly documents conversion failures even for valid LaTeX.

The historical Server Pro 4.0-launch blog, under "What's the difference between GitHub and Git?", excludes direct GitHub sync from Server Pro: https://www.overleaf.com/blog/creating-connections-using-overleafs-git-integration-and-github . Publication date was not exposed by retrieval; treat this as legacy evidence, not a current deployment test.

**Deprecated-behavior correction:** current authentication docs say username/password login is **no longer available**, not merely being phased out. Tokens are the only login method for Cloud and Server Pro Git integration: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/git-integration-authentication-tokens , opening paragraphs. This is separate from GitHub OAuth sync. Retrieved current sync documentation describes an active feature, not deprecation.

Current S2 "Overleaf AI" and https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans , opening paragraph, say AI is included with plan-dependent allowances. This supersedes the older separate-AI-purchase model flagged in the brief; the brief dates the announcement July 2, 2026 (publication date not independently exposed by retrieval). AI bundling does not establish GitHub entitlement.

## Sources

- S1: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization
- S2: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features
- S3: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project
- S4: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits
- S5: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project
- S6: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project/files-that-should-not-be-included-in-a-project
- S7: https://docs.overleaf.com/navigating-in-the-editor/generated-files
- S8: https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files
- S9: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration
- S10: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration

## Counter-search queries

- `site:docs.overleaf.com "GitHub" "deprecated"`
- `site:docs.overleaf.com "GitHub" "discontinued"`
- `site:docs.overleaf.com "GitHub" "conflict" "merge"`
- `site:docs.overleaf.com "GitHub" "Community" "Server Pro"`
- `site:overleaf.com "export" "Word" "free"`
- `site:overleaf.com/blog "July 2, 2026"`

## EXPAND

- **LEAD: post-conflict guarantees, UNRESOLVED.** S1 ends at merging into default; automatic recognition, follow-up clicks, branch cleanup, and in-editor resolution are not promised.
- **LEAD: API thresholds, UNRESOLVED.** S1 gives recommendations, not exact quotas or repository-dependent guarantees.
- **LEAD: conversion entitlement/deployment, UNRESOLVED.** S8 lacks explicit plan and self-hosted availability labels.
- **LEAD: deployment precision, UNRESOLVED.** Reconcile S9's 4.0.1 versus S10's 4.0+, and obtain current direct-sync Server Pro/Community Edition availability evidence.
