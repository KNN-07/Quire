# Verify 43: Dropbox synchronization and availability

Research date: October 26, 2026. **Verdict: PARTIAL**: availability and operating boundaries are documented; conflicting official PDF descriptions prevent an unconditional behavior guarantee. Both `harvest-43.md` and `expand-43.md` were read. Public documentation verification only; no authenticated tests, purchases, or functional execution.

## Primary sources

- **D:** https://docs.overleaf.com/integrations-and-add-ons/dropbox — current integration instructions, including "Avoiding conflicts on PDF and compiled output files."
- **G:** https://docs.overleaf.com/groups/user-management/controlling-feature-availability — feature table, Dropbox Synchronization row.
- **P:** https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features — opening entitlement note and "Dropbox synchronization."
- **E:** https://www.overleaf.com/for/enterprises/features — "Benefits for Users" comparison.
- **L:** https://www.overleaf.com/learn/how-to/Syncing_PDF_file_in_Dropbox — legacy help-library page, "Syncing PDF file in Dropbox"; undated, still publicly served on the research date.
- **I:** https://help.dropbox.com/sync/how-to-prevent-files-from-syncing — accessed on the research date; "Supported features," "Unsupported features," and "What to expect."

Source letters below resolve to these exact URLs; headings identify the relevant evidence.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Premium access through individual, group, or institutional subscriptions; two-way account integration. | P, opening note; Dropbox synchronization | Cloud premium, including Commons; not Free-only entitlement | CONFIRMED |
| Enabled on all group plans unless administrator requests disablement through Support. | G, feature table and introduction | Cloud group plans | CONFIRMED |
| Third-party integration row explicitly includes Dropbox; both self-hosted columns say feature absent. | E, Benefits for Users | Group/Commons included; Community Edition/Server Pro excluded | CONFIRMED; closes upstream deployment lead |
| Collaborators need their own premium access. | D, opening information box | Cloud premium per user | CONFIRMED |
| Authorize through Account Settings; fixed `Apps/Overleaf`; panel shows status/manual background sync. | D, How do I set it up?; What does it look like? | Cloud premium | CONFIRMED |
| File edits/additions synchronize both ways; adding a Dropbox project folder creates a project. | D, What are the benefits? | Cloud premium | CONFIRMED |
| Owned active/direct-edit shares qualify; read-only/link shares do not. Archived/trashed copies remain; archived Overleaf edits may still push outward. | D, Which Overleaf projects are synchronized? | Cloud premium | CONFIRMED |
| Dropbox deletion removes project contents, retaining project/history; moves/renames risk history/comments/tracked changes. Apps folders cannot be shared. | D, What should I know before syncing projects? | Cloud premium | CONFIRMED |
| Check limits, unsupported files/names, duplicates, permissions; manual sync/relink/support are diagnostics. | D, Troubleshooting | Cloud premium | CONFIRMED; no recovery guarantee |
| Current docs say regenerated PDFs sync and can conflict; legacy page excludes compiled PDFs. | D, Avoiding conflicts; L, opening paragraph | Cloud premium | CONTRADICTORY official descriptions |
| Ignore rules are individual-account-only, per-device, prospective, and do not remove existing synced files. | I, Supported/Unsupported features | Dropbox individual; not team accounts | CONFIRMED |

## Corrections and limitations

The expansion's self-hosted uncertainty is resolved by E's explicit comparison, not by inference from Git support.

The expansion overstates closure of the PDF discrepancy: D supports its account of current documentation, but L remains contradictory and neither provides a dated migration/version boundary. Prefer D when describing current instructions, label L legacy, and do not represent documentation verification as proof of universal runtime behavior.

Dropbox's own I says ignored files remain local and remotely added matching files do not reach that computer. Consequently, desktop ignore rules alone do not establish prevention of Overleaf's server-to-Dropbox uploads. That stronger mitigation interpretation remains UNRESOLVED.

This is a platform file integration, not arbitrary LaTeX functionality. D's setup/benefits describe file access; they do not establish Dropbox-side TeX execution or an offline hosted editor. No AI entitlement is needed to explain these Dropbox claims; unrelated AI pricing language is not imported from P.

## Counter-search queries

Executed: `site.docs.overleaf.com Dropbox "Server Pro"`; `site.github.com/overleaf Dropbox community edition`; `site.docs.overleaf.com "Dropbox" "Server"`; `site.docs.overleaf.com "Dropbox" "PDF"`; `site.overleaf.com Dropbox sync discontinued PDF`; `site.overleaf.com "Dropbox" "discontinued"`. Opened current primary pages, rather than accepting snippets. No deprecation notice was established by these searches; that is not an uptime guarantee.

## EXPAND

- **LEAD: PDF/version boundary.** Seek an official reconciliation of D versus L; current documentation preference is not functional verification.
- **LEAD: Ignore-rule efficacy.** Seek explicit official confirmation that desktop rules can prevent server-originated Overleaf uploads, rather than merely suppress desktop synchronization.
- **Other leads: none.** Enterprise comparison closes Community Edition/Server Pro availability; remaining upstream claims are supported or qualified above.
