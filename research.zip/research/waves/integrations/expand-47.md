# Expand 47: Error Assist and AI-assisted compilation debugging

Research date: 2026-10-26. Public sources only; no authenticated tests, purchases, or product execution. Each claim cites the primary page and the heading or paraphrased evidence I read.

## Platform feature: Error Assist workflow (current)

- Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist, headings "Using Error Assist" and "Troubleshooting".
- Error markers appear in the editor margin and in the Logs and output files panel. The user selects **Suggest fix**, reviews a red/green line diff, can regenerate, and selects **Apply suggestion**, which recompiles. Undo or Ctrl/Cmd+Z reverses it. Thumbs up/down rating is available.
- The docs advise fixing errors top-down, because earlier errors can change later ones.
- Suggestions are not offered for code-check errors shown while typing. Fixes need the full error message from the compile logs.
- The docs warn that AI can misinterpret custom or specialised LaTeX, so suggestions must be reviewed.
- Availability: AI features are a platform/account feature. Account settings must enable them, and group-subscription administrators can disable them for members (https://docs.overleaf.com/integrations-and-add-ons/ai-features, "Where to find AI tools" and the group-subscription hint).

## Availability and plan tiers (current, 2026)

- Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans, dated July 2, 2026, headings "What each plan includes" and "What's new: Commons AI". Overleaf AI is said to be included in all plans at no extra cost, with plan-dependent allowances.
- Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features, table "AI allowance by plan". Free: Basic allowance, no AI assistant. Student: Basic, assistant included. Standard: Standard, assistant included. Pro: Max (fair use), assistant included. Commons: Basic, no assistant. Commons AI: Max (fair use), assistant included.
- Each Suggest fix counts as one use from the shared daily allowance, which resets every 24 hours. The docs give no fixed numeric limit per tier. "Max" is fair use, not unlimited by documented number.
- Label: Error Assist is in the Free, Student, Standard, Pro, Commons, and Commons AI tiers, subject to the allowance above. Premium/paid status depends on the tier.

## Data handling

- Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist, heading "Data and privacy". Error Assist is powered by OpenAI. On request it sends the full error message, relevant project code lines, and a list of project file names. Nothing is sent before Suggest fix is selected. The docs say user data is not used to train AI models.
- Source: https://www.overleaf.com/about/ai-features states the same no-training claim and says third-party services such as OpenAI are disclosed to users.

## Not AI: ordinary compiler diagnostics

- Stop on first error: https://docs.overleaf.com/troubleshooting-and-support/stop-on-first-error, "Compilation modes on Overleaf". Default mode tries to produce a PDF despite errors, which may be incorrect. Stop on first error halts at the first error. It is a per-user, per-project setting.
- Syntax checks and clickable error lines: https://docs.overleaf.com/getting-started/recompiling-your-project, "Syntax checks". These are compiler and editor behaviour, not AI.

## Legacy information (date-tagged)

- A regional-mirror snapshot of the Error Assist page, https://no.overleaf.com/learn/latex/Error_Assist, is the source the harvest cited as legacy. Search snippets of that page (dated before the July 2026 bundling, approximately 2025) say Error Assist was free once per day, with an AI Assist add-on for more uses that was described as unlimited, subject to fair use. The Jan 2025 Overleaf newsletter (https://us11.campaign-archive.com/?e=a347fb3fe3&id=80f4a4b97a&u=cb492c3cf501e9910fdcb160c) also called Error Assist a separate paid feature at the individual-account level. Treat this as legacy, dated to 2025 or earlier.
- Correction to the harvest: the www.overleaf.com/learn/latex/Error_Assist URL now returns the current wording (shared daily allowance, no one-per-day rule). The one-per-day and add-on wording appears only in the legacy regional-mirror snippet. I did not confirm the exact date that mirror was last updated.
- Not combined: the legacy "AI Assist" add-on and the current "Overleaf AI" bundled plans are different descriptions. The current docs and the July 2026 blog are the current position.

## Self-hosted (Server Pro / Community Edition)

- Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition and https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x. Neither fetched page mentions AI or Error Assist in the text I read, so self-hosted Error Assist availability is UNRESOLVED from official sources.
- A third-party mirror (Ayakaleaf Pro, https://ayakaleaf-pro.mintlify.app/on-premises/configuration/overleaf-toolkit/ai-integration) describes AI and Error Assist config for a self-hosted toolkit. It is not an official Overleaf source and I did not verify it against the Overleaf toolkit repository, so I do not rely on it.

## Unresolved

- No official source I read gives a supported error taxonomy, model/version, accuracy rate, retry limit, or guarantee that a suggested patch compiles.
- Whether AI features in self-hosted editions exist and how they are licensed is UNRESOLVED.
- Exact legacy-to-current migration for existing AI Assist add-on subscribers is UNRESOLVED.
- Arbitrary LaTeX correctness is bounded by the TeX engine and project packages; AI availability does not imply all valid LaTeX is understood.

## EXPAND

- LEAD (self-hosted AI availability): open. Needs the official toolkit configuration docs or the overleaf/toolkit repository. Not expanded here: official pages I read do not mention AI, and the only AI config page found is third-party.
- LEAD (legacy AI Assist subscription migration): open. Needs official billing or help-center pages on transitions. Out of this angle's scope unless subscription transitions matter.
- Duplicate closed: Stop on first error and syntax checks are compiler behaviour, covered here only as complements to Error Assist.
