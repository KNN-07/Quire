# Overleaf angle 41: Git bridge, authentication, and offline workflows (expand)

Checked: 2026-10-26. Sources are Overleaf primary docs (docs.overleaf.com, overleaf.com/learn) and the official overleaf/overleaf wiki. No authenticated tests, no purchases, no functional execution claimed. Harvest-41 claims were re-checked against primary pages where noted.

## 1. Git bridge (Git integration)

- **Core function (Cloud and Server Pro):** a project is a Git remote. Clone with `git clone https://git.overleaf.com/<id>` on Cloud; Server Pro uses the instance URL pattern `https://git@<site>/git/<id>`. Source: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration.md, headings "Overleaf Cloud" and "Overleaf Server Pro (version 4.0 or later)". Use the project's Git panel as the authoritative URL.
- **Availability labels:**
  - Cloud: **Premium**. Documented in the same page's Troubleshooting section and in https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md, "Git and GitHub integration" and the "Git" tab under "Account and project level features". Access follows the project owner's subscription, so collaborators on a premium-owned project can use it.
  - Server Pro: available from 4.0, **not enabled by default** (same page hint).
  - Community Edition: **not available**. https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md, "Integrations": "The Git Bridge integration is **only** available in Server Pro."
- **Commit model:** Overleaf history is translated to Git on demand. A commit is created when you pull/fetch and no commit exists for the current state, or when you push. Edits made in the browser do not generate commits automatically. Labeling a version forces a commit. Source: git-integration.md, "Git commits and the Overleaf Git integration" and "When are commits created?". Authorship: the most recent change before a commit is generated becomes its author ("Tracking authorship").
- **Documented limitations** (git-integration.md, "Known limitations"):
  - Branches: not supported; clones use `main` (older clones may use `master`). Tags: not supported.
  - Symlinks become regular files and overwrite local symlinks on next pull.
  - Execute permissions are not preserved (workaround: `core.fileMode false`).
  - Git LFS: not supported.
  - Projects cannot contain submodules, but can be submodules of other repos.
  - Renaming a folder and pushing leaves an empty old folder in the project.
  - Pushes can displace or lose comments and tracked changes (harvest claim; see the page's rename/comment rows, not fully extracted here).
- **Large repositories:** https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/interacting-with-large-git-repositories, Rule 1: do not sync a large workspace repo directly with an Overleaf project, via GitHub sync or Git integration.
- **Rate limits:** manual operations generally do not hit Git Bridge limits; automated polling by clients can (git-integration.md, "Rate limits").
- **Push failures:** can come from file size/count plan limits or unsupported file types; docs suggest raising `http.postBuffer` (git-integration.md, "Failure to push references").
- **Other hosts (GitHub/GitLab/etc.):** the Git bridge is not a Git hosting service. Overleaf's direct integration is GitHub synchronization (premium, per project). For other remotes, docs describe a local clone as intermediary (harvest claim; "Advanced Git operations" page not re-fetched, so **treat as harvest-sourced**).

## 2. Authentication and access

- **Current method:** Git authentication tokens, the only login method on Cloud and Server Pro. Username `git`, token as password. Source: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/git-integration-authentication-tokens.md, "Summary" and "Understanding Overleaf Git authentication tokens".
- **Token rules:** one token covers all projects you can access; expires after one year; maximum 10 per account; deleted tokens stop working; full token cannot be viewed after creation (same page).
- **Deprecation (dated):** the username/password method "is no longer available" (tokens page, current). An older Overleaf Learn article, https://www.overleaf.com/learn/how-to/Git_integration_password-based_authentication, states the password method "is deprecated and is being phased out" (legacy, date unverified in the article body; superseded by the tokens page). Stack Overflow (https://stackoverflow.com/questions/78946324/git-integration-breaks-with-latest-update-to-overleaf) reports token-based 'git@' URL workaround for a break after an update; anecdotal, not an official fix.
- **Collaborators:** each collaborator should create their own account and token; tokens should not be shared (tokens page, "How to work with collaborators").
- **Role permissions (Server Pro):** roles-and-permissions.md, "Integrations": Git clone/pull is Yes for Owner, Editor, Reviewer, named Viewer and link-sharing Viewer. Git push is Yes for Owner and Editor only; No for Reviewer and both Viewer types.
- **Cloud permissions:** the Cloud page does not give a role table in the pages fetched; the premium page describes that any member of a premium-owned project can clone/push/pull (premium-features.md, "Git" tab). Do not infer finer Cloud role rules beyond that: **UNRESOLVED** for exact Cloud role matrix.
- **Credential helper:** `git config --global credential.helper store` is documented (tokens page, "How to save your token").

## 3. Offline workflows

- **Local-repo workflow (supported path):** clone via Git bridge, edit locally in any plain-text editor, push when back online. Source: premium-features.md, "Git and GitHub integration" ("allows you to work offline and synchronize your files whenever you come back online"). The older Learn article (https://www.overleaf.com/learn/how-to/Working_Offline_in_Overleaf) describes the same pattern, but its passage was not re-extracted in this pass.
- **Local compilation:** requires a local TeX installation; the hosted compiler runs on Overleaf servers. Exact parity between local and hosted builds is not promised by the docs. **Not verified in this pass.**
- **Browser offline editing (distinct feature):** https://docs.overleaf.com/writing-and-editing/working-offline.md, "How to work offline": after connectivity loss, the editor shows "You're offline", the current file stays editable for a short period, edits sync on reconnect. If still offline, the editor shows "Editing paused" and locks. A hint says "basic support" with a more advanced offline experience "in development."
- **Conflict on duration:** the working-offline page gives no number ("short period"). The premium-features page says 10 minutes, or 2 minutes on Free ("Offline editing"). Which is current for all plans: **UNRESOLVED**.
- **Air-gapped self-hosting:** https://docs.overleaf.com/on-premises/installation/air-gapped-offline-deployments.md says Community Edition and Server Pro can be deployed offline by exporting and importing Docker images (sharelatex, sharelatex-pro, TeX Live) from a connected machine. This is deployment offline support, not evidence of Git bridge in Community Edition (which is excluded above).

## 4. Authentication for institutional/SSO (Commons)

- https://docs.overleaf.com/commons/single-sign-on-sso.md: Commons supports SAML SSO; new users can create accounts via SSO and existing users can link their SSO identity. Label: **Commons** subscription feature. Search snippets (not fully fetched) also describe Group SSO for Pro group subscriptions (https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso) and institutional SSO FAQs. Whether SSO affects Git token issuance was **not checked**.

## 5. Deprecation and omitted functionality

- Password-based Git auth: deprecated (see section 2). Token auth is the current path.
- No Git branching, tagging, LFS, or submodule-containing projects per current limitations.
- Harvest-41 mentions Overleaf AI and other angles; not in scope here. No AI bundling claims are made in this expansion.

## 6. Legacy / date tags

- Learn article "Working Offline in Overleaf": legacy, undated in fetched text; treat as older guidance.
- Learn article on password-based auth: legacy, deprecated.

## EXPAND

- **UNRESOLVED - browser offline duration:** 10/2-minute figure (premium-features.md) vs. "short period" (working-offline.md). Reason: official pages do not reconcile; no authenticated test performed.
- **UNRESOLVED - Cloud Git role matrix:** only Server Pro table fetched. Reason: no Cloud equivalent page read.
- **UNRESOLVED - local compile parity and local-workflow details:** Reason: docs not extracted beyond the summary.
- **UNRESOLVED - whether Commons/Group SSO affects Git token creation:** Reason: not verified.
- **Lead not re-verified:** GitHub synchronization and "Advanced Git operations" (sync with another remote) rely on harvest-41 and search snippets; not re-opened in this pass.
- **Duplicates closed:** Git bridge plan/deployment labels and token auth are covered once here; the password-auth deprecation is consolidated in section 2.
