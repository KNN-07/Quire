# Harvest 44: Zotero and Mendeley integrations

Research checked October 26, 2026. Scope: Overleaf's integrations with Zotero and Mendeley, not general LaTeX reference handling. Sources below are public, official Overleaf pages; no authenticated product tests were performed.

## Availability and shared workflow

Overleaf currently classifies reference-manager integration and Advanced Reference Search as **premium features**. Premium access includes Overleaf Commons participants, group-subscription members, and individual subscription owners; the docs do not assign these integrations specifically to AI plans, Server Pro, or Community Edition. Free users can still export a `.bib` file from a manager and upload it manually. Source: [Reference Manager integrations](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations), “Reference manager integration is a premium feature”; [Zotero](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero), opening notice and free-user note; [Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), “Reference manager integration.”

Overleaf offers a bulk-import/sync workflow and an individual-reference workflow via Advanced Reference Search. Individual results can be searched alongside project `.bib` entries while typing citation commands; citing a found record adds its data to a project `.bib` file. The project bibliography is editable by collaborators, while bulk-imported manager files are read-only. This is a platform integration for transferring bibliography data; citation syntax, bibliography generation, and formatting remain LaTeX features using `.bib` data, not manager-side Overleaf functionality. Sources: [How to search for references in an Overleaf project](https://www.overleaf.com/learn/how-to/How_to_search_for_references_in_an_Overleaf_project), “Benefits of advanced reference search” and “How to use advanced reference search”; [Managing citations and bibliographies in Overleaf just got easier](https://www.overleaf.com/blog/managing-citations-and-bibliographies-in-overleaf-just-got-easier), March 5, 2025, “Which approach is right for you?”

Overleaf says it consumes data from each manager's web API “as provided,” without controlling or converting API output. Citation keys may differ between API-imported data and manually exported `.bib` files, so replacing one with the other can break existing citations. This limitation is explicitly documented for both integrations. Sources: [Zotero](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero), “Notes on Overleaf’s integration with reference managers” and “Citation keys”; [Mendeley](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley), same headings.

## Zotero

Current Zotero docs describe **three** paths:

- **Zotero Sync (account Library):** one-way sync from selected Zotero collections into Overleaf’s account-level Library, reusable across projects. New/changed Zotero items appear on sync; deletions or collection deselection remove matching Library entries. Synced entries are read-only, and Library edits do not write back to Zotero. Users choose collections; a limit on collections/items applies, but the page does not state its numeric threshold. Source: [Zotero](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero), “Zotero Sync: keep your Library up to date automatically,” “Choosing what to sync.”
- **Zotero-linked `.bib` file:** bulk import of an entire personal library or group library into one project as a read-only file, refreshable from Zotero. It does not select a specific folder; a library’s contents are imported as a flat list. This is distinct from account Library sync. Source: [Zotero](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero), “Zotero-linked .bib file: import a whole library or group into a project,” “Importing Zotero references into an Overleaf project.”
- **Advanced Reference Search:** search selected Zotero libraries and import individual cited records into an editable project `.bib`. A project without an editable `.bib` gets `references.bib`; with an existing file Overleaf selects or offers a file. Source: [How to search for references in an Overleaf project](https://www.overleaf.com/learn/how-to/How_to_search_for_references_in_an_Overleaf_project), “Configuring advanced reference search to use Zotero.”

Zotero platform updates can change citation keys, requiring manual citation updates. Source: [Zotero](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero), “Citation keys.”

## Mendeley

Mendeley offers bulk import of the whole library or a specific group into a read-only project `.bib`; users refresh it after making source changes. **Folders are not supported** for import. Advanced Reference Search imports individual Mendeley records into an editable project `.bib`, but cannot retrieve individual records from a Mendeley group; import the whole group read-only instead. Sources: [Mendeley](https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley), “Import Mendeley library or group” and “Import individual references using Advanced Reference Search.”

The search configuration requires an editable main bibliography file. With none, Overleaf creates `references.bib`; with one it selects it; with multiple it offers a choice (and the guide says it may select one if none is chosen). Source: [How to search for references in an Overleaf project](https://www.overleaf.com/learn/how-to/How_to_search_for_references_in_an_Overleaf_project), “Configuring advanced reference search to use Mendeley.”

## Legacy and unresolved boundaries

**Legacy (March 29, 2018):** an Overleaf blog described direct integrations as including CiteULike; do not treat that historical list as current—the current integration index lists ReadCube, Zotero, and Mendeley. **Legacy (July 4, 2016; explicitly marked obsolete after Overleaf v2 launched September 4, 2018):** a post described Mendeley Groups as then-free; current docs classify integration as premium. Sources: [2018 reference-manager post](https://www.overleaf.com/blog/639-tip-of-the-week-overleaf-and-reference-managers); [2016 Mendeley Groups post](https://www.overleaf.com/blog/348-new-manage-shared-references-with-mendeley-groups).

No current source consulted establishes Server Pro or Community Edition availability, API quotas, or a guarantee of sync timing; those details remain unresolved. No claim of functional execution is made.

## EXPAND

- **LEAD (unresolved):** Server Pro / Community Edition deployment availability. Current public user docs describe subscription/Commons access but do not specify self-hosted edition support; official deployment documentation would be needed.
- **LEAD (unresolved):** Zotero collection/item cap and sync cadence. Current Zotero guide confirms a limit and manual sync, but gives no numeric cap or timing guarantee.
