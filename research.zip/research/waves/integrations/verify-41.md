# Verify 41: Git bridge, authentication, offline workflows

Checked **2026-10-26** against both upstream reports and current public primary pages. **Verdict: PARTIAL**: core functionality is confirmed and the offline-duration discrepancy is resolved; Cloud role/entitlement edge cases remain undocumented or contradictory. Documentation verification only: no authenticated tests, purchases, or functional execution.

## Claim table

Sources below give exact URLs and relevant headings.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Clone a project, edit locally, push/pull on reconnect; direct GitHub sync is a separate integration. | [S1], overview table; [S2], “Git and GitHub integration” | Cloud premium, including institutional/group access; Git bridge also Server Pro | CONFIRMED |
| Premium-owned projects confer Git access on members; premium users also have Git access to projects they can access. | [S2], “Account and project level features”, Git tab | Cloud premium entitlement | CONFIRMED wording; [S3] troubleshooting instead says owner subscription is required. Do not infer an exact role matrix or deny personal entitlement. |
| Git bridge requires enabling; deployment guide dates availability to 4.0.1, whereas user guide says 4.0+. | [S4], opening and Toolkit configuration; [S3], “Overleaf Server Pro” | Server Pro only; not Community Edition [S5], “Settings” | CONFIRMED; retain patch-version discrepancy |
| History is translated into Git on demand: pull/fetch creates a missing current-state commit; push creates commits; browser edits alone do not. Labels force commits only if no newer commit already exists; most recent editor supplies authorship. | [S3], “Git commits and the Overleaf Git integration” | Git-enabled projects | CONFIRMED; upstream omitted the label qualification |
| One linear history, `main` (older clones: `master`); no branching, tags, LFS, contained submodules, or preserved execute bits. Symlinks become files. Folder renames leave empty folders; file moves/renames become delete/create. Pushes may lose/displace comments and tracked changes. | [S3], “Known limitations”; [S6], opening | Git-enabled projects | CONFIRMED; project itself may be another repository’s submodule |
| GitLab/GitHub Enterprise/other hosts use a local intermediary with two remotes, not a direct connection. | [S6], “Synchronizing with another remote” | Git entitlement required | CONFIRMED |
| Tokens are the only current Git login method on Cloud/Server Pro: username `git`, token as password. One token spans accessible projects; one-year expiry, maximum 10; deleted tokens stop authenticating, full values cannot be redisplayed. Collaborators need their own account/token; credential helpers are supported. | [S7], introduction, “Summary”, “More help” | Cloud/Server Pro Git | CONFIRMED; password authentication is removed, not merely being phased out |
| Clone/pull allowed for owner/editor/reviewer/named and link viewers; push only owner/editor. SAML/LDAP users can generate/delete Git tokens. | [S5], “Integrations”, “Settings” | Server Pro | CONFIRMED; not extrapolated to Cloud |
| Browser offline editing lasts up to 10 minutes premium / 2 minutes Free, current file only; then editor locks. No file switching, compilation, comments, or AI offline. Reconnection usually syncs; conflicts permit preview/save-as-new-file/discard. Original-tab restoration may recover browser-backed-up edits, not guaranteed; private browsing cannot restore tabs. | [S8], “How to work offline”, “Syncing your offline edits”, “Limitations”, “Recovering lost edits” | Cloud Free/premium | CONFIRMED; resolves both upstream duration/blanket-unavailability claims |
| Longer offline work can use Git or ZIP download and later re-upload; metadata may be lost. Local LaTeX compilation is a separate local-toolchain capability, not hosted offline compilation or a parity guarantee. | [S8], “Working on your project outside Overleaf”; [S9], server compilation; [S10], local-installation support exclusion | ZIP alternative not labeled premium; Git premium | CONFIRMED boundary; upstream legacy Learn URL now redirects to [S1] |
| Air-gapped deployment transfers exported Docker images from connected machines; prevent automatic TeX-image pulls with `SIBLING_CONTAINERS_PULL=false`. | [S11], procedure and final warning | Community Edition / Server Pro; does not grant CE Git bridge | CONFIRMED |

Operational boundaries: [S3], “Rate limits” and “Failure to push references”, confirms automated polling may hit limits and pushes face file/type limits; buffer adjustment is a troubleshooting suggestion, not a guarantee. [S12], “Recommended workflow strategies”, advises a small paper repository rather than a large research workspace; custom scripts/CI are external workflows.

Authentication beyond Git: [S13] confirms Commons SAML account creation/linking. [S14] restricts Group SSO to Pro group members, requires an existing account/password and excludes JIT provisioning. Neither establishes Cloud SSO-specific Git-token restrictions. AI subscription bundling does not affect this angle; only offline unavailability is asserted.

## Sources

- [S1] https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization
- [S2] https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features.md
- [S3] https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration.md
- [S4] https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/git-integration.md
- [S5] https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.md
- [S6] https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/advanced-git-operations.md
- [S7] https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/git-integration-authentication-tokens.md
- [S8] https://docs.overleaf.com/writing-and-editing/working-offline.md
- [S9] https://docs.overleaf.com/troubleshooting-and-support/tex-live
- [S10] https://docs.overleaf.com/troubleshooting-and-support/user-support-policy
- [S11] https://docs.overleaf.com/on-premises/installation/air-gapped-offline-deployments.md
- [S12] https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/interacting-with-large-git-repositories
- [S13] https://docs.overleaf.com/commons/single-sign-on-sso.md
- [S14] https://docs.overleaf.com/accounts-and-security/email-address-and-login-options/logging-in-with-group-sso.md

## Counter-search queries

`site:docs.overleaf.com "offline" "10 minutes"`; `site:docs.overleaf.com "working offline" "Editing paused"`; `site:docs.overleaf.com Git "read-only" "push"`; `site:docs.overleaf.com git integration authentication tokens offline editing 10 minutes`; `site:docs.overleaf.com Git integration viewer push permissions`; `site:docs.overleaf.com local compiling TeX Live latexmk offline`.

Searches were supplemented by direct primary-page retrieval. Legacy check: https://www.overleaf.com/learn/how-to/Working_Offline_in_Overleaf redirects to [S1] as of this verification date; do not preserve its older blanket claim that browser editing cannot work offline.

## EXPAND

- **LEAD - UNRESOLVED: Cloud role matrix and personal-versus-owner entitlement.** [S2] and [S3] differ; https://docs.overleaf.com/collaborating/sharing-a-project.md, “Understanding permission levels”, supplies no explicit Git matrix. Do not assume viewers can push.
- **LEAD - UNRESOLVED: Cloud Commons/Group SSO-specific Git-token restrictions.** [S7] is general; [S5] explicitly resolves SSO token issuance only for Server Pro.
- **LEAD - UNRESOLVED: minimum Server Pro patch version.** [S3] says 4.0+, [S4] says 4.0.1; use the deployment-specific minimum conservatively.
