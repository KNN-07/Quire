# Verify 45: Reference search, citation discovery and bibliography refresh

Checked October 26, 2026. **Verdict: PARTIAL**: core hosted features are confirmed, but upstream coverage omitted Library/Zotero Sync; current deployment parity and some entitlement details remain unresolved. Both `harvest-45.md` and `expand-45.md` were read. Evidence is public documentation, not authenticated functional execution.

## Claim table

Sources below include exact URLs and relevant headings.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Citation-key autocomplete searches project `.bib` files; autocomplete must be enabled. | [S1], “How can Overleaf help to find and cite references?” | Hosted Free/all users | CONFIRMED |
| Advanced search uses key, author, journal, title, year and date for project `.bib` data; external fields vary. ReadCube, Zotero and Mendeley results can supply editable individual entries. | [S2], “Benefits of advanced reference search” | Premium; individual/group/Commons entitlement in [S3] | CONFIRMED |
| Mendeley advanced search cannot import individual group references; bulk group import is the documented alternative. | [S3], “Configuring advanced reference search to use Mendeley” | Premium/Commons | CONFIRMED limitation |
| Linked-library `.bib` imports are read-only; edit externally, then use project file-preview Refresh. Zotero bulk import flattens libraries/groups and cannot select collections. Manual export/upload remains available without a paid subscription. | [S4], “Zotero-linked .bib file,” “Importing Zotero references,” “Updating project .bib files,” introductory note | Integration premium/Commons; manual upload Free | CONFIRMED, not automatic live project synchronization |
| Account-level Library supports DOI lookup, pasted entries, `.bib` upload and search; citing copies records into a project. Simple search uses keys; advanced adds authors/titles. Library edits do not update previously copied project entries. | [S5], “Overview,” “Using the Library in projects,” “Managing your Library” | Advanced search premium; Library's complete plan matrix UNRESOLVED | CONFIRMED omission upstream |
| Zotero Sync automatically updates selected collections into Library, one-way; synced entries are read-only, with additions/changes/removals applied on the next sync. Manual sync is also possible. | [S4], “Zotero Sync,” “Keeping your Library in sync” | Zotero page labels integration premium/Commons | CONFIRMED omission; no documented refresh interval or numeric collection/item ceiling |
| Citation Reviewer scans unsupported statements, suggests Dimensions publications, and inserts selected citations/bibliography records. Ordinary chat requests are not equivalently source-verified. | [S6], “Citation reviewer” | AI Assistant; plan distinctions below | CONFIRMED; no completeness/relevance guarantee inferred |
| Citation formatting, ordering and bibliography-system behavior belong to LaTeX, not reference search. | [S7], introduction; [S8], introduction | LaTeX capability, not premium search | CONFIRMED boundary |
| Current Server Pro/Community Edition parity for these workflows | [S9], “Benefits for users”; [S10], legacy “Is reference search and Mendeley available?” | On-premises | UNRESOLVED current matrix; no hosted-plan inference |

## Corrections and availability

**Refresh has three distinct meanings.** Project linked-file Refresh, editable per-reference imports, and account-level Zotero Sync must not be merged. Library documentation explicitly says project copies are not updated by Library edits; remove/re-add the citation or edit the project entry [S5, “Managing your Library”]. Provider API output is used as supplied, and Zotero/API export changes can alter citation keys [S4, “Notes on Overleaf’s integration,” “Citation keys”].

**AI discrepancy is narrower than expand claims.** The July 2, 2026 announcement [S11, “What each plan includes,” “What's new: Commons AI”] bundles AI into plans: Free and ordinary Commons exclude AI Assistant; Student/Standard/Pro include it, and Commons AI explicitly includes Citation Reviewer. [S6] agrees on Free and ordinary Commons exclusions, but retains legacy “AI Assist add-on” wording and omits Commons AI. Therefore Free/ordinary Commons exclusion is corroborated, not contradictory. Commons AI inclusion is supported by the dated announcement; the documentation omission remains visible rather than silently combined.

The March 5, 2025 post's update confirms Papers became ReadCube without losing the integration [S12, opening update]. Older interface names are historical. The official GitHub FAQ, last edited August 28, 2025, labels its content outdated and says advanced reference features were unavailable on-premises [S10]. The current comparison [S9] does not settle this angle; legacy absence is not proof of today's behavior.

## Sources

- S1: https://docs.overleaf.com/citing-and-references/adding-citations-and-references
- S2: https://docs.overleaf.com/citing-and-references/adding-citations-and-references/searching-for-references
- S3: https://docs.overleaf.com/citing-and-references/adding-citations-and-references/configuring-advanced-reference-search
- S4: https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero
- S5: https://docs.overleaf.com/citing-and-references/library
- S6: https://docs.overleaf.com/integrations-and-add-ons/ai-features/ai-assistant
- S7: https://docs.overleaf.com/citing-and-references/creating-a-bibliography
- S8: https://docs.overleaf.com/citing-and-references/working-with-.bib-files
- S9: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
- S10: https://github.com/overleaf/overleaf/wiki/FAQ
- S11: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- S12: https://www.overleaf.com/blog/managing-citations-and-bibliographies-in-overleaf-just-got-easier

## Counter-search queries

Executed searches included `site:docs.overleaf.com reference search deprecated Mendeley`, `site:docs.overleaf.com/on-premises "reference search"`, `site:docs.overleaf.com "Server Pro" "Zotero"`, `site:github.com/overleaf "reference" "Server Pro"`, `site:overleaf.com "Commons AI" "Citation"`, and `site:docs.overleaf.com "Library" "Free"`. Primary pages were opened; stale search snippets were not treated as current evidence.

## EXPAND

- LEAD: Find an explicit current Library plan matrix; the feature page establishes mechanisms but not full entitlement.
- LEAD: Obtain a current official on-premises reference-feature matrix; the migrated legacy FAQ cannot establish present absence or parity.
- LEAD: Reconcile remaining AI Assist add-on terminology and Commons AI omission in current documentation with July 2, 2026 packaging.
