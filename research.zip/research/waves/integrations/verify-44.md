# Verify 44: Zotero and Mendeley integrations

Checked October 26, 2026. **Verdict: PARTIAL**: current official documentation confirms the hosted workflows; numerical sync limits, precise cadence, current self-hosted availability, and connector endpoint dependencies remain unresolved. Both upstream reports were read. This is public-document verification, not authenticated functional execution.

## Claim table

Source IDs resolve to exact URLs below; headings identify the supporting evidence.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Both integrations are premium; Free users can export and upload `.bib` manually. | Z/M, opening notices | Premium, including Commons, group and individual subscriptions; manual upload Free | CONFIRMED |
| Linking is account-level; collaborators can cite imported references, but only the project owner can re-sync an imported file. | P, "Account and project level features" | Premium linking; shared citation use | CONFIRMED; do not generalize this permission to account Library sync |
| Zotero Sync imports selected collections one-way into the account Library, reusable across projects. Source edits/additions/deletions and collection deselection propagate on sync; entries are read-only. | Z, "Zotero Sync: keep your Library up to date automatically" | Premium, per page notice | CONFIRMED |
| Zotero-linked `.bib` bulk-imports My Library or a group into one project, read-only and refreshable; folders become a flat list. This is independent of Library sync. | Z, "Zotero-linked .bib file" / "Importing Zotero references" | Premium | CONFIRMED |
| Zotero Sync has a collection/item cap; manual sync is available alongside automatic syncing. No numeric cap or precise interval is supplied. | Z, "Choosing what to sync" / "Keeping your Library in sync" / "Updating project .bib files" | Premium | CONFIRMED limitation; values UNRESOLVED |
| Mendeley bulk import supports an entire library or a group, read-only, updated through Refresh; folders are unsupported. | M, "Import Mendeley library or group" | Premium | CONFIRMED |
| Advanced search imports cited individual records into an editable project `.bib`; Zotero libraries are selectable. Mendeley group records cannot be imported individually; bulk-import the group instead. | A, manager-specific configuration headings; M, warning | Premium, including Commons | CONFIRMED |
| Advanced search creates `references.bib` on first citation if no editable bibliography exists, auto-selects a sole file, and offers a choice among multiple files; absent selection it chooses one. | A, both manager-specific headings | Premium | CONFIRMED |
| Both connectors use API data without conversion; manual exports can produce different citation keys and break citations when substituted. Zotero platform changes can also change keys. | Z/M, "Notes on Overleaf's integration" / "Citation keys" | Integration users | CONFIRMED |
| Changed Zotero group permissions may require account re-linking. | Z, "Notes on permissions" | Integration users | CONFIRMED |

## Sources

- **Z:** https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/zotero
- **M:** https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/mendeley
- **P:** https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features
- **A:** https://docs.overleaf.com/citing-and-references/adding-citations-and-references/configuring-advanced-reference-search

## Corrections and boundaries

**Legacy dates corrected:** https://www.overleaf.com/blog/348-new-manage-shared-references-with-mendeley-groups is dated **July 4, 2016**. Its "Feature update (18 September 2018)" says v2 made Mendeley paid on September 4, 2018 and labels the old behavior obsolete. Expand mistook the update for publication. https://www.overleaf.com/blog/639-tip-of-the-week-overleaf-and-reference-managers does contain the March 29, 2018 historical integration list; close the failed-retrieval lead without treating that list as current.

**Self-hosting:** https://github.com/overleaf/overleaf/wiki/FAQ, "Is reference search and Mendeley available?", says advanced reference features were unavailable and proposed for Server Pro. However, it explicitly labels its contents outdated (legacy; date unspecified). Current https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition omits these integrations and distinguishes Server Pro licensing from the hosted Pro plan. Thus current Server Pro/Community Edition support is **UNRESOLVED**, not confirmed by hosted premium access.

**Deprecation:** https://www.elsevier.support/mendeley/answer/mendeley-api-changes, endpoint table, removes public-group/follower functionality; https://dev.mendeley.com/, "Changes to the Mendeley Developer APIs", dates the changes to early 2021. Neither identifies Overleaf's actual endpoints. Do not infer that its documented group import is deprecated.

**AI and LaTeX:** https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans (July 2, 2026), opening, bundles AI with plans, but establishes no Zotero/Mendeley entitlement change. Retain their explicit premium notices. https://docs.overleaf.com/citing-and-references/creating-a-bibliography, "LaTeX reference management systems", separates bibliography processing from integration-provided data: formatting/generation is LaTeX functionality.

## Counter-search queries

- `site:docs.overleaf.com Zotero Sync collections limit`
- `site:docs.overleaf.com/on-premises Zotero Mendeley integration`
- `site:github.com/overleaf/overleaf "mendeley"`
- `site:overleaf.com "Mendeley" "deprecated"`
- `Mendeley developer API retired public groups`
- `site:overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans`

## EXPAND

- **LEAD — UNRESOLVED:** Current Server Pro/Community Edition connector availability; only explicitly outdated negative evidence found.
- **LEAD — UNRESOLVED:** Numeric Zotero Sync cap and exact automatic cadence; current guide gives neither.
- **LEAD — UNRESOLVED:** Overleaf's actual Mendeley endpoint dependencies; platform retirement notices do not establish connector impact.
