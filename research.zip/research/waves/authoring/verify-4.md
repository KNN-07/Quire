# Overleaf angle 4: keyboard shortcuts and editing preferences

Research date: October 26, 2026. Scope: Overleaf editor shortcuts, keybinding modes, and editing preferences. Sources are public official Overleaf pages and its shortcut reference. No authenticated product testing or functional execution was performed. Product shortcuts are distinct from arbitrary LaTeX package, macro, or command behavior.

## Findings

The current shortcut documentation confirms the common list: Ctrl/Cmd+F find/replace; Ctrl/Cmd+Enter or Ctrl/Cmd+S compile; Ctrl/Cmd+Z/Y undo/redo; Ctrl/Cmd+Home/End move to the first/last line of the current file; Ctrl/Cmd+Shift+L go to a line; Ctrl/Cmd+/ comment; Ctrl/Cmd+D delete line; Ctrl/Cmd+A select all; Tab/Shift+Tab indent/unindent; Ctrl/Cmd+U and Ctrl/Cmd+Shift+U change case; Ctrl/Cmd+B/I bold/italic. Ctrl+Space opens autocomplete, including bibliography search in `\cite{...}`; Mac users are explicitly told to use Ctrl+Space, not Cmd+Space. The page warns that some shortcuts may fail on non-US keyboards and in Vim/Emacs modes. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts, heading “Keyboard shortcuts,” shortcut table and caveat; page marked updated 5 months ago when checked October 26, 2026.

The official shortcut-reference PDF is dated May 31, 2023. It lists additional bindings, but the current common-shortcuts page does not enumerate them; regard those extras as **dated reference material, not a guarantee of current behavior**. Source: https://www.overleaf.com/latex/templates/overleaf-keyboard-shortcuts/pphdnzrwmttk.pdf, “Overleaf Keyboard Shortcuts,” pages 1–2, update date at page 1. Project search uses Ctrl/Cmd+Shift+F and excludes files above 2 MB; file-level search/replace excludes read-only content, including some imported files and files above 2 MB. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project, headings “Search and replace within the current file,” “How to access search and replace,” and “Project-wide search.”

Vim and Emacs are user-specific emulations, with None as the default; the official page places their setting in Project menu > Settings. It warns they do not support every native binding, browser-reserved Emacs combinations may be intercepted, and Vimium may interfere with Vim mode. Source: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding, headings “Vim and Emacs keybinding,” “Emacs,” “Vim,” and “Troubleshooting.” Custom Vim mappings through userscripts are not a supported product capability: Overleaf identifies the editor API as unstable and scripts as unsupported. Source: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding/providing-custom-vim-key-bindings, “Caution regarding Tampermonkey and UserScripts.”

Current redesigned-editor docs describe Settings in the left bar, with Editor options including autocomplete, code checking, editor language, and spell-check dictionary; Appearance includes editor/interface themes and fonts. This supersedes older menu-location wording where the two differ. Source: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor, “Project settings” (last updated one month before this research). Font size, family, and line-height controls are documented separately; the page describes fonts for Code and Visual editors and adjustment via editor settings. Source: https://docs.overleaf.com/navigating-in-the-editor/editor-display-font, “Editor display font” and following font-option headings. Specific ranges/font choices in upstream notes are **not independently verified in the current page evidence captured here** and are omitted as current guarantees.

Simple citation search is available to all users; advanced reference search is labeled premium. Both rely on autocomplete. This is a specific tier distinction, not evidence that general shortcuts, keybinding modes, or appearance preferences are tier-limited. Source: https://docs.overleaf.com/citing-and-references/adding-citations-and-references, “How can Overleaf help to find and cite references?” and “How to enable Overleaf’s auto-complete.” PDF-viewer shortcuts are separate from source editing and require viewer focus: Ctrl/Cmd +/-, 0, and 9 for zoom and fit; presentation navigation uses arrows, Space/Shift-Space, Backspace, PgUp/PgDn, with Esc to exit. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation, “Document navigation in presentation mode” and “Keyboard shortcuts.”

## Claim table

| claim | source | availability | evidence status |
|---|---|---|---|
| Common editor shortcuts and Mac substitution, except Ctrl+Space remains Ctrl | Keyboard shortcuts, “Keyboard shortcuts” | Tier not specified | Confirmed; layout/mode caveat explicit |
| Extra shortcut-reference bindings | Official PDF, pages 1–2 (May 31, 2023) | Tier not specified | Dated; current support not established |
| Project search and file search limits | Searching within a project, named headings | Tier not specified | Confirmed |
| None/Vim/Emacs modes; emulation/browser conflicts | Vim and Emacs keybinding, named headings | Tier not specified | Confirmed |
| Custom Vim userscripts | Providing custom Vim key bindings, caution section | Unsupported | Confirmed unsupported/unstable |
| Editor settings, spellcheck, language, code checking, autocomplete; appearance/themes/fonts | Redesigned Overleaf editor, “Project settings” | Tier not specified | Confirmed; current navigation differs from older descriptions |
| Exact font size range and choices | Editor display font, “Editor display font” | Tier not specified | Exact values not verified in current evidence; unresolved |
| Citation simple vs. advanced search | Adding citations and references, search headings | Simple: all users; advanced: premium | Confirmed, specific feature only |
| PDF viewer shortcuts and presentation navigation | PDF viewer options and navigation, named headings | Tier not specified | Confirmed; distinct from source editor |
| Any shortcuts for arbitrary LaTeX commands/packages | No supporting Overleaf editor source found | N/A | **UNRESOLVED**; no guarantee inferred |
| Free/premium/AI/Commons/Server Pro/Community Edition matrix for general editor settings | Current editor/keybinding pages above | Not specified | **UNRESOLVED**; no blanket tier claim |

## Counter-search queries

- `site:docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts Overleaf keyboard shortcuts`
- `site:docs.overleaf.com "redesigned Overleaf editor" "Project settings" editor language spell check`
- `site:docs.overleaf.com "Auto-complete" "premium" Overleaf citation search`
- `site:docs.overleaf.com "Keybindings" "Project menu" Overleaf`
- `site:docs.overleaf.com/navigating-in-the-editor/editor-display-font "10" "24"`

## Verdict

**PARTIAL.** Core documented behavior and known caveats are supported by current official pages. The linked comprehensive shortcut sheet is explicitly dated; exact font ranges from the upstream notes and a full tier matrix remain unresolved. No authenticated behavior or arbitrary LaTeX shortcut behavior is asserted.

## EXPAND

- **LEAD: General editor-setting tier matrix** — UNRESOLVED; current official editor/keybinding docs do not assign general shortcuts, modes, or appearance preferences across Free, premium, AI, Commons, Server Pro, and Community Edition.
- **LEAD: Additional shortcut bindings** — Partially resolved; the official reference was inspected but is dated May 31, 2023, and current docs do not confirm all its extra bindings.
- **LEAD: Exact font choices/ranges** — UNRESOLVED; current official font page confirms configurable editor font but the exact values in upstream notes were not independently verified in captured evidence.
- Arbitrary LaTeX macro/package shortcuts — UNRESOLVED and outside Overleaf editor-feature documentation; do not infer support.
