# Verify-1: Overleaf Code Editor syntax highlighting, autocomplete, linting

Date: October 26, 2026. Public official sources only. No authenticated tests, purchases, or functional execution. Pages were fetched and searched directly. Upstream files: harvest-1.md and expand-1.md.

**Verdict: PARTIAL.** Autocomplete, Code Check, and citation search are confirmed. The editor-theme `.tex` claim could not be found in the cited pages. One upstream claim (Error Assist on Code Check errors) is unsupported and was removed. Edition parity is unresolved.

## Claim table

| Claim | Source (heading) | Availability | Evidence status |
|---|---|---|---|
| Code Check flags mismatched `\begin`/`\end`, `{}`, `\left`/`\right`, `$`/`$$`, math-only and text-in-math commands | https://docs.overleaf.com/troubleshooting-and-support/code-check ("Code Check") | No plan restriction stated | CONFIRMED |
| Code Check uses heuristics and assumes standard LaTeX | same page ("Code Check limitations") | - | CONFIRMED |
| Code Check can be turned off globally (Settings > Editor > Code Check), per file (`%%novalidate`), or per region (`%%begin novalidate`/`%%end novalidate`) | same page ("Disabling Code Check") | Project setting | CONFIRMED |
| Known false positives: literal `%` in `\url`-like commands followed by code on the same line | same page ("Known issues") | - | CONFIRMED |
| Syntax checks run "as you type" and cover undefined commands and missing/extra `\begin`/`\end` | https://docs.overleaf.com/getting-started/recompiling-your-project ("Syntax checks") | - | CONFIRMED; the "unmatched braces/brackets" item is PARTIAL (not seen in the fetched text) |
| Editor settings include auto-complete, code checking, editor language, spell-check | https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor (Editor tab) | Project setting | CONFIRMED |
| Appearance tab switches editor and interface themes | same page ("Appearance") | - | CONFIRMED |
| Editor theme controls highlighting, is user-specific, and does not affect Visual Editor; LaTeX may need a `.tex` filename | https://nl.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu (cited as "Editor theme," lines 134-138) | - | UNRESOLVED: the phrases "theme," "highlight," and ".tex" are absent from both fetched pages (nl and www) |
| Ctrl+Space opens autocomplete; inside `\cite{}` it searches the bibliography; also Ctrl+Space on Mac | https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts (shortcut table) | - | CONFIRMED |
| Simple citation search is available to all users; advanced reference search is premium | https://docs.overleaf.com/citing-and-references/adding-citations-and-references (opening; "premium feature") | Advanced = premium | CONFIRMED |
| Citation search requires Editor > Auto-complete to be enabled | same page ("How to enable Overleaf's auto-complete") | - | CONFIRMED |
| Overleaf moved the source editor to CodeMirror 6; legacy editor retired June 14, 2023 | https://www.overleaf.com/blog/towards-the-future-a-new-source-editor (Nov 29, 2022, with update) | Historical | CONFIRMED |
| Autocomplete/highlighting "may differ" from legacy | same post | Historical | UNRESOLVED (phrase not found) |
| 2017: suggestions from used commands plus top-100 corpus commands; fuzzy search via Fuse.js; package-based suggestions as future work | https://www.overleaf.com/blog/523-a-data-driven-approach-to-latex-autocomplete (Aug 24, 2017) | Historical, 2017 | CONFIRMED as history only; not current behavior |
| 2017: `\ref` labels checked continuously for autocomplete | https://www.overleaf.com/blog/auto-complete-ref-commands-2017-06-15 (archival ShareLaTeX post) | Historical, 2017 | CONFIRMED as history only |
| Error Assist explains compile errors and suggests fixes ("Suggest fix," shared daily AI allowance) | https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist ("Using Error Assist," "AI allowance") | Daily allowance, plan-based | CONFIRMED |
| Error Assist does not offer "Suggest fix" for Code Check errors | same page | - | UNSUPPORTED: text not found; REMOVED from the report |
| AI is bundled into plans from July 2, 2026; Free = Basic without Assistant; Student = Basic with Assistant; Commons AI adds Max + Assistant | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans (July 2, 2026) | Plan-dependent (Free, Student, Pro, Commons confirmed; Standard not checked) | CONFIRMED except Standard (UNRESOLVED) |
| Error Assist docs describe an "AI Assist add-on" | same Error Assist page | - | UNRESOLVED: phrase absent; the body describes a plan-level daily allowance, which is consistent with the July 2026 bundling |
| Community Edition vs Server Pro distinction; no feature mapping for these editor features | https://docs.overleaf.com/on-premises/installation/introduction | Edition-dependent | CONFIRMED distinction; parity UNRESOLVED |
| Error logs pane shows LaTeX errors, warnings, and compiler output | redesigned-editor page ("Error logs") | - | CONFIRMED |
| CodeMirror autocomplete/lint packages in the official repository | https://github.com/overleaf/overleaf/blob/main/package.json | - | UNRESOLVED (not fetched in this pass) |
| Legacy-editor retirement dated April 24, 2023 at a "were-retiring" URL | upstream only | - | UNRESOLVED; URL was truncated and not verified; dropped |

## Corrections to upstream files

- Removed: "Error Assist does not offer Suggest fix for Code Check errors." Unsupported by the cited page.
- Downgraded: the `.tex` filename and theme-scope claims (no primary text found).
- Downgraded: "AI Assist add-on" packaging. The July 2, 2026 plan post supersedes it for plan packaging, but the docs' own wording was not found.
- Kept but date-tagged: all 2017 autocomplete material.

## Limitations

- Code Check is a heuristic. Passing checks do not mean LaTeX compiles, and the docs do not claim completeness.
- Highlighting grammar coverage, the exact completion corpus, and package- or custom-macro-aware completion remain UNRESOLVED.
- No edition-specific mapping was found for Community Edition or Server Pro.

## Counter-search queries (for future waves)

1. `site:docs.overleaf.com editor theme syntax highlighting .tex`
2. `site:docs.overleaf.com auto-complete editor setting`
3. `site:docs.overleaf.com Code Check novalidate`
4. `site:docs.overleaf.com Error Assist AI Assist add-on plan`
5. `site:docs.overleaf.com on-premises Community Edition Server Pro features editor`
6. `site:overleaf.com blog CodeMirror 6 source editor legacy retirement`

## EXPAND

- LEAD: exact syntax-highlighting modes, file-extension rule, and theme scope. UNRESOLVED; the cited nl.overleaf text was not found. Next: search for the current "Editor theme" help article.
- LEAD: current completion corpus and package/custom-macro awareness. UNRESOLVED; only 2017 material exists.
- LEAD: Standard plan AI allowance and "AI Assist" wording in Error Assist docs. UNRESOLVED.
- LEAD: Community Edition / Server Pro parity for these editor features. UNRESOLVED; no public mapping found.
- LEAD: official repository CodeMirror dependency check. Not performed in this pass. Low priority, since dependencies do not establish shipped behavior.
