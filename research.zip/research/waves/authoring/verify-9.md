# Verify 9: Accessibility, screen readers, and tagged PDF workflows

Checked: October 26, 2026 (task date). Method: fetched primary Overleaf docs, Overleaf blog posts, and the LaTeX Tagging Project pages, and matched upstream claims against them. No web search was run, no compile or screen-reader test was done, and no authenticated or paid checks were made.

**Verdict: PARTIAL.** Core tagging setup and the platform accessibility statements are confirmed. Plan/edition availability, the VPAT contents, and project-level TeX Live versions are unresolved. Several upstream details were corrected.

## Claim table

| Claim | Source (exact URL, heading) | Availability | Evidence status |
|---|---|---|---|
| Web editor uses browser accessibility features; latest VPAT shows WCAG 2.2 AA | https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs, "Is the Overleaf editor accessible?" | Web product, not plan-specific | Confirmed (docs) |
| Product tested with screen-reading technology; OpenDyslexic Mono and dark mode options | https://www.overleaf.com/blog/accessible-pdfs-with-latex (Jan 29, 2026) | Web editor; dated Jan 2026 | Confirmed (blog) |
| VPAT page exists with a "Current version" link | https://www.overleaf.com/for/customers/vpat | Public | Partly confirmed: landing page loads; linked VPAT document NOT opened. Upstream "returned only a contact form" is a mis-description. |
| Keyboard shortcut list; some may not work on non-US keyboards or Vim/Emacs modes | https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts | Editor | Confirmed (caveat text). Does not prove full keyboard operability. |
| Enable tagging with `\DocumentMetadata{tagging=on}` before `\documentclass` | https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs, "tagging" / "Tagging and \DocumentMetadata" | LaTeX via Overleaf compiler | Confirmed |
| `tagging=draft` omits tags in output | same page, "tagging" | LaTeX | Confirmed |
| Select TeX Live 2025 or later | same page, "Selecting a TeX Live version" | Compiler setting; plan access unstated | Confirmed (requirement). Plan access UNRESOLVED. |
| `pdfstandard=ua-2` recommended; UA-1 may be needed for older readers | same page, "pdfstandard" | LaTeX | Confirmed |
| `lang` default en-US; tells screen readers pronunciation | same page, "lang" | LaTeX | Confirmed (default, pronunciation). Upstream "only sets PDF metadata" NOT verified. |
| Figures: `alt`, `artifact`, `actualtext`; `\includegraphics`, `picture`, `tikzpicture` accept keys | same page "Descriptions"; https://www.overleaf.com/blog/tex-live-2026-is-now-available, "Graphics and figures now carry meaning too" | LaTeX | Confirmed (TL2026 blog for graphic commands) |
| Tables: `table/header-rows`, `table/tagging=presentation` | docs "Tables"; https://tagging-project.latex-project.org/documentation/usage-instructions | LaTeX | Carried from upstream; NOT re-checked in this pass |
| Math: `mathml-SE` needs LuaLaTeX; `\MathMLintent`, `\MathMLarg`; needs `unicode-math` or `lua-unicode-math` | TL2026 blog, "Accessible math, with meaning" | LaTeX; TL2026 | Confirmed (blog). `mathml-AF` route carried from upstream, not re-checked. |
| Tagging out of prototype for supported packages/classes | TL2026 blog, "Tagged, accessible PDF has left the prototype stage" | LaTeX; TL2026 | Confirmed |
| Beamer incompatible with tagging; `ltx-talk` experimental | docs "FAQs" (beamer question) | LaTeX | Confirmed. CORRECTION: docs say ltx-talk needs "a more recent version of TeX Live 2025" than Overleaf's default, not "TeX Live 2026 or Labs" as upstream stated. |
| Package compatibility status list (2245 entries) | https://latex3.github.io/tagging-project/tagging-status/ | Public | Confirmed (page exists) |
| `tabu`/`tabls` unsupported in TL2026; `frenchb`/`francais` obsolete | TL2026 blog, "Unsupported tabular-related packages", "babel obsolete language options" | TL2026 | Confirmed. `titlesec` "not fully compatible" with tagging code, emulation in progress (blog). `flowfram`, `enumerate`/`theorem`/`verbatim` legacy: NOT verified. |
| Validators: veraPDF, ngPDF; results vary | docs "FAQs" | External tools | Confirmed. Overleaf provides no built-in validation. |
| Built-in "Export as HTML"; GitHub sync alternative | docs "LaTeX to HTML" | Overleaf feature; plan access unstated | Confirmed |
| ADA Title II: WCAG 2.1 AA by April 26, 2027 (2028 for smaller entities) | docs "Regulations" | Legal context | Confirmed (docs). CONTRADICTED by Jan 2026 blog ("goes into effect April 2026"). UNRESOLVED; check the rule text. |
| Server Pro: point `TEX_LIVE_DOCKER_IMAGE` at TL2026 image | TL2026 blog, "TeX Live 2026 in Server Pro" | Server Pro | Confirmed in blog only. Not checked in Server Pro docs. |
| Project TeX Live versions: 2026-06-11 only 2025-11-01 via Rolling TeXLive, else 2025-06-01 | https://tagging-project.latex-project.org/documentation/usage-instructions | Overleaf | Confirmed as stated on that date. SUPERSEDED-LIKELY by TL2026 blog (Aug 18, 2026: switch in Settings > Compiler). Live-project check UNRESOLVED. |
| Jan 2026 blog: "PDF/UA-1 (and the upcoming PDF/UA-2)" | https://www.overleaf.com/blog/accessible-pdfs-with-latex | Legacy | Date-tagged outdated; docs now recommend UA-2. |
| Oct 14, 2026 "Bridging the accessibility gap" post (Commons AI claim) | https://www.overleaf.com/blog/bridging-the-accessibility-gap | Commons | URL returns 404. UNRESOLVED; remove from harvest or mark unsourced. |
| Free vs premium access to tagging / TL2025-2026 | None found in the reviewed pages | Plan | UNRESOLVED |
| Labs entitlement / rolling TeX Live terms | docs describe Labs as experimental route | Labs | UNRESOLVED (login gate, not opened) |
| Community Edition / On-premises tagging support | None found | Community Edition | UNRESOLVED |
| AI bundled July 2, 2026 | Out of this angle | AI | UNRESOLVED here |

## Corrections to upstream

1. VPAT: the landing page is real, not a contact form. Its VPAT document itself is unread.
2. ltx-talk: docs say "more recent TeX Live 2025", not "TeX Live 2026".
3. Oct 14, 2026 Commons/accessibility post: 404, so it cannot support any claim.
4. ADA dates conflict between docs and the Jan 2026 blog.
5. The "only sets PDF metadata" wording for `lang` is not in the sources checked.

## Limits

Tagging does not make an output accessible. Alt text and heading meaning need human review, and no PDF was compiled or checked here. Nothing in this report confirms screen-reader behavior.

## Counter-search queries (proposed, not run)

- `site:docs.overleaf.com tagging-setup pdfstandard`
- `Overleaf TeX Live 2026 Settings Compiler plan`
- `Overleaf Labs rolling TeX Live`
- `ADA Title II web accessibility rule April 2026 compliance date`
- `Overleaf VPAT WCAG 2.2 pdf`
- `LaTeX Tagging Project flowfram enumerate theorem verbatim status`

## EXPAND

- LEAD: Open the Overleaf VPAT PDF and check its test matrix. Status: open.
- LEAD: Confirm plan and Community Edition access to TeX Live 2025/2026 tagging. Status: UNRESOLVED; no public source states it.
- LEAD: Confirm the TeX Live version offered in a live project (2025-11 vs 2026). Needs an authenticated check. Status: open.
- LEAD: Confirm Labs entitlement and terms. Status: open.
- LEAD: Confirm the ADA Title II effective date from the rule text. Status: open.
- LEAD: Re-check table and `mathml-AF` syntax and the `flowfram`/`enumerate` status. Status: open.
- LEAD: Validate a real compiled PDF's structure, reading order, alt text, and screen-reader output. Status: open; nothing executed here.
