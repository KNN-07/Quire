# Expand 5: Math insertion, equation editing, symbol palette

Checked October 26, 2026. Primary pages were opened unless marked "search snippet" or "harvest-cited." No authenticated tests, purchases, or hands-on execution were performed.

## Symbol Palette

- **Availability: Premium, account-level.** The docs say the palette is a premium feature and that a premium subscriber "always has access to this feature regardless of which project they are working on." Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features ("Symbol Palette" and "Account and project level features"). Free-plan access is not documented as available.
- **Opening and use.** The Ω button opens the palette in the Code Editor or Visual Editor, at the bottom of the editor. Symbols can be browsed or searched by name or alias. Source: https://docs.overleaf.com/writing-and-editing/inserting-symbols ("Using the Symbol Palette").
- **Math mode required.** Palette symbols must be placed in math mode (`\( \)`, `$ $`, `math`, `\[ \]`, `equation`). Inserting them outside math mode can cause errors such as `Missing $ inserted`. Source: same page, "Math mode." This is LaTeX behavior that the palette does not automatically handle.
- **Package hints.** Hovering a symbol shows the package it needs, for example `amsmath` for `\iint`. Source: same page, "Required packages."
- **Legacy (2021).** The launch blog, https://www.overleaf.com/blog/new-feature-find-symbols-quicker-with-our-new-symbol-palette-for-premium (November 2021), describes the same premium-only palette. Its trial and discount text is 2021-era and is not treated as current. Current docs and the 2021 blog agree on premium gating, so no conflict is recorded.

## Equation generator and AI

- **Current AI bundling (July 2, 2026).** The blog says "Overleaf AI is now included in all Overleaf plans at no extra cost," with allowances varying by plan. Commons AI gives the Max allowance and AI Assistant. Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans.
- **Equation Generator.** The current AI feature docs list it as converting plain English into LaTeX math code, and the "What's included" table says it converts "an image or natural language into LaTeX math." Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features ("Feature" table, "What's included"). It is reached from the Insert menu or the TeXGPT button. Source: same page, "Where to find AI tools."
- **Plan allowances (current docs).** Free: Basic, no AI assistant. Student: Basic, with AI assistant. Standard: Standard, with AI assistant. Pro: Max, fair use. Commons: Basic, no AI assistant. Commons AI: Max, with AI assistant. Each AI use counts against a 24-hour allowance. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features ("AI allowance by plan"). The July 2026 blog's plan descriptions match this table.
- **Access exceptions.** Organization-managed accounts, or institutions that opted out, cannot use AI features. Source: same docs page, "Who can use Overleaf AI."
- **Legacy naming (not combined).** Older pages describe "AI Assist add-on" and a per-day Error Assist limit. Example: a search snippet from https://cs.overleaf.com/learn/latex/Error_Assist ("Daily use limits"). Those statements predate the July 2026 bundling and are date-tagged as legacy. They are not used for current claims here.

## Editing and insertion

- **Editor surfaces.** The redesigned editor keeps a Code/Visual toggle at the top left of the editing pane. Source: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor ("Getting Started").
- **Right-click menu.** The contextual menu documents Cut, Copy, Paste, Delete, Comment, and Jump to PDF. No math-specific entries are documented. Source: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor/contextual-menu ("Common Actions," "Specialized tools").
- **Keyboard shortcuts.** The documented table covers find, compile, undo, comment toggle, bold, italic, and autocomplete. It does not list math or equation shortcuts. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts.
- **amsmath constructs (harvest-cited, not re-opened in this pass).** `split`, `multline`, `align`, and `gather` are LaTeX package environments. They are not a visual equation editor. Source: https://www.overleaf.com/learn/latex/Aligning_equations_with_amsmath (cited in harvest-5).

## Community Edition and deployment

- A closed GitHub issue, https://github.com/overleaf/overleaf/issues/1424 (created November 24, 2025; updated May 5, 2026), shares a third-party floating symbol-palette plugin for Community Edition. It is not an Overleaf-maintained feature. Its existence does not show that the palette is in the official Community Edition build.
- Search snippets from forks, such as https://github.com/yu-i-i/overleaf-cep and a davrot fork with "Enable Symbol Palette" commits, indicate third-party work. They are not official evidence.

## Duplicates closed

- The 2021 blog and current premium docs both state premium gating. Closed in favor of the current docs.
- The harvest's "Pro and Commons AI: Max" row matches the current plan table. Closed.

## UNRESOLVED

- **Symbol Palette on Server Pro or Community Edition.** No official deployment page reviewed establishes parity. Do not infer it from the hosted service.
- **Non-AI graphical equation editor.** No official page reviewed documents fraction, root, or template insertion, or equation-specific shortcuts.
- **Equation Generator constraints.** Accepted image formats, size limits, and math-complexity limits are not stated. Correctness is not guaranteed by any reviewed page.

## EXPAND

- LEAD: Check Server Pro and Community Edition documentation or the official overleaf/overleaf repository for Symbol Palette and Equation Generator availability. Reason: current docs state premium and plan entitlements, but not deployment parity.
- LEAD: Check whether Visual Editor offers any math-specific insertion or editing controls beyond the Insert menu. Reason: reviewed pages do not document one.
- LEAD: Find the Equation Generator's accepted image formats and limits. Reason: the AI feature page describes conversion but leaves inputs unspecified.
