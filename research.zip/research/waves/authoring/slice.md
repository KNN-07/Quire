# Authoring inventory slice

Cutoff: October 26, 2026. Overleaf documents source and visual authoring, navigation, configurable editing, math/table/image tools, reference workflows, spelling/language controls, and accessible-PDF guidance. This slice consolidates the ten verified authoring angles, including the challenge corrections. **Evidence status: documented, not runtime tested.** No authenticated session, compilation, PDF validation, or assistive-technology test was performed. Unspecified plan or edition availability is not evidence of absence. Current live documentation takes precedence over stale indexed snippets; undated pages are not historical snapshots. No arbitrary LaTeX package, macro, font, or visual round-trip guarantee is implied.

## Feature matrix

URLs identify primary documentation; supplemental sources and contradiction handling follow.

| Feature | Behavior | Availability/limits | Primary URL |
|---|---|---|---|
| 1a. Code Editor | Source editing, autocomplete, themes, and Code/Visual switching. | Completion corpus, precise highlighting grammar, and subfeature deployment parity are not established. The current Code Editor is distinct from the retired legacy source editor. | https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor ; https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts |
| 1b. Code Check | Highlights common delimiter, environment, and math-context mistakes while typing; disable globally, by file, or by region. | Heuristic rather than a compiler; does not expand custom environment macros. Error Assist does not handle these as-you-type errors. | https://docs.overleaf.com/troubleshooting-and-support/code-check ; https://docs.overleaf.com/integrations-and-add-ons/ai-features |
| 2. Visual/source interoperability | Switch modes; generated tables remain source-editable, with additional Visual Editor formatting controls. | Complex tables may preview partly or entirely as source. Specific table/image paste workflows do not establish universal formatted paste or lossless arbitrary-LaTeX rendering. | https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables ; https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor |
| 3a. Navigation and outline | Resizable panes, source/PDF jump controls, file tree, and current-file heading outline. | Outline omits headings in included files and does not expand arbitrary macros. Exact outline parity between modes is unassigned. | https://docs.overleaf.com/navigating-in-the-editor/selecting-and-managing-files ; https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor |
| 3b. Search | Current-file find/replace supports case, regex, word, and selection filters; project search finds text across files. | Current-file replacement requires an editable file. Project search excludes files larger than 2 MB; project-wide replacement is not established. | https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project |
| 4a. Shortcuts | Compile, undo/redo, search, navigation, formatting, indentation, autocomplete; optional Vim/Emacs bindings. | Mac generally uses Cmd, but autocomplete remains Ctrl+Space. Vim/Emacs are user-specific emulations, not complete native implementations; browser/layout conflicts apply. Custom userscripts are unsupported. | https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts ; https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding |
| 4b. Display preferences | Editor font size, font-family choices, line height, and appearance controls. | Documented size is 10-24 px, three font-family groups, and Compact/Normal/Wide line heights. Full tier matrix unspecified. | https://docs.overleaf.com/navigating-in-the-editor/editor-display-font ; https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor |
| 5a. Symbol Palette | Search and insert math-mode symbols in either editor mode; identify required packages. | Premium hosted feature; Server Pro includes it, Community Edition does not in the edition comparison. Not a general graphical equation editor. | https://docs.overleaf.com/writing-and-editing/inserting-symbols ; https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition |
| 5b. Equation Generator | Converts an image or natural language into LaTeX math. | Uses shared daily AI allowance; generator format/size limits and self-hosted availability remain unassigned. | https://docs.overleaf.com/integrations-and-add-ons/ai-features |
| 6a. Tables | Insert/generate tables, paste supported tabular content, edit source, or use AI generation. | Visual Editor offers extra formatting. AI generator consumes shared allowance; no separate table quota established. | https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables ; https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables/pasting-tables-into-your-project ; https://docs.overleaf.com/integrations-and-add-ons/ai-features |
| 6b. Figures | Insert Figure accepts device, project, other-project, or URL images, with caption, label, and width controls. | Requires `graphicx`; cloud insertion entitlement matrix unspecified. Crop/retouch tools are unconfirmed. | https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button |
| 6c. Image paste | Paste one image in either mode; image is saved as PNG. | Preview is Visual Editor-only; multiple-image paste unsupported. | https://docs.overleaf.com/writing-and-editing/inserting-images/pasting-images-into-your-project |
| 7a. Citation search | Project `.bib` workflows and simple citation-key search; advanced search uses additional reference fields/providers. | Advanced search is Premium. Current label-command autocomplete coverage is separate and unresolved. | https://docs.overleaf.com/citing-and-references/adding-citations-and-references/searching-for-references |
| 7b. Account Library | Account-level BibTeX/BibLaTeX repository; form/code entry, DOI lookup, `.bib` upload; citing copies data into project `.bib` files. | Library edits do not update already-cited project entries: edit the project entry or remove/re-add its citation. This is not continuous synchronization. | https://docs.overleaf.com/citing-and-references/library |
| 7c. ReadCube reference routes | Bulk import produces a refreshable, read-only `.bib`; individual advanced-search imports remain editable. | Paid reference-manager integration. Manual `.bib` upload is a separate fallback, not the integration. | https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md |
| 8. Spelling and language | Distinct editor-language and spell-check dictionary controls; spell check can be disabled. Writefull model selection is under Spelling and language. | Grammarly is not directly integrated or officially supported and can mishandle LaTeX. Custom-word persistence, dictionary scope, and detailed spell-check entitlements are unresolved. | https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor ; https://docs.overleaf.com/integrations-and-add-ons/grammarly ; https://docs.overleaf.com/integrations-and-add-ons/ai-features |
| 9a. Accessible PDF authoring | Tagging guidance places `\DocumentMetadata` before `\documentclass`; covers image descriptions, table headers/presentation tables, and MathML SE/AF. | TeX Live 2025+; MathML SE requires LuaLaTeX. Tagging does not guarantee accessible output; external validation and human review are necessary. | https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs |
| 9b. Accessibility evidence and experiments | Vendor publishes a dated VPAT; Labs offers opt-in experiments, including a rolling TeX Live route. | VPAT is a qualified report, not unconditional WCAG certification. Labs can change or disappear; rolling TeX Live is experimental, untested by Overleaf, and unsupported. | https://www.overleaf.com/for/customers/vpat ; https://docs.overleaf.com/accounts-and-security/overleaf-labs ; https://docs.overleaf.com/troubleshooting-and-support/tex-live |
| 10a. Encoding | UTF-8 source support; non-UTF-8 integration inputs may be read-only. NUL storage and non-BMP editing are restricted. | Emoji documentation explicitly allows uploaded non-editable UTF-8 files containing non-BMP text for inclusion; broader encoding-page wording conflicts. Do not claim non-BMP typing/paste support. | https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings ; https://www.overleaf.com/learn/latex/Questions/Inserting_emojis_in_LaTeX_documents_on_Overleaf |
| 10b. Multilingual typesetting | Documentation covers non-Latin language workflows and XeLaTeX/LuaLaTeX font/language choices. | Compiler/font guidance does not prove current bidirectional editor behavior. Glyph/package support remains conditional; no universal language entitlement matrix is established. | https://docs.overleaf.com/troubleshooting-and-support/typesetting-non-latin-languages ; https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_polyglossia_and_fontspec |

## Ten-angle coverage map

| Angle | Covered rows | Boundary retained |
|---|---|---|
| 1 Code Editor | 1a-1b | Highlighting/completion corpus; edition parity |
| 2 Visual/source | 2, 6a-6c | Bounded previews and paste, no universal round trip |
| 3 Navigation | 3a-3b | Included-file outline, 2 MB search cutoff, replacement scope |
| 4 Preferences/shortcuts | 4a-4b | Emulation and browser conflicts |
| 5 Math | 5a-5b | Premium palette; shared AI allowance |
| 6 Tables/figures | 6a-6c | Specific insertion/paste controls only |
| 7 References | 7a-7c | Library copying versus provider refresh |
| 8 Spelling/language | 8 | Dictionary provenance versus runtime implementation |
| 9 Accessibility | 9a-9b | Output not validated; Labs experimental |
| 10 Multilingual/Unicode | 10a-10b | Typesetting versus editor behavior |

## Resolved contradictions and freshness decisions

1. **AI commercial wording:** live allowance documentation and the July 2, 2026 announcement supersede indexed AI Assist add-on wording. Generator invocations use the shared allowance, resetting every 24 hours. Free/ordinary Commons exclude Assistant; Student, Standard, Pro, and Commons AI include it. Pricing documents 5 daily uses for Free/Student and 10 for Standard; Max is subject to fair use. Do not translate AI availability into all-plan Assistant access. Sources: https://docs.overleaf.com/integrations-and-add-ons/ai-features ; https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans ; https://www.overleaf.com/user/subscription/plans
2. **Removed AI actions:** the live overview still lists Summarize/Explain, but Troubleshooting explicitly says those named actions were removed. Record them as removed with an internal stale-overview conflict, not current inventory features. The former Writefull toolbar was removed and its tools relocated. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features
3. **Library synchronization:** the opened live Library page explicitly rules out update propagation to already-cited project entries. This resolves the supplement's earlier unasserted propagation question. Provider refresh remains a distinct ReadCube workflow, not Library behavior. Sources: https://docs.overleaf.com/citing-and-references/library ; https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md
4. **Unicode conflict:** the encoding page broadly rejects non-BMP storage, while the live emoji article permits uploaded non-editable non-BMP files. Preserve the specific upload/include route and the editing restriction; the storage wording remains internally inconsistent, not experimentally resolved. Sources: https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings ; https://www.overleaf.com/learn/latex/Questions/Inserting_emojis_in_LaTeX_documents_on_Overleaf
5. **Hosted versus self-hosted:** both on-prem editions document a LaTeX editor and full project history. Hosted Free retention is not a CE limit; the comparison does not establish exact editor subfeature parity or CE absence of simultaneous editing. Symbol Palette attribution is explicit. Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
6. **Legacy and cutoff:** old project-menu and formatted-paste guides now redirect, so their indexed claims do not establish current runtime spell-check engines, highlighting, or general paste support. One original math verifier used an October 27 date; reconciliation independently reopened the retained claims, without treating that future date as cutoff evidence. TeX Live 2026 has a pre-cutoff announcement; accessible-PDF guidance is not limited to experimental images. Sources: https://www.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu ; https://www.overleaf.com/learn/how-to/How_to_paste_formatted_content_into_Overleaf ; https://www.overleaf.com/blog/tex-live-2026-is-now-available

## Unresolved annex

These are documentation boundaries, not feature-absence findings:

- Exact hosted/CE/Server Pro matrices for editor subfeatures, insertion controls, spell check, language features, and accessible-tagging access.
- Exact highlighting/completion corpus, arbitrary macro behavior, label-autocomplete command/refresh coverage, outline mode parity, and shipped CE citation-search version.
- Equation-generator accepted formats/size limits and self-hosted availability; a general non-AI graphical equation editor; image crop/retouch.
- Spell-check custom-word persistence/shared scope and runtime engine. The official dictionaries repository establishes Hunspell-derived dictionary provenance only: https://github.com/overleaf/dictionaries
- Current RTL/bidirectional editing and actual accessible PDF/screen-reader outcomes.

The verifier's verdict is **PASS with explicit caveats**, not a remaining verification FAIL. No runtime acceptance claim is made. The Unicode and AI overview conflicts remain disclosed; no extra public-source research or account test is deferred as a prerequisite to this inventory.

## Bounded source map for final report author

The matrix URLs are the primary source list. Use these controlling groups rather than stale search snippets:

| Report topic | Controlling sources / locator |
|---|---|
| Core editor, navigation, preferences | Matrix 1a-4b; current redesigned editor, Code Check, managing files, searching, keyboard shortcuts, display font, Vim/Emacs |
| Math, tables, images | Matrix 5a-6c; Symbol Palette, table/paste, Insert Figure/image paste; AI parent page controls shared allowance |
| Bibliography | Matrix 7a-7c; reference search, Library, ReadCube. Library headings: Using the Library in projects; Managing your Library |
| Spelling | Matrix 8; Grammarly limitations; dictionary repository linked in annex |
| Accessible output and product report | Matrix 9a-9b; Creating accessible PDFs; VPAT landing page links the May 2025 ACR. Its qualified findings are not a current blanket certification |
| Unicode/languages | Matrix 10a-10b; compare encoding with emoji article's Emoji characters and the Overleaf editor |
| Commercial/deployment limits | Contradictions 1 and 5; current pricing plus July 2 announcement; on-prem edition comparison |
| Historical/experimental labels | Contradictions 2 and 6, matrix 9b; removed named AI actions/toolbar, retired legacy editor, redirecting old guides, opt-in Labs |

Audit inputs: `brief.md`, `lead-supplement.md`, `expand-cluster-2.md`, and `verify-cluster-2.md`. The reconciliation closes all 39 original EXPAND items; its source/closure tables retain the detailed trail. This reduction reopened consequential Library, AI, and non-BMP primary content; it did not repeat the completed wide research.
