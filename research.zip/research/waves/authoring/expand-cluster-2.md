# Authoring cluster reconciliation

Cutoff: October 26, 2026. Inputs: brief, lead-supplement, verify-1 through verify-10. Public primary documentation only; no account actions, compilation, screen-reader testing, or runtime acceptance testing. All ten angles and all 39 EXPAND items are covered below. Angle 5's October 27 access date is not evidence of availability on October 26; its retained claims were independently reopened here or corroborated by pre-cutoff announcements. Undated live documentation is not a historical snapshot.

## Consolidated claim table

Evidence labels describe documentation, not tested behavior. Unassigned entitlement means undocumented, not unavailable.

| Angle | Corrected consolidated claim | Availability / evidence |
|---|---|---|
| 1 Code Editor | Autocomplete and Ctrl+Space are documented. Code Check detects common delimiter/environment and math-context mistakes; it is heuristic, does not expand custom environment macros, and can be disabled globally, per-file, or per-region. Appearance controls themes. Exact highlighting grammar and completion corpus are not established. | Documented: S1-S3. No blanket deployment parity. The parent AI page explicitly excludes as-you-type Code Check errors from Error Assist; verify-1's removal of that restriction was overcautious (S9, Troubleshooting). |
| 2 Visual/source interoperability | Code/Visual switching remains supported. Generated tables can be edited as source; complex tables may preview partly or entirely as source. Visual preview is not a lossless arbitrary-LaTeX guarantee. Paste support is bounded by the specific table/image documentation. | Documented: S1, S6-S8. General plan/edition matrix unspecified. Current Code Editor must not be confused with the retired legacy source editor. |
| 3 Navigation | Resizable panes, source/PDF jump controls, file tree, current-file outline, file search/replace and project search are documented. Outline omits included-file headings and does not expand arbitrary macros. In-file search supports case, regex, word and selection filters; read-only files cannot use it. Project search excludes files larger than 2 MB; project-wide replacement is unasserted. | S1, S4-S5. Server Pro project search explicitly appears in 6.1.0 notes (S16). Mode-specific outline parity remains undocumented. |
| 4 Shortcuts/preferences | Common shortcuts cover compile, undo/redo, find, navigation, formatting, indentation and autocomplete. Mac generally substitutes Cmd, but Ctrl+Space stays Ctrl. Vim/Emacs are user-specific emulations, not complete native implementations; browser/layout conflicts apply. Font size is 10-24 px; three font-family groups and Compact/Normal/Wide line height are documented. | S2-S3, S24-S25. Custom userscripts are unsupported. Extra dated shortcut-sheet bindings are not independently current guarantees. |
| 5 Math | Premium Symbol Palette works in both modes, searches symbols for math mode and identifies required packages. Equation Generator accepts an image or natural language and produces LaTeX. No general non-AI graphical equation editor is established. | S9, S11. Palette: Server Pro yes, CE no (S15). Generator self-hosted availability and input-format limits remain unasserted. |
| 6 Tables/figures | Tables can be inserted, pasted, source-authored or AI-generated; Visual Editor supplies additional formatting controls. Insert Figure accepts device/project/other-project/URL images with caption, label and width settings, requiring `graphicx`. Single-image paste works in either mode, saves PNG and previews only in Visual; multiple-image paste is unsupported. | S6-S8, S12. Cloud insertion entitlements unspecified. AI table generation uses plan-wide allowance, not a documented separate quota (S9-S10). Crop/retouch tools unconfirmed. |
| 7 References | Project `.bib` workflows and simple citation-key search are documented; advanced field/provider search is Premium. Library is account-level, accepts DOI/BibTeX/BibLaTeX/upload data and copies cited entries into project `.bib` files. ReadCube bulk imports are refreshable/read-only; individual advanced-search imports are editable. | S13-S14, S26; supplementary omission corrected. S14 now explicitly says Library edits do NOT update existing project entries: edit the project entry or remove/re-add its citation. Current label-autocomplete coverage and CE shipped citation-search version remain unresolved. |
| 8 Spelling/language | Editor language and spell-check dictionary controls are distinct. Built-in spell check can be switched off in Settings; Grammarly is neither directly integrated nor officially supported and can mishandle LaTeX. The official dictionary repository contains Hunspell-derived UTF-8 dictionaries, not proof of a particular current runtime engine. Writefull model selection lives under Spelling and language. | S1, S9, S17-S18. Current dictionary persistence/custom-word behavior and detailed spell-check entitlements are not established. |
| 9 Accessibility | Tagging uses `\DocumentMetadata` before `\documentclass`, with TL2025+; TL2026 is publicly announced pre-cutoff. Tagging alone does not guarantee accessible output. Current docs cover image descriptions, table headers/presentation tables and MathML SE/AF; SE requires LuaLaTeX. External validation and human review remain necessary. | S19-S21. VPAT is a dated conformance report with qualifications, not unconditional WCAG certification. No PDF or assistive-technology execution here. |
| 10 Multilingual | Source uses UTF-8; NUL storage and non-BMP editing are restricted. S22 broadly prohibits non-BMP storage, but S31 explicitly permits uploaded, non-editable non-BMP files for inclusion: retain this documentation conflict, not a universal storage ban. Git/Dropbox non-UTF-8 inputs can be read-only. Xe/LuaLaTeX language/font guidance is distinct from editor RTL behavior. S22 says TL2022 for default input encoding, not universal LaTeX history. | S22-S23, S31. Font/glyph/package coverage is conditional. Current RTL editing and detailed entitlements remain unresolved. |

### Shared AI correction

S9's live allowance table and S10's July 2 announcement agree: Free and ordinary Commons have Basic without AI Assistant; Student has Basic with Assistant; Standard includes Assistant; Pro/Commons AI have Max subject to fair use. S10 pricing gives Free 5 and Standard 10 daily uses. Generator invocations consume the shared allowance, resetting every 24 hours. "AI included in all plans" does not mean every plan includes Assistant. Cached add-on/unlimited/separate-quota descriptions are stale; Error Assist's live page also uses shared allowance. Summarize/Explain remain in an introductory table but are explicitly removed in Troubleshooting: preserve that internal conflict (S9).

## Sources reopened

IDs below give exact URLs and relevant headings; references in the closure table reuse these.

| ID | Exact official URL | Heading/location |
|---|---|---|
| S1 | https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor | Getting Started; Project settings |
| S2 | https://docs.overleaf.com/troubleshooting-and-support/code-check | Code Check limitations; Disabling Code Check globally |
| S3 | https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts | Keyboard shortcuts |
| S4 | https://docs.overleaf.com/navigating-in-the-editor/selecting-and-managing-files | Supported heading commands; Navigating within your files using the File Outline |
| S5 | https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project | Search and replace within the current file; Project-wide search |
| S6 | https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables | Using Insert Table to generate a table; FAQs about tables |
| S7 | https://docs.overleaf.com/writing-and-editing/generating-and-inserting-tables/pasting-tables-into-your-project | Pasting tables into your Overleaf project |
| S8 | https://docs.overleaf.com/writing-and-editing/inserting-images/pasting-images-into-your-project | Pasting images into your project |
| S9 | https://docs.overleaf.com/integrations-and-add-ons/ai-features | What's included; AI allowance by plan; Troubleshooting |
| S10 | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans ; https://www.overleaf.com/user/subscription/plans | What each plan includes; Compare all features |
| S11 | https://docs.overleaf.com/writing-and-editing/inserting-symbols | Using the Symbol Palette; Required packages |
| S12 | https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button | Upload from computer; From project files; From another project; From URL |
| S13 | https://docs.overleaf.com/citing-and-references/adding-citations-and-references/searching-for-references | How to use simple search; Benefits of advanced reference search |
| S14 | https://docs.overleaf.com/citing-and-references/library | Overview of how to use the Library; Managing your Library |
| S15 | https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition | Benefits for users |
| S16 | https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x | Server Pro 6.1.0; 6.3.0; 6.3.2 |
| S17 | https://docs.overleaf.com/integrations-and-add-ons/grammarly | How to use Grammarly with Overleaf; Known limitations |
| S18 | https://github.com/overleaf/dictionaries | About; README |
| S19 | https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs | Tagging and `\DocumentMetadata`; Tables; FAQs |
| S20 | https://www.overleaf.com/blog/tex-live-2026-is-now-available | Can I switch to TeX Live 2026 for existing projects?; TeX Live 2026 in Server Pro |
| S21 | https://assets.ctfassets.net/nrgyaltdicpt/5lMZlUenRhhcjkq0CpC1W2/bb9463f97519c8bcf56439b14dd5a2ad/Overleaf_ACR_VPAT_for_WCAG_2.2_Level_AA_202505___2_.pdf | Evaluation Methods Used; criteria 2.1.1, 4.1.2, 4.1.3 |
| S22 | https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings | Invalid/Unsupported Characters; Support with LaTeX and pdfLaTeX |
| S23 | https://docs.overleaf.com/troubleshooting-and-support/typesetting-non-latin-languages | Greek, Polish, Vietnamese and Languages using Cyrillic Script (e.g. Russian, Bulgarian, Ukrainian, Serbian); Other Non-Latin Languages and more control over fonts |
| S24 | https://docs.overleaf.com/navigating-in-the-editor/editor-display-font | Editor font size; Editor font family; Editor line height |
| S25 | https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding ; https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding/providing-custom-vim-key-bindings | Troubleshooting; Caution regarding Tampermonkey and UserScripts |
| S26 | https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md | Updating project .bib files produced by reference managers |
| S27 | https://docs.overleaf.com/accounts-and-security/overleaf-labs | What to expect from a Labs experiment; Risks and limitations |
| S28 | https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/localization | i18n Languages |
| S29 | https://github.com/overleaf/overleaf/issues/1391 | Staff comment, October 23, 2025 |
| S30 | https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_polyglossia_and_fontspec | Enter XeTeX and LuaTeX |
| S31 | https://www.overleaf.com/learn/latex/Questions/Inserting_emojis_in_LaTeX_documents_on_Overleaf | Emoji characters and the Overleaf editor |

## Search and freshness audit

Executed counter-searches included `Overleaf non BMP characters editor Unicode limitation` (consequential restriction), `Overleaf visual equation editor non AI`, `Overleaf spell check user specific dictionary`, `Overleaf editor syntax highlighting theme tex extension`, and site-limited searches for current cross-reference autocomplete, CE citations, image crop/retouch, RTL and equation-generator formats. The first search found S31; its opened full text narrows S22's storage claim as recorded above.

The upstream project-menu claims describe Aspell, user scope and `.tex` highlighting, but opening https://www.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu now redirects to the docs homepage. Likewise https://www.overleaf.com/learn/how-to/How_to_paste_formatted_content_into_Overleaf redirects: verify-2's "remains published" is not current evidence. The inputs report indexed AI Assist wording; opened live S9 supersedes those snippets. No redirect archaeology or exhaustive inventories were pursued.

## Closure table

IDs are angle.item in original EXPAND order. DUPLICATE points to the controlling verdict; UNRESOLVED records an actual documentation boundary without claiming feature absence.

| Lead | Verdict and evidence |
|---|---|
| 1.1 Highlighting modes/extension/theme scope | UNRESOLVED: S1 confirms themes; old menu redirects, despite indexed `.tex` wording. |
| 1.2 Completion corpus/package/macros | UNRESOLVED: searches and S2-S3 do not establish current corpus or macro awareness. |
| 1.3 Standard AI/add-on wording | RESOLVED: S9-S10; Standard 10 shared daily uses, Assistant included; add-on snippet stale. |
| 1.4 Editor CE/Server Pro parity | UNRESOLVED: S15 says both have a LaTeX editor, not exact subfeature parity; S16 insufficient. |
| 1.5 CodeMirror dependencies | OUT OF SCOPE: dependency presence is not shipped functionality evidence. |
| 2.1 Editor plan/deployment matrix | DUPLICATE: 1.4; hosted matrix also unassigned by S1/S10. |
| 2.2 Arbitrary round-trip fidelity | OUT OF SCOPE/unasserted universal guarantee; S6 explicitly limits previews. |
| 2.3 Broad formatted-paste matrix | UNRESOLVED: old URL redirects; S7-S8 support only specific current workflows. |
| 3.1 Outline/search entitlements | DUPLICATE: 1.4/2.1; S5/S16 establish behavior, not full matrix. |
| 3.2 Current outline mode parity | UNRESOLVED: S4 does not specify modes; historical parity is not current proof. |
| 3.3 Hosted redesign completion date | OUT OF SCOPE: incidental rollout chronology; current design documented by S1. |
| 4.1 Settings tier matrix | DUPLICATE: 2.1. |
| 4.2 Extra shortcut bindings | OUT OF SCOPE/unasserted beyond dated sheet; retain current S3 list. |
| 4.3 Exact fonts/ranges | RESOLVED: S24 supplies 10-24 px, three families, three line heights. |
| 4.4 Arbitrary macro/package shortcuts | OUT OF SCOPE: no arbitrary compatibility guarantee. |
| 5.1 Non-AI graphical equation editor | UNRESOLVED: counter-search plus S1/S9/S11 establishes palette/generator, not this editor. |
| 5.2 Generator formats/limits/share | RESOLVED share via S9; UNRESOLVED input formats/size limits after search. |
| 5.3 On-prem generator/palette | RESOLVED palette via S15; UNRESOLVED generator via S15-S16. Release-introduction date unnecessary. |
| 5.4 AI Assist/Error Assist legacy wording | RESOLVED: live S9 and https://docs.overleaf.com/integrations-and-add-ons/ai-features/error-assist ("AI allowance") supersede cached wording. |
| 6.1 Insertion on-prem parity | DUPLICATE: 1.4; image IDs do not establish parity. |
| 6.2 Crop/retouch | UNRESOLVED: crop/retouch searches and full S12 controls provide no such workflow. |
| 6.3 Cloud insertion entitlement | DUPLICATE: 2.1; no restriction inferred. |
| 6.4 Table-generator allocation | RESOLVED: S9 shared daily allowance; no separate allocation asserted. |
| 7.1 Current label autocomplete coverage/freshness | UNRESOLVED: current-doc counter-search and S3/S13 do not define commands, refresh or coverage. |
| 7.2 CE citation shipped release | UNRESOLVED: S29 promises post-6.0.0; S16 through 6.3.2 does not confirm delivery. |
| 7.3 Citation/label edition parity | DUPLICATE: 1.4, 7.1-7.2; do not merge distinct autocomplete questions. |
| 8.1 Dictionary scope/disable | RESOLVED disable via S17 Settings; UNRESOLVED persistence/shared scope in S1; old guide redirects. |
| 8.2 AI contradiction | DUPLICATE: 1.3; all-plan AI is not all-plan Assistant. |
| 8.3 Hunspell repository | RESOLVED: S18 directly opened; dictionary provenance, not runtime-engine proof. |
| 8.4 Site-language/pdfLaTeX guidance | RESOLVED: S28 explicitly names `OVERLEAF_SITE_LANGUAGE`; S23 covers all named language groups. |
| 9.1 VPAT matrix | RESOLVED: S21 linked by https://www.overleaf.com/for/customers/vpat ("Current version of Overleaf VPAT"). PDF text decoded in memory after web-reader failure. May 2025 report tests Axe/Lighthouse, keyboard, NVDA/Chrome/Windows and VoiceOver/Safari/Mac. 2.1.1/4.1.2/4.1.3 remain Partially Supports with October 2025 fix notes. |
| 9.2 Tagging plan/CE access | UNRESOLVED full matrix: S19-S20 do not assign tiers; S16 explicitly supports TL2026 sandboxed Server Pro. |
| 9.3 Live-project version | OUT OF SCOPE: authenticated check prohibited; S20 resolves public TL2026 availability, not a particular project configuration. |
| 9.4 Labs entitlement/terms | RESOLVED experimental opt-in/withdrawal/instability via S27 and rolling-image route S19; authenticated experiment list and specific eligibility unasserted. |
| 9.5 ADA rule dates | OUT OF SCOPE: legal chronology, not product functionality; conflicting dates excluded, no rule-text search claimed. |
| 9.6 Table/MathML/package syntax | RESOLVED table keys and `mathml-AF` via S19; package-status inventory OUT OF SCOPE/unasserted. Current ltx-talk FAQ actually specifies TL2026 or rolling image, correcting verify-9's omission. |
| 9.7 Real PDF validation | OUT OF SCOPE: documentation research, no runtime testing. |
| 10.1 Language plan/edition matrix | DUPLICATE: 1.4/9.2; no universal entitlement inference. |
| 10.2 Current RTL editing | UNRESOLVED: searches, S24 and undated S30 caveat do not establish current bidi editor behavior. |

Other residuals: custom dictionaries and spell-check edition parity remain undocumented/unasserted (S1/S18). Supplement Library/ReadCube and Labs are incorporated; unrelated conversion/offline/Drive/AI-administration details stay in their owning clusters.

## EXPAND

None. All input leads have closure verdicts. Remaining documentation gaps are explicit UNRESOLVED boundaries above, not new actionable public-source leads; authenticated checks and arbitrary compatibility guarantees are outside this task.
