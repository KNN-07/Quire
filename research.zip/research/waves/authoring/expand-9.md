# Expand 9: Accessibility, screen readers, and tagged PDF workflows

Checked: October 26, 2026. Documentation research only. Nothing was compiled, and no screen reader or assistive technology was run. Authenticated checks and purchases were not done.

## Platform features (Overleaf web product)

- **Editor accessibility claim.** The docs FAQ "Is the Overleaf editor accessible?" says the web app uses browser accessibility features, is assessed by experts, and that the latest completed VPAT shows WCAG 2.2 AA conformance. Source: https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs (FAQ). Availability: not plan-specific in the source.
- **Screen reader testing and display options.** The Jan 29, 2026 post "Accessible PDFs with LaTeX" says the product was tested with screen reading technology and that the editor can use OpenDyslexic Mono and dark mode. Source: https://www.overleaf.com/blog/accessible-pdfs-with-latex. Dated Jan 2026. The post says product-level conformance, not per-workflow conformance.
- **Keyboard access.** The shortcut page lists editor shortcuts, and it warns that some may not work on non-US keyboards or in Vim/Emacs modes. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts. A list of shortcuts does not show that every editor function is keyboard-operable. Not tested here.
- **VPAT.** The VPAT URL (https://www.overleaf.com/for/customers/vpat) returned only a contact form. The VPAT content itself was not read. The WCAG 2.2 AA claim rests on the docs FAQ and the Jan 2026 blog.

## LaTeX capabilities (TeX and LaTeX, surfaced through Overleaf's compiler)

These are LaTeX features, not Overleaf-specific services. Overleaf only provides the compiler and project settings.

- **Enable tagging.** Put `\DocumentMetadata{...}` before `\documentclass`, with `tagging=on`. Source: https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs, "tagging". `tagging=draft` runs the logic but does not write tags, so it is not a final accessible-PDF setting.
- **Required choices.** Use TeX Live 2025 or later for the keys. Source: same page, "Tagging and `\DocumentMetadata`". The docs recommend `pdfstandard=ua-2` and a BCP 47 `lang`. The docs say the default `lang` is en-US and that `lang` only sets PDF metadata. Source: same page, "pdfstandard" and "lang".
- **Figures.** Use `alt` for meaningful figures, `artifact` for decoration, and `actualtext` for image-rendered characters. Source: same page, "Descriptions". The TeX Live 2026 post also says `\includegraphics`, `picture`, and `tikzpicture` accept these keys. Source: https://www.overleaf.com/blog/tex-live-2026-is-now-available.
- **Tables.** Use `table/header-rows` for data tables and `table/tagging=presentation` for layout tables. Source: docs page, "Tables". The tagging-project page confirms this syntax. Source: https://tagging-project.latex-project.org/documentation/usage-instructions.
- **Math.** Use `math/setup=mathml-SE` (needs LuaLaTeX) or `mathml-AF` (associated MathML file, which is shown in project logs/files). Source: docs page, "tagging-setup". TeX Live 2026 adds `\MathMLintent` and `\MathMLarg` for author-supplied meaning. Source: TeX Live 2026 blog. The post requires LuaLaTeX plus `unicode-math` or `lua-unicode-math`.
- **Structure and reading order.** Use `\section` rather than bold text. Avoid layout-driven `\\` and blank lines inside paragraphs or equations. Source: docs page, "Best practices".

## Limits and conditional claims

- **Not automatic.** The docs say tagging alone does not make every element accessible. Source: docs page warning and "FAQs". Accessibility also depends on the content of alt text and headings, which checkers cannot judge.
- **Package support.** Check packages against the LaTeX Tagging Project status list at https://latex3.github.io/tagging-project/tagging-status/ (the docs link to it). The docs say `beamer` is incompatible with tagging. The experimental `ltx-talk` class needs TeX Live 2026 or Labs rolling TeX Live. Source: docs page, "FAQs".
- **PDF/UA versions.** The docs recommend PDF/UA-2 and say some older readers may need UA-1 (PDF 1.7). Source: docs page, "pdfstandard" and "Standards".
- **Validators.** The docs name veraPDF and ngPDF for checking, and say results vary by tool. Source: docs page, "FAQs". These are external tools; Overleaf does not provide validation.
- **HTML.** The docs say Overleaf has an "Export as HTML (.html)" option. Source: docs page, "LaTeX to HTML". PDF-to-HTML is a third-party path (ngPDF). Not tested.

## Version and deprecation status (date-tagged)

- **TeX Live version on Overleaf: conflicting dates.** The tagging-project usage page says that, as of 2026-06-11, Overleaf only had LaTeX 2025-11-01 via "Rolling TeXLive", otherwise 2025-06-01. Source: https://tagging-project.latex-project.org/documentation/usage-instructions. The TeX Live 2026 blog (later) says a project can be switched to TeX Live 2026 in Settings > Compiler. Source: https://www.overleaf.com/blog/tex-live-2026-is-now-available. The later post supersedes the earlier one, but this was not checked in a live project. UNRESOLVED for an individual project.
- **Tagging status.** The TeX Live 2026 blog says tagging is "no longer a prototype" for production, provided packages/classes support tagging. The Jan 2026 blog still says "PDF/UA-1 (and the upcoming PDF/UA-2)". Date-tagged: the Jan post is outdated on PDF/UA version.
- **Removed or legacy packages.** The TeX Live 2026 blog says `tabu` and `tabls` are unsupported and cause compile errors; `enumerate`, `theorem`, and `verbatim` are legacy; `frenchb` and `francais` are obsolete (replace with `french`); `titlesec` and `flowfram` are incompatible. Source: TeX Live 2026 blog. The docs page also says the `accessibility` package is still distributed but unmaintained.
- **Regulatory dates conflict.** The docs say ADA Title II requires WCAG 2.1 AA by April 26, 2027 (or 2028 for smaller entities). Source: docs page, "Regulations". The Jan 2026 blog says the ADA Title II update "goes into effect April 2026". Not resolved against the legal text here. Do not treat either date as legal advice.
- **Server Pro.** The TeX Live 2026 blog says Server Pro admins can move to TeX Live 2026 by pointing `TEX_LIVE_DOCKER_IMAGE` (and `ALL_TEX_LIVE_DOCKER_IMAGES`) at the 2026 image. Source: TeX Live 2026 blog, "TeX Live 2026 in Server Pro". This is documented only in that blog post, not in the Server Pro docs.

## Plan availability

- **Free vs premium.** The accessibility docs and TeX Live posts do not state plan-level access to tagging or TeX Live 2025/2026. UNRESOLVED.
- **Labs.** The docs describe Labs as the experimental rolling-TeX-Live route. The Labs page (https://www.overleaf.com/labs/participate) returned only a login form. Labs entitlement and terms are UNRESOLVED.
- **AI and Commons.** The harvest cites an Oct 14, 2026 post, "Bridging the accessibility gap". The URL I tried returned a 404, so that claim is UNRESOLVED. The July 2, 2026 AI bundling claim was out of this angle and was not checked.
- **Community Edition.** No source reviewed states Community Edition tagging or TeX Live support. UNRESOLVED.

## Duplicates and dropped items

- The harvest's "editor accessibility" and "tagged PDF" claims are the same two claims that appear in the docs FAQ and the Jan 2026 blog. Merged, not double-counted.
- Search results from SIGACCESS, eSAIL, and UCLA DTS are third-party. They were not opened and are not used as evidence.
- The 2020 "An introduction to tagged PDF files" article was not opened. Its Jan 2026 update note is the only claim taken from it, and it is only a search snippet.

## EXPAND

- LEAD: Open the Overleaf VPAT document itself to check the criteria and test matrix. The landing page only shows a form. Status: open.
- LEAD: Verify plan and self-hosted entitlements for TeX Live 2025/2026 tagging, and whether Community Edition supports it. No source reviewed states this. Status: open.
- LEAD: Confirm, in a live project, which TeX Live version and compiler are offered (the 2026-06-11 vs later-blog conflict). Requires an authenticated check. Status: open.
- LEAD: Open the Oct 14, 2026 Commons/accessibility post. The cited URL returned 404. Status: open.
- LEAD: Verify Labs entitlement and rolling TeX Live terms. Login gate. Status: open.
- LEAD: Verify the ADA Title II compliance date from the official rule text (conflicting dates above). Status: open.
- LEAD: For a specific document, check package tagging status and validate real PDF structure, reading order, alt text, and screen-reader output. Nothing in this report was executed or certified.
