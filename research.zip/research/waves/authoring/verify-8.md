# Verify 8: Spell checking, dictionaries, and language settings

Research date: October 26, 2026. Public official Overleaf sources only. No authenticated tests, purchases, or functional execution.

**Verdict: PARTIAL.** The core spell-check facts (editor controls, language list, Grammarly limits, Writefull location, LaTeX language packages) are confirmed. Scope and persistence of the dictionary setting, custom words, plan entitlement for the built-in checker, and the legacy Aspell and user-specific claims are not confirmed. One upstream claim (Aspell) conflicts with an official GitHub repository. Tooling note: I wrote this file with `write` because `apply_patch` was not available in this session.

## Platform spell checker

- The redesigned editor's Settings > Editor tab lists "editor language" and a separate "spell-check dictionary" control. The page does not say whether the setting is per user, per project, or shared. Source: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor, heading "Project settings."
- The supported-language page lists a long set of spell-check languages, including English variants, German (Austria, Switzerland), Norwegian Bokmål and Nynorsk, Portuguese (Brazilian and European), Arabic, Hindi, Korean, Persian, Thai, Ukrainian, and Vietnamese. Source: https://www.overleaf.com/learn/how-to/What_languages_are_currently_supported_in_the_spell_checker%3F, the list itself. The upstream count of 68 was not re-verified; my own token count was unreliable. The page states no plan requirement.
- A 2015 blog post has a section "Integrated spell-check": misspellings are underlined in red, the language is picked from account settings, and a global spell-check option is in the project settings menu. Source: https://www.overleaf.com/blog/194-new-year-new-name-new-free-features, heading "Integrated spell-check." Date tag: January 8, 2015 (legacy). The post describes features as "freely available" in 2015. Current tier status is UNRESOLVED.
- Upstream claim "user-specific, Aspell dictionary, can be turned off" (legacy project-menu guide): the cited URL redirected to the current docs home when fetched, so this could not be confirmed. Status: UNRESOLVED.
- Overleaf's official `overleaf/dictionaries` repository describes its dictionaries as Hunspell dictionaries converted to UTF-8 from Debian packages. Source: https://github.com/overleaf/dictionaries, README (seen in search snippet; page not opened). This CONTRADICTS the "Aspell" wording in the upstream files. Treat the engine as Hunspell-derived per the repo.
- Custom words, ignore lists, and dictionary upload: no current official user doc found. UNRESOLVED.
- A feature request for per-document spell check, opened December 4, 2024, is still listed as open. Source: https://github.com/overleaf/overleaf/issues/1291. This shows per-document spell check was requested, not that it is absent from the product. Status: UNRESOLVED.

## Writefull and AI language feedback

- The AI features page says Writefull's settings moved to the main Settings modal, under the Editor and "Spelling and language" tabs. The Spelling and language tab lets users pick a suggestion model, including the Writefull model. Source: https://docs.overleaf.com/integrations-and-add-ons/ai-features, heading "Enabling and disabling AI features" and the Writefull FAQ items. Current.
- The AI features page has a table "AI allowance by plan" with daily allowances. Rows read: Free (Basic, AI assistant not included), Student (Basic, included), Standard, Pro (Max, fair use, included), Commons Basic (same as Free, not included), Commons AI Max (included). Source: same URL, "AI allowance by plan." Current, but parsed from flattened text; re-check the table visually before publishing.
- The July 2, 2026 blog says Overleaf AI "is now included in all Overleaf plans at no extra cost," with allowances varying by plan, and introduces Commons AI. Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans, dated July 2, 2026. CONTRADICTS the docs table, which says Free AI assistant is not included. The blog also says Commons subscriptions get the Basic allowance with no AI Assistant. Status: UNRESOLVED; do not combine these as one fact.
- Legacy: Error Assist docs on the cs.overleaf.com mirror describe a separate "AI Assist add-on" with unlimited use. Source: https://cs.overleaf.com/learn/latex/Error_Assist, heading "Daily use limits." Date tag: legacy, not the current bundled model. Not used to describe today's plans.
- The upstream statement "free daily limits, paid AI Assist for unlimited" is therefore legacy wording. The current AI page does not describe an AI Assist add-on.

## Grammarly

- Grammarly is a browser extension with no direct integration or official support. Overleaf says it may help to switch off built-in spell check in project Settings to avoid conflicts. Source: https://docs.overleaf.com/integrations-and-add-ons/grammarly, headings "How to use Grammarly with Overleaf" and "How to temporarily disable Grammarly." Current.
- Known limitations: Grammarly does not fully understand LaTeX markup, which can cause wrong suggestions and words left unchecked. Same URL, "Known limitations."

## LaTeX document language (separate from the editor checker)

- Overleaf's international-language guide says `babel` enables typesetting in many languages and that polyglossia uses LuaLaTeX or XeLaTeX. Source: https://www.overleaf.com/learn/latex/International_language_support, sections "Introduction" and "Babel." Partially verified; the upstream `\selectlanguage` and label-translation details were not seen in my extract.
- The non-Latin troubleshooting page recommends XeLaTeX or LuaLaTeX with babel or polyglossia for Arabic, Farsi, Hebrew, and Indic languages. Source: https://docs.overleaf.com/troubleshooting-and-support/typesetting-non-latin-languages, section "Other Non-Latin Languages." Current. The upstream pdfLaTeX claims for Greek, Polish, Vietnamese, and Cyrillic were not seen in my extract: UNRESOLVED.

## Self-hosted localization

- Both Community Edition and Server Pro have interface translations. Multi-language routing uses the `OVERLEAF_LANG_DOMAIN_MAPPING` variable. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/localization, heading "i18n Languages." Current. This is UI localization, not dictionary support.
- `OVERLEAF_SITE_LANGUAGE`: named in the upstream harvest but not seen in my extract. UNRESOLVED.
- Spell-check parity between Community Edition, Server Pro, and Commons: no official source found. UNRESOLVED; do not infer parity.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Editor tab has editor language and spell-check dictionary selectors | redesigned-overleaf-editor, "Project settings" | Current, all users | Confirmed |
| Spell-check language list is long and includes many variants | learn/how-to/What_languages_are_currently_supported_in_the_spell_checker | Current | Confirmed; count 68 not verified |
| Built-in spell check is Free | 2015 blog, "Integrated spell-check" | Historical 2015 | Partial; current tier UNRESOLVED |
| Dictionaries are Hunspell-derived | github.com/overleaf/dictionaries README | Official repo | Confirmed via snippet; upstream "Aspell" CONTRADICTED |
| Spell check is user-specific, can be off | Legacy project-menu guide | Legacy | UNRESOLVED (URL redirected) |
| Per-document spell check requested | github.com/overleaf/overleaf issue 1291 | Open request | Request only |
| Writefull and language settings in Settings > Spelling and language | ai-features | Current | Confirmed |
| AI allowance table by plan | ai-features | Current | Confirmed, parsed; re-check |
| AI included in all plans from July 2, 2026 | Blog July 2, 2026 | Current | CONTRADICTS docs table; UNRESOLVED |
| AI Assist add-on unlimited | cs.overleaf.com Error Assist | Legacy | Legacy only |
| Grammarly unofficial, disable built-in spell check | docs grammarly | Current | Confirmed |
| babel and polyglossia for multilingual LaTeX | International_language_support | Current | Partial |
| XeLaTeX or LuaLaTeX for Arabic, Farsi, Hebrew, Indic | typesetting-non-latin-languages | Current | Confirmed |
| UI localization for CE and Server Pro | on-premises localization | Current | Confirmed; not spell check |

## Counter-search queries

- "Overleaf spell check dictionary per project user setting" (scope/persistence)
- "Overleaf custom dictionary add word ignore spell check"
- "Overleaf spell check Server Pro Community Edition dictionary"
- "Overleaf AI included all plans July 2 2026 AI Assistant Free allowance"
- "overleaf/dictionaries hunspell build.sh"
- "Overleaf OVERLEAF_SITE_LANGUAGE toolkit"

## EXPAND

- LEAD: Confirm the dictionary setting's scope (user, project, or shared) and the current disable path in the redesigned editor. Reason: the only sources are a current page with no scope text and legacy pages that did not load.
- LEAD: Resolve the AI plan contradiction between the July 2, 2026 blog and the docs allowance table, including whether Free gets the AI Assistant. Reason: the blog and the table disagree and both are official.
- LEAD: Open https://github.com/overleaf/dictionaries and confirm the Hunspell statement directly, since it was only seen in a search snippet. Reason: it overrides the upstream Aspell wording.
- LEAD: Check whether `OVERLEAF_SITE_LANGUAGE` exists in current toolkit docs, and the Greek/Polish/Vietnamese/Cyrillic pdfLaTeX guidance. Reason: named upstream, not seen in my extracts.
- No LEAD: custom dictionaries and Commons or Server Pro spell-check parity. Reason: I found no official material on either, so this stays UNRESOLVED and needs no further search in this angle.
