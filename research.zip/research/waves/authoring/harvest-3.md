# Harvest 3: Editor navigation, outline, search and replace

Research checked against official Overleaf documentation on October 26, 2026. Sources are linked directly below; section labels identify the relevant headings. This report covers Overleaf editor functions, not general LaTeX behavior. No authenticated product testing was performed.

## Editor navigation

The redesigned editor keeps the editing pane on the left and PDF viewer on the right, with Code/Visual editor toggle at the editing pane’s top-left. The left navigation bar exposes File tree and Search (plus Integrations, Review, and Chat); top-right controls include History, Share, and editor layout. Panes can be resized or hidden with dividers. SyncTeX arrows between source and PDF jump between corresponding locations. These are product UI functions, not guarantees about arbitrary source/PDF correspondence. **Source:** [Redesigned Overleaf editor](https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor), “Getting Started,” “Left bar,” and “Resizing the panes.”

Keyboard navigation includes Ctrl+Home/End for first/last line in the current file and Ctrl+Shift+L to open a go-to-line dialog. Mac uses Cmd in place of Ctrl for listed shortcuts, but the docs warn some shortcuts may not work on non-US keyboards or in Vim/Emacs modes. **Source:** [Keyboard shortcuts](https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts), “Keyboard shortcuts.” The documented shortcut table does not establish every shortcut’s availability in every editor mode.

## File Outline

File Outline appears in the left pane and displays recognized standard sectioning elements from the currently open `.tex` file, not the entire multi-file project. Opening another file changes the outline. Clicking a heading moves the cursor to it; the outline can be collapsed/expanded and resized. Supported commands are `\book` (memoir), `\part`, `\chapter` (book/report), `\section`, `\subsection`, `\subsubsection`, `\paragraph`, and `\subparagraph`, including starred variants. **Source:** [Selecting and managing files](https://docs.overleaf.com/navigating-in-the-editor/selecting-and-managing-files), “Navigating within your files using the File Outline,” “Supported heading commands,” and “Expanding and collapsing the File Outline and File Tree.”

This outline is a product-side structural parser, not a full LaTeX engine: it does not show headings brought in through `\input`, `\include`, or `\import`; custom macro expansion and math-mode content in headings are not rendered; multiple labels after a heading or section commands split over lines may not be detected. The docs suggest placing an included file after a supported heading as a workaround to show the parent heading, not the included file’s nested headings. These limits distinguish outline presentation from what LaTeX can typeset. **Source:** same File Outline documentation, caveats under “Supported heading commands” and the note preceding it.

The current docs describe File Outline as a standard editor feature and do not state a plan restriction. **Availability: plan tier unresolved** (no explicit Free/Premium/Commons/Server Pro/Community Edition entitlement found in the cited feature documentation). A September 1, 2020 Overleaf blog described File Outline as available in both source and rich-text modes; treat this as dated context, not proof of current editor-mode behavior. **Legacy source (2020-09-01):** [File Outline announcement](https://www.overleaf.com/blog/new-feature-file-outline-is-now-available-on-overleaf), “Does the file outline work in both source and rich text modes?”

## Search and replace

With the cursor in the editor, Ctrl+F (Cmd+F on macOS) or the Search file control opens the current-file search panel. Search-as-you-type highlights the first match; controls offer match case, regular expression, whole word, and within-selection filtering, with previous/next match navigation. “Replace” updates one match and advances to the next; “Replace All” affects all matches in the selected file. **Source:** [Searching within a project](https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project), “Search and replace within the current file” and “How to use search or search and replace.”

In-file search/replace is unavailable for read-only files, including text files uploaded from external URLs (including Google Drive) and imported reference-manager `.bib` files, and text files larger than 2 MB, which the editor treats as read-only. **Source:** same, “Search and replace within the current file.”

Project-wide search is available from the left-sidebar Project search control or from the file search panel. It searches files under 2 MB, can match case/use regex/whole-word options, groups results by file, and selecting a result jumps to its location. The docs describe project-wide search only; they do not document project-wide replacement. **Source:** same, “Project-wide search” and “How to use project-wide search.”

Overleaf docs label neither search nor replacement as Premium; **plan availability unresolved** for Free, Premium, Commons, Server Pro, and Community Edition except that the Server Pro 6.1.0 release notes explicitly list project-wide search as a new feature (release dated 2026-01-20; notes also name Community Edition image IDs but do not establish feature parity or tier entitlement). **Source:** [On-premises 6.x release notes](https://docs.overleaf.com/on-premises/release-notes/release-notes-6.x.x), “Server Pro 6.1.0.” No AI feature is implicated.

## EXPAND

- **LEAD — explicit current plan entitlements:** official feature docs do not assign tiers to outline or search/replace; leave unresolved unless a current plan/Commons/Community Edition source explicitly documents them.
- **LEAD — current editor-mode outline parity:** the 2020 blog says source and rich-text modes; current documentation does not make that promise. Legacy claim dated above; current parity unresolved.
- **No further lead:** this bounded angle is otherwise covered by current official editor, outline, search, shortcut, and on-premises documentation.
