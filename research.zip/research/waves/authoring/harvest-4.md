# Overleaf authoring research: keyboard shortcuts and editing preferences

Research date: October 26, 2026. Scope: user-facing keyboard shortcuts, keybinding modes, and editor personalization. Evidence comes from public Overleaf documentation and its official shortcut reference; no authenticated testing was performed.

## Keyboard shortcuts

Current documentation lists the common editor shortcuts (Windows/Linux; substitute Command for Control on Mac unless noted): Ctrl/Cmd+F find and replace; Ctrl/Cmd+Enter or Ctrl/Cmd+S compile; Ctrl/Cmd+Z undo; Ctrl/Cmd+Y redo; Ctrl/Cmd+Home/End move to the first/last line of the current file; Ctrl/Cmd+Shift+L go to a line; Ctrl/Cmd+/ toggle comments; Ctrl/Cmd+D delete current line; Ctrl/Cmd+A select all; Tab / Shift+Tab indent/unindent; Ctrl/Cmd+U uppercase; Ctrl/Cmd+Shift+U lowercase; Ctrl/Cmd+B bold; Ctrl/Cmd+I italic. Ctrl+Space opens autocomplete, including bibliography search inside `\cite{...}`; the docs explicitly say to use Ctrl+Space on Mac too, not Cmd+Space. The docs warn some shortcuts may not work on non-US keyboards or in Vim/Emacs modes. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts, heading “Keyboard shortcuts” (common shortcuts table and Mac/keymap caveat).

The current docs link to a more comprehensive shortcut-reference project, but its detailed contents and update date were not independently verified here. Extra bindings beyond the common-shortcuts table are **UNRESOLVED**; do not treat undocumented additions as guaranteed. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts, heading “Keyboard shortcuts.”

For project search, Ctrl/Cmd+Shift+F opens search across project files. Current docs say project-wide search includes files under 2 MB; larger files are excluded. File-level search/replace likewise excludes read-only files, including files over 2 MB and certain externally supplied/imported files. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project, headings “Search and replace within the current file,” “How to access search and replace,” and “Project-wide search.”

PDF viewer shortcuts are separate from source-editor shortcuts and require the viewer to have focus: Ctrl/Cmd++ and Ctrl/Cmd+- zoom; Ctrl/Cmd+0 fit width; Ctrl/Cmd+9 fit height. Presentation mode navigation supports arrows, Space/Shift-Space, Backspace, PgUp/PgDn, and Esc exits. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation, headings “Document navigation in presentation mode” and “Keyboard shortcuts.”

## Keybinding modes and constraints

The current docs describe three user-specific modes, configured in the project menu/settings: None (default), Vim, and Emacs. Vim and Emacs are emulations, not full implementations. Emacs is described as a loose approximation based on CodeMirror 5; browser-reserved combinations such as Ctrl+N, Ctrl+T, and Ctrl+W may be intercepted before reaching the editor. Vim may conflict with the Vimium browser extension. Sources: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding, headings “Vim and Emacs keybinding,” “Emacs,” “Vim,” and “Troubleshooting”; https://www.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu, heading “Keybindings” (older menu description).

## Editing preferences

Current documentation places font controls under Settings > Appearance (or File > Settings > Appearance), covering font size, family, and line height. Autocomplete can be enabled under Settings > Editor > Auto-complete. Other preference controls such as editor language, spellcheck, code checking, and themes are **UNRESOLVED** in the current pages consulted. Sources: https://docs.overleaf.com/navigating-in-the-editor/editor-display-font, heading “Editor display font”; https://docs.overleaf.com/citing-and-references/adding-citations-and-references, heading “How to enable Overleaf’s auto-complete.”

Font size is configurable from 10px to 24px and applies to Code and Visual editors. Font family applies to Code Editor, with Monaco/Menlo/Consolas, Lucida/Source Code Pro, or OpenDyslexic Mono; the latter is documented as an accessibility option. Line height choices are Compact, Normal, Wide. Overleaf recommends adjusting editor font size rather than browser zoom and says the interface is optimized for 100% browser zoom. Cursor misalignment may occur with unavailable fonts or some scripts (including Thai, Japanese, Cyrillic). Source: https://docs.overleaf.com/navigating-in-the-editor/editor-display-font, respective headings above.

Custom Vim key bindings are not offered as a standard preference: official docs say the editor emulates Vim without running its interpreter, so Vim’s usual remapping mechanisms do not work. The page mentions a Tampermonkey userscript workaround, but labels userscripts unsupported and the editor API unstable; this is not a supported product feature. Source: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding/providing-custom-vim-key-bindings, headings “Providing custom Vim key bindings” and “Caution regarding Tampermonkey and UserScripts.”

## Availability and boundaries

These sources describe general editor features and do not assign the listed shortcuts, keybindings, or font preferences to a paid tier. Availability by Free, premium, AI, Commons, Server Pro, or Community Edition is **UNRESOLVED**; no tier claim is inferred. Mobile/tablet access is supported through a browser but has known limitations: external keyboards/input methods may vary and shortcuts/hotkeys might be unavailable. Source: https://www.overleaf.com/learn/how-to/Can_I_use_Overleaf_on_an_iPad_or_other_mobile_devices%3F, headings “Can I use Overleaf on an iPad or other mobile devices?” and “Known issues and areas for improvement.”

Keyboard commands documented here are Overleaf product/editor behaviors. They do not establish that arbitrary LaTeX commands, macros, or packages have corresponding keyboard shortcuts; such shortcuts are **UNRESOLVED** in these sources. No claim of functional execution is made.

## EXPAND

- **LEAD: tier-by-tier availability** — UNRESOLVED; consulted official editor documentation gives no Free/premium/AI/Commons/Server Pro/Community Edition matrix for these settings.
- **LEAD: keyboard shortcut reference project** — UNRESOLVED; current docs link a project for a comprehensive list, but detailed extra bindings were not verified here.
