# Authoring cluster 2 independent verification

Cutoff: October 26, 2026. This is a check of public vendor documentation, not an account session or runtime test. Primary source URLs are explicit below. I opened the full content for consequential claims and counter-searched for current contradictory statements. “Documented” does not mean independently measured.

## Accepted claim groups

- **Angles 1–4: editor, modes, navigation, preferences.** Accept the consolidated claims in `expand-cluster-2.md`: code/visual editing and bounded visual previews; autocomplete and heuristic Code Check; panes, outline, file/project search with documented limitations; shortcuts and display preferences. Project-wide search docs explicitly say files over 2 MB are excluded; search/replace applies to the current editable file. Exact syntax highlighting, completion coverage, cross-mode parity, and full plan/deployment parity remain unassigned where the sources do not specify them.
- **Angles 5–6: math, tables, figures.** Accept Symbol Palette and equation/table generation plus table and image insertion/paste workflows as documented. Keep claims limited to described controls and workflows. No general visual equation editor, arbitrary LaTeX rendering guarantee, image crop/retouch feature, or arbitrary package guarantee is established.
- **Angle 7: references.** Accept project `.bib`, Library, and ReadCube distinctions. The Library source says citing a Library item adds its reference data to the project `.bib`; this supports copying, not a live synchronized link. Keep refresh/read-only versus editable import distinctions scoped to the documented ReadCube routes.
- **Angle 8: spelling and language.** Accept language/dictionary controls and the documented Grammarly caveat. Repository dictionary provenance does not prove runtime spell-check implementation, custom-word persistence, or tier availability.
- **Angle 9: accessibility.** Accept documented tagging guidance, `\DocumentMetadata` before `\documentclass`, TeX Live 2025+ requirement, and stated image/table/math accessibility workflows. The docs explicitly warn that applying practices does not guarantee every PDF element is accessible. No output or screen-reader testing was done.
- **Angle 10: multilingual/Unicode.** Accept UTF-8 support, integration encoding caveats, and current documented editor limitation for non-BMP text. The emoji article says non-BMP characters cannot be edited in the editor but uploaded UTF-8 text files may contain them and be included in a document. This narrows the encoding page’s broad statement that Overleaf cannot store files containing such characters; retain as a source-level contradiction/scope ambiguity, not a blanket claim that non-BMP content cannot be used.

## Corrections to reconciliation

1. **AI tool removal claim is supported, with an internal stale overview.** The live AI page’s opening feature table lists “Summarize and Explain,” but its detailed “What’s included” table omits these, and Troubleshooting explicitly says they were removed and are no longer available. Accept the reconciled removed-action claim with this conflict recorded. The current AI page also describes daily plan allowances, and its detailed plan table agrees with the official July 2, 2026 announcement and pricing page about Free/Commons Basic without Assistant, Student Basic with Assistant, Standard Assistant, and Pro/Commons AI Max subject to fair use. The plans page gives Free and Student 5 daily uses and Standard 10; group administrators can disable AI. Use dated announcement and pricing page for current entitlements; do not repeat older indexed add-on/72-hour snippets as current evidence.
2. **Non-BMP conflict is real but bounded.** The file-encoding page says it cannot store files containing non-BMP characters. The emoji article, also live, explicitly permits uploaded UTF-8 text files containing them, but says they are not editable in Overleaf. Preserve both documented statements and the operational distinction; do not treat this as evidence that typing/pasting those characters works.
3. **Community Edition scope.** The current Server Pro comparison explicitly gives both editions full project history and a powerful LaTeX editor, while marking commenting, real-time track changes, Git integration, and Symbol Palette Server Pro-only. The documented history claim is reinforced by Community Edition 3.5 release notes. Do not project hosted Free’s 24-hour history limit onto CE. Conversely, this edition comparison does not establish exact parity for each editor subfeature. Do not construe its “easy internal collaboration” row as proving CE lacks all simultaneous editing.
4. **Search and accessibility are supported with limits.** Current search documentation supports the 2 MB cutoff and current-file replacement scope. Current accessibility docs require TeX Live 2025+ and explicitly disclaim guaranteed accessibility. These are documentation findings, not execution results.

## Unresolved caveats and inventory effect

Unresolved: exact hosted/on-prem editor subfeature matrices; completion/highlighting coverage and arbitrary macro/package behavior; equation-generator input/size limits and self-hosted availability; current RTL editor behavior; citation/label autocomplete coverage; spell-check tier and custom-dictionary behavior; and actual PDF/assistive-technology outcomes. Some older/undated pages and indexed snippets disagree with current dated announcements. A search result snippet alone is not evidence; where a URL redirects or a query yielded no primary support, retain the question as unresolved rather than infer absence.

These caveats do **not** remove the ordinary documented authoring features from the final inventory. They affect qualification, deployment/plan attribution, or runtime confidence only. Nothing here warrants downgrading a useful documented control to “unavailable” merely because its page omits a tier label.

## Ten-angle coverage checklist

- [x] 1 — Code editor
- [x] 2 — Visual/source interoperability
- [x] 3 — Navigation and search
- [x] 4 — Shortcuts and preferences
- [x] 5 — Math and symbols
- [x] 6 — Tables and figures
- [x] 7 — References and citation tools
- [x] 8 — Spelling and language
- [x] 9 — Accessibility
- [x] 10 — Multilingual and Unicode

## Evidence and explicit primary URLs

- Current code/project search: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project
- Current on-prem edition comparison: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition
- CE full-history release evidence: https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x/full-project-history-migration
- Live AI feature page (commercial copy conflicts with 2026 plan change): https://docs.overleaf.com/integrations-and-add-ons/ai-features
- Dated plan-change announcement, July 2, 2026: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- Current plans page: https://www.overleaf.com/user/subscription/plans
- Current accessibility guidance: https://docs.overleaf.com/writing-and-editing/creating-accessible-pdfs
- Current Library workflow: https://docs.overleaf.com/citing-and-references/library
- Current encoding limitation: https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings
- Current emoji/non-BMP editing and upload qualification: https://www.overleaf.com/learn/latex/Questions/Inserting_emojis_in_LaTeX_documents_on_Overleaf

## Verdict

**PASS — evidence-complete inventory with explicit caveats**, provided the final inventory applies the AI correction above and carries both the plan-doc freshness conflict and bounded Unicode conflict. Documentation supports the inventory; runtime functionality was not measured.

## EXPAND

Lead closure: **conditional closed**. Existing ten angles are covered; no new angle is required. Correct the AI “removed” assertion and label the conflicting AI entitlement source as stale before final synthesis. Remaining unresolved caveats are explicit and do not change the documented feature inventory.
