# Overleaf angle 4: keyboard shortcuts and editing preferences

Research date: October 26, 2026. Scope is Overleaf's editor shortcuts, keybinding modes, and documented editing preferences. Sources below are official Overleaf documentation or its official shortcut-reference project. No authenticated product testing was performed. These are Overleaf product capabilities, not guarantees about arbitrary LaTeX packages, macros, or commands.

## Shortcuts and keybinding caveats

The current shortcut page identifies common editor commands: Ctrl/Cmd+F search/replace; Ctrl/Cmd+Enter or Ctrl/Cmd+S compile; Ctrl/Cmd+Z undo; Ctrl/Cmd+Y redo; Ctrl/Cmd+Home/End first/last line in the current file; Ctrl/Cmd+Shift+L go to line; Ctrl/Cmd+/ comment/uncomment; Ctrl/Cmd+D delete line; Ctrl/Cmd+A select all; Tab/Shift+Tab indent/unindent; Ctrl/Cmd+U and Ctrl/Cmd+Shift+U change case; Ctrl/Cmd+B/I bold/italic. Ctrl+Space opens autocomplete, including bibliography suggestions within `\cite{...}`; on Mac the documentation specifically says Ctrl+Space, not Cmd+Space. The page cautions that some combinations can fail on non-US keyboards and in Vim/Emacs modes. Source: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts, “Keyboard shortcuts.”

The linked official two-page shortcut-reference project is dated May 31, 2023, so treat its additional bindings as dated rather than a current guarantee. It lists, among other things, duplicate selection, move/copy lines, fold/unfold, multiple cursors, next/previous find, and Vim `:w`; the current common-shortcuts page does not enumerate these. It also warns that keyboard layout/input methods and Vim/Emacs modes affect availability. Source: https://www.overleaf.com/latex/templates/overleaf-keyboard-shortcuts/pphdnzrwmttk.pdf, “Overleaf Keyboard Shortcuts,” pages 1–2 (updated May 31, 2023). The current docs link this project but do not establish that every listed binding remains supported.

Search has both file-local and project-wide bindings: Ctrl/Cmd+F searches the current editable file; Ctrl/Cmd+Shift+F opens project search. Project search excludes files over 2 MB, and file search/replace excludes read-only files, including files over 2 MB and some externally supplied text/reference files. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project, “Search and replace within the current file,” “How to access search and replace,” and “Project-wide search.”

The PDF viewer has its own shortcuts, which require focus: Ctrl/Cmd++ and Ctrl/Cmd+- zoom, Ctrl/Cmd+0 fit width, and Ctrl/Cmd+9 fit height. Presentation mode navigates with arrows, Space/Shift-Space, Backspace, and Page Up/Page Down; Escape exits. These apply to the PDF viewer, not source editing. Source: https://docs.overleaf.com/navigating-in-the-editor/working-with-the-pdf-viewer/pdf-viewer-options-and-navigation, “Document navigation in presentation mode,” “Keyboard shortcuts.”

## Modes and customization

The current docs expose user-specific None (default), Vim, and Emacs modes in Project menu > Settings. These are emulations, not full Vim/Emacs interpreters; browser-reserved shortcuts may be intercepted. The docs specifically note Vimium can interfere with Vim mode and Ctrl+N/Ctrl+T/Ctrl+W may not reach Emacs mode. Source: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding, “Vim and Emacs keybinding,” “Emacs,” “Troubleshooting.”

Custom Vim mappings are not a standard supported setting. A documentation page describes a Tampermonkey/userscript workaround through an explicitly unstable editor interface, and warns userscripts are unsupported and may interfere with normal operation. Do not present this workaround as a product feature. Source: https://docs.overleaf.com/navigating-in-the-editor/vim-and-emacs-keybinding/providing-custom-vim-key-bindings, “Providing custom Vim key bindings,” “Caution regarding Tampermonkey and UserScripts.”

## Editing preferences and plan distinctions

Current editor settings documentation describes auto-complete, code checking, editor language, and spell-check dictionary under Settings > Editor; Appearance includes interface/editor themes and font controls. The available official pages do not specify every option's exact choices or plan eligibility, so no blanket tier assignment is made. Source: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor, “Project settings.”

Font size ranges from 10px to 24px and applies to Code and Visual editors. Code Editor font choices are Monaco/Menlo/Consolas, Lucida/Source Code Pro, or OpenDyslexic Mono; line height is Compact, Normal, or Wide. Overleaf recommends adjusting editor font rather than browser zoom and says the app is optimized for 100% browser zoom. Source: https://docs.overleaf.com/navigating-in-the-editor/editor-display-font, “Editor font size,” “Editor font family,” “Editor line height.” Availability of particular fonts may depend on local installation; cursor alignment issues are documented for unavailable fonts and some scripts.

Simple citation search is available to all users; advanced reference search and its project setting are labeled premium. Both rely on auto-complete being enabled. This is a specific documented premium distinction, not evidence that other editing preferences vary by plan. Source: https://docs.overleaf.com/citing-and-references/adding-citations-and-references, “How can Overleaf help to find and cite references?” and “How to enable Overleaf’s auto-complete.”

An older project-menu article is now redirected to the docs landing page; its historical claims (including a separate “Show Hotkeys” menu and a particular Emacs search binding) are not treated as current. Source: https://www.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu (legacy article URL; currently redirects to https://docs.overleaf.com/).

## EXPAND

- **LEAD: keyboard shortcut reference project** — Resolved with limitation: official project opened and inspected; it is explicitly dated May 31, 2023. Extra bindings are recorded above as legacy-listed, not guaranteed current.
- **LEAD: tier-by-tier availability** — Partially resolved: citation search has an explicit all-users vs premium distinction; no official matrix found for the general editor shortcuts, modes, or appearance preferences. Free/premium assignment for those remains **UNRESOLVED**; Commons, Server Pro, and Community Edition applicability is also **UNRESOLVED**.
- Duplicates closed: harvest's common shortcuts, search limits, PDF viewer commands, keybinding caveats, font options, and unsupported custom Vim workaround were rechecked against the cited official pages. General LaTeX command/package shortcut behavior remains **UNRESOLVED** and is outside documented Overleaf editor guarantees.
