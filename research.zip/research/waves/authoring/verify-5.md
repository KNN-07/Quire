# Verify angle 5: Math insertion, equation editing, symbol palette

Verdict: PARTIAL

Checked on 2026-10-27 from public Overleaf pages only. No authenticated tests, no purchases, no functional execution.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Symbol Palette inserts math symbols with a click and shows the package each symbol needs | Overleaf Symbol Palette blog; Symbol palette section of inserting-symbols docs | Premium (account-level) | Source-backed (fetched) |
| Symbol Palette requires math mode | inserting-symbols docs, "Using the Symbol Palette" | Same as above | Source-backed (fetched) |
| Symbol Palette is not in Free; included in Student, Standard, Pro, Organizations | Plans page feature table; features overview | Free: not included. Student, Standard, Pro, Organizations: included | Source-backed (fetched) |
| Symbol Palette is in Server Pro and not in Community Edition | Server Pro vs. Community Edition page, benefits table | Server Pro: yes. Community Edition: no | Source-backed (fetched) |
| Keyboard shortcuts for math insertion | Keyboard shortcuts page | None listed on the fetched page | Absence in fetched page only |
| Visual Editor lets users edit without writing code, with a toolbar for figures, tables, and text formatting | Features overview | Plan not stated for Visual Editor | Source-backed, but does not name equations |
| Equation-specific editing in Visual Editor (graphical equation editor, non-AI) | None found | Unknown | UNRESOLVED |
| AI Equation Generator converts an image or natural-language description to LaTeX | Overleaf AI features page, "Feature" table and "What's included" | AI tool; reached via Insert menu or TeXGPT | Source-backed (fetched), capability only |
| AI is included in all plans | Overleaf blog, dated July 2, 2026 | All plans per blog | Source-backed (fetched) |
| Per-tier AI daily allowances | Plans page | Free: Basic, 5 uses per day. Student: Basic, 5 per day. Standard: 10 per day. Pro: Max, fair use. Commons: varies | Source-backed (fetched), but per-tool share is not stated |
| Equation Generator availability on Server Pro or Community Edition | None found | Unknown | UNRESOLVED |
| amsmath is recommended for advanced math; \frac and \binom need it in examples | Overleaf learn pages (Mathematics, Fractions and Binomials, video tutorial) | Open LaTeX package, not an Overleaf feature | Search-snippet evidence only, not opened in full |

## Platform features versus LaTeX

- Platform features: Symbol Palette, AI Equation Generator, and any visual equation editing. Their availability depends on plan, deployment, and AI allowance.
- Arbitrary LaTeX: math typeset with amsmath or core LaTeX. This works in any LaTeX compile and is not an Overleaf feature.

## Conflicts and limitations

- Legacy AI wording: the llms.txt index still says the AI assistant is a component of an "AI Assist" add-on, and older Error Assist pages say the same. The July 2, 2026 blog says AI is bundled into plans. The two are not combined here. The newer blog is the more recent statement.
- AI allowance wording: an earlier search snippet listed Free as "5 AI uses per day," and the AI features table lists Free as Basic. The fetched plans page shows 5 uses per day for Free, so that number is used here. The snippet had no page context, so this is a fetched-page reading, not a second source.
- Equation Generator input limits, supported image formats, and output correctness were not found. No guarantee is claimed.
- Visual equation editing outside AI was not found in any public page checked.
- No functional test of any feature was run.

## Counter-search queries

- Run: "Overleaf visual editor equation insert math fraction template shortcut" (domain-limited to docs.overleaf.com and overleaf.com).
- Not run, suggested: "Overleaf equation editor visual editor" on docs.overleaf.com; "Overleaf AI Equation Generator limits"; "Overleaf Server Pro release notes symbol palette"; "overleaf/overleaf GitHub symbol palette".

## Sources

- Server Pro vs. Community Edition: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition (benefits table: Symbol Palette row)
- Plans and pricing: https://www.overleaf.com/user/subscription/plans (feature table: AI allowance, Symbol palette row)
- Features overview: https://www.overleaf.com/about/features-overview (Symbol palette, Premium tag; Visual Editor)
- Symbol Palette launch blog: https://www.overleaf.com/blog/new-feature-find-symbols-quicker-with-our-new-symbol-palette-for-premium (premium launch, required package display)
- Inserting symbols docs: docs.overleaf.com inserting-symbols page (URL not recorded in the upstream notes; "Using the Symbol Palette" section, math-mode requirement)
- AI features: Overleaf docs AI features page (URL not recorded in the upstream notes; "Feature" table, AI Equation Generator)
- Overleaf AI in plans, July 2, 2026: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans (URL inferred from the upstream slug; verify before citing)
- Keyboard shortcuts: https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts (no math shortcuts listed)
- Mathematics learn index: https://www.overleaf.com/learn/latex/Mathematics (search snippet)
- Fractions and Binomials: https://www.overleaf.com/learn/latex/Fractions_and_Binomials (search snippet)
- Aligning equations with amsmath: https://www.overleaf.com/learn/latex/Aligning_equations_with_amsmath (upstream slug, not reopened)
- Visual Editor overview: https://docs.overleaf.com/getting-started/how-do-i-use-overleaf (search snippet)

## EXPAND

- LEAD: Find whether Overleaf documents a non-AI graphical equation editor in Visual Editor. Reason: no public page checked names one.
- LEAD: Find AI Equation Generator input limits, supported formats, and per-tool daily share. Reason: the plans page gives only aggregate AI uses.
- LEAD: Confirm Equation Generator and Symbol Palette availability in Server Pro release notes. Reason: the Server Pro page confirms the palette only in the benefits table, and no page covers the generator.
- LEAD: Open the llms.txt-referenced AI Assist and Error Assist pages to resolve the legacy add-on wording. Reason: this report flags the conflict and does not resolve it.
