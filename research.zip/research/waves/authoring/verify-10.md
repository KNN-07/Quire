# Verify 10: Multilingual authoring, Unicode, fonts, and RTL

Checked October 26, 2026 against public Overleaf documentation. No account testing, compilation, purchases, or functional execution was performed. Package/engine behavior below is LaTeX capability as documented for use on Overleaf, not a separate editor feature.

## Verdict: PARTIAL

The core multilingual workflows are supported by current official guidance. Availability by Free/premium/AI/Commons/Server Pro/Community Edition is undocumented in the reviewed sources, and current RTL source-editor behavior remains unresolved. A material correction to both upstream reports: the current encoding page dates pdfLaTeX/LaTeX's UTF-8 default to TeX Live 2022, not 2018, and explicitly says Overleaf cannot store source characters outside the BMP even though XeLaTeX/LuaLaTeX can typeset much more UTF-8 natively.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Overleaf text files use UTF-8; direct uploads are converted, while some Git/Dropbox non-UTF-8 files can become non-editable. NUL and non-BMP source characters cannot be stored. | https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings — “Encoding,” “Problems with file encoding,” “Invalid/Unsupported Characters” | Platform; plan/edition unspecified | CONFIRMED. This platform storage constraint is distinct from engine Unicode support. |
| pdfLaTeX/LaTeX UTF-8 input is default as of TeX Live 2022; not all UTF-8 characters are typesettable with pdfLaTeX. XeLaTeX/LuaLaTeX handle more natively. | https://docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings — “Support with LaTeX and pdfLaTeX,” “Support with XeLaTeX or LuaLaTeX” | Platform project compiler setting + engine capability; tier unspecified | CONFIRMED. Older 2018 statement at https://www.overleaf.com/learn/latex/International_language_support — “Input encoding” is legacy context and should not override current docs. |
| pdfLaTeX with `babel` is documented for Greek, Polish, Vietnamese, and Cyrillic; XeLaTeX/LuaLaTeX with `babel` or `polyglossia` is recommended for Arabic, Farsi, Hebrew, Indic scripts and modern OTF/TTF font control. | https://docs.overleaf.com/troubleshooting-and-support/typesetting-non-latin-languages — “Greek, Polish, Vietnamese and Languages using Cyrillic Script”; “Other Non-Latin Languages and more control over fonts” | LaTeX packages/engines on Overleaf; tier unspecified | CONFIRMED as guidance, not universal compatibility guarantee. |
| `babel` supports language switching, language-specific conventions, and per-language/script fonts; `fontspec`/`polyglossia` examples use XeLaTeX or LuaLaTeX. | https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_babel_and_fontspec — “Multiple languages/scripts,” “Specifying fonts for specific languages”; https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_polyglossia_and_fontspec — “Changing the project’s compiler” | LaTeX packages/engines; tier unspecified | CONFIRMED. These are author-configured typesetting behaviors, not translation or language-detection services. |
| Overleaf lists installed OTF/TTF fonts, including Google Noto; CJK articles demonstrate XeLaTeX/`xeCJK`, Chinese `ctex`, Japanese pTeX/`luatex-ja`, and project-uploaded Korean fonts. | https://www.overleaf.com/learn/latex/Questions/Which_OTF_or_TTF_fonts_are_supported_via_fontspec%3F — opening; https://www.overleaf.com/learn/latex/Chinese — “Introduction,” “xeCJK with XeLaTeX”; https://www.overleaf.com/learn/latex/Japanese — “The pTeX engine”; https://www.overleaf.com/learn/latex/Korean — “Example using Google Noto CJK fonts,” uploaded-font example | Overleaf hosted environment examples; tier unspecified | CONFIRMED with limits. Glyph coverage depends on chosen font; Japanese page says some packages do not support every convention, including vertical typesetting. |
| For Arabic-main mixed RTL/LTR output, `babel` documents `bidi=basic` with LuaLaTeX and `bidi=default` with pdfLaTeX/XeLaTeX; LuaLaTeX is strongly recommended for comprehensive complex-script and bidi support. | https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_babel_and_fontspec — “Mixing right-to-left (RTL) and left-to-right (LTR) languages” | LaTeX package/engine behavior; tier unspecified | CONFIRMED for typeset output only; no claim of successful execution. |
| RTL editing in Source/Rich Text views may be incomplete. | https://www.overleaf.com/learn/latex/Multilingual_typesetting_on_Overleaf_using_polyglossia_and_fontspec — “Introduction” | Editor behavior; tier unspecified | UNRESOLVED/current status. The undated “at the time of writing” caveat is potentially stale. Current https://docs.overleaf.com/navigating-in-the-editor/editor-display-font — “Editor font family” documents font choices and cursor misalignment for Thai/Japanese/Cyrillic, not RTL support. |
| Plan or deployment-edition availability of these workflows. | The language/compiler/editor pages above | Free, premium, AI, Commons, Server Pro, Community Edition | UNRESOLVED. The reviewed sources provide no tier matrix; do not infer access or restrictions. |

## Counter-search queries

- `site:docs.overleaf.com/troubleshooting-and-support/file-encodings-and-line-endings Overleaf BMP NUL UTF-8 TeX Live 2022`
- `site:docs.overleaf.com/troubleshooting-and-support/typesetting-non-latin-languages Overleaf Arabic XeLaTeX LuaLaTeX babel`
- `site:overleaf.com/learn/latex Multilingual typesetting babel fontspec RTL bidi=basic`
- `site:docs.overleaf.com editor RTL source Rich Text right-to-left Overleaf`
- `site:docs.overleaf.com "Editor display font" cursor misalignment Thai Japanese Cyrillic`

## EXPAND

- **LEAD — plan/edition availability:** UNRESOLVED; reason: reviewed primary language, compiler, font, and editor pages do not map the workflows to Free/premium/AI/Commons/Server Pro/Community Edition.
- **LEAD — current RTL editing behavior:** UNRESOLVED; reason: the explicit polyglossia editor caveat is undated and possibly stale; current editor-font docs do not address RTL editing.
