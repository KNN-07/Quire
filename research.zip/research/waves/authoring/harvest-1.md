# Overleaf Code Editor: highlighting, autocomplete, and linting

Research date: October 26, 2026. Public official Overleaf sources only; no authenticated account testing or purchase was performed. Current docs were read directly rather than relying on search snippets. Claims below describe editor assistance, not general LaTeX execution or compiler guarantees.

## Syntax highlighting

The Code Editor has selectable editor themes that control syntax highlighting; this is a user-specific preference and does not affect the Visual Editor. Overleaf specifically says LaTeX code may not be highlighted unless the source filename has a `.tex` extension. **Source:** https://nl.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu#TeX_Live_version, headings “Editor theme,” lines 134–138; the same source describes this as a user-specific setting. **Availability:** the documentation does not identify this as paid or plan-restricted; treat it as a standard editor capability, not a plan guarantee.

Current-editor context: Overleaf’s November 29, 2022 source-editor post says the source editor moved to CodeMirror 6 and warned that autocomplete suggestions and highlighting could differ from the legacy editor. Its update says the legacy editor was retired for all users on June 14, 2023. **Source:** https://www.overleaf.com/blog/towards-the-future-a-new-source-editor, opening/update and editor changes. This is dated transition context, not evidence for exact current highlighting grammar or language coverage; those details are **UNRESOLVED**.

## Autocomplete

Current documentation calls autocomplete a toggle under project Settings > Editor; it enables/disables the suggestion list while typing a LaTeX command. `Ctrl+Space` opens the autocomplete menu; within `\cite{...}` it searches the bibliography. **Sources:** https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor, heading “Project settings” > “Editor,” lines 54–62; https://docs.overleaf.com/navigating-in-the-editor/keyboard-shortcuts, shortcut table, lines 23–25. This is presented as a normal editor setting with no paid restriction.

Citation assistance has two distinct levels. Simple search browses and filters citation keys in project `.bib` files and is available to all users. Advanced reference search searches project `.bib` files plus linked reference managers and is documented as premium. Both rely on autocomplete recognizing citation commands, so autocomplete must be enabled. **Source:** https://docs.overleaf.com/citing-and-references/adding-citations-and-references, opening feature description and “How to enable Overleaf’s auto-complete” / “How to select a reference search style (premium feature),” lines 6–25. Do not conflate the premium advanced reference-search integration with ordinary command completion.

Historical implementation detail (2017, not a current guarantee): an Overleaf blog described suggestions from commands already used in the document plus the 100 most frequent commands in a corpus, and discussed context-sensitive ideas as work in progress. **Source:** https://www.overleaf.com/blog/523-a-data-driven-approach-to-latex-autocomplete, “What’s Next?” and preceding analysis, lines 13–20, 28–31, 54–63. The post itself says its data was not fully representative. Current exact suggestion corpus, package-awareness, custom-command coverage, and completion behavior beyond the cited docs are **UNRESOLVED**.

Legacy note (2017): a ShareLaTeX archival post says labels were checked continuously for `\ref` autocomplete. This is explicitly historical, not independently confirmed as current behavior. **Source:** https://www.overleaf.com/blog/auto-complete-ref-commands-2017-06-15, lines 3–14.

## Linting / Code Check

Code Check is a heuristic editor-side syntax checker that reports selected common problems as the user types, before compilation. Current Code Check documentation enumerates mismatched `\begin`/`\end`, `{}`, `\left`/`\right`, `$...$`/`$$...$$`, math commands outside math mode, and text commands inside math mode. Another current getting-started page additionally lists undefined commands and unmatched braces/brackets. **Sources:** https://docs.overleaf.com/troubleshooting-and-support/code-check, “Code Check” and “Known issues,” lines 3–20, 48–52; https://docs.overleaf.com/getting-started/recompiling-your-project, “Syntax checks,” lines 28–32. The pages do not establish that Code Check is a complete or authoritative test for all listed compiler errors.

Restrictions matter: Code Check assumes typical LaTeX and standard commands; custom macros and packages that alter standard behavior may produce incorrect results. In particular it does not expand shortcut macros standing in for environments. Known false-positive/coverage cases include literal `%` in URL/verbatim-like commands followed by code on the same line, LaTeX3 underscore macro names, and custom definitions splitting `\begin` and `\end`. It can be disabled globally, for a whole file with `%%novalidate`, or for a region bracketed by `%%begin novalidate` and `%%end novalidate`. **Source:** same Code Check page, headings “Code Check limitations,” “Disabling…,” and “Known issues,” lines 15–52. These are parser limitations, not restrictions on what LaTeX the project may compile.

**Availability:** current docs present Code Check as a project Editor setting and do not state a paid-plan restriction. Do not infer that every warning/error found by LaTeX compilation will be caught while typing. Compiler diagnostics are separate: current redesigned-editor docs describe a log pane for LaTeX errors, warnings, and compiler output (https://docs.overleaf.com/getting-started/how-do-i-use-overleaf/redesigned-overleaf-editor, “Error logs,” lines 36–43).

## AI distinction and deployment scope

AI Error Assist is separate from ordinary syntax highlighting, autocomplete, and Code Check. The July 2, 2026 official plan update says Overleaf AI is included across plans with differing allowances: Free has Basic without AI Assistant; Student has Basic with Assistant; Standard has a higher allowance and Assistant; Pro has Max allowance; Commons has Basic without Assistant, while Commons AI adds Max plus Assistant. **Source:** https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans, dated announcement and plan headings, lines 3–7, 14–18, 20–43. This newer dated source supersedes older AI Assist add-on docs for plan packaging; no AI claim is used to characterize deterministic linting or completion.

Current on-premises docs distinguish Community Edition from Server Pro and enumerate some additional Pro capabilities, but do not map the three editor features in this report to edition-specific availability. **Source:** https://docs.overleaf.com/on-premises/installation/introduction, lines 2–6. Therefore Community Edition/Server Pro parity or differences for highlighting, autocomplete, and Code Check are **UNRESOLVED**. The official public repository shows CodeMirror dependencies, including autocomplete and lint packages, but dependencies alone do not establish shipped feature behavior or edition guarantees: https://github.com/overleaf/overleaf/blob/main/package.json, lines 1119–1129.

## EXPAND

- **LEAD — current syntax-highlighting language/file coverage:** unresolved; official docs only specify themes and `.tex` filename behavior, not full mode coverage.
- **LEAD — exact present-day completion sources and custom/package macro behavior:** unresolved; current docs describe the toggle and citation integration, while algorithm details found are dated 2017.
- **LEAD — Community Edition versus Server Pro parity:** unresolved; current deployment docs do not attribute these editor facilities by edition.
