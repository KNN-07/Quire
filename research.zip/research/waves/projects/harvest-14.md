# Overleaf angle 14: Files and folders, renaming, moving and deletion

Research date: 2026-10-26. Sources below are official Overleaf documentation. No authenticated product testing was performed.

## Findings

### Folder creation and file placement

Overleaf's current upload guide documents creating nested folders by opening a parent folder and choosing **New folder**, or right-clicking the parent and choosing **New folder**. The same guide says users can upload an entire local folder while preserving its directory structure, or select multiple files; each upload is limited to 180 files and 50 MB. These are documented editor capabilities, not LaTeX features. Availability is not presented as a paid-only feature. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project — headings **Uploading multiple files**, **Creating folders**.

The official image-upload guide additionally documents dragging already-uploaded files between folders in the left panel and uploading directly into a selected folder. This supports a UI-level move workflow for files. It does not specify whether moving a folder itself is supported, nor document collision handling or undo guarantees. Source: https://docs.overleaf.com/writing-and-editing/inserting-images/uploading-images — heading **Uploading images to a folder**. The guide is general editor documentation, not limited to an image-only storage model.

### Rename, move, and delete permissions

Overleaf's on-premises role matrix explicitly groups **create/rename/delete/move files**: project owners and editors have permission; reviewers and both named and link-sharing viewers do not. It separately says only owners can rename the project. This matrix is documented for Server Pro and Community Edition deployment roles, not a complete cloud-plan matrix; do not assume identical role names or permissions for every hosted plan based on this page. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — heading **Project & file operations**.

Current public editor docs located in this research do not specify the exact in-editor steps for renaming/deleting individual files or folders, whether empty folders can be removed, or the undo/recovery behavior for an individual file deletion. These details are **UNRESOLVED**; the permission matrix confirms capabilities but is not a usage guide.

### Project-level deletion is distinct from file deletion

The project dashboard has separate archive and trash states. Archiving removes a project from the main list without scheduling deletion; a trashed project remains until its owner manually deletes it. An owner can restore it or permanently delete it, and permanent project deletion has no undo and removes it for collaborators. A collaborator who does not own a shared project can trash it from their own list and then leave, but cannot permanently delete it. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project — headings **Trashed Projects**, **How does trashing a project affect collaborators?**, **How to leave a shared project**. This is project-level behavior, not evidence of file-level trash.

### External synchronization caveats

For Overleaf Git integration, a local file rename or move is represented on Overleaf as delete plus create; Overleaf warns this can lose file-associated metadata, including tracked changes and comments. A pushed folder rename can leave an empty folder with its old name alongside the new folder; in a name-collision case, the Git integration may reject a combined rename/new-file commit, and the guide recommends splitting it and deleting the leftover folder. These are integration-specific effects, not a claim about renaming through the editor UI. Source: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration/advanced-git-operations — **Known limitations**, subsections **Renaming folders** and **Renaming files and moving files**.

Dropbox sync is explicitly premium; docs say premium access includes individual subscribers, group-subscription members, and Overleaf Commons participants. Deleting a Dropbox folder removes its contents in Overleaf while retaining the project; renaming/moving project folders or files in Dropbox may be treated as delete-and-create and lose history, tracked changes, and comments. This describes Dropbox synchronization, not ordinary editor operations. Source: https://docs.overleaf.com/integrations-and-add-ons/dropbox — opening paragraph under **Dropbox**, and **What should I know before syncing projects?** No AI-specific or other plan-tier file-operation claim was found.

## Boundaries

LaTeX commands such as `\input`, `\include`, or `\graphicspath` refer to files and paths when compiling; they are not Overleaf file-manager operations and do not themselves rename, move, or delete project files. A directory/path usable by LaTeX should not be conflated with a documented editor operation. The cited upload guide covers platform storage organization; it does not establish arbitrary LaTeX filesystem access.

## EXPAND

- **LEAD — direct in-editor rename/delete steps and file recovery:** unresolved in current official pages found; search/navigation docs found here describe the file tree/outline but not these actions. Needed for precise UI procedure and guarantees.
- **LEAD — folder move, rename, delete and empty-folder behavior in the editor:** unresolved; current evidence only describes creating nested folders and dragging files between folders. Needed to distinguish folder operations from file operations.
- **LEAD — hosted Free/premium role-specific file-operation matrix:** unresolved; the explicit matrix reviewed is in the on-premises Server Pro/Community Edition docs. Needed before assigning cloud-plan-specific permissions.
