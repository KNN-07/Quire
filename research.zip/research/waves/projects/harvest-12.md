# Harvest 12: Template gallery, search, publishing and institutional templates

Research checked October 26, 2026. Sources below are public Overleaf primary sources. This report distinguishes Overleaf product behavior from what a template's LaTeX source can do; no template was compiled or submission flow functionally tested.

## Gallery discovery and use

The public gallery presents filters for All, Templates, Examples and Community articles, a search field, and category links including journal articles, bibliographies, books, calendars, CVs, letters, assignments, newsletters, posters, presentations and theses. These are documented/live page affordances, not a claim about search ranking, exact matching, or result completeness. Source: [Overleaf Gallery](https://www.overleaf.com/gallery/), headings “Filters,” “LaTeX templates and examples,” and “Categories.”

Users can browse by document type from New Project > Templates or go directly to the gallery; opening a listing shows details and “Open as Template” creates an editable copy. The public template guide describes this flow; it does not say that the original published project is changed by editing the copy. Source: [Creating a project from a template](https://docs.overleaf.com/templates/creating-a-project-from-a-template), heading “Creating a project from a template.”

Any existing project can serve as a private starting point by making a copy; public gallery publication is unnecessary. Source: [Can I create my own private templates on Overleaf?](https://www.overleaf.com/learn/how-to/Can_I_create_my_own_private_templates_on_Overleaf%3F), opening paragraph. This is a project-copy workflow, not evidence of a private template catalog on the cloud service.

## Publishing and eligibility

The public gallery is curated and accepts official journal/proceedings templates, official university templates (including theses, reports, letters and presentations), official conference templates, and selected broadly useful or less-common templates. Required official publisher, university or conference guideline links belong in the submission description. Common-class templates are rarely accepted as the gallery already has many. Overleaf may also accept institution/partner-requested templates. Source: [Submitting to the Overleaf template gallery](https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery), headings “Templates suitable for the gallery.”

Exclusions include unofficial journal or university templates, near-duplicates/minimal modifications, CV/resume templates, personally identifying sample content, incomplete projects, preprints/complete works, promotional material, limited-use material, and incompatible licensing. Use dummy text. Overleaf reserves discretion and says high submission volume may mean no response or specific rejection reason. Source: same URL, heading “Templates not suitable for the gallery.”

Submission starts from File or the project-name menu > Submit > Overleaf Gallery. Updates must be made in the original submitted project and resubmitted; edits alone do not update the listing. Replacement occurs only after Overleaf approves it. Source: same URL, headings “How to submit a project to the Overleaf Gallery” and “How to update a published template.”

## Publisher submission is a separate workflow

For partnered publishers, some official gallery templates add a submission link that exports and sends project files to the publisher system. Other partners have a less-complete Submit-menu integration: users download files and upload them themselves. The Submit menu can search supported journals, repositories, author services and conference proceedings; publisher-specific actions and requirements vary. Do not infer that every gallery journal template supports direct submission, that formatting guarantees acceptance, or that Overleaf itself decides publisher requirements. Source: [Submitting to publishers](https://docs.overleaf.com/templates/submitting-to-publishers), headings “Publisher submission links,” “The Submit menu option,” and “Submit modal.”

## Institutional and self-hosted availability

Overleaf Commons subscribers can have a customized institutional portal with quick-start links and optional featured templates selected from the public gallery. A template must first be in the gallery; an administrator then contacts Overleaf Support to feature it. Portal text/images are arranged during onboarding; updates go through Overleaf’s Success team. Commons is an institutional subscription, not a general gallery feature or a per-template access guarantee. Source: [Your Overleaf portal](https://docs.overleaf.com/commons/your-overleaf-portal), headings “Your Overleaf portal” and FAQ “How do we add a new template to our featured templates page?”; [Intro to Overleaf Commons](https://docs.overleaf.com/commons), heading “What is Overleaf Commons?”

For self-hosting, Server Pro documents local template publication by a designated Template User and redistribution of downloaded public templates. Gallery categories are controlled by project tags; multiple tags can put a template in multiple groups. Public-gallery transfer is manual per template because Server Pro is designed to work offline. A downloaded project may lack packages in the default minimal TeX Live environment; Sandboxed Compiles is recommended for broader package compatibility. Sources: [Templates (Server Pro)](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/templates), headings “Publishing templates,” “Your gallery,” and “Transferring templates from overleaf.com”; [Sandboxed Compiles](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles), “Easier package management.”

**Availability:** cloud gallery browsing and starting projects are documented for standard Overleaf users; Commons featured-template portals require Commons; local template management/publishing and the Template User role are Server Pro-specific. Server Pro documentation says Community Edition lacks the Template User role and its template-management permissions. Sources: above, plus [Roles and permissions](https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions), headings “Manage template” and “Template Gallery.” No paid-plan gate for ordinary public gallery use is documented in these sources. Search entitlement differences and any current cloud plan-specific publishing limits: **UNRESOLVED**.

## Boundary and open questions

Gallery descriptions and sample projects are template content. LaTeX classes, packages, styles, and institutional rules are supplied by authors/institutions; they are not platform guarantees that a document complies with current submission rules. Likewise, the gallery's presence of a template does not establish official status unless its description/source links support that status. The gallery page contains both official and explicitly unofficial institutional examples (e.g., UTFPR entry), so verify each listing's stated provenance.

## EXPAND

- **LEAD — Search behavior/filters:** current page confirms visible search and filters, but official documentation located here does not specify matching, ranking, or whether all listing types share the same search. Reason: no authoritative behavioral specification found.
- **LEAD — Cloud plan entitlement:** no source in this pass established whether gallery submission or particular publisher links depend on Free, premium, or AI entitlements. Reason: docs describe workflows but omit plan matrix.
- **LEAD — Publisher coverage:** partner-specific actions vary; no exhaustive, stable partner list was established. Reason: the official guide describes variable integrations without a durable full roster.
