# Verify 13: ZIP upload, importing existing projects, file limits

Research date: 2026-10-26. Public official Overleaf sources only. No logged-in tests, no purchases.

## Verdict: PARTIAL

Core ZIP upload steps, file limits, and most import routes are confirmed by primary docs. Three items are unresolved: free-tier availability of ZIP upload and project copy, the harvest-13 input (file missing), and the Server Pro and download-page claims from expand-13, which I did not verify.

## Inputs

- `harvest-13.md`: the read returned ENOENT at the expected path. Harvest leads could not be reconciled.
- `expand-13.md`: read successfully. Its LEAD 1 (180-files cap) is now resolved, see below.

## Verified findings

### ZIP upload (platform feature)

- **Creation path.** Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project, heading "How to upload a project". The dashboard "New project" menu has "Existing project (.zip)", which opens the "Upload Zipped Project" modal. If the upload succeeds, the project opens. Availability: no tier gate stated on this page.
- **Zip contents.** Same page, heading "Uploading large projects". The zip should contain only LaTeX-processable files: plain text, plus .eps, .pdf, .svg, .png images. It cannot exceed 7 MB of editable material.
- **Top-level folder.** Same page, heading "Troubleshooting project upload issues". If all files sit in one top-level folder, move them out so the main document is not inside a folder.
- **Build artifacts.** https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project/files-that-should-not-be-included-in-a-project, the sections on compiled PDFs and on local build files to remove before zipping. Remove *.aux, *.bbl, *.synctex.gz, *.run.xml and similar. Do not upload .git folders.
- **Compiler settings after upload.** Upload page, heading "Troubleshooting project upload issues". Check the compiler (pdfLaTeX default), TeX Live version, and main document. This is a platform setting, not a LaTeX capability.

### File and upload limits

Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits, table "Overleaf plan limits". Free and premium columns are identical for these rows:

| Limit | Value |
|---|---|
| Files per project | 2000 |
| Editable material per project | 7 MB |
| Individual editable text file | 2 MB (advisory; larger may stay editable) |
| Individual upload | 50 MB |
| Total project size | no enforced limit; recommended 500 MB, under 100 MB with GitHub sync or Git integration |
| Number of projects | Unlimited |

- **180 files per upload.** Verified in the primary upload page, heading "Uploading large projects": each upload holds up to 180 files, and extra files are dropped. This resolves expand-13 LEAD 1. The number also appears on https://www.overleaf.com/learn/how-to/Uploading_a_project%23Limitations_on_Uploads (same heading).
- **Oversized zips.** Same upload page: if the zip exceeds 50 MB, create the project from a subset and upload the rest by hand.
- **Plan labels.** The plan-limit table gives the same values for Free and premium. Premium-features page (https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features) does not list file limits or upload as a premium feature.

### Importing existing projects

- **Copy a project.** https://docs.overleaf.com/managing-projects-and-files/copying-a-project. Two routes: dashboard "More > Make a copy", or File > Make a copy. The copy is owned by the copier, drops collaborators, history, comments and tags, and uses the latest TeX Live. No tier gate is stated. Availability: UNRESOLVED for free accounts.
- **Word and Markdown import.** https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files. Converted with Pandoc. The page says files over 50 MB cannot be converted. Layout and custom packages do not carry over. No tier gate stated.
- **GitHub import.** https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization. The page's hint says GitHub sync is a premium feature. Heading "Creating a new Overleaf project from a GitHub repository" covers creating a project from a repo. The page says it is not possible to synchronize an existing Overleaf project with an existing repo. Submodules and Git LFS are not supported. Sync does not operate once editable content exceeds 7 MB (warning box on file limits). Also: no more than about 100 files per commit is recommended.
- **Cross-project files.** https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects, "From Another Project". Linked files are read-only in the child project and can be refreshed. A .tex file from another project cannot be the main file. No tier gate stated.

### Premium gating (documented)

- Premium-features page: GitHub and Git integration are account-level premium features tied to the subscription holder. Premium features like track changes and compile time apply at the project owner's level.
- Plans page (https://www.overleaf.com/user/subscription/plans): Free plan lists "Unlimited projects". The table does not mention ZIP upload or copy.

### Platform features vs LaTeX

Upload, copy, Pandoc conversion, GitHub sync and cross-project linking are platform behaviour. The LaTeX side is only what the compiler does with the uploaded files, controlled by compiler, TeX Live version and main document settings.

### Date and legacy tags

- The upload page includes a screenshot file dated May 2026. The page text read here has no last-updated date; treat it as current as of the read date.
- expand-13 cites a GitHub Server Pro FAQ wiki as "outdated". I did not open it. Not used here.
- No deprecation of ZIP upload, copy or file limits found in the pages read.

## Unverified or contradicted from expand-13

- Download (export) zip contents: cited only from a search snippet. Not opened. UNRESOLVED.
- "Max projects unlimited" sourced to the plans page: confirmed on the plans page for Free.
- Harvest-13 leads: UNRESOLVED, input missing.
- AI bundling (July 2, 2026 blog vs older AI Assist): out of scope for this angle. Not investigated. Not combined with anything here.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Zip upload via "Existing project (.zip)" | docs.overleaf.com/managing-projects-and-files/uploading-a-project, "How to upload a project" | Not tier-gated in docs | Confirmed; tier UNRESOLVED |
| Zip may contain only LaTeX-processable files; 7 MB editable cap | same, "Uploading large projects" | Free and premium (plan-limits table) | Confirmed |
| 50 MB per individual file | same; plan-limits table | Free and premium | Confirmed |
| 180 files per upload | same, "Uploading large projects"; learn page same heading | Not tier-gated | Confirmed (resolves expand LEAD 1) |
| 2000 files per project | plan-limits table | Free and premium | Confirmed |
| 2 MB advisory per editable text file | plan-limits table, footnote * | Free and premium | Confirmed |
| No enforced total project size; 500 MB recommended, under 100 MB with GitHub sync | plan-limits table, footnote † | Free and premium | Confirmed |
| Move main document out of top-level folder | uploading-a-project, "Troubleshooting project upload issues" | n/a | Confirmed |
| Remove *.aux, *.bbl, *.synctex.gz, *.run.xml; do not upload PDF or .git | files-that-should-not-be-included-in-a-project | n/a | Confirmed |
| Copy project via dashboard or File menu | copying-a-project | Tier not stated | Confirmed; tier UNRESOLVED |
| Copy drops collaborators, history, comments, tags; latest TeX Live | copying-a-project | n/a | Confirmed |
| Word/Markdown import via Pandoc; files over 50 MB not converted | importing-and-exporting-files | Not tier-gated in docs | Confirmed |
| GitHub sync is premium | github-synchronization, hint | Premium | Confirmed |
| Cannot link existing project to existing repo; no submodules or LFS | github-synchronization | Premium | Confirmed |
| Sync stops above 7 MB editable | github-synchronization, warning box | Premium | Confirmed |
| Cross-project linked files are read-only, refreshable, cannot be main file | sharing-files-across-projects | Not tier-gated in docs | Confirmed |
| Download zip contains source only | downloading-a-project (snippet only) | n/a | UNRESOLVED |
| Server Pro FAQ is outdated | github wiki FAQ (not opened) | n/a | UNRESOLVED |

## Counter-search queries

- "site:docs.overleaf.com copying a project free plan"
- "site:docs.overleaf.com downloading a project zip source only"
- "site:overleaf.com plans Free ZIP upload feature"
- "Overleaf 180 files per upload limit changed"
- "Overleaf zip upload 7 MB editable limit images count"

## EXPAND

- **Free-tier availability of ZIP upload and copy.** Reason open: no official page states a tier for these; the plans and premium-features pages are silent. Next: check the Overleaf plans FAQ or support articles for upload and copy.
- **Download-page zip contents.** Reason open: only a search snippet read. Next: open https://docs.overleaf.com/managing-projects-and-files/downloading-a-project.
- **Harvest-13 leads.** Reason open: harvest-13.md missing (ENOENT). Next: confirm the harvest file path.
- **AI bundling (July 2, 2026 blog vs older AI Assist).** Out of scope for this angle; left for the AI angle. Plans page shows tiered AI allowances, which does not settle the bundling change.
- **Server Pro FAQ.** Reason open: not opened. Only relevant if deployment claims are needed; use the Overleaf GitHub repository docs.
