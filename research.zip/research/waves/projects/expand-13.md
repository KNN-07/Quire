# Expand 13: ZIP upload, importing existing projects, file limits

Research date: 2026-10-26 (task date). Sources: public Overleaf docs and pages only. No logged-in tests, no purchases.

## Harvest input

`harvest-13.md` was not found at the expected path (ENOENT). This report therefore starts from the angle scope and does not reconcile against prior harvest leads. Leads listed in the EXPAND section are the ones this pass found.

## Findings

### ZIP upload (platform feature)

- Creation path: the dashboard "New project" menu has an "Existing project (.zip)" option that opens an "Upload Zipped Project" modal. Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project (heading "How to upload a project"). Tier: the page does not say whether this is premium, so it is documented as available with no tier gate stated.
- Zip contents: the page says a zip should contain only files a LaTeX compiler can process (plain text, and .eps, .pdf, .svg, .png images). Same source, heading "Uploading large projects".
- Top-level folder problem: if the main .tex sits inside a single top-level folder, the docs recommend moving files out so the main document is not in a folder. Source: same page, heading "Troubleshooting project upload issues".
- Compiled PDFs and build artifacts: the docs say Overleaf does not add the compiled PDF to source files, and advise removing `*.aux`, `*.bbl`, `*.synctex.gz`, `*.run.xml` and similar before zipping. Also do not include `.git` folders. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project/files-that-should-not-be-included-in-a-project (headings "Best practice: do not upload a copy of the compiled PDF" and "Local project files to remove before uploading a ZIP file").
- Download (export) is the reverse path: the zip contains source files only, and the PDF is downloaded separately. Source: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project (search snippet only; not opened, so treated as secondary).

### File and upload limits

| Limit | Value | Free | Premium | Source |
|---|---|---|---|---|
| Max files per project | 2000 | yes | yes | https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits (table) |
| Max editable material per project | 7 MB | yes | yes | same table |
| Max individual editable text file | 2 MB (advisory; some larger files may stay editable) | yes | yes | same table, footnote * |
| Max individual upload | 50 MB | yes | yes | same table; also upload page heading "Uploading large projects" |
| Max total project size | no enforced limit; recommended 500 MB, or under 100 MB with GitHub sync or Git integration | yes | yes | same table, footnote † |
| Max projects | unlimited | yes | yes | plans page https://www.overleaf.com/user/subscription/plans |

Notes:
- The upload page says a project zip over 50 MB should be split: upload a subset as the zip, then add the rest by hand. Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project.
- The plan-limits table lists limits identically for Free and premium tiers. The plans page labels Free as "Unlimited projects". Both are sourced; no source found a file-limit difference by plan.
- Editable-material cap (7 MB) is the binding constraint for LaTeX source. The docs define the cap as editable material only; whether non-editable assets such as images count toward it is INFERRED from that wording, not stated by the docs.
- A 180-files-per-upload cap is reported on the learn page, but the fetched learn page returned only a form shell. This appears only in the search snippet for https://www.overleaf.com/learn/how-to/Uploading_a_project%23Limitations_on_Uploads. The docs page for the same topic does not list it. Status: UNRESOLVED (see EXPAND).

### Importing existing projects

- Copy an existing project: two routes, the dashboard "More > Make a copy" and in-project "File > Make a copy". Source: https://docs.overleaf.com/managing-projects-and-files/copying-a-project. Copies are owned by the copier, collaborators, link-sharing, history, comments and tags are not carried over, and the copy uses the latest TeX Live. Tier gating not stated.
- Import from .docx or .md: the New project menu offers Word and Markdown import, converted with Pandoc. Source: https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files. The page says layout and custom packages do not convert, and files over 50 MB cannot be converted.
- Import from GitHub: GitHub sync is labelled a premium feature. Source: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/github-synchronization (hint at top). The same page says a new project can be created from a GitHub repo and that existing projects cannot be linked to existing repos. It also says submodules and Git LFS are not supported, and that GitHub sync stops working if editable content exceeds 7 MB.
- Share files from another project: the "From Another Project" option in Add Files. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects. Linked files are read-only in the child project, can be refreshed from the parent, and a .tex file from another project cannot be the main file. Tier gating not stated.

### Platform features vs LaTeX

- Platform features above: zip creation, copy, Pandoc import/export, GitHub import, cross-project file linking, and the file limits. These are Overleaf behaviour.
- LaTeX capabilities are not described by the upload docs, except that the compiler, TeX Live version, and main-document settings affect whether an uploaded project compiles. Source: upload page heading "Troubleshooting project upload issues".

### Legacy and deprecation

- The GitHub Server Pro FAQ at https://github.com/overleaf/overleaf/wiki/FAQ is marked as moved to on-premises docs and "outdated content". Its statements about limits defer to the learn wiki and are undated. It also says reference search and Mendeley are not available in Server Pro. Date-tag: legacy, undated. Not used for Overleaf.com limits.
- No deprecation of ZIP upload, copy, or file limits was found in the pages read.

## EXPAND

Open LEADs in this angle:

1. **180-files-per-upload cap** - the only source is a search snippet of the learn page. The fetched learn page returned a form shell, and the docs page does not list the cap. Reason open: no primary text confirms it is current. Next step: open the learn page's full text or the Overleaf support page for uploads.
2. **Free-tier availability of ZIP upload and copy** - the docs state no tier gate, and the plans page does not list upload as a feature. Reason open: no page states it explicitly. UNRESOLVED.
3. **Harvest-13 leads** - the harvest file is missing, so any harvest-specific leads could not be checked. Reason open: missing input.
4. **AI bundling (July 2, 2026 blog vs older separate AI Assist)** - out of scope for this angle. Not investigated. The plans page does show AI tiers per plan, but that does not establish the bundling change. Left for the AI angle.

Closed as duplicates: the upload-size limit (50 MB) appears on both the learn wiki snippet and the docs page; the docs page and plan-limits table agree, so one fact is recorded. The 2000-file limit appears on the docs page and plan-limits table and is recorded once.
