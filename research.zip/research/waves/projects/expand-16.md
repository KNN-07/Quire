# Overleaf angle 16: Linked files between projects and refresh behavior

**Research date:** 2026-10-26  
**Scope:** Public primary sources only. No authenticated use, purchases, or functional execution.

## Current cloud workflow

Overleaf's current [Sharing files across projects](https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects), heading **“Sharing files across projects”** (last updated seven months before this research), documents a parent/child model: choose **Upload files** / **Upload file**, then **From Another Project**, select a parent project and a file. Examples include `.bib`, `.cls`, `.sty`, and graphics. The resulting child-project linked file can be used but not edited there; selecting it and choosing **Refresh** pulls in changes made to the parent's original. Thus the documented refresh is an explicit user action, not continuous or automatic sync. Imported `.tex` files cannot be set as the child's main compile file. The docs do not say that linked `.tex` files cannot be used as inputs.

No documented refresh guarantees cover conflict resolution, change detection, atomicity, deleted or renamed parent files, permissions changing, or refresh failure behavior. Treat those details as **UNRESOLVED**, not implied by the “pull in changes” wording.

The [Main document](https://docs.overleaf.com/getting-started/recompiling-your-project/the-main-document), heading **“Compiling other files in the same project,”** identifies “input from another project” as the mechanism to share common files. LaTeX's `\input`/`\include` are document composition commands; they do not establish platform-level links or refresh behavior. Their arbitrary behavior with linked files is not specified in these sources. This closes the harvest's question only to the extent that Overleaf explicitly presents cross-project input as a platform feature; file-type-specific compilation behavior beyond the main-file restriction remains unresolved.

## Similar workflows and duplicate leads

Do not conflate linked project files with graphics insertion or external URLs. The current [Insert figure button](https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button), heading **“From another project,”** describes selecting a graphic or a generated output for insertion, not a linked file with the documented child-file Refresh control. Its persistence and refresh semantics are **UNRESOLVED**. The separate current [Adding a file from a URL](https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/adding-a-file-from-a-url), headings **“From External URL”** and **“Google Drive example,”** does show refreshing an externally hosted file after its source changes. That is a distinct link source and does not establish cross-project refresh behavior. These are related but not duplicates of the parent/child feature.

Overleaf's [2018 blog announcement](https://www.overleaf.com/blog/new-overleaf-v2-features-rich-text-and-adding-linked-files), heading **“Adding Linked Files,”** is legacy corroboration: it described refreshing external images, datasets, and shared bibliographies, as well as files in a master Overleaf project. Use the current docs above for present workflow; the blog's broader examples do not add current guarantees.

## Availability and deployment

The cloud feature page does not identify Free, premium, or AI eligibility; plan availability is **UNRESOLVED**. No AI relationship is documented for this feature; the July 2, 2026 AI-bundling announcement is therefore not relevant evidence and should not be used to infer linked-file eligibility.

For self-hosting, the official [Overleaf Toolkit current `variables.env`](https://github.com/overleaf/toolkit/blob/master/lib/config-seed/variables.env) currently sets `ENABLED_LINKED_FILE_TYPES=project_file,project_output_file`, direct evidence that linked project files and linked output files are configurable in the Toolkit deployment defaults. The official [Overleaf 2.0 release notes](https://github.com/overleaf/overleaf/wiki/Release-Notes-2.0), dated **2019-10-09**, historically say Linked Files were introduced to both Community Edition and Server Pro; they also describe that variable as controlling available linked-file types. This is date-tagged historical evidence, not a current version-by-version guarantee. Current Toolkit defaults support the project-file type, but current Community Edition versus Server Pro feature parity and their refresh semantics are not specified by the sources reviewed. No deprecation notice was found in the current cloud feature page or current Toolkit default; absence of a notice is not a guarantee against future removal.

## EXPAND

- **LEAD — Refresh semantics:** Partially closed: current docs establish manual Refresh for parent-project changes. Conflict, deletion/rename, atomicity, and failure guarantees remain **UNRESOLVED** because official docs do not specify them.
- **LEAD — Plan and deployment matrix:** Partially closed: current Toolkit defaults enable `project_file`; 2019 release notes establish historical CE/Server Pro support. Cloud plan eligibility and current CE/Server Pro parity remain **UNRESOLVED** because current official feature documentation does not state a matrix.
