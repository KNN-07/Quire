# Projects cluster reconciliation: angles 11-20

Checked October 26, 2026. Public primary sources only; no authenticated tests, purchases, runtime acceptance claims, or inferences of unavailability from absent tier labels. `harvest-13.md` is genuinely absent from the project-wave directory; angle 13 was reconstructed from `expand-13.md`, `verify-13.md`, the brief, and duplicate evidence in angles 11, 14, 15, 19, and 20.

## Source register

| ID | Official URL | Exact heading(s) used |
|---|---|---|
| S1 | https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project | “Uploading multiple files”; “Creating folders” |
| S2 | https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits | “Overleaf plan limits” |
| S3 | https://docs.overleaf.com/managing-projects-and-files/downloading-a-project | “Downloading a project”; “How to download the PDF file”; “How to download multiple projects as a .zip file” |
| S4 | https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery | “Templates suitable for the gallery”; “Templates not suitable for the gallery”; “How to update a published template” |
| S5 | https://docs.overleaf.com/groups/user-management/managed-user-accounts | “Removing Managed Users from your subscription”; “Deleting users and transferring project ownership” |
| S6 | https://www.overleaf.com/legal | “Your Stuff & Your Privacy”; “Managed Accounts” (Terms last modified May 5, 2026; page overview last modified August 5, 2026) |
| S7 | https://docs.overleaf.com/integrations-and-add-ons/ai-features | “AI allowance by plan”; “Who can use Overleaf AI”; “Troubleshooting” |
| S8 | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans | “What each plan includes”; “What’s new: Commons AI for institutions” (July 2, 2026) |
| S9 | https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription | “AI features with Commons access” |
| S10 | https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions | “Project Dashboard”; “Project & file operations”; “Manage template”; “Template Gallery”; “Deleted Docs” |
| S11 | https://docs.overleaf.com/on-premises/user-and-project-management/project-management | “Recovering deleted documents”; “Transferring ownership of a project” |
| S12 | https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects | “Sharing files across projects” |
| S13 | https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/adding-a-file-from-a-url | “Direct download links (URLs)”; “Overleaf’s ‘From External URL’ feature” |
| S14 | https://docs.overleaf.com/integrations-and-add-ons/google-drive | “Google Drive”; “Notes and caveats on changes to Google-based services” |
| S15 | https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/changing-the-name-or-color-of-a-tag | “Changing the name or color of a tag” |
| S16 | https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/deleting-a-tag | “Deleting a tag” |
| S17 | https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project | “Deleting a project”; “Trashed Projects”; “How does trashing a project affect collaborators?” |
| S18 | https://docs.overleaf.com/writing-and-editing/history-and-versioning | “Using the full History feature”; “Recovering deleted files”; “Restoring an earlier version of the project” |
| S19 | https://docs.overleaf.com/collaborating/sharing-a-project | “By Email”; “By Link”; “Do share links expire?” |

## Corrected claim table

| Angles | Corrected current claim | Availability / boundary | Status |
|---|---|---|---|
| 11, 13, 14, 15 | Uploads allow 180 files and 50 MB per upload; folders preserve structure. Projects have 2,000 files, 7 MB editable material, 2 MB advisable per editable text file, and no enforced total-size ceiling, with documented recommendations. | S1-S2 explicitly give the file limits for Free and premium; they do not make every import workflow a separately tiered entitlement. | CONFIRMED |
| 11, 13, 20 | Blank/example, copy, ZIP import, and Open as Template workflows are documented. Copy ownership/history/collaborator behavior is documented. | When a workflow page has no hosted-plan label, record “plan gate not stated,” not “unavailable” or “Free confirmed.” | CONFIRMED workflow; tier UNASSERTED |
| 11, 12, 20 | The Gallery is curated; the full current exclusion list includes unofficial journal/university templates, minimal changes, PII/CVs, limited-use/incomplete/completed work, incompatible licensing, near-duplicates, homework/activity sheets, and promotions. Updates require resubmission and approval. | S4 supersedes partial fetches in verify-11/20. | CONFIRMED |
| 11 | Managed Users has a non-destructive Remove User route and destructive Delete User plus project transfer. Overleaf claims no ownership of user content, while managed organizations have stated administrative access/control. | Legal ownership under an institution’s separate policy is not a universal product-functionality claim. | CONFIRMED platform terms; institution-specific ownership OUT OF SCOPE |
| 12 | Commons has Basic AI allowance without AI Assistant; Commons AI has Max allowance with Assistant. Free similarly lacks Assistant. | S7-S9 and the dated July 2, 2026 announcement now agree. The AI page still contradicts itself by listing Summarize/Explain near the top while “Troubleshooting” says they were removed; treat those named actions as removed. | RESOLVED with caveat |
| 12, 20 | Server Pro public template publishing belongs to Template User, not Admin; private publishing allows Template User or Admin. Community Edition has no Template User role. | S10 is a current role matrix; do not speculate about custom code paths. | CONFIRMED |
| 13, 19 | Source ZIP contains source only; compiled PDF is separate after successful compilation. Generated files and submission bundles have separate routes. | S3 closes the source/PDF ambiguity. Cross-plan and deployment parity for every generated-output control is not documented. | CONFIRMED workflow; parity UNASSERTED |
| 14 | Owner/Editor can create, rename, delete, and move files in the on-premises role matrix. Server Pro admins can undelete documents; Community Edition cannot use that admin control. Hosted History can recover deleted files within the visible history window. | No current public page found for exact hosted file-tree rename/move/delete clicks or a hosted role matrix. | Capability CONFIRMED; exact hosted procedure UNRESOLVED |
| 15, 16 | Linked project files are read-only in the child and manually refreshed; linked `.tex` cannot be the child main file. External-URL imports require a direct-download URL; Drive has no direct sync but imported files can be manually refreshed. | S12-S14 do not promise conflict handling, atomicity, rename/delete behavior, or automatic polling. | CONFIRMED documented behavior; extra guarantees UNASSERTED |
| 17 | Current tag rename and deletion procedures are documented; deleting a tag does not delete projects. Dashboard project search exists in the on-premises user matrix. | No official current specification was found for SaaS search matching, sort fields/default order, or a numeric bulk-selection cap. | Tags CONFIRMED; search/sort semantics UNRESOLVED |
| 18 | Trash has no automatic expiry; owner permanent deletion has no undo and removes collaborator access. History restores files/versions, not a permanently deleted hosted project. | Official pages do not promise support recovery after permanent deletion. Do not restate that silence as proof that backend recovery is impossible. | CONFIRMED limitation; support recovery UNASSERTED |
| 20 | Link sharing supports Anyone with the link, Viewer/Reviewer/Editor permissions, revocation, and non-expiring links. Email invite acceptance explicitly requires an authenticated account. | S19 does not explicitly say whether a link Viewer must have an account. | CONFIRMED except account requirement UNRESOLVED |

## Closure table for every EXPAND lead

| Angle(s) and input lead | Closure |
|---|---|
| 11 plan availability; 12/20 Gallery/copy/publisher entitlements; 13 ZIP/copy Free status | **UNASSERTED, duplicate cluster.** Workflow docs omit a plan gate; missing labels are not evidence of absence. No claim needs a fabricated exhaustive entitlement matrix. |
| 11 license display/default | **UNRESOLVED but bounded.** Policy requires clear licensing and recommends licenses; it provides no universal fallback license or per-listing compliance guarantee. |
| 11 managed-account legal ownership | **OUT OF SCOPE.** S5-S6 establish product control and Terms wording; institution-specific IP ownership depends on external agreements. |
| 11 upload limits; 13 180-file cap | **RESOLVED** by S1-S2. |
| 11/20 Gallery exclusions and republish rules | **RESOLVED** by full live S4 text. |
| 11 managed-user removal/deletion | **RESOLVED** by S5. |
| 11 Terms ownership wording/date | **RESOLVED** by S6; correct dates are May 5, 2026 for Terms and August 5, 2026 for the overview. |
| 11 AI post date; 12 Commons AI conflict | **RESOLVED** by S7-S9; post date July 2, 2026. Preserve the Summarize/Explain internal-doc contradiction as a caveat. |
| 12 Gallery search behavior | **UNRESOLVED after concrete check.** Public UI/search exists, but no official matching/ranking/coverage specification was found. |
| 12 Server Pro 6.3.0 server-side search/pagination | **OUT OF SCOPE / UNASSERTED.** Version-incidental claim relied on an unofficial mirror and is unnecessary to current functionality inventory. |
| 12/20 current publisher roster and per-publisher payload mechanics | **OUT OF SCOPE.** An exhaustive, changing partner inventory is excluded; current docs only guarantee partner-dependent workflows. |
| 13 missing harvest leads | **CLOSED BY RECONSTRUCTION.** `harvest-13.md` does not exist; all leads visible in expand/verify and duplicate angles were reconciled. No unknown claim is invented. |
| 13 download ZIP contents | **RESOLVED** by S3 and angle 19. |
| 13 legacy Server Pro FAQ; 13 AI bundling | **OUT OF SCOPE.** Legacy redirect/FAQ and unrelated AI claims do not determine ZIP import. |
| 14 exact file/folder rename, move, delete steps; single-file delete page | **UNRESOLVED after official search.** S10 confirms capability, but no current hosted procedure page was found. |
| 14 folder empty-state/collision behavior | **OUT OF SCOPE / UNASSERTED.** Arbitrary edge guarantees are not documented. |
| 14 upload/folder upload, Git rename/move, Dropbox effects | **RESOLVED** in verify-14 and duplicates; S1 confirms upload/folders. |
| 14 hosted role matrix | **UNASSERTED.** Do not transpose S10’s on-premises matrix to hosted plans. |
| 14 hosted deleted-document recovery; Deleted Docs recheck | **RESOLVED boundary.** S11/S10 confirm Server Pro admin undelete; S18 confirms hosted History recovery. No broader hosted admin undelete is claimed. |
| 15 exhaustive binary-type matrix | **OUT OF SCOPE.** Exhaustive package/file inventories are excluded; compiler-specific image formats are separate from storage acceptance. |
| 15 External URL plan/edition matrix | **UNASSERTED.** S13 documents the hosted workflow without tier labels. |
| 15 Drive overwrite/conflict/history; 16 refresh conflicts/deletion/atomicity/failures | **OUT OF SCOPE / UNASSERTED.** S12-S14 establish only manual refresh. |
| 16 current cloud/CE/Server Pro parity | **UNASSERTED.** Toolkit defaults and dated release notes do not prove universal current deployment parity. |
| 16 figure-insertion relationship to linked-file Refresh | **UNRESOLVED but nonessential.** The figure workflow does not document the same linked object semantics. |
| 17 current sort/default order | **UNRESOLVED after official search.** The cited 2017 post does not support a current guarantee. |
| 17 SaaS dashboard search semantics | **UNRESOLVED after official search.** S10 names search only for on-premises users. |
| 17 tag rename/delete | **RESOLVED** by S15-S16. |
| 17 dashboard plan matrix | **UNASSERTED.** No tier label; do not infer unavailability. |
| 17 bulk selection cap | **OUT OF SCOPE / UNASSERTED.** No numeric guarantee is documented. |
| 18 support recovery after permanent hosted deletion | **UNASSERTED.** S17 says no undo; support guidance for “missing” projects is not a recovery promise. |
| 19 generated-file/submission ZIP plan and deployment parity | **UNASSERTED.** Current workflow is documented; an exhaustive parity matrix is not. |
| 20 link viewers need an account | **UNRESOLVED after concrete check.** S19 explicitly requires authentication for email invites but is silent for link participants. |
| 20 Community Edition publishing beyond documented roles | **CLOSED AS UNASSERTED.** S10 shows no Template User role in CE; no claim is made about custom modifications. |

## EXPAND

None. Every inherited lead is resolved, deduplicated, excluded as incidental/exhaustive/speculative, or explicitly bounded as UNRESOLVED after checking current official sources. The remaining unresolved items (hosted file-tree click procedures, dashboard search/sort semantics, link-viewer account requirement, and per-listing license fallback) would require new official documentation, an authenticated product test, or a support statement; those routes are outside this public-source/no-account task.
