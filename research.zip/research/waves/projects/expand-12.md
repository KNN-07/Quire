# Expand 12: Template gallery, search, publishing and institutional templates

Checked 2026-10-26. Public sources only. No authenticated tests, no purchases, no template compiled, no submission flow exercised.

Labels: **Standard** = cloud overleaf.com user; **Commons** = institutional subscription; **Server Pro** = self-hosted; availability is stated only where a source documents it.

## Verified facts

### Gallery use (Standard)
- Starting a project from a template: New Project > Templates > document type, then "Open as Template" creates an editable copy. Also reachable directly at the gallery. Source: https://docs.overleaf.com/templates/creating-a-project-from-a-template (steps 1-3).
- The gallery page shows a search field, filters and categories (Journal articles, Bibliographies, CVs, Theses, etc.). Source: https://www.overleaf.com/gallery/ (read via search snippet and harvest; the page body was not fully parsed this pass).
- No plan gate for opening gallery templates is documented in the pages I read. Free/premium entitlement: **UNRESOLVED**.

### Gallery submission (Standard, curated)
- Suitable types: official journal/proceedings templates, official university templates, official conference templates, and less-common types with wide interest. Official templates must link to the publisher, university or conference guidelines. Basic common-class templates are "rarely accepted." Source: https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery, heading "Templates suitable for the gallery."
- Rejected types include non-official journal or university templates, minimal modifications, personal data such as CVs, incomplete work or preprints, and promotional material. Overleaf may not explain rejections. Same URL, heading "Templates not suitable for the gallery."
- Submit path: File or project-name menu > Submit > Overleaf Gallery. Same URL, "How to submit a project to the Overleaf Gallery."
- Updates: edit the original project and resubmit; the listing changes only after Overleaf approves. Same URL, "How to update a published template."

### Publisher submission (Standard)
- Some partner publishers provide a submission link from their official gallery template, which sends files directly. Other partners need a manual download and upload. The Submit menu searches journals, repositories, author services and proceedings. Source: https://docs.overleaf.com/templates/submitting-to-publishers, headings "Publisher submission links" and "The Submit menu option."
- Legacy, dated 2016-11-18: Overleaf's blog describes the same Submit menu and a figshare export flow. Source: https://www.overleaf.com/blog/437-submit-to-overleafs-publishing-partners. Current partner list: **UNRESOLVED**.

### Institutional portals (Commons)
- A Commons subscription includes a portal with Overview, Quick Start, Featured Templates and FAQ sections. Source: https://docs.overleaf.com/commons/your-overleaf-portal, heading "Your Overleaf portal."
- Featured templates must already be in the public gallery. Admins then contact Overleaf Support. Same URL, FAQ "How do we add a new template to our featured templates page?"
- AI access for Commons members is at a Basic allowance across Error Assist and language suggestions, and "The AI assistant is not included." Source: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription, heading "AI features with Commons access." This is kept separate from the July 2, 2026 AI-bundling announcement and is not reconciled with it: **UNRESOLVED** for current AI entitlements.

### Server Pro (self-hosted)
- Template User role publishes and unpublishes templates through Manage Template. Public publishing is Template User only. Private publishing is Template User or Admin. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Manage template" table.
- The Template User role is Server Pro-specific. Same URL.
- Publishing steps: compile a project as the templates user, use Manage Template, then tag it to a category. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/templates, "Publishing templates."
- Overleaf.com gallery templates are not integrated automatically and must be transferred one at a time. Same page, "Transferring templates from overleaf.com."
- Sandboxed Compiles is recommended. Without it, the default basic TeX Live scheme can cause missing-package errors. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles, "Sandboxed Compiles."

### Boundary
Gallery templates are author- or institution-supplied LaTeX. Platform status comes from the listing's stated provenance, not from the template itself. Submission rules are Overleaf policy; they do not guarantee that a document meets a journal's rules.

## EXPAND

- **LEAD: Gallery search behavior.** The page shows a search field, but no official page specifying matching, ranking or coverage was found. Reason: no authoritative spec.
- **LEAD: Server-side gallery search and pagination in Server Pro 6.3.0.** The only source is an unofficial mirror (https://ayakaleaf-pro.mintlify.app/on-premises/configuration/overleaf-toolkit/templates). My keyword search of the official toolkit CHANGELOG (https://github.com/overleaf/toolkit/blob/master/CHANGELOG.md) found only 6.3.0-6.3.2 default-version lines. Reason: unconfirmed; not used as a fact.
- **LEAD: Plan entitlements for gallery use, submission and publisher links.** The pages describe workflows and omit a plan matrix. Reason: no source.
- **LEAD: Current publisher partner roster.** The docs say integrations vary and give no durable list. Reason: no source.
- **LEAD: Commons AI entitlement after bundling.** The Commons page and the July 2, 2026 announcement are not reconciled. Reason: no combined source; kept separate.
- **Deprecation check:** no gallery or template deprecation found in the pages reviewed. The 2016 publisher blog is legacy and date-tagged.
- **Duplicates closed:** the harvest's gallery-submission and publisher-submission claims were each confirmed against the same primary pages above. No further duplicates remain.
