# Verify 14: Files and folders, renaming, moving and deletion

Research date: 2026-10-27. Public official Overleaf pages only. No authenticated testing, no purchases, no functional execution of any feature.

## Verdict: PARTIAL

Confirmed: folder creation, folder upload, drag-to-move of files in the editor, project rename, project trash and delete, file-level role permissions (on-premises matrix), hosted plan limits, and the Git and Dropbox sync caveats.
Corrected: the harvest cited the Git "Known limitations" to the advanced-git page. They are on the main Git integration page.
Unresolved: exact in-editor steps to rename, move, or delete an individual file or folder; empty-folder behavior; hosted role matrix for files; hosted file recovery.

## Findings

**Folders and uploads.** The upload guide documents "New folder" (toolbar button or right-click on a parent) and folder upload that preserves structure, with a limit of 180 files and 50 MB per upload. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project, headings "Creating folders", "Uploading multiple files". The upload guide also documents dragging uploaded files between folders in the left panel. Source: https://docs.overleaf.com/writing-and-editing/inserting-images/uploading-images, heading "Uploading images to a folder". This is editor UI, not a LaTeX feature. The page does not say whether folders can be dragged or how name collisions are handled.

**Plan limits.** The plan-limits page lists a 50 MB maximum per individual upload and 2000 files per project for both Free and Premium. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits, table "Overleaf plan limits". Date-tag: current.

**Renaming.** Only the project owner can rename a project, from the dashboard (More > Rename) or the editor project-name menu. Source: https://docs.overleaf.com/managing-projects-and-files/renaming-a-project. Availability: not labeled. Renaming an individual file in the editor is UNRESOLVED (see EXPAND).

**Project trash and deletion.** Trashing does not schedule deletion. Permanent deletion has no undo and removes the project for collaborators. Non-owners can archive, trash, or leave a shared project, but cannot permanently delete it. Restore is supported. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project, headings "Trashed Projects", "How does trashing a project affect collaborators?". Availability: not labeled.

**File permissions (on-premises only).** The "Project & file operations" table says Owner and Editor can create, rename, delete, and move files. Reviewer and both Viewer roles cannot. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions. Availability: Server Pro and Community Edition only. Do not apply this to hosted plans. The hosted role matrix is UNRESOLVED.

**Recovery and history.** The hosted premium-features page says full document history is premium, and that Free accounts get 24 hours of history. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features, heading "Full document history and versioning". Availability: Premium (Full document history); Free (24 hours). An undated blog says anyone with edit rights can restore a file or project from the past 24 hours via History, and that older versions need the premium feature. Source: https://www.overleaf.com/blog/turn-back-time-with-restore-version-with-comments-and-tracked-changes. Date-tag: undated, treat as legacy-sensitive. Deleted Docs (list and undelete) is listed as Server Pro only in the roles page, as reported in expand-14; not re-fetched in this pass.

**Git integration (premium on Overleaf cloud).** The Known limitations table says a file rename or move in a local repository becomes delete plus create on Overleaf, which can drop tracked changes and comments. A folder rename can leave an empty old-named folder behind. Source: https://docs.overleaf.com/integrations-and-add-ons/git-integration-and-github-synchronization/git-integration, heading "Known limitations", rows "Renaming folders", "Renaming files and moving files". The troubleshooting section says Git integration is premium on Overleaf cloud. Availability: Premium (cloud). The advanced-git-operations page does not contain these rows; do not cite it for them.

**Dropbox (premium).** Deleting a Dropbox folder removes its contents in Overleaf but keeps the project. Renaming or moving items in Dropbox may be treated as delete and create, losing history, tracked changes, and comments. Archived and trashed projects stop syncing. Source: https://docs.overleaf.com/integrations-and-add-ons/dropbox, opening section and "What should I know before syncing projects?". Availability: Premium; Commons participants and group members also get access.

**Legacy: Archive and Trash announcement.** Undated blog: archive and trash do not affect collaborators, and archiving or trashing stops Dropbox sync for that user. Source: https://www.overleaf.com/blog/new-feature-using-archive-and-trash-to-keep-your-projects-organized. Date-tag: undated dashboard announcement; current behavior is in the deleting-a-project page above.

**Single-file deletion (weak evidence).** A search snippet from an official Overleaf help page says an uploaded file can be deleted from the dropdown next to the file. The page fetch returned only a feedback form, so the answer was not read in full. Source: https://www.overleaf.com/learn/how-to/Is_it_possible_to_delete_single_uploaded_files%3F. Status: UNRESOLVED until the full answer is read.

## Limitations

- Pages were read, not the editor UI. No rename, move, or delete was performed.
- Hosted role matrix, folder move/delete behavior, and file-level undo are not documented in pages reviewed.
- "AI bundled July 2, 2026" does not apply to file operations; not used here.

## Counter-search queries

- "Overleaf delete uploaded file file tree dropdown" (official help)
- "site:docs.overleaf.com rename file folder editor"
- "site:docs.overleaf.com Deleted Docs Server Pro undelete"
- "site:overleaf.com plans full document history 24 hours"
- Non-official pages (howrebuild.blog, rapidrepair.blog) claiming a Trash icon in the file tree: unreliable, not cited.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| New folder via button or right-click | uploading-files-to-a-project, "Creating folders" | Not labeled | Confirmed |
| Folder upload keeps structure; 180 files / 50 MB per upload | uploading-files-to-a-project, "Uploading multiple files" | Not labeled | Confirmed |
| Drag uploaded files between folders | uploading-images, "Uploading images to a folder" | Not labeled | Confirmed (no folder-move claim) |
| 50 MB per upload; 2000 files per project | plan-limits, table | Free and Premium | Confirmed |
| Only owner renames project | renaming-a-project | Not labeled | Confirmed |
| Trash then permanent delete; no undo | deleting-a-project | Not labeled | Confirmed |
| Owner/Editor create, rename, delete, move files | roles-and-permissions, "Project & file operations" | Server Pro / Community Edition | Confirmed (on-prem only) |
| Full document history premium; 24 h on Free | premium-features | Premium / Free | Confirmed |
| Restore from History within 24 h by editors | turn-back-time blog | Free (24 h) | Confirmed, legacy-tagged |
| Git rename = delete + create; folder rename leaves empty folder | git-integration, "Known limitations" | Premium (cloud) | Confirmed; harvest source corrected |
| Git integration is premium on cloud | git-integration, "Troubleshooting" | Premium | Confirmed |
| Dropbox delete/rename effects | integrations-and-add-ons/dropbox | Premium | Confirmed |
| Delete single uploaded file via dropdown | learn.overleaf.com how-to (snippet) | Not labeled | UNRESOLVED |
| In-editor rename/move/delete steps for files and folders | None found | Not labeled | UNRESOLVED |
| Hosted role matrix for files | None found | Hosted plans | UNRESOLVED |
| Deleted Docs recovery | roles-and-permissions, as cited in expand-14 | Server Pro only | Reported, not re-verified |

## EXPAND

- LEAD: In-editor rename, move, and delete steps for files and folders. UNRESOLVED. Official pages found do not describe these actions. Needed for an accurate UI procedure.
- LEAD: Folder move, rename, and delete behavior, including empty folders. UNRESOLVED. Needed to separate folder from file operations.
- LEAD: Single-file delete answer on learn.overleaf.com. Open the full page to confirm the dropdown steps.
- LEAD: Hosted Free and Premium role matrix for file operations. UNRESOLVED.
- LEAD: Hosted deleted-document recovery. UNRESOLVED; Deleted Docs appears Server Pro only.
- LEAD: Re-verify the Deleted Docs claim on the roles page; it was not re-fetched in this pass.
- None for: upload limits, plan limits, project trash, Git and Dropbox sync caveats (confirmed above).
