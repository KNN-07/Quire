# Recovered harvest 13: ZIP upload, existing-project import, file limits

This is a lead-written recovery artifact, not the original worker's missing output. The handoff existence check found the original harvest absent even though the node reported completion. The expand and verify files already reconstructed most of the angle independently. The lead reopened the three primary sources below and recovered this record without claiming the original research happened.

## Documented functionality

- Upload a local multi-file LaTeX project as a ZIP through New project > Existing project (.zip). After a successful upload the project opens in the editor. The upload guide describes `.tex`, `.bib` and image assets. Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project.md , How to upload a project.
- The same guide explicitly links DOCX/Markdown conversion and GitHub import as separate routes. Their detailed functionality and availability are covered by the conversion and integration angles, not inferred from ZIP support.
- Troubleshooting covers choosing the compiler, selecting a compatible TeX Live release, checking the detected main document, and moving the main document out of a wrapping top-level folder. Upload is not a guarantee that arbitrary local packages or executables will compile.

## Limits recovered from current primary text

Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project.md , Uploading large projects.

- An individual upload must not exceed 50 MB.
- Each upload can contain up to 180 files; the guide says only 180 are uploaded if more are attempted.
- A project cannot contain more than 2,000 files.
- Editable project material is limited to 7 MB.
- For a ZIP larger than 50 MB, the documented workaround is to create the project from a subset and upload remaining files separately.

The 180-file limit is now directly confirmed, correcting expand-13's snippet-only uncertainty.

Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits.md , Overleaf plan limits.

- Free and premium have the same documented file-count, editable-material and individual-upload limits.
- The individual editable-file threshold is 2 MB, with a footnote that some larger files may remain editable in some circumstances; do not present that exception as a guarantee.
- Project count is unlimited. Total project size has no enforced limit, but the guidance recommends at most 500 MB, or below 100 MB for Git/GitHub use; those are recommendations, not the upload cap.
- Compile timeout differs: 10 seconds Free, 240 seconds premium. This does not alter the stated storage/file limits.

## Download distinction

Source: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project.md , opening note and download sections.

Source ZIP export excludes the final typeset PDF, which is downloaded separately after compilation. Multiple projects can be exported as an enclosing ZIP of project ZIPs. Generated `output.bbl` is available through Logs and output files or the arXiv submission ZIP flow; opening that flow does not immediately submit files to arXiv.

## Availability and evidence limits

The ZIP workflow guide does not label ZIP import premium-only. No self-hosted parity or arbitrary import-format guarantee is asserted. This recovery checked public documentation, not a live upload or compile.

## EXPAND

- Closed: missing harvest input, recovered transparently from primary pages.
- Closed: 180-files-per-upload uncertainty, explicitly stated in the current upload guide.
- Closed: ordinary source ZIP versus compiled PDF contents, stated by the download guide.
- Duplicate: DOCX/Markdown conversion and GitHub import are covered in their dedicated angle and lead-supplement records.
- No new actionable lead for the scoped functionality inventory.
