# Overleaf angle 16 verification: Linked files between projects and refresh behavior

**Research date:** 2026-10-26  
**Verdict: PARTIAL.** The core cloud workflow is confirmed by current Overleaf documentation. Refresh semantics beyond the documented manual action, cloud plan eligibility, and a current Community Edition/Server Pro parity matrix remain unspecified. Sources were opened directly; no authenticated tests, purchases, or functional execution were performed.

## Findings

Current cloud docs, [Sharing files across projects](https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects), headings **“Sharing files across projects”** (lines 3–20), describe selecting **From Another Project** in Add Files, choosing a parent project and file, then using that linked file in a child project. The examples include `.bib`, `.cls`, `.sty`, and graphics. A child copy cannot be edited there; after modifying the original in the parent, select the child link and **Refresh** to pull changes. This supports a user-initiated refresh, not automatic synchronization. Imported `.tex` files cannot be the child project's main compile file; that restriction does not establish whether every other linked `.tex` use works.

Keep two adjacent features distinct. The same docs page describes linked files and their Refresh control. [Using the Insert figure button](https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button), headings **“From another project”** and **“Select from output files”** (lines 40–62), describes choosing an uploaded graphic or generated output from another project, naming it, and generating a LaTeX `figure` environment. It does not document that this inserted asset is the editable linked-file object or that it shares the same refresh mechanism. Its persistence/update behavior is **UNRESOLVED**.

For self-hosting, the official [Overleaf Toolkit `variables.env`](https://github.com/overleaf/toolkit/blob/master/lib/config-seed/variables.env), default configuration `ENABLED_LINKED_FILE_TYPES`, currently lists `project_file,project_output_file`. This confirms those types are represented in current Toolkit defaults, not that every deployment enables them unchanged or guarantees a particular refresh behavior. The official [Overleaf developer wiki](https://github.com/overleaf/overleaf/wiki/), **“Home”** (lines 146–153), identifies Community Edition and Server Pro as deployment editions and recommends Toolkit, but supplies no feature-by-feature linked-file parity or cloud plan table.

**Legacy, date-tagged evidence:** Overleaf's [Server Pro 2.x release notes](https://docs.overleaf.com/on-premises/release-notes/release-notes-2.x.x), section **“Server Pro 2.0.0”** (2019-10-09), reportedly records linked files as added to Community Edition and Server Pro. Treat that as historical release evidence only, not a current version guarantee. No deprecation statement was found in the current cloud workflow page or Toolkit default; absence of a deprecation notice is not a guarantee of future support. Overleaf's [2018 announcement](https://www.overleaf.com/blog/new-overleaf-v2-features-rich-text-and-adding-linked-files), heading **“Adding Linked Files,”** is likewise legacy corroboration, not the basis for current behavior.

LaTeX's `\input`, `\include`, or graphics commands are document-level composition mechanisms; the platform link and refresh workflow is separately documented by Overleaf. Do not infer arbitrary LaTeX capabilities or linked-file compilation behavior from those commands. No AI/AI Assist dependency is identified by the relevant feature sources; cloud Free/premium eligibility is **UNRESOLVED**. No claim about AI bundling is needed for this angle.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Add reusable files from a parent project into a child via **From Another Project**; examples include `.bib`, `.cls`, `.sty`, graphics. | Current cloud docs, **“Sharing files across projects”**: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects | Cloud feature; Free/premium not stated. | CONFIRMED |
| Child linked file is not editable there; selecting it and **Refresh** pulls parent changes. | Same current cloud docs, lines 15–18. | Cloud feature; plan eligibility not stated. | CONFIRMED; manual action only |
| Linked `.tex` cannot be the child main compile file. | Same current cloud docs, line 20. | Cloud feature; plan eligibility not stated. | CONFIRMED; other `.tex` use not determined |
| Figure insertion can select uploaded or generated files from another project and create a figure environment. | Current figure docs, **“From another project”** / **“Select from output files”**: https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button | Cloud docs; plan eligibility not stated. | CONFIRMED; relationship to linked-file Refresh unresolved |
| Toolkit defaults list `project_file,project_output_file`. | Current official Toolkit `variables.env`, `ENABLED_LINKED_FILE_TYPES`: https://github.com/overleaf/toolkit/blob/master/lib/config-seed/variables.env | Self-hosted Toolkit configuration; not a cloud plan label. | CONFIRMED as default config, not universal deployment guarantee |
| Current cloud plan eligibility and CE/Server Pro parity are established. | No current official matrix found; wiki identifies editions but gives no linked-file matrix: https://github.com/overleaf/overleaf/wiki/ | Free/premium, CE, Server Pro | UNRESOLVED |
| Conflict, deletion/rename, atomicity, automatic polling, and refresh-failure behavior are guaranteed. | Current sharing docs explain only manual Refresh to pull changes; no edge-case guarantees stated. | Cloud and self-hosted behavior not specified. | UNRESOLVED |
| Historical CE/Server Pro releases included linked files. | Official 2.x notes, **“Server Pro 2.0.0”** (2019-10-09): https://docs.overleaf.com/on-premises/release-notes/release-notes-2.x.x | CE/Server Pro, historical only. | CONFIRMED as dated history; current parity not established |

## Counter-search queries

- `site:docs.overleaf.com "Sharing files across projects" Refresh`
- `site:docs.overleaf.com "From Another Project" Overleaf`
- `site:github.com/overleaf/toolkit ENABLED_LINKED_FILE_TYPES`
- `site:github.com/overleaf/overleaf "ENABLED_LINKED_FILE_TYPES" "project_file"`
- `site:docs.overleaf.com linked files deprecated Overleaf`
- `site:docs.overleaf.com linked files Free premium`

The searches found a current workflow page and current Toolkit configuration, but no official current plan matrix, refresh edge-case specification, or deprecation notice. Search absence is not proof of a product guarantee.

## EXPAND

- **LEAD — Refresh edge cases:** Still open: official docs do not specify behavior for conflicts, deletion/rename, atomicity, detection, or failures. Reason: sources establish only manual Refresh and its stated purpose; no stronger guarantee should be inferred.
- **LEAD — Availability matrix:** Still open: Free/premium eligibility and current CE/Server Pro parity remain unstated. Reason: current feature docs have no plan labels; Toolkit defaults and 2019 release notes cannot establish current universal availability.
- **LEAD — Figure insertion refresh relationship:** Still open only if a workflow requires it. Reason: figure docs describe selecting/copying a graphic or output into a generated figure workflow but do not document linked-file Refresh semantics for that path.
