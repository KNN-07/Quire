# Overleaf Dashboard: search, sorting, labels, and bulk operations

Research checked October 26, 2026. Scope is the Overleaf project dashboard, not search inside a LaTeX project. Sources are public primary Overleaf documentation and product posts. No authenticated testing or purchases were performed; features are reported from documentation, not functionally executed.

## Search and sorting

On-premises documentation explicitly lists “Search for projects,” project listing for owned and invited projects, and group filters (All, Your, Shared with you, Archived and Trashed Projects). This documents dashboard capability for on-premises users, but does not define search matching fields, case sensitivity, partial matching, query syntax, or whether the same precise behavior applies on SaaS. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — **Project Dashboard → Organizing and finding projects**.

Do not transfer editor search semantics to the dashboard: “Searching within a project” concerns project files, not the dashboard catalog. Its regex, whole-word, and case-sensitive options are therefore out of scope here. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project — **Search and replace within the current file**, **Project-wide search**.

Current sort keys, direction, and default remain **UNRESOLVED**. The official product post dated May 15, 2017 says users could sort projects and choose projects per page, but gives no sort fields; this is legacy evidence only, not proof of current behavior. Source: https://www.overleaf.com/blog/503-overleaf-product-update-may-2017 — **My Projects Dashboard Pagination Controls** (2017-05-15).

## Tags (labels)

Current documentation calls dashboard labels **tags**. A user can create a uniquely named tag and choose among nine preset colors or a custom color (color map, HEX, or RGB); clicking a tag filters the dashboard to projects carrying it. Sources: https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/creating-a-new-tag — **Creating a new tag**, **Viewing projects with a specific tag**; https://www.overleaf.com/blog/organizing-your-work-in-overleaf-just-got-easier-with-custom-colors-for-tags — **What is the Tag feature?**, **What have we changed?** (2023-04-12).

Multiple project tagging is documented as selecting project-title checkboxes, clicking the Tag icon, then choosing one or more tags. Source: https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/adding-tags-to-your-projects — steps 1–3. Historically, Overleaf used the name “Tags/Folders”; its 2023 post says it changed the name to “Tags” and that functionality did not change. The July 16, 2013 post also described filtering by project name or tags, but that is archival evidence, not current search semantics. Sources: https://www.overleaf.com/blog/organizing-your-work-in-overleaf-just-got-easier-with-custom-colors-for-tags — **What have we changed?**; https://www.overleaf.com/blog/tag-and-search-your-latex-projects-2013-07-16 — archival post (2013-07-16).

## Bulk operations and limits

Current SaaS help documents selecting multiple projects to archive or trash, and selecting multiple items in Archived or Trashed Projects to restore. Trashing only moves projects to the user's Trashed Projects page; permanent deletion or leaving a shared project is a later action. Only owners can permanently delete; collaborators can leave a project they do not own. Sources: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects — **How to archive or trash multiple projects**, **How to restore multiple projects**; https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project — **Trashed Projects**, **How does trashing a project affect collaborators?**

The dashboard also supports selecting multiple projects for a single ZIP download, containing a ZIP per project. Sources: https://docs.overleaf.com/managing-projects-and-files/downloading-a-project — **How to download multiple projects as a .zip file**; https://docs.overleaf.com/accounts-and-security/managing-your-personal-information — **How to download your information**. The current docs do not give a numeric selection cap; bulk selection limits are **UNRESOLVED**. On-premises permissions also list bulk trash, restore, download, leave, archive, and tag actions as available to a regular User. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — **Project Dashboard → Project management and collaboration**, **Organizing and finding projects**. This table does not establish a SaaS subscription entitlement or distinguish Community Edition from Server Pro for these regular-user dashboard actions.

## Availability and scope limits

The cited dashboard help does not label search, sorting, tags, or listed bulk operations as Free, Premium, or AI features. SaaS plan availability is **UNRESOLVED**; do not infer a tier from the on-premises permissions table. No cited source associates these actions with AI or Commons. Arbitrary LaTeX content capabilities do not imply dashboard behavior.

## EXPAND

- **LEAD — Current dashboard sort fields/order/default:** UNRESOLVED; current help reviewed does not specify sort controls. The only direct product announcement found is dated 2017 and omits fields.
- **LEAD — Dashboard search matching semantics:** UNRESOLVED; on-premises permissions confirm search but do not state matching rules. The 2013 search description is legacy, not a current guarantee.
- **LEAD — SaaS plan matrix for dashboard features:** UNRESOLVED; cited sources do not assign these actions to Free/Premium/AI/Commons. On-premises user permissions are a separate scope.
- **LEAD — Bulk selection limits:** UNRESOLVED; current instructions describe selection and actions but no cap.
- **Duplicates closed:** bulk tagging, archiving/trashing/restoring, and multi-project ZIP download are covered above; no additional current dashboard bulk operation was established by sources reviewed. “Tags/Folders” is historical naming, superseded by current “Tags” terminology.
