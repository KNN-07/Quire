# Verify 12: Template gallery, search, publishing and institutional templates

Checked 2026-10-26. Public sources only. No authenticated tests, no purchases, no template compiled, no submission flow exercised. Labels: **Standard** = overleaf.com user; **Commons** = institutional subscription; **Server Pro** = self-hosted.

**Verdict: PARTIAL.** Gallery use, curated submission, update flow, Commons portal featuring, and Server Pro publishing are confirmed against primary docs. Gallery search behavior, plan entitlements, current publisher roster, and Commons AI entitlement remain UNRESOLVED.

## Claim table

| Claim | Source | Availability | Evidence status |
| --- | --- | --- | --- |
| Start project from gallery template (Open as Template) | docs.overleaf.com/templates/creating-a-project-from-a-template | Standard | Confirmed |
| Gallery is curated; common-class templates rarely accepted | docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery | Standard | Confirmed |
| Exclusions (non-official, minimal edits, CVs, incomplete) | same, "not suitable" | Standard | Confirmed |
| Submit via File/name menu > Submit > Overleaf Gallery | same, submission section | Standard | Confirmed |
| Updates require resubmission and approval | same, update section | Standard | Confirmed |
| Publisher direct-submission links vary by partner | docs.overleaf.com/templates/submitting-to-publishers | Standard | Confirmed; partner list UNRESOLVED |
| Figshare export flow | overleaf.com/blog/437-submit-to-overleafs-publishing-partners (2016) | Standard | Legacy, date-tagged; not re-verified |
| Commons portal featuring after gallery publication | docs.overleaf.com/commons/your-overleaf-portal | Commons | Confirmed |
| Commons AI = Basic allowance, no AI Assistant | docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription | Commons | Contradicted by July 2, 2026 blog; UNRESOLVED |
| All plans include Overleaf AI (July 2, 2026) | overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans | Free/Student/Standard/Commons | Confirmed (blog); per-plan allowances not re-verified |
| Server Pro Template User publishes public/private templates | docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions | Server Pro | Confirmed |
| Publishing steps and category tags | docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/templates | Server Pro | Confirmed |
| Community Edition lacks private template management | docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition | Community Edition | Confirmed (feature table); Template User wording not in source: PARTIAL |
| Gallery search matching/ranking | overleaf.com/gallery (UI only) | Standard | UNRESOLVED |
| Plan entitlements for gallery use or submission | none found | Standard | UNRESOLVED |

## Confirmed claims

- **Creating a project from a template (Standard).** Dashboard > New Project > Templates > document type, then "Open as Template" creates an editable copy. Source: https://docs.overleaf.com/templates/creating-a-project-from-a-template, steps 1-3. Evidence: confirmed on page.
- **Gallery is curated.** Suitable types are official journal, university and conference templates, plus less-common types with wide interest; official templates must link to the publisher or institution guidelines. Common-class templates are "rarely accepted." Source: https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery, "Templates suitable for the gallery." Evidence: confirmed.
- **Exclusions.** Non-official journal or university templates, minimal modifications, CVs/resumes, incomplete work or preprints, promotional material, and wrong-project updates are rejected. Overleaf may not give a reason. Same URL, "Templates not suitable for the gallery." Evidence: confirmed.
- **Submission path.** File or project-name menu > Submit > Overleaf Gallery, which is the first option in the modal. Same URL, "How to submit a project to the Overleaf Gallery." Evidence: confirmed.
- **Updates.** Edit the original submitted project and resubmit; the listing changes only after Overleaf approves. Same URL, "How to update a published template." Evidence: confirmed.
- **Publisher submission.** Some partner official templates add a submission link that sends files directly; other partners require manual download and upload. The Submit modal searches partner journals, repositories and proceedings. Source: https://docs.overleaf.com/templates/submitting-to-publishers, "Publisher submission links" and "The Submit menu option." Evidence: confirmed; the partner list is not reproduced there.
- **Legacy publisher blog (2016-11-18, date-tagged).** Describes the Submit menu and a figshare draft-export flow. Source: https://www.overleaf.com/blog/437-submit-to-overleafs-publishing-partners. Evidence: legacy; figshare behavior is not re-verified for 2026.
- **Commons featured templates.** Portal sections are Overview, Quick Start, Featured Templates and FAQ. Featured templates must already be in the gallery; then contact Overleaf Support. Source: https://docs.overleaf.com/commons/your-overleaf-portal, "Your Overleaf portal" and FAQ "How do we add a new template to our featured templates page?" Evidence: confirmed.
- **Server Pro publishing.** Template User publishes and unpublishes public templates; Template User or Admin publishes private ones. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Manage template" table. Evidence: confirmed. The role is Server Pro-specific per the same page.
- **Server Pro publishing steps.** Log in as the templates user, compile the project, choose Manage Template, publish, then tag the project with a category. Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/templates, "Publishing templates." Evidence: confirmed. Tags group templates; multiple tags put one template in several groups.
- **Overleaf.com templates are not auto-synced to Server Pro.** They must be transferred one at a time. Same page, "Transferring templates from overleaf.com." Evidence: confirmed.
- **Sandboxed Compiles recommended for Server Pro.** Source: https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/sandboxed-compiles, "Sandboxed Compiles." Evidence: confirmed as the recommended approach; package-error wording was not re-checked.
- **Commons AI access (docs).** Commons members get the Basic allowance across Error Assist and language suggestions; "The AI assistant is not included." Source: https://docs.overleaf.com/subscriptions-payments-and-billing/commons-subscription, "AI features with Commons access." Evidence: confirmed on page, but it conflicts with the July 2026 blog (below).

## Contradictions and corrections

- **Commons AI after July 2026 (CONTRADICTION, UNRESOLVED).** The Commons docs say the AI assistant is not included. The July 2, 2026 blog says AI is included in all plans and introduces "Commons AI" as an option that raises the allowance for campus-wide subscriptions. Source: https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans. The blog does not say the Commons docs were updated. Per instructions, the two are not merged; current Commons AI entitlement is UNRESOLVED.
- **Community Edition lacks template management (PARTIAL).** The Server Pro vs Community Edition comparison marks "Private template management system" as not available in Community Edition. Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition, feature table. The harvest's specific "Template User role" wording is not in that table, so only the template-management part is confirmed.
- **Gallery search (UNRESOLVED).** The gallery page shows a search field and categories (Journal articles, Bibliographies, CVs, Theses, and others). Source: https://www.overleaf.com/gallery (search snippet; the full body was not parsed here). No official doc specifies matching, ranking or coverage.

## Platform features vs LaTeX content

Gallery listings and sample projects are author- or institution-supplied LaTeX. Overleaf documents the listing workflow and policy, not whether a template's classes or packages meet a journal's current rules. Official status depends on the listing's stated provenance; the gallery also holds unofficial institutional entries, so check each one.

## Availability summary

- **Standard:** browsing, opening templates, and submitting to the gallery are documented. No plan gate is documented in the pages read. Plan entitlement for gallery use or publisher links: UNRESOLVED.
- **Commons:** featured-template portal, documented; AI tier: UNRESOLVED (see contradiction above).
- **Server Pro:** Template User publishing, documented; Community Edition lacks private template management, documented.

## Counter-search queries

- "Overleaf Gallery search ranking filters site:overleaf.com"
- "Overleaf Commons AI allowance July 2026 site:overleaf.com"
- "Overleaf Server Pro template user role community edition site:docs.overleaf.com"
- "Overleaf submit to publishers partner list site:overleaf.com"
- "Overleaf gallery deprecated template legacy site:docs.overleaf.com"

Queries 1-3 were run in this pass; the July 2026 blog was opened directly. Queries 4-5 were not run; no deprecation was found in the pages read.

## EXPAND

- **LEAD: Gallery search behavior and filters.** Reason: no official behavioral spec found; only the visible search and filter UI.
- **LEAD: Commons AI entitlement.** Reason: the Commons docs and the July 2, 2026 blog conflict and were not reconciled; the newer blog is dated but the docs' update date is unknown.
- **LEAD: Plan entitlements for gallery submission and publisher links.** Reason: the pages describe workflows without a plan matrix.
- **LEAD: Current publisher partner roster.** Reason: the docs say integrations vary; the list linked from the 2016 blog was not fetched.
- **LEAD: Server Pro 6.3.0 server-side gallery search.** Reason: only an unofficial mirror was found; the official toolkit changelog was not confirmed to list it. Not used as a fact.
- **Closed:** gallery submission rules, update flow, Commons featuring, and Server Pro publishing were each confirmed on the primary page; no further duplicates.
