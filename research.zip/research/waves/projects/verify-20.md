# Verify angle 20: Sharing reusable templates, read-only copies, submission workflows

Checked 2026-10-26 against official docs.overleaf.com pages (fetched this pass). Upstream: harvest-20.md, expand-20.md. No authenticated tests, purchases, or workflow execution. Statements describe documented platform behavior, not functional execution or guarantees about arbitrary LaTeX.

**Verdict: PARTIAL.** Most platform claims are confirmed. One harvest claim is contradicted (public template publishing). Free-plan eligibility, per-publisher submission details, and a few Gallery exclusion items remain unresolved.

## Confirmed

- **Open as Template** creates an editable copy from a Gallery item. Source: [Creating a project from a template](https://docs.overleaf.com/templates/creating-a-project-from-a-template), step 3. No plan label on the page.
- **Link sharing.** Audiences are "Only invited people" or "Anyone with the link"; link permission defaults to Viewer, with Reviewer and Editor as options. Source: [Sharing a project](https://docs.overleaf.com/collaborating/sharing-a-project), "By Link."
- **Revocation and expiry.** Links do not expire; owners deactivate by switching back to "Only invited people." Source: same page, FAQ "Do share links expire?" and the revocation answer.
- **Public exposure.** A publicized link lets anyone view and download the project. Source: same page, "Are my Overleaf projects private?"
- **Premium collaborator limit.** Adding more than one editor or reviewer is a premium feature. Source: same FAQ. The premium table lists Free at 1 Editor/Reviewer and "unlimited" Viewers. Source: [Premium features](https://docs.overleaf.com/getting-started/free-and-premium-plans/premium-features), "Invite more collaborators."
- **Viewer link is live, read-only access.** Recipients can copy but not edit; changes to the project are immediately visible to link holders. Source: [Alternatives to templates](https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery/alternatives-to-templates), "Copying a project via a shared link" and its warning hint.
- **Copies.** Dashboard "More > Make a copy" and in-project "File > Make a copy." Source: [Copying a project](https://docs.overleaf.com/managing-projects-and-files/copying-a-project). Defaults: the copier owns it; collaborators, link sharing, history, Tracked Changes, comments, chat, and tags are not carried over; latest TeX Live is used. Older projects may not compile; the page points to a TeX Live switch. Plan requirements are not stated.
- **Gallery is curated.** Basic common-class templates are "rarely accepted"; CVs/resumes, PII beyond attribution, templates similar to existing ones, and incompatible-license files are excluded. Source: [Submitting to the Overleaf template gallery](https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery), "Templates suitable/not suitable."
- **Submit path and updates.** File or project-name menu, then Submit, then Overleaf Gallery. Edits to the original project do not affect the public template until resubmission is approved. Same page, "How to submit" and "How to update."
- **Not a course or preprint route.** Gallery submission does not submit homework to a course; preprints and completed works are not accepted. Source: Alternatives to templates, "Other submission types."
- **Publisher submission.** Official publisher templates from the Gallery create a submission link in the project menu; partner workflows vary, and each publisher has its own download/submit steps. Source: [Submitting to publishers](https://docs.overleaf.com/templates/submitting-to-publishers), "How to submit to a publisher" and "Submit modal."
- **Server Pro.** A single Template User publishes the curated local gallery; overleaf.com templates are transferred manually, with no automated integration. Source: [Server Pro templates](https://docs.overleaf.com/on-premises/configuration/overleaf-toolkit/server-pro-only-configuration/templates), "Publishing templates" and "Transferring templates from overleaf.com."

## Contradictions and corrections

- **Harvest, "Self-hosted availability":** says public publishing is "restricted to admins." The roles table contradicts this. Under "Manage template," Publish/Unpublish/Republish to the public gallery is **Yes for Template User and No for Admin**; Admin can publish privately only. Source: [Roles and permissions](https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions), "Manage template" and "Template Gallery." Expand-20 already states the correct reading. **Correction applied here.** Availability: Server Pro only.
- **Harvest, "Sharing":** says a Viewer link does not require an account. The sharing page states account authentication only for email invitations. It does not say whether link viewers need an account. **UNRESOLVED; not inferred.**
- **Harvest, "Gallery exclusions":** lists unofficial institutional/journal templates, incomplete work, limited-use templates, and promotions. I did not find these in the fetched text of the gallery page, so they are **not re-verified in this pass**.
- **Harvest, "Publisher submission":** says some integrations send files directly and others need manual upload. The page confirms variation by publisher but does not name direct-send versus manual per publisher. **PARTIAL.**

## Availability labels

- **Free:** Viewer link sharing and copying are not labeled by plan in the reviewed pages. Free accounts are limited to one Editor/Reviewer collaborator. Free eligibility for Gallery creation, copy, and publisher Submit is **UNRESOLVED**.
- **Premium:** more than one Editor/Reviewer collaborator. Unlimited Viewers are not a premium limit.
- **AI, Commons:** not relevant to this angle; the Commons note on the sharing page applies only to the collaborator limit. The July 2, 2026 AI bundling blog is out of scope here.
- **Community Edition:** no Template User role; no public gallery publishing role. Source: Roles and permissions, "Template Gallery" note.
- **Server Pro:** Template User role and local gallery publishing.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Open as Template creates an editable copy | Creating a project from a template | Not plan-labeled | Confirmed |
| Link audiences and Viewer default | Sharing a project, "By Link" | Viewers unlimited | Confirmed |
| Links never expire; revoke via Only invited people | Sharing a project, FAQ | Not plan-labeled | Confirmed |
| Publicized link allows view and download | Sharing a project, FAQ | Not plan-labeled | Confirmed |
| More than one Editor/Reviewer is premium | Sharing a project, FAQ; Premium features table | Free = 1 | Confirmed |
| Viewer link is copy-only, live source | Alternatives to templates | Not plan-labeled | Confirmed |
| Link viewers need no account | Harvest only | Unknown | UNRESOLVED |
| Copy defaults (owner, no collaborators, tags removed) | Copying a project | Plan not stated | Confirmed |
| Gallery curated; common classes rarely accepted | Submitting to the gallery | Not plan-labeled | Confirmed |
| Unofficial, incomplete, promo exclusions | Harvest only | Not plan-labeled | Not re-verified |
| Update via resubmit, approval required | Submitting to the gallery | Not plan-labeled | Confirmed |
| Gallery submission does not submit homework | Alternatives to templates | Not plan-labeled | Confirmed |
| Publisher submission link from official templates | Submitting to publishers | Partner-dependent | Confirmed |
| Per-publisher direct vs manual upload | Harvest only | Partner-dependent | PARTIAL |
| Public publishing: Template User only, not Admin | Roles and permissions | Server Pro | Confirmed (harvest corrected) |
| Server Pro manual transfer, no cloud integration | Server Pro templates | Server Pro | Confirmed |
| Template User absent in Community Edition | Roles and permissions | Community Edition | Confirmed |
| Free eligibility for Gallery / Submit | None | Unknown | UNRESOLVED |
| No deprecation notice for these workflows | Fetched pages only | N/A | Not found in reviewed pages |

## Counter-search queries (not run this pass)

- "Overleaf Free plan Open as Template copy eligibility"
- "Overleaf submit publisher partners list LaTeX template"
- "Overleaf anyone with link viewer account required"
- "Overleaf template gallery exclusion unofficial institutional template"

## EXPAND

- **LEAD: Free-plan eligibility for Gallery creation, copy, and publisher Submit.** Reason: no plan labels on the reviewed pages; resolve with a plan-comparison page search.
- **LEAD: whether link viewers need an Overleaf account.** Reason: the sharing guide is silent; resolve by checking the Share menu help or the Overleaf sharing FAQ.
- **LEAD: exact Gallery exclusion list (unofficial, incomplete, limited-use, promotional).** Reason: fetched text did not confirm these; re-fetch the full gallery submission page.
- **LEAD: per-publisher submission mechanics and roster.** Reason: publishers page says behavior varies and gives no list; search official partner pages.
- No EXPAND lead for Community Edition template publishing: the roles page documents that the Template User role is absent there.
