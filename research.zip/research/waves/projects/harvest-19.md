# Overleaf angle 19: Downloading source ZIP, PDF and generated output

Research date: October 26, 2026. Public official Overleaf documentation only; no authenticated use or functional execution tested.

## Source ZIP

For an open project, the current help article says to open the editor Menu and choose **Source** under Download; this downloads a `.zip` named after the project by default, subject to browser save settings. The ZIP contains project source files, not the typeset PDF. Official documentation defines source as text/graphics files needed to typeset the document. [Exporting your work from Overleaf — “Introduction,” “Downloading your current project as a .zip file”](https://www.overleaf.com/learn/how-to/Exporting_your_work_from_Overleaf%C2%A0), https://docs.overleaf.com/navigating-in-the-editor/generated-files (“Downloading generated files along with the source”).

Multiple-project download is documented from the projects dashboard: select projects and download one outer ZIP containing an individual ZIP for each project. [Exporting your work from Overleaf — “Quick guide,” “Downloading multiple projects as a .zip file”](https://www.overleaf.com/learn/how-to/Exporting_your_work_from_Overleaf%C2%A0). The standard source download reflects the current project version; to get an older version, History > All history > version menu > download that version, producing a project-files ZIP. [History and versioning — “Downloading an older version of your project”](https://docs.overleaf.com/writing-and-editing/history-and-versioning).

Important boundary: standard source ZIPs omit compile-generated files. If a same-named PDF was uploaded as a project file, it remains that uploaded source file and is not replaced with the newly compiled PDF; Overleaf says the compiled PDF is regenerated and separately downloadable. [Generated files — “Downloading generated files along with the source”](https://docs.overleaf.com/navigating-in-the-editor/generated-files); [Files that should not be included in a project — “Best practice: do not upload a copy of the compiled PDF”](https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project/files-that-should-not-be-included-in-a-project).

## Typeset PDF

The UI offers PDF download from the editor Menu or the PDF viewer’s download control near Recompile. The documented object is the typeset result, saved according to browser settings and normally named after the project. The output is the PDF produced by compiling the LaTeX sources; the separate PDF download presupposes successful compilation in the export guide. [Exporting your work from Overleaf — “Downloading the typeset PDF file”](https://www.overleaf.com/learn/how-to/Exporting_your_work_from_Overleaf%C2%A0). The PDF is not normally added to source files; an uploaded PDF is not overwritten. [Files that should not be included in a project — “Best practice: do not upload a copy of the compiled PDF”](https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project/files-that-should-not-be-included-in-a-project).

The docs say browser/editor access to `compiles.overleafusercontent.com` is needed to download PDF and log files; they suggest Browser PDF Viewer if the generated-PDF viewer is blank. [Resolving PDF rendering and project loading problems](https://docs.overleaf.com/troubleshooting-and-support/resolving-pdf-rendering-and-project-loading-problems). This is a documented access dependency, not a guarantee of success in every environment.

## Generated output and limits

Compiler artifacts such as `.aux`, `.log`, and `.toc` are accessed through **Logs and output files** > **Other logs and files**. The docs say users can download selected generated files or all generated files. For a bibliography artifact specifically, the UI lists `output.bbl` for individual download. [Generated files — opening paragraphs and “How to download a .bbl file”](https://docs.overleaf.com/navigating-in-the-editor/generated-files).

To bundle source plus generated output, use **File > Submit**, choose a journal/service, then **Download project ZIP with submission files**. Overleaf describes this as producing a submission-format ZIP (including `.bbl`/generated files), not submitting it automatically; the external-site step comes afterward. [Generated files — “Downloading generated files along with the source” and “How to submit to a journal or service”](https://docs.overleaf.com/navigating-in-the-editor/generated-files). This is a distinct export route from the ordinary source ZIP.

Generated auxiliary files are cached behind the scenes, not listed as project files; they can be regenerated on recompilation. Clearing cached files deletes them without recompiling; “Recompile from scratch” deletes them and immediately recompiles. [Clearing the project cache — opening paragraphs, “Recompile from scratch,” “Clear cached files”](https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache). These are LaTeX/compiler artifacts, not a promise that arbitrary package outputs or every tool’s intermediate products will always exist or be exportable. Features above are described in general editor documentation; plan-specific access, quotas, and availability on Community Edition or Server Pro are **UNRESOLVED** by the cited pages. These are Overleaf product workflows; arbitrary LaTeX can generate additional files, but that does not establish platform export support for them.

## EXPAND

- **LEAD (unresolved):** Whether generated-file download and submission ZIP workflows have plan or deployment-specific restrictions. Reason: current cited general docs do not state Free/premium, Commons, Server Pro, or Community Edition availability; no inference made.
- No other open lead: core source ZIP, PDF, individual/all generated output, and submission-bundle behavior is documented above.
