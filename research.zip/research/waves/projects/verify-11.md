# Verify 11: New projects, examples, copying, and ownership

Checked October 26-27, 2026 against docs.overleaf.com and overleaf.com primary pages. Platform project-management features only; no LaTeX capability claims, no authenticated tests, no purchases.

**Verdict: PARTIAL.** Core creation, copy, and ownership-transfer mechanics are confirmed by primary pages. Plan availability, upload limits, gallery submission rules, and legal ownership are not confirmed.

## Confirmed

- **New project menu** (Blank, Example, Upload, Import from GitHub). Blank asks for a name and opens a starter `.tex` file; Example opens a sample with a float image and basic bibliography. Source: https://docs.overleaf.com/getting-started/your-first-project, "Starting with a blank project" and "Starting with the example project." No plan gate is stated.
- **Template gallery copy**: New Project > Templates > document type > **Open as Template** creates the user's own editable copy. Source: https://docs.overleaf.com/templates/creating-a-project-from-a-template, steps 1-3. Some publisher templates are suitable for direct submission. No plan gate stated.
- **Copy a project**: Dashboard **More > Make a copy** or in-project **File > Make a copy**; user names the copy. Source: https://docs.overleaf.com/managing-projects-and-files/copying-a-project, "From the project dashboard" and "From within the project."
- **Copy defaults**: copy is owned by its creator (even when copying another user's shared project); collaborators, link sharing, history, Tracked Changes, comments, chat, and tags are not carried over; the copy uses the latest TeX Live. Source: same page, "Default settings of copied projects." Older projects may need an older TeX Live selected to compile. Availability: documented for regular users in the roles matrix (https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, "Project Dashboard" table); no hosted plan gate.
- **Share by link instead of gallery**: for a personal or small-audience template, share directly as Viewers with link sharing off. Source: https://docs.overleaf.com/templates/submitting-to-the-overleaf-template-gallery/alternatives-to-templates, "Copying a project via a shared link." Link edits are immediately visible to link holders (same page, warning hint).
- **Ownership transfer (hosted)**: only the owner can transfer, except managed-account projects. Share > permissions > **Make owner** > **Change owner**; the change is immediate. Source: https://docs.overleaf.com/collaborating/transferring-project-ownership, "How can I transfer the ownership of a project?"
- **Collaborator effect on transfer**: the plan table lists edit-collaborator capacity by plan (Free 1; Standard/Group Standard 10; Professional/Group Professional/Commons unlimited). Moving to a lower plan makes collaborators view-only. Source: same page, "Will transferring project ownership affect collaborator access?"
- **Licensing**: gallery items need clear license information; Overleaf recommends CC BY 4.0 for articles and examples and LPPL for templates, with any license permitted at its discretion. Source: https://docs.overleaf.com/templates/licensing-and-copyright, intro and recommendations.
- **Gallery exclusion of preprints**: preprints and completed works are not accepted. Source: alternatives-to-templates page, "Preprints or other completed works."
- **Self-hosted (Server Pro only)**: admin **Transfer Ownership** to any user, including non-collaborators; the previous owner becomes a read-write collaborator. Source: https://docs.overleaf.com/on-premises/user-and-project-management/project-management, "Transferring ownership of a project." Community Edition lacks this (roles page, Project Info table).
- **Server Pro Template User role**: publishing and unpublishing public templates is Server Pro-only; "Open as Template" and gallery listing are open to all users. Source: roles-and-permissions, "Manage template" and "Template Gallery" tables.
- **Managed accounts**: admins can delete a managed account and reassign its projects; managed users cannot delete their own account or change its email. Source: https://docs.overleaf.com/accounts-and-security/understanding-managed-accounts, "What's the difference..."
- **Commons ownership model**: users own their accounts and project data; the institution controls only administrative (entitlement) data. Users keep projects after leaving and drop to the free personal tier. Source: https://docs.overleaf.com/commons/data-ownership-and-user-accounts, "Overleaf accounts are owned by users" and "What happens when a user leaves the institution?"

## Corrections and contradictions

- **Commons IP wording**: the harvest says Commons "does not override" institutional IP policies. The page says the model "should not conflict with" them and advises institutions to capture outputs through their own mechanisms. Use the page's wording.
- **Commons URL**: the harvest's Commons link (`/commons/data-ownership-and-usage`) is a 404. The correct page is `/commons/data-ownership-and-user-accounts`.
- **Upload limits (harvest)**: the 50 MB, 180-file, 2,000-file, and 7 MB figures were not visible on the fetched upload page, which returned only a support form. They are **UNRESOLVED**, not confirmed.
- **AI blog date**: the July 2, 2026 date comes from the harvest, not the fetched body. The blog (https://cs.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans) says AI is included in all plans with plan-specific allowances, and its Commons AI tier is a separate subscription option. It uses "AI Assistant," not "AI Assist." AI is outside this angle; it does not change project creation or copy entitlements.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| New menu: Blank, Example, Upload, GitHub | docs.overleaf.com/getting-started/your-first-project | Hosted; plan gate not stated | Confirmed (menu partly from harvest; Blank/Example text fetched) |
| Gallery "Open as Template" makes own copy | docs.overleaf.com/templates/creating-a-project-from-a-template | Hosted; plan not stated | Confirmed |
| Copy via dashboard or File menu | docs.overleaf.com/managing-projects-and-files/copying-a-project | All users (roles table) | Confirmed |
| Copy owned by creator; collaborators/history/tags not carried | copying-a-project, "Default settings" | All users | Confirmed |
| Copy uses latest TeX Live; older version selectable | copying-a-project hint | All users | Confirmed |
| Share link or direct Viewer share instead of gallery | alternatives-to-templates | All users | Confirmed |
| Make owner / Change owner, immediate | transferring-project-ownership | Hosted owner | Confirmed |
| Collaborator edit limits by plan (1/10/unlimited) | transferring-project-ownership table | Free/Standard/Professional/Commons | Confirmed |
| Gallery licensing recommendations | docs.overleaf.com/templates/licensing-and-copyright | Gallery contributors | Confirmed |
| Preprints not accepted to gallery | alternatives-to-templates | Gallery | Confirmed |
| CV/resume and incomplete-work exclusions | Gallery submission page (not fetched) | Gallery | UNRESOLVED |
| Upload limits (50 MB, 180/2,000 files, 7 MB) | Upload guide (not visible) | Hosted | UNRESOLVED |
| Admin transfer to any user (Server Pro) | on-premises project-management | Server Pro only | Confirmed |
| Template User publishes gallery templates | roles-and-permissions | Server Pro only | Confirmed |
| Managed-account admin deletes and reassigns | understanding-managed-accounts | Managed/Professional groups | Confirmed |
| Non-destructive removal of managed users | Admin managed-user page (not fetched) | Group Professional | UNRESOLVED |
| Commons: users own accounts/data, keep on leaving | commons/data-ownership-and-user-accounts | Commons | Confirmed |
| Overleaf API can create projects from ZIP/files | docs alternatives-to-templates (API section) | API access; plan not stated | Partly confirmed (API mention only; no plan data) |
| Legal ownership (Terms "no ownership claim") | overleaf.com/legal (not fetched this pass) | All | UNRESOLVED |
| AI bundled in plans from July 2, 2026 | cs.overleaf.com blog | All plans, varying allowances | Content confirmed; date UNRESOLVED from body |

## Limitations

- Upload guide and gallery submission pages returned no body text in this pass.
- The legal Terms and the managed-user admin page were not re-read.
- No plan-by-plan availability matrix exists for New Project, copy, or gallery use in any fetched page.
- Only one search was run; the rest is primary-page checking.

## Counter-search queries (for follow-up)

- "Overleaf upload zip limit 180 files" (confirm upload limits on docs.overleaf.com)
- "Overleaf template gallery submission requirements CV resume exclusion"
- "Overleaf managed user non-destructive removal Group Professional"
- "overleaf.com legal terms managed accounts ownership of content"
- "Overleaf API create project from zip docs"

## EXPAND

- LEAD: Confirm upload limits from the live upload guide or docs mirror (`docs.overleaf.com` page for uploading). Reason: fetched page had no body.
- LEAD: Confirm gallery submission exclusions and republish rules on the submission page. Reason: not fetched.
- LEAD: Confirm managed-user removal vs. deletion from the group admin page. Reason: not fetched; only the user-side page was read.
- LEAD: Confirm Terms ownership wording and its managed-account clause. Reason: not fetched this pass.
- LEAD: Confirm the July 2, 2026 date for the AI bundling post from the post metadata. Reason: body has no date.
