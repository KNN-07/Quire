# Verify angle 15: Uploading images, binary assets, and external URL files

Checked October 26, 2026 against official docs.overleaf.com pages (fetched as markdown). Inputs: harvest-15.md and expand-15.md. No authenticated tests, purchases, or functional execution. No codebase edits.

**Verdict: PARTIAL.** Upload limits, the external-URL workflow, Google Drive refresh, cross-project linked files, and pasted-image behavior are confirmed. One harvest claim about raster size and compile time is not in the cited page and is corrected below. Plan or edition availability for URL import and the binary-type matrix remain UNRESOLVED.

## Confirmed findings

**Upload and limits.** The "Uploading multiple files" heading states a hard limit of 180 files per upload and 50 MB per upload. The "I am seeing a rate limit error" troubleshooting entry describes a dynamic throttle of roughly 200 files per 30 minutes. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project

**Plan limits.** The Plan limits table lists the same values for Free and Premium: 2000 files per project, 7 MB editable material per project, 2 MB per editable text file, and 50 MB per individual upload. Source: https://docs.overleaf.com/getting-started/free-and-premium-plans/plan-limits. Premium features in that table are compile timeout, history, track changes, and integrations. External-URL import is not listed there.

**Editable text.** The "I can't edit some of the files" entry says only common LaTeX extensions are editable online and text files over 2 MB cannot be edited online. Source: uploading-files-to-a-project page above.

**ZIP import.** The "Uploading large projects" heading says ZIPs should contain plain text and images in EPS, PDF, SVG, or PNG, with the 50 MB, 180-file, 2000-file, and 7 MB limits. Source: https://docs.overleaf.com/managing-projects-and-files/uploading-a-project. This is a ZIP-import guideline, not an upload allowlist.

**Pasted images.** Single images can be pasted; multiple-image paste is "not currently supported." Pasted images save as `.png` and can be named, placed in a folder, and given a caption, label, and width. `graphicx` must be loaded. Source: https://docs.overleaf.com/writing-and-editing/inserting-images/pasting-images-into-your-project

**Insert figure menu.** The menu offers Upload from computer, From project files, From another project, Select from output files, and From URL. Source: https://docs.overleaf.com/writing-and-editing/inserting-images/using-the-insert-figure-button. The page does not state plan gating for these options.

**External URL.** "From External URL" needs a direct download link. Sharing links that require login or lead to a landing page must be converted. The filename must not contain spaces. Organizational policies may block direct links, and host URL formats change. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/adding-a-file-from-a-url

**Google Drive.** Overleaf says it does not offer direct sync with Drive. An uploaded Drive file "can be refreshed at any time" to resync the latest version. The page documents the `resourcekey` URL form and says the procedure is not guaranteed for everyone. Source: https://docs.overleaf.com/integrations-and-add-ons/google-drive. No overwrite, conflict, or history semantics are stated.

**Cross-project linked files.** Files from "From Another Project" cannot be edited in the child project. They can be refreshed from the parent. Imported `.tex` files cannot be the child's main file. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/sharing-files-across-projects

**LaTeX image formats.** Under `latex`, only EPS works. Under `pdflatex`, JPG, PNG, PDF, and EPS work. The page recommends JPG for photos, PNG for diagrams and screenshots, and PDF or EPS for vectors. It states bitmaps stored in PDF or EPS take a lot of disk space. Source: https://docs.overleaf.com/writing-and-editing/inserting-images/advanced-latex-image-topics. These are LaTeX and compiler facts, separate from platform upload.

**Server Pro history.** Server Pro 3.5.0 (2023-02-13) states that Full Project History tracks changes in binary files, which the legacy system did not. The entry lists both Server Pro and Community Edition image IDs. It does not mention upload or URL import. Source: https://docs.overleaf.com/on-premises/release-notes/release-notes-3.x.x

## Corrections to upstream

- **Corrected:** The harvest says raster files over 1 MB may slow compiles and recommends resizing to about 1200 px. The cited LaTeX image page does not say this. It says bitmaps in PDF or EPS use a lot of disk space. Treat the 1 MB and 1200 px guidance as unsupported.
- **Clarified:** The harvest's "2 MB per individual text file recommendation" matches the plan table, which says to keep editable files at 2 MB or less.
- **Not re-verified:** The expand's claim about UTF-8 conversion of non-binary uploads comes from the file-encoding guide, which I did not fetch. Treat it as unverified.
- **Not re-verified:** The harvest's "Files that should not be included" guidance was not fetched. Treat it as unverified.

## Unresolved

- **Binary type matrix (UNRESOLVED).** No primary page lists every accepted binary type for ordinary upload or for each compiler.
- **URL import plan and edition availability (UNRESOLVED).** The URL and Insert Figure pages state no plan gate. Free, Premium, Commons, Server Pro, and Community Edition availability is not established.
- **Drive refresh mechanics (UNRESOLVED).** Overwrite, conflict, and version-history behavior are not documented.
- **AI bundling (not relevant).** No AI claims are made in this angle, so the July 2, 2026 AI bundling question was not investigated.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| 180 files and 50 MB per upload | uploading-files-to-a-project, "Uploading multiple files" | Free and Premium (per plan table) | CONFIRMED |
| About 200 files per 30 minutes throttle | uploading-files-to-a-project, rate-limit entry | Not plan-specific | CONFIRMED (described as dynamic) |
| 2000 files, 7 MB editable, 2 MB per editable text, 50 MB per upload | plan-limits | Free and Premium equal | CONFIRMED |
| Text over 2 MB not editable online | uploading-files-to-a-project, editable-files entry | Not plan-specific | CONFIRMED |
| ZIP content guidance (EPS, PDF, SVG, PNG) | uploading-a-project, "Uploading large projects" | Hosted ZIP import | CONFIRMED |
| Multiple-image paste not supported | pasting-images-into-your-project | Editor feature | CONFIRMED |
| Pasted image saved as PNG with caption, label, width | pasting-images-into-your-project | Editor feature | CONFIRMED |
| Insert Figure menu options incl. From URL and From another project | using-the-insert-figure-button | Editor feature; no plan gate stated | CONFIRMED (menu); PARTIAL (per-option flow) |
| Direct download link required for From External URL | adding-a-file-from-a-url | No plan gate stated | CONFIRMED |
| Drive file refreshable to latest version | google-drive | Google Drive integration | CONFIRMED; mechanics UNRESOLVED |
| Linked cross-project files read-only, refreshable, `.tex` not main file | sharing-files-across-projects | Not plan-specific | CONFIRMED |
| `latex` supports EPS only; `pdflatex` supports JPG/PNG/PDF/EPS | advanced-latex-image-topics | Compiler-dependent | CONFIRMED |
| 1 MB and 1200 px raster guidance | Harvest only | N/A | CONTRADICTED (not in cited page) |
| Full Project History tracks binary changes | release-notes-3.x.x, 3.5.0 | Server Pro and CE image IDs listed | CONFIRMED (history only; not upload or URL) |
| Binary type matrix | none | N/A | UNRESOLVED |
| URL import on Community Edition or Commons | none | N/A | UNRESOLVED |

## Counter-search queries

No web_search was run. Primary pages were opened directly. Queries to run next:

- `site:docs.overleaf.com "From External URL" plan`
- `site:docs.overleaf.com supported file types upload binary`
- `site:github.com/overleaf/overleaf "external url" upload`
- `site:docs.overleaf.com Google Drive refresh overwrite`

## EXPAND

- **LEAD: Accepted binary types for ordinary upload and each compiler.** UNRESOLVED. No official list was found. Would need the file-encoding page and any compiler-specific docs.
- **LEAD: Availability of From External URL on Free, Premium, Commons, Server Pro, and Community Edition.** UNRESOLVED. Would need plan-feature pages and the Server Pro/CE configuration docs.
- **LEAD: Drive refresh overwrite and conflict behavior.** UNRESOLVED. Would need Drive-specific troubleshooting or a product test, which is out of scope here.
