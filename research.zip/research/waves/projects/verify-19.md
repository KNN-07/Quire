# Overleaf angle 19 verification: Source ZIP, PDF, generated output

Research date: October 26, 2026. Public official sources only. No authenticated tests, purchases, or functional execution were performed.

## Verdict: PASS, with availability limits unresolved

Current documentation directly supports the core distinction: the ordinary project ZIP contains source files only; the compiled typeset PDF is downloaded separately, after successful compilation. Generated compiler files have separate download paths. The user-facing instructions have been updated since older menu documentation, so use current menu labels rather than treating historic wording as evidence of deprecation.

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Individual source ZIP contains source files, not the compiled PDF; File > Download as source (.zip) starts it. | https://docs.overleaf.com/managing-projects-and-files/downloading-a-project — “Downloading a project,” “How to download Overleaf projects,” “How to download an individual project as a .zip file” | Hosted product; docs do not specify plan. | CONFIRMED |
| Compiled PDF is a separate download from File menu or PDF viewer and requires successful compilation. | https://docs.overleaf.com/managing-projects-and-files/downloading-a-project — “How to download the PDF file”; also https://www.overleaf.com/learn/how-to/Exporting_your_work_from_Overleaf%C2%A0 — “Downloading the typeset PDF file” | Hosted product; free-use FAQ describes PDF downloads but no complete feature matrix. | CONFIRMED |
| Multiple selected projects download in an outer ZIP containing one ZIP per project. | https://docs.overleaf.com/managing-projects-and-files/downloading-a-project — “How to download multiple projects as a .zip file” | Hosted product; plan not specified. | CONFIRMED |
| Ordinary source ZIP excludes compile-generated artifacts; Logs and output files > Other logs and files allows selected or all generated files, including `output.bbl`. | https://docs.overleaf.com/navigating-in-the-editor/generated-files — “Downloading generated files along with the source,” “How to download a .bbl file” | Hosted product; plan/deployment availability not stated. | CONFIRMED |
| File > Submit can create a submission ZIP with `.bbl` and generated files; this prepares a ZIP and does not itself submit it externally. | https://docs.overleaf.com/navigating-in-the-editor/generated-files — “How to submit to a journal or service” | Hosted product; service/template-specific menu options; plan/deployment availability not stated. | CONFIRMED, with route limitations |
| Current source ZIP uses current project version; History > All history > version menu > Download this version gives an earlier-version ZIP. | https://docs.overleaf.com/writing-and-editing/history-and-versioning — “Downloading an older version of your project” | Hosted product; page documents free plan history visibility separately, but not a download entitlement matrix. | CONFIRMED |
| Cached auxiliary files are not project-tree files and may be regenerated; clear-cache and recompile-from-scratch actions differ. | https://docs.overleaf.com/troubleshooting-and-support/clearing-the-project-cache — opening section, “Recompile from scratch,” “Clear cached files” | Hosted product; plan not stated. | CONFIRMED |
| Access to `compiles.overleafusercontent.com` is required by the editor to download PDF and log files. | https://docs.overleaf.com/troubleshooting-and-support/resolving-pdf-rendering-and-project-loading-problems — “Things to try before contacting Overleaf” | Environment/network dependency, not a plan guarantee. | CONFIRMED |
| Generated-output UI and submission ZIP entitlement across Free, premium, Commons, Server Pro, and Community Edition. | General workflow docs above; https://docs.overleaf.com/getting-started/creating-an-account/getting-started-faq — “How do I save a new document I've created?” and “Is Overleaf free to use?” | FAQ places ordinary PDF/source download in general/free-use context. It does not establish all generated-file workflows or deployment parity. AI is not relevant to this angle. | UNRESOLVED |
| Server-side administrator export script is available for CE and Server Pro version 5.4.0, with user/project/all-user ZIP modes. | https://github.com/overleaf/overleaf/wiki/Data-and-Backups/eab831d3c4fb819199b29b99d87332dccb5faf4a — “Exporting users' projects” | Community Edition and Server Pro admin operation; distinct from end-user editor download, and not evidence of generated-output UI parity. | CONFIRMED |

## Corrections and boundaries

The harvest and expand reports are substantively accurate. Current docs refine the source/PDF labels to **File > Download as source (.zip)** and **Download as PDF**; older “Menu > Source/PDF” or “Download - Source/PDF” wording is legacy UI terminology, not evidence those capabilities were removed. The current docs page itself uses a page updated in 2026 and explicitly retains the paths.

An uploaded PDF remains a project source file and is not synonymous with the compiled PDF download. This distinction is described in the older official project-menu article: https://www.overleaf.com/learn/how-to/Using_the_Overleaf_project_menu — “Download - Source” and “Download - PDF” (the URL now redirects to the docs landing page; the wording is therefore dated and current status is not independently confirmed by that redirected page). Do not promise that every user-uploaded or arbitrary LaTeX-generated file is included in a particular export. The documented generated-file control concerns files produced by the compiler and exposed in the output panel; arbitrary LaTeX/package behavior is not itself an Overleaf export guarantee.

No deprecation notice for the ordinary source ZIP, PDF download, generated-file panel, or submission ZIP appeared in the current docs consulted. Submission menus can vary: the official arXiv checklist says a dedicated journal template may expose only that journal option; making a project copy can show all Submit options. Source: https://docs.overleaf.com/troubleshooting-and-support/checklist-for-arxiv-submissions — “Are you using the Overleaf Submit to arXiv feature?”

## Counter-search queries

- `site:docs.overleaf.com/navigating-in-the-editor/generated-files download generated files source ZIP`
- `site:docs.overleaf.com/managing-projects-and-files/downloading-a-project .bbl generated files Overleaf`
- `site:docs.overleaf.com "Download project ZIP with submission files" plan`
- `site:overleaf.com/plans download source PDF Free Overleaf generated files`
- `site:docs.overleaf.com "Download - Source" deprecated Overleaf`
- `site:github.com/overleaf/overleaf export-user-projects generated files download source zip`

Search results were opened against primary documentation and the official Overleaf GitHub wiki; snippets alone were not used as support.

## EXPAND

- **LEAD (UNRESOLVED):** Whether generated-file panel downloads and submission ZIPs have plan- or deployment-specific restrictions, including Commons, Server Pro, and Community Edition. Reason: current official end-user docs describe the workflow without an entitlement/deployment matrix. The CE/Server Pro administrator export script is a different operation and does not resolve UI parity.
- All other leads from the upstream reports are closed by the current official sources cited above; no additional open lead identified.
