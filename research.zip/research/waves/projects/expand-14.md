# Expand 14: Files and folders, renaming, moving, and deletion

Research date: 2026-10-26. Public official Overleaf sources only. No authenticated testing, no purchases. Availability labels (Free, premium, AI, Commons, Server Pro, Community Edition) are given only where the cited page states them; otherwise the label is "not labeled in pages reviewed."

## Verified findings

**Project-level rename.** Two routes: on the dashboard, select the project, then More > Rename; in the editor, click the project name and choose Rename. Only the project owner can rename. Source: https://docs.overleaf.com/managing-projects-and-files/renaming-a-project (headings "From the project dashboard", "From within the project"). Availability: not labeled.

**Project-level deletion.** Deletion is two steps: move the project to Trashed Projects, then delete it permanently from there. Trashing does not schedule automatic deletion and can be kept indefinitely. Permanent deletion has no undo and removes the project for collaborators. Owners can delete their own projects; for shared projects owned by someone else, the user can only archive, trash, or leave. Restore is available from Trashed Projects. Source: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project (headings "Trashed Projects", "How does trashing a project affect collaborators?", "How to restore a trashed project"). Availability: not labeled.

**Archive and Trash behavior (legacy-sensitive).** A blog post, which carries no date in the fetched text and describes the v2 dashboard change, says Archive and Trash both leave collaborators unaffected, that Archived Projects still holds older projects, and that archiving or trashing stops Dropbox sync for that user. Date tag: undated; treat as a dashboard-change announcement, not current-state documentation. Source: https://www.overleaf.com/blog/new-feature-using-archive-and-trash-to-keep-your-projects-organized.

**Deprecated model (date tag: older, undated in search snippet).** A search snippet from an older v2 announcement describes the replaced Deleted Projects folder (ShareLaTeX) and the separate Archive and Trash folders (Overleaf v1). It was seen only in the search snippet, not opened. Source: https://www.overleaf.com/blog/644-two-quick-updates-to-overleaf-v2-based-on-your-feedback.

**File and folder permissions.** The on-premises role matrix has a "Project & file operations" table: Owner and Editor can create, rename, delete, and move files; Reviewer and both Viewer roles cannot. Download and duplicate are open to all roles. This matrix is documented for Server Pro and Community Edition roles and is not a cloud-plan matrix. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions.

**File recovery (on-premises only).** The same matrix lists "Restore file or project from history" for Owner and Editor. The Admin Panel section lists "Deleted Docs: list and undelete" and is marked Server Pro only; Community Edition shows No. Source: same URL, headings "History" and "Manage Users -> Project -> Deleted Docs".

**Navigation scope.** The "Selecting and managing files" page covers the File Outline and file tree only; it does not document rename, move, or delete steps. Source: https://docs.overleaf.com/navigating-in-the-editor/selecting-and-managing-files.

**Upload and add-file entry points.** The "Adding files to a project" index lists upload, adding from a URL, sharing files across projects, and Git and Dropbox integrations. The page itself does not document folder operations. Source: https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project.

## Harvest claims not verified by this pass

- Upload limits (180 files, 50 MB) and "New folder" steps are cited in the harvest from the uploading-files page. I did not open that page; treat as unverified.
- Git limitations (a rename or move is delete plus create; folder rename leaves an empty folder; collision rejection) are cited to the advanced-git-operations page. I fetched that page and it contains only repository setup, submodules, and branch notes; the "Known limitations" section did not appear. These claims are unverified and need a re-fetch or a different source.
- "Dropbox sync is premium" and the Dropbox delete and rename behavior are cited to the Dropbox page. I did not open it; unverified.

## EXPAND

- **LEAD: direct in-editor rename, move, and delete steps for individual files and folders.** UNRESOLVED. No official usage page found in this pass; the permission matrix confirms capability only.
- **LEAD: folder move, rename, delete, and empty-folder behavior.** UNRESOLVED.
- **LEAD: upload limits and folder-upload behavior.** Harvest-cited; re-fetch https://docs.overleaf.com/managing-projects-and-files/adding-files-to-a-project/uploading-files-to-a-project to verify.
- **LEAD: Git rename and move limitations.** Harvest-cited; the fetched page lacks that section. Find the current section or the Git integration overview page.
- **LEAD: Dropbox premium status and rename/delete effects.** Harvest-cited; open the Dropbox page to verify.
- **LEAD: role matrix for hosted Free and premium plans.** UNRESOLVED; the matrix found is on-premises only.
- **LEAD: deleted-document recovery on hosted Overleaf.** UNRESOLVED; the Deleted Docs feature is documented only for Server Pro admins.
- **Adjacent, out of angle:** project copy, download, and tags (linked from the managing-projects index) were not researched here.
