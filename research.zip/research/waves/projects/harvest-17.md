# Overleaf Dashboard: search, sorting, labels, and bulk operations

Research checked October 26, 2026. Scope is the Overleaf project dashboard, not text search inside a LaTeX project. Sources below are public, official Overleaf documentation or Overleaf product posts. No account interaction or functional execution was performed.

## Search

The On-premises “Roles and permissions” page, under **Project Dashboard → Organizing and finding projects**, explicitly lists “Search for projects” for a regular user and says users may list owned and invited projects. It also lists filters for All, Your, Shared with you, Archived, and Trashed Projects. This is authoritative for the on-premises deployment’s listed user capabilities; it does not define the search matching rules (fields, case sensitivity, partial matching, or query syntax), nor does it establish current SaaS implementation details. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — headings **Project Dashboard**, **Organizing and finding projects**.

Do not conflate this with editor search: “Searching within a project” documents textual search across project files, not a Dashboard catalog search. It supports case-sensitive, regex, and whole-word options, but those belong to in-project search. Source: https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project — headings **Search and replace within the current file**, **Project-wide search**. The documentation states files over 2 MB are excluded from project-wide search results; that restriction is not evidence about Dashboard search.

## Sorting

**Current sort choices/order are UNRESOLVED.** The current official documentation reviewed lists search and filters but does not specify Dashboard sorting controls, sort keys, direction, or defaults. A dated legacy product post, **May 15, 2017**, says pagination controls were moved to the top of “My Projects” and users could sort projects and choose projects per page. It gives no sort fields and is too old to establish current availability or behavior. Source: https://www.overleaf.com/blog/503-overleaf-product-update-may-2017 — heading **My Projects Dashboard Pagination Controls** (legacy, 2017-05-15).

## Tags (Dashboard labels)

Current docs call these **tags**. Users can create a tag with a unique name and choose one of nine preset colors or a custom color via color map, HEX, or RGB. Clicking a tag in the dashboard’s tag list or beside a project title filters to projects carrying it. Sources: https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/creating-a-new-tag — **Creating a new tag**, **Viewing projects with a specific tag**; https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags — **Organizing projects with tags**.

To tag several projects, select their title checkboxes, click the Tag icon above the project list, then select one or more tags. Tag names/colors can be edited; deleting a tag removes the tag, not its projects. Sources: https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/adding-tags-to-your-projects — steps 1–3; https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/changing-the-name-or-color-of-a-tag — steps; https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/deleting-a-tag — **Deleting a tag**. Tagging is documented for desktop, laptop, or tablet; mobile phones are not supported for adding tags. Source: https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags — compatibility note. The on-premises permissions table lists these dashboard actions for User without distinguishing Server Pro from Community Edition; this is not a separate SaaS plan entitlement statement. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — **Organizing and finding projects**.

## Bulk operations and restrictions

The on-premises permissions table explicitly lists trashing/restoring multiple projects, downloading multiple projects as one ZIP, leaving multiple projects, and archiving multiple projects, alongside tagging multiple projects. Source: https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions — **Project management and collaboration**, **Organizing and finding projects**. Current dashboard instructions show checkboxes followed by Archive or Trash buttons for multiple selections, and Restore for multiple selections within Archived or Trashed Projects. Sources: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects — **How to archive or trash multiple projects**, **How to restore multiple projects**; https://docs.overleaf.com/managing-projects-and-files/downloading-a-project — **Downloading multiple projects as a single .zip file**.

Archiving hides projects from the main list without queuing deletion. Trashing is a separate step before permanent deletion or leaving; a user cannot permanently delete a project they do not own, and leaving a shared project is distinct from deleting it. Sources: https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects — **Archiving**, **Trashing**; https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project — **How does trashing a project affect collaborators?** The bulk-action docs do not state a maximum selection count.

Availability note: these features are not identified as Premium or AI features in the cited dashboard docs. Do not infer a Free-versus-paid distinction. The cited permissions table is explicitly for on-premises user permissions; it is not a complete Community Edition-versus-Server Pro feature matrix.

## EXPAND

- **LEAD — Current Dashboard sort fields, order, and default:** unresolved because current official dashboard docs reviewed do not describe sorting; the only direct product evidence found is dated 2017 and does not give sort fields.
- **LEAD — Dashboard search matching semantics:** unresolved because official permissions documentation confirms search exists but does not specify matching, query syntax, or result scope beyond owned/invited project listing.
- **LEAD — SaaS plan matrix for dashboard features:** unresolved because current official docs do not label these dashboard features by Free/Premium tier; on-premises permissions do not establish SaaS entitlements.
- **LEAD — Bulk selection limits:** unresolved because official bulk-operation instructions describe selection and actions but no numeric cap.
