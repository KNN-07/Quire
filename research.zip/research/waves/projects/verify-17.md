# Verify angle 17: Overleaf Dashboard search, sorting, labels, bulk operations

Checked: October 26, 2026. Method: opened primary Overleaf docs and blog pages; search snippets used only where noted. No authenticated testing, purchases, or functional execution.

## Verdict: PARTIAL

Tags (labels) and bulk archive/trash/restore/download are confirmed by primary docs. Dashboard search is confirmed only as a feature name. Sorting is unsupported: the 2017 blog cited upstream does not contain the sort/pagination text. Plan availability is unresolved.

## Findings

**Search.** The on-premises roles page lists "Search for projects" under Organizing and finding projects for a regular User (https://docs.overleaf.com/on-premises/user-and-project-management/roles-and-permissions, heading "Organizing and finding projects"). It does not define matching rules, fields, or query syntax. Separately, the admin table lists "Search projects" as Server Pro only under Manage Users > Projects. That is an admin feature, not the user dashboard. Editor search (https://docs.overleaf.com/navigating-in-the-editor/searching-within-a-project) is out of scope; I saw only a search snippet for it, not the full page.

**Sorting.** UNRESOLVED. I opened https://www.overleaf.com/blog/503-overleaf-product-update-may-2017 (dated May 15, 2017, legacy). It contains only a line saying more updates are coming. The upstream claim that users could sort projects and pick projects per page is **not supported by this page** and is marked CONTRADICTED by the fetched source. Third-party tools (netique/overleaf-mcp, Glama) say their list is "sorted by most recently updated," but they describe their own API, not Overleaf's UI. Overleaf issue #1101 (https://github.com/overleaf/overleaf/issues/1101, 2023, open) is a user request for a last-modified field and says the UI is "naturally ordered" by last modified. That is an unofficial, unverified observation, not a documented guarantee.

**Tags (labels).** Confirmed:
- Creating a tag, with nine preset colors or custom HEX/RGB, and viewing projects by clicking a tag (https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/creating-a-new-tag, headings "Creating a new tag" and "Viewing projects with a specific tag").
- Tagging multiple projects: tick the title boxes, click the Tag icon, select tags (https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags/adding-tags-to-your-projects, steps 1 to 3).
- Rename-of-tags naming history: the 2023 post says "Tags/Folders" became "Tags" with functionality unchanged, and tags are "purely for your personal use" (https://www.overleaf.com/blog/organizing-your-work-in-overleaf-just-got-easier-with-custom-colors-for-tags, 2023, legacy; the fetched text has no date, so the 2023-04-12 date is not verified here).
- Mobile phones are not supported for adding tags. This comes from a search snippet of https://docs.overleaf.com/managing-projects-and-files/organizing-projects-with-tags, not the full page.
- The 2013 ShareLaTeX-origin post (https://www.overleaf.com/blog/tag-and-search-your-latex-projects-2013-07-16, archival) described tag and name filtering via a search bar. The fetched text has no date. Treat as legacy.

**Bulk operations.** Confirmed:
- Archive or trash multiple: tick boxes, then the Archive or Trash button above the list (https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects, "How to archive or trash multiple projects").
- Restore multiple from Archived or Trashed pages (same page, "How to restore multiple projects").
- Permanently delete multiple, and the rule that you cannot delete shared projects you do not own (https://docs.overleaf.com/managing-projects-and-files/archiving-deleting-and-leaving-projects/deleting-a-project, "Permanently deleting multiple projects" and "How does trashing a project affect collaborators?").
- ZIP download of multiple projects: a top-right Download icon with selected checkboxes produces one ZIP containing a ZIP per project, named "Overleaf Projects (N items)" (https://docs.overleaf.com/managing-projects-and-files/downloading-a-project, "How to download multiple projects as a .zip file").
- Leave multiple projects and archive/tag/trash/restore/download are listed for User on the on-premises roles page. Leave on SaaS requires trashing first (archiving page, info hint).

**Corrections to upstream.** The upstream claim that leaving a shared project is "distinct from deleting" is correct, but the docs add that leaving also goes through Trashed Projects first. Archive is not a deletion queue (confirmed).

**Availability.** The cited dashboard docs and the on-premises User table do not label search, sort, tags, or bulk actions as Free, Premium, AI, Commons, Server Pro, or Community Edition. Plan availability is UNRESOLVED. I did not open the July 2, 2026 AI-bundling blog, because no cited dashboard feature depends on it.

## Claim table

| Claim | Source | Availability | Evidence status |
|---|---|---|---|
| Search for projects exists for User | on-prem roles page, "Organizing and finding projects" | On-prem; SaaS not stated | Confirmed (feature name only) |
| Search matching rules | none found | - | UNRESOLVED |
| Dashboard sort controls | 2017 blog (fetched) | Legacy | CONTRADICTED: text absent |
| Default sort is last-modified | GitHub issue #1101; third-party MCP | Unofficial | UNRESOLVED |
| Tags: nine colors, custom HEX/RGB | creating-a-new-tag | Not tiered | Confirmed |
| Click tag to filter | creating-a-new-tag | Not tiered | Confirmed |
| Tag multiple projects | adding-tags-to-your-projects | Not tiered | Confirmed |
| Tags not on mobile | organizing-projects-with-tags (snippet) | Not tiered | Snippet only |
| Tags/Folders renamed Tags (2023) | 2023 blog (legacy) | Legacy | Confirmed; date unverified |
| Archive/trash multiple | archiving-deleting-and-leaving-projects | Not tiered | Confirmed |
| Restore multiple | archiving-deleting-and-leaving-projects | Not tiered | Confirmed |
| Permanently delete multiple, owner-only | deleting-a-project | Not tiered | Confirmed |
| Multi-project ZIP download | downloading-a-project | Not tiered | Confirmed |
| Leave multiple | on-prem roles page | On-prem | Confirmed (on-prem only) |
| Bulk selection cap | none | - | UNRESOLVED |
| Free/Premium/AI tiering | none | - | UNRESOLVED |

## Counter-search queries

- "Overleaf dashboard sort by" (current docs, forum, and release notes)
- "site:docs.overleaf.com sort projects dashboard"
- "site:docs.overleaf.com deleting a tag" and "changing the name or color of a tag" (not fetched; unverified here)
- "site:overleaf.com/blog dashboard search projects 2025 2026"
- "site:github.com/overleaf/overleaf dashboard search sort projects"
- "Overleaf project list maximum selection bulk"

## EXPAND

- LEAD: Current dashboard sort fields and default order. Reason: no primary page found; 2017 claim contradicted.
- LEAD: Dashboard search matching rules and scope on SaaS. Reason: docs name the feature only.
- LEAD: Deleting-a-tag and tag-rename pages. Reason: cited upstream but not opened.
- LEAD: Plan tiering (Free/Premium/Server Pro/Community) for dashboard tags and bulk actions. Reason: no source assigns one.
- LEAD: Bulk selection limit. Reason: no cap documented.
- None: editor search (out of scope for this angle; belongs to a separate editor angle).
