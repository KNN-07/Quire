# Lead-verified supplementary functionality

Read on October 26, 2026. This supplements the sixty-angle graph; it is not a claim of runtime product testing.

## Conversion and interchange (angles 13, 19)
Overleaf documents Word/DOCX and Markdown import and Word/DOCX, Markdown and HTML export, using Pandoc. It warns that conversion does not preserve every LaTeX construct or complex layout. Retain source ZIP and PDF as the faithful source/output routes; do not claim exact Word round trips.
Source: https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files

## Central reference Library (angles 7, 45)
The reference Library belongs to an account rather than one project. It supports BibTeX/BibLaTeX data, forms and code, DOI entry, and .bib upload. Citing a Library reference copies the needed entry into a project .bib file. Do not describe this as a guaranteed continuous live link without a source proving update propagation.
Source: https://docs.overleaf.com/citing-and-references/library

## ReadCube reference integration (angles 44, 45)
The paid reference-manager integration supports bulk import into a refreshable read-only .bib file and individual citations through advanced reference search into an editable .bib file. Manual .bib upload remains the non-integration fallback. ReadCube documentation describes it as the enterprise version of Papers.
Source: https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md

## Limited offline editing (angles 41, 60)
The browser editor can tolerate a short disconnection on the current file: up to two minutes on Free and ten on premium plans. It then pauses editing. Reconnection normally syncs changes; conflicts can be previewed and saved as a new file. Switching files, compiling, comments and AI are unavailable offline. Restoring the original browser tab may recover unsynced text; simply reopening the project is not equivalent, and incognito lacks tab restoration.
Long-term offline work uses downloaded sources or premium Git/GitHub/Dropbox workflows and a separate local editor/compiler. This is not an offline Overleaf desktop application.
Source: https://docs.overleaf.com/writing-and-editing/working-offline

## Google Drive boundary (angles 15, 43, 60)
Overleaf explicitly does not offer direct Google Drive synchronization. Shared-file direct-download URLs can be imported through From External URL and manually refreshed. Do not list this beside GitHub or Dropbox as equivalent two-way native sync.
Source: https://docs.overleaf.com/integrations-and-add-ons/google-drive.md

## Labs (angles 1, 60)
Overleaf Labs is opt-in access to experiments that can change or disappear. Stable product availability must not be inferred from an experimental listing.
Source: https://docs.overleaf.com/accounts-and-security/overleaf-labs.md

## AI documentation freshness (angles 46, 49, 50, 51, 53)
The current parent AI page, current pricing and July 2, 2026 announcement agree that AI allowances are bundled by plan. Free and ordinary Commons exclude AI Assistant; the other listed plans have it. Some cached search descriptions still mention the old AI Assist add-on. Prefer the opened live source over those snippets.
The AI page also has an internal inconsistency: its introductory table lists Summarize and Explain, but its troubleshooting section says those named actions were removed and suggests other tools. Record them as removed named actions with a documentation conflict, not unqualified current features.
Sources:
- https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans
- https://docs.overleaf.com/integrations-and-add-ons/ai-features
- https://www.overleaf.com/user/subscription/plans

## Deployment distinction (angles 51, 57)
Server Pro is separately licensed from hosted Pro. Both self-hosted editions list full project history; do not apply hosted Free's retention limit to Community Edition. The comparison lists various review, admin, authentication, integration and isolated-compilation features only for Server Pro. Its phrase about easy internal collaboration is not evidence that Community Edition lacks all real-time coediting.
Source: https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition

## Lead closure
- L1 conversion: resolved by current conversion docs.
- L2 Library/ReadCube: resolved at feature-inventory level; automatic Library update propagation remains unasserted.
- L3 offline: resolved by detailed offline documentation.
- L4 AI removed tools: documented contradiction; retain caveat.
- L5 Labs: resolved as experimental category; no authenticated experiment list was inspected.
