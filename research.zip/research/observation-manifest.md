# Observation manifest

All observations below were read on October 26, 2026. Evidence layer: first-party public documentation, not authenticated runtime testing. Independence exception: product vendor primary documentation is the appropriate authority for stated functionality; multiple vendor pages are not independent organizations.

| ID | Source | Anchor / observation | Status |
|---|---|---|---|
| O1 | https://www.overleaf.com/blog/overleaf-ai-now-a-part-of-overleaf-plans | July 2, 2026; bundled AI allowances, AI Assistant excluded from Free and Commons | Read |
| O2 | https://docs.overleaf.com/integrations-and-add-ons/ai-features | AI allowance by plan; current locations and removed actions | Read; internal table/FAQ contradiction |
| O3 | https://www.overleaf.com/user/subscription/plans | Compare all features | Read; localized prices not used |
| O4 | https://docs.overleaf.com/llms.txt | Complete navigation: User docs, Groups, Commons, On-premises | Read for coverage discovery |
| O5 | https://docs.overleaf.com/managing-projects-and-files/importing-and-exporting-files | Importing / Exporting / Pandoc limitations | Read |
| O6 | https://docs.overleaf.com/citing-and-references/library | Account-level Library, DOI, BibTeX forms and project copies | Read |
| O7 | https://docs.overleaf.com/on-premises/welcome/server-pro-vs.-community-edition | Benefits tables and separate licensing | Read |
| O8 | https://docs.overleaf.com/on-premises/ | Trusted-user CE scope and Server Pro sandboxing | Read |
| O9 | https://docs.overleaf.com/writing-and-editing/working-offline | Brief offline current-file editing, limits, conflict handling and tab restoration | Read through webfetch |
| O10 | https://docs.overleaf.com/integrations-and-add-ons/reference-manager-integrations/readcube.md | Bulk read-only versus individual editable .bib imports | Read through webfetch |
| O11 | https://docs.overleaf.com/accounts-and-security/overleaf-labs.md | Optional experiments, not guaranteed stable functionality | Read through webfetch |
| O12 | https://docs.overleaf.com/integrations-and-add-ons/google-drive.md | No direct sync; shared external URL import and refresh | Read through webfetch |
| O13 | https://www.overleaf.com/for/enterprises/features | Benefits for Users: GitHub/Dropbox/Mendeley/Zotero row excluded from CE and Server Pro; Git included Server Pro only. Metrics for Server Pro still Coming Soon. | Lead directly reopened via web.run |

## Retrieval failures
- Query-string variant of pricing: timeout; resolved by canonical URL.
- Guessed on-premises overview paths: inaccessible; resolved from official navigation.
- Non-Markdown working-offline route: inaccessible; Markdown route queued.
