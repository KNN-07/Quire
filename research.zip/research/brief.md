# Overleaf functionality research brief

## Core question
What functionality does Overleaf publicly document, and what are the limitations and availability differences across hosted plans and self-hosted editions?

## Scope
Current documented functionality as of October 26, 2026, with explicitly dated legacy/deprecated entries. Cover authoring, project management, compilation, collaboration, integrations, AI, subscriptions, institutions, and deployment.
Exclude exhaustive enumeration of every LaTeX package, every template, undocumented private endpoints, procurement advice, and fabricated authenticated tests.

## Deliverable
lane: no-format (answered_by: request)
state: none
formats: post and durable Markdown inventory (answered_by: default)
destination: this thread and shared workspace (answered_by: request)
audience: reader seeking a comprehensive product functionality map (answered_by: request)
length: detailed inventory with concise front summary (answered_by: default)
template: readable feature taxonomy (answered_by: default)
Reference compare: not applicable; no visual reproduction requested.

## Components and owners
1. authoring: code and visual editor, math, tables, references, accessibility.
2. projects: project creation, templates, import/export, file management, organization.
3. compilation: engines, TeX Live, PDF, diagnostics, packages and limits.
4. collaboration: permissions, simultaneous editing, review, history, restoration.
5. integrations: Git/GitHub/Dropbox, reference managers, AI and publication.
6. administration: plans, accounts, organizations, privacy controls, self-hosting.

## Evidence policy
Primary official documentation is authoritative for product functionality, with a documented primary-source-only exception to independent-domain corroboration.
Compare product claims to dated release announcements and detailed docs; record conflicts and unresolved availability.
All lane results are candidates until their verifier counter-checks them and the lead inspects the combined inventory.
No benchmarks, legal assurances, or runtime acceptance claims without evidence.

## Topology and routing
Sixty angles, each harvest -> expand -> verify; six cluster runs, thirty nodes each before later amendments.
quick: bounded primary-document extraction and source checks.
unspecified-low: subscription/deployment/AI verification that requires interpreting overlapping current and legacy sources.
architect: slice and final reductions that resolve cross-axis duplication and contradictions.
Lead: independent source checks, final coverage audit, recordkeeping, final delivery.
No nested agents or recursive research protocols.
