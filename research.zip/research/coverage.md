# Research coverage

All entries start pending. Per-angle harvest, expand, and verify handoffs live under waves/<cluster>/.

## authoring
1. Code Editor syntax highlighting, autocomplete and linting
2. Visual Editor and source-mode interoperability
3. Editor navigation, outline, search and replace
4. Keyboard shortcuts, keybindings and editing preferences
5. Math insertion, equation editing and symbol palette
6. Tables, figures, image insertion and visual tools
7. Bibliography editing, citation insertion and cross-reference autocomplete
8. Spell checking, dictionaries and language settings
9. Accessibility, screen readers and tagged PDF workflows
10. Multilingual authoring, Unicode, fonts and right-to-left text

## projects
11. New projects, examples, copying and ownership
12. Template gallery, search, publishing and institutional templates
13. ZIP upload, importing existing projects and file limits
14. Files and folders, renaming, moving and deletion
15. Uploading images, binary assets and external URL files
16. Linked files between projects and refresh behavior
17. Dashboard search, sorting, labels and bulk operations
18. Archiving, trash, deletion and project recovery
19. Downloading source ZIP, PDF and generated output
20. Sharing reusable templates, read-only copies and submission workflows

## compilation
21. Compiler engines and main document selection
22. TeX Live versions, upgrades and reproducibility
23. Automatic/manual recompilation and compile modes
24. PDF viewer, SyncTeX, search, zoom and split layouts
25. Compile errors, warnings, logs and troubleshooting
26. Timeouts, resource limits and performance tuning
27. LaTeX packages, custom classes and local fonts
28. latexmkrc, build configuration and shell escape restrictions
29. Bibliography tools, BibTeX, biblatex and Biber builds
30. R knitr, PythonTeX, minted, plots and external tools

## collaboration
31. Real-time simultaneous editing and collaborator presence
32. Invitations, collaborator limits and project access
33. Link sharing, token access and read/edit permissions
34. Reviewer roles, comments, threads and resolution
35. Track Changes, accepting/rejecting edits and permissions
36. Chat, mentions, notifications and communication
37. History timeline, labels and retention windows
38. Version comparison, restore and deleted-file recovery
39. Project ownership transfer and leaving shared projects
40. Sharing security boundaries and collaborator premium inheritance

## integrations
41. Git bridge, authentication and offline workflows
42. GitHub synchronization, import/export and conflict handling
43. Dropbox synchronization and availability
44. Zotero and Mendeley reference-manager integrations
45. Reference search, citation discovery and bibliography refresh
46. AI Assistant, TeXGPT and project-aware chat
47. Error Assist and AI-assisted compilation debugging
48. AI table/equation generation and image input
49. Writefull language/rewrite/generation tools and Citation Reviewer
50. AI consent, controls, quotas and current versus legacy subscriptions

## administration
51. Free, Student, Standard and Pro feature entitlements
52. Group subscriptions, billing and license management
53. Overleaf Commons, institutional access and Commons AI
54. Accounts, email identities, ORCID and authentication
55. Managed users, SSO and organization administration
56. Privacy, data handling, security controls and export
57. Community Edition versus Server Pro feature differences
58. Self-host deployment, Toolkit, upgrades and backups
59. Self-host compile isolation, scaling, logging and monitoring
60. APIs, integrations, mobile/browser support and unsupported boundaries

## Verification rule
Each angle must have a verify file giving a verdict, primary-source URLs, availability caveats, and any unresolved evidence. An angle with missing documentation is unresolved, not a claimed feature.
