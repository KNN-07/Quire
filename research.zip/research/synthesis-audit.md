# Overleaf synthesis audit

**Audited:** `research/OVERLEAF-FUNCTIONALITY.md`, `research/summary.md`, `research/coverage.md`, `research/verification.md`, and the six specified `waves/*/slice.md` files.  
**Audit type:** Documentation-synthesis evidence audit, not functionality acceptance.

## Verdict

**FAIL — targeted corrections required before calling the synthesis fully auditable.** The inventory passes the requested structural checks: all sixty coverage angles occur exactly once in the report, source links are direct Markdown links, no citation-reference identifiers are used (so no reference-ID collision or missing definitions), and no draft-placeholder markers were found. The principal feature and entitlement claims are generally primary-cited and the source slices substantiate the important limits. However, angle 60 compresses multiple required operational/API limits into an incomplete boundary; and `summary.md` drops material conflict and limit disclosures present in the report/slices, including several called out for explicit comparison. These are synthesis gaps, not evidence that the underlying report's features are false.

## Check results

- **Angle coverage: PASS.** Parsed `coverage.md`'s numbered angle entries and the report's `### NN.` headings. Each value 01–60 appears once; no missing, extra, or duplicate numbered headings. Each heading title matches its corresponding coverage entry.
- **Citation integrity: PASS.** Report contains 189 Markdown links with HTTP(S) destinations. It uses no `[A-Z]N` reference IDs, hence has no reference-ID collisions or missing link definitions. Reused URLs are ordinary repeated inline citations, not collisions. The supplied slices support the report's key quantified, conditional, and deployment-scoped claims. Citations point to primary Overleaf documentation, product pages, announcements, or official repositories.
- **Placeholders: PASS.** No TODO, TBD, PLACEHOLDER, INSERT HERE, or FIXME markers found.
- **Summary stronger than report: PASS, with omissions.** No examined summary claim contradicts or materially exceeds the report. The summary is less complete: it omits conflicts and operating limits that the report/slices preserve. Fix the omissions below rather than strengthening summary claims.
- **Contradiction preservation: PARTIAL.** The report preserves the material Reviewer-link and link-joiner visibility conflicts (33), Unicode upload/edit boundary (10), Dropbox output conflict (43), AI reset and managed-account conflicts (49–50), SAML conflict (55), deployment/package uncertainty (22, 27, 28, 57–60), and not-yet-delivered metrics/API boundaries (59–60). The summary mentions only a subset; angle 60 in the report does not enumerate the concrete API exclusions as clearly as its administration slice.
- **Evidence/acceptance distinction: PASS.** The inventory defines support as documentation, not authenticated use; verification and all six slices likewise disclaim runtime tests. The inventory must not be presented as product functionality acceptance.

## Actionable FAIL findings

1. **`OVERLEAF-FUNCTIONALITY.md` — angle 60, “APIs, integrations, mobile/browser support and unsupported boundaries”: make the API limit explicit.** The current wording says Open in Overleaf and CLSI do not prove a general hosted API and that hosted terms restrict external processing-engine/API use, but does not name the boundary with the same specificity as the administration slice: distinguish snippet/HTTP(S) `.tex`/ZIP import and the CLSI JSON compilation interface from a general hosted account or compile-automation API, and state that the AUP restriction applies to external processing-engine/API use. The slice also says private/partner interfaces are unasserted. Retain that distinction; do not broaden this into a categorical claim that no API exists. Evidence: administration slice, angle 60 and [S53]/[S54] plus [S28] (as indexed there); inventory's own angle 60 citations are its `/devs`, CLSI, terms, browser, offline, and Labs links.
2. **`summary.md` — “Integrate and use AI”: restore the unresolved AI reset conflict.** Summary says quotas but omits the concrete disagreement between current documentation's 24-hour reset and marketing FAQ's “up to 72 hours.” Add a short unresolved-conflict clause with both sources, consistent with report angle 50 and the integrations/administration slices. Do not silently choose one.
3. **`summary.md` — “Collaborate and recover” / “Manage projects, references and publication files”: surface the Reviewer-link conflict.** Summary reports role distinctions but omits the angle-33 conflict: sharing documentation offers Reviewer links while Reviewer guidance says initial Reviewer assignment is named-collaborator-only. Add it as unresolved, not as supported or unavailable. Evidence: collaboration slice, angle 33; report angle 33.
4. **`summary.md` — “Write, typeset and navigate” and “Choose the operating model”: retain the search and file-size boundaries.** The summary says project search exists and that there are shared file limits, but omits that project search excludes files larger than 2 MB and that the 2 MB individual-text threshold is a keep-at-or-below recommendation/guaranteed-editability boundary with documented exceptions. Add both caveats, without describing 2 MB as a hard universal file ceiling. Evidence: authoring slice, angles 3 and 13; projects slice F13; report angles 03 and 13.
5. **`summary.md` — “Manage projects, references and publication files”: state the key source-export limitation concretely.** “Source ZIP is not a full history/settings/review-metadata backup” is present, but the self-hosted backup boundary is only described in this section in general terms and is not echoed in the summary. Clarify that configuration export is not project-data backup, and project ZIP export omits settings/history/collaborators/comments/tracked changes/chat; distinguish this from consistent operator backups. Evidence: administration slice, angles 56 and 58; report angles 19 and 58. This is a material backup limit, not a request to reproduce the whole backup procedure.

These are focused audit findings. Other unresolved caveats already honestly retained in the report are not FAILs and need not be “resolved” by speculation or new feature research.

## Sixty-angle coverage checklist

Titles below were compared directly with `coverage.md`; each corresponding report heading occurs exactly once.

- [x] 01 — Code Editor syntax highlighting, autocomplete and linting
- [x] 02 — Visual Editor and source-mode interoperability
- [x] 03 — Editor navigation, outline, search and replace
- [x] 04 — Keyboard shortcuts, keybindings and editing preferences
- [x] 05 — Math insertion, equation editing and symbol palette
- [x] 06 — Tables, figures, image insertion and visual tools
- [x] 07 — Bibliography editing, citation insertion and cross-reference autocomplete
- [x] 08 — Spell checking, dictionaries and language settings
- [x] 09 — Accessibility, screen readers and tagged PDF workflows
- [x] 10 — Multilingual authoring, Unicode, fonts and right-to-left text
- [x] 11 — New projects, examples, copying and ownership
- [x] 12 — Template gallery, search, publishing and institutional templates
- [x] 13 — ZIP upload, importing existing projects and file limits
- [x] 14 — Files and folders, renaming, moving and deletion
- [x] 15 — Uploading images, binary assets and external URL files
- [x] 16 — Linked files between projects and refresh behavior
- [x] 17 — Dashboard search, sorting, labels and bulk operations
- [x] 18 — Archiving, trash, deletion and project recovery
- [x] 19 — Downloading source ZIP, PDF and generated output
- [x] 20 — Sharing reusable templates, read-only copies and submission workflows
- [x] 21 — Compiler engines and main document selection
- [x] 22 — TeX Live versions, upgrades and reproducibility
- [x] 23 — Automatic/manual recompilation and compile modes
- [x] 24 — PDF viewer, SyncTeX, search, zoom and split layouts
- [x] 25 — Compile errors, warnings, logs and troubleshooting
- [x] 26 — Timeouts, resource limits and performance tuning
- [x] 27 — LaTeX packages, custom classes and local fonts
- [x] 28 — latexmkrc, build configuration and shell escape restrictions
- [x] 29 — Bibliography tools, BibTeX, biblatex and Biber builds
- [x] 30 — R knitr, PythonTeX, minted, plots and external tools
- [x] 31 — Real-time simultaneous editing and collaborator presence
- [x] 32 — Invitations, collaborator limits and project access
- [x] 33 — Link sharing, token access and read/edit permissions
- [x] 34 — Reviewer roles, comments, threads and resolution
- [x] 35 — Track Changes, accepting/rejecting edits and permissions
- [x] 36 — Chat, mentions, notifications and communication
- [x] 37 — History timeline, labels and retention windows
- [x] 38 — Version comparison, restore and deleted-file recovery
- [x] 39 — Project ownership transfer and leaving shared projects
- [x] 40 — Sharing security boundaries and collaborator premium inheritance
- [x] 41 — Git bridge, authentication and offline workflows
- [x] 42 — GitHub synchronization, import/export and conflict handling
- [x] 43 — Dropbox synchronization and availability
- [x] 44 — Zotero and Mendeley reference-manager integrations
- [x] 45 — Reference search, citation discovery and bibliography refresh
- [x] 46 — AI Assistant, TeXGPT and project-aware chat
- [x] 47 — Error Assist and AI-assisted compilation debugging
- [x] 48 — AI table/equation generation and image input
- [x] 49 — Writefull language/rewrite/generation tools and Citation Reviewer
- [x] 50 — AI consent, controls, quotas and current versus legacy subscriptions
- [x] 51 — Free, Student, Standard and Pro feature entitlements
- [x] 52 — Group subscriptions, billing and license management
- [x] 53 — Overleaf Commons, institutional access and Commons AI
- [x] 54 — Accounts, email identities, ORCID and authentication
- [x] 55 — Managed users, SSO and organization administration
- [x] 56 — Privacy, data handling, security controls and export
- [x] 57 — Community Edition versus Server Pro feature differences
- [x] 58 — Self-host deployment, Toolkit, upgrades and backups
- [x] 59 — Self-host compile isolation, scaling, logging and monitoring
- [x] 60 — APIs, integrations, mobile/browser support and unsupported boundaries

## Documentation PASS versus functionality acceptance

The report is a documentation-backed inventory with deliberate unknowns, not a runtime acceptance record. The coverage ledger and verification file describe source verification and visual report checks; they do not establish successful use of Overleaf accounts, project workflows, integrations, compilation, accessibility output, SSO, billing, deployment, backup/restore, metrics, or APIs. No runtime/account tests were requested or performed. Preserve this distinction in any downstream use.
