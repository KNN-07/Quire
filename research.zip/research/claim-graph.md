# Claim graph

## verified-claims
No high-risk claims released to final synthesis yet. Ordinary feature claims below have a primary-source-only exception: official product documentation describes the vendor's own functionality. "Supported" means documentation support, not a runtime test.

| claim_id | statement | risk tier | status | supporting observations | counter-search result | final synthesis location |
|---|---|---|---|---|---|---|
| C1 | AI is bundled by plan; Free/Commons omit AI Assistant | normal | supported | O1, O2, O3 | Current parent docs and pricing agree with July announcement; child metadata may lag | Integrations and AI |
| C2 | Summarize and Explain are no longer available as named actions | normal | partial | O2 | FAQ explicitly removes actions still listed in introductory table | Legacy and unresolved |
| C3 | DOCX/Markdown import and DOCX/Markdown/HTML export use Pandoc with fidelity limits | normal | supported | O5 | Direct current documentation contradicts older source-only-export assumptions | Projects and files |
| C4 | Central Library stores references independently of projects and copies cited data into project .bib | normal | supported | O6 | Direct documentation read; refresh/propagation details still need checking | References |
| C5 | Cloud Pro does not license Server Pro | normal | supported | O7 | Explicit current licensing distinction | Deployment differences |
| C6 | Community Edition and Server Pro both have full project history | normal | supported | O7 | Current comparison table; must not apply cloud Free retention to CE | Deployment differences |

## Final inventory claim coverage

Each row maps a final research area to its paragraph-level primary sources. Supported means the documented functionality and explicitly stated limits are evidenced; it does not turn unresolved details into facts or imply runtime testing. Detailed corrections and counter-checks are in the corresponding waves/<cluster>/verify files. A primary-source-only exception applies because the claims concern the vendor's own documented functionality.

| claim_id | statement | risk tier | status | primary sources | final synthesis location |
|---|---|---|---|---|---|
| A01 | Documentation inventory: Code Editor syntax highlighting, autocomplete and linting | normal | supported with explicit unresolved boundaries | S8, S9 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 01 |
| A02 | Documentation inventory: Visual Editor and source-mode interoperability | normal | supported with explicit unresolved boundaries | S8, S10 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 02 |
| A03 | Documentation inventory: Editor navigation, outline, search and replace | normal | supported with explicit unresolved boundaries | S11, S12 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 03 |
| A04 | Documentation inventory: Keyboard shortcuts, keybindings and editing preferences | normal | supported with explicit unresolved boundaries | S13, S14, S15 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 04 |
| A05 | Documentation inventory: Math insertion, equation editing and symbol palette | normal | supported with explicit unresolved boundaries | S16, S17, S7 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 05 |
| A06 | Documentation inventory: Tables, figures, image insertion and visual tools | normal | supported with explicit unresolved boundaries | S10, S18, S19 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 06 |
| A07 | Documentation inventory: Bibliography editing, citation insertion and cross-reference autocomplete | normal | supported with explicit unresolved boundaries | S20, S21 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 07 |
| A08 | Documentation inventory: Spell checking, dictionaries and language settings | normal | supported with explicit unresolved boundaries | S8, S22, S17 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 08 |
| A09 | Documentation inventory: Accessibility, screen readers and tagged PDF workflows | normal | supported with explicit unresolved boundaries | S23, S24 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 09 |
| A10 | Documentation inventory: Multilingual authoring, Unicode, fonts and right-to-left text | normal | supported with explicit unresolved boundaries | S25, S26, S27 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 10 |
| A11 | Documentation inventory: New projects, examples, copying and ownership | normal | supported with explicit unresolved boundaries | S28, S29 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 11 |
| A12 | Documentation inventory: Template gallery, search, publishing and institutional templates | normal | supported with explicit unresolved boundaries | S30, S31, S32 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 12 |
| A13 | Documentation inventory: ZIP upload, importing existing projects and file limits | normal | supported with explicit unresolved boundaries | S33, S34, S35, S4 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 13 |
| A14 | Documentation inventory: Files and folders, renaming, moving and deletion | normal | supported with explicit unresolved boundaries | S35, S36, S37 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 14 |
| A15 | Documentation inventory: Uploading images, binary assets and external URL files | normal | supported with explicit unresolved boundaries | S38, S39, S40 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 15 |
| A16 | Documentation inventory: Linked files between projects and refresh behavior | normal | supported with explicit unresolved boundaries | S41, S18 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 16 |
| A17 | Documentation inventory: Dashboard search, sorting, labels and bulk operations | normal | supported with explicit unresolved boundaries | S42, S43, S44 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 17 |
| A18 | Documentation inventory: Archiving, trash, deletion and project recovery | normal | supported with explicit unresolved boundaries | S43, S45, S46 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 18 |
| A19 | Documentation inventory: Downloading source ZIP, PDF and generated output | normal | supported with explicit unresolved boundaries | S44, S47, S34 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 19 |
| A20 | Documentation inventory: Sharing reusable templates, read-only copies and submission workflows | normal | supported with explicit unresolved boundaries | S48, S49, S50 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 20 |
| A21 | Documentation inventory: Compiler engines and main document selection | normal | supported with explicit unresolved boundaries | S51, S52 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 21 |
| A22 | Documentation inventory: TeX Live versions, upgrades and reproducibility | normal | supported with explicit unresolved boundaries | S53, S54, S55 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 22 |
| A23 | Documentation inventory: Automatic/manual recompilation and compile modes | normal | supported with explicit unresolved boundaries | S56, S57, S58 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 23 |
| A24 | Documentation inventory: PDF viewer, SyncTeX, search, zoom and split layouts | normal | supported with explicit unresolved boundaries | S59, S60, S61 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 24 |
| A25 | Documentation inventory: Compile errors, warnings, logs and troubleshooting | normal | supported with explicit unresolved boundaries | S62, S47, S63 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 25 |
| A26 | Documentation inventory: Timeouts, resource limits and performance tuning | normal | supported with explicit unresolved boundaries | S4, S64, S65 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 26 |
| A27 | Documentation inventory: LaTeX packages, custom classes and local fonts | normal | supported with explicit unresolved boundaries | S66, S67, S68 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 27 |
| A28 | Documentation inventory: latexmkrc, build configuration and shell escape restrictions | normal | supported with explicit unresolved boundaries | S69, S70, S71 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 28 |
| A29 | Documentation inventory: Bibliography tools, BibTeX, biblatex and Biber builds | normal | supported with explicit unresolved boundaries | S72, S73, S74 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 29 |
| A30 | Documentation inventory: R knitr, PythonTeX, minted, plots and external tools | normal | supported with explicit unresolved boundaries | S75, S76, S77, S78, S79 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 30 |
| A31 | Documentation inventory: Real-time simultaneous editing and collaborator presence | normal | supported with explicit unresolved boundaries | S80, S7 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 31 |
| A32 | Documentation inventory: Invitations, collaborator limits and project access | normal | supported with explicit unresolved boundaries | S50, S81, S3 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 32 |
| A33 | Documentation inventory: Link sharing, token access and read/edit permissions | normal | supported with explicit unresolved boundaries | S50, S82, S83 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 33 |
| A34 | Documentation inventory: Reviewer roles, comments, threads and resolution | normal | supported with explicit unresolved boundaries | S82, S84, S37 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 34 |
| A35 | Documentation inventory: Track Changes, accepting/rejecting edits and permissions | normal | supported with explicit unresolved boundaries | S85, S50, S3 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 35 |
| A36 | Documentation inventory: Chat, mentions, notifications and communication | normal | supported with explicit unresolved boundaries | S80, S84, S86 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 36 |
| A37 | Documentation inventory: History timeline, labels and retention windows | normal | supported with explicit unresolved boundaries | S87, S7 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 37 |
| A38 | Documentation inventory: Version comparison, restore and deleted-file recovery | normal | supported with explicit unresolved boundaries | S87, S88 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 38 |
| A39 | Documentation inventory: Project ownership transfer and leaving shared projects | normal | supported with explicit unresolved boundaries | S89, S45, S46 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 39 |
| A40 | Documentation inventory: Sharing security boundaries and collaborator premium inheritance | normal | supported with explicit unresolved boundaries | S3, S90, S50 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 40 |
| A41 | Documentation inventory: Git bridge, authentication and offline workflows | normal | supported with explicit unresolved boundaries | S91, S3, S92, S93 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 41 |
| A42 | Documentation inventory: GitHub synchronization, import/export and conflict handling | normal | supported with explicit unresolved boundaries | S94, S1 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 42 |
| A43 | Documentation inventory: Dropbox synchronization and availability | normal | supported with explicit unresolved boundaries | S95, S96, S1 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 43 |
| A44 | Documentation inventory: Zotero and Mendeley reference-manager integrations | normal | supported with explicit unresolved boundaries | S97, S98, S99, S1 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 44 |
| A45 | Documentation inventory: Reference search, citation discovery and bibliography refresh | normal | supported with explicit unresolved boundaries | S20, S100, S21 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 45 |
| A46 | Documentation inventory: AI Assistant, TeXGPT and project-aware chat | normal | supported with explicit unresolved boundaries | S101, S17, S5 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 46 |
| A47 | Documentation inventory: Error Assist and AI-assisted compilation debugging | normal | supported with explicit unresolved boundaries | S63, S17 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 47 |
| A48 | Documentation inventory: AI table/equation generation and image input | normal | supported with explicit unresolved boundaries | S17, S102 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 48 |
| A49 | Documentation inventory: Writefull language/rewrite/generation tools and Citation Reviewer | normal | supported with explicit unresolved boundaries | S17, S101 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 49 |
| A50 | Documentation inventory: AI consent, controls, quotas and current versus legacy subscriptions | normal | supported with explicit unresolved boundaries | S17, S86, S103, S5 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 50 |
| A51 | Documentation inventory: Free, Student, Standard and Pro feature entitlements | normal | supported with explicit unresolved boundaries | S2, S3, S4 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 51 |
| A52 | Documentation inventory: Group subscriptions, billing and license management | normal | supported with explicit unresolved boundaries | S104, S105, S106, S107 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 52 |
| A53 | Documentation inventory: Overleaf Commons, institutional access and Commons AI | normal | supported with explicit unresolved boundaries | S108, S109, S110, S5 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 53 |
| A54 | Documentation inventory: Accounts, email identities, ORCID and authentication | normal | supported with explicit unresolved boundaries | S111, S112, S113 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 54 |
| A55 | Documentation inventory: Managed users, SSO and organization administration | normal | supported with explicit unresolved boundaries | S114, S115, S116, S86 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 55 |
| A56 | Documentation inventory: Privacy, data handling, security controls and export | normal | supported with explicit unresolved boundaries | S117, S118, S119, S120 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 56 |
| A57 | Documentation inventory: Community Edition versus Server Pro feature differences | normal | supported with explicit unresolved boundaries | S7, S1, S121 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 57 |
| A58 | Documentation inventory: Self-host deployment, Toolkit, upgrades and backups | normal | supported with explicit unresolved boundaries | S122, S123, S124, S125, S126 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 58 |
| A59 | Documentation inventory: Self-host compile isolation, scaling, logging and monitoring | normal | supported with explicit unresolved boundaries | S55, S127, S128, S1 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 59 |
| A60 | Documentation inventory: APIs, integrations, mobile/browser support and unsupported boundaries | normal | supported with explicit unresolved boundaries | S129, S130, S117, S131, S93, S132 (source-index.md) | OVERLEAF-FUNCTIONALITY.md section 60 |
